function outputFiles = plot_chapter6_G2_G3_symmetry_comparison(dataLocation)
%PLOT_CHAPTER6_G2_G3_SYMMETRY_COMPARISON
% Reproduce the two-panel Chapter 6 comparison of Delta T_G2 and Delta T_G3.
%
% Left panel:
%   N=2, same-sign symmetric array: N=2,sys,g=0.3
% Right panel:
%   N=2, mixed-sign barrier-well dimer: N=2,asys,g=0.3,-0.3
%
% The script reads only the primary scan_summary.csv files and deliberately
% excludes all results_replot_v1.3.0 subfolders.
%
% USAGE
%   plot_chapter6_G2_G3_symmetry_comparison
%   plot_chapter6_G2_G3_symmetry_comparison( ...
%       'C:\path\chapter6数据.zip')
%   plot_chapter6_G2_G3_symmetry_comparison( ...
%       'C:\path\chapter6数据')
%
% For the no-input form, place chapter6数据.zip or the extracted
% chapter6数据 folder next to this file. The function exports PNG, vector
% PDF, and editable MATLAB FIG files next to this script.

    if nargin < 1
        dataLocation = "";
    end

    scriptDir = fileparts(mfilename('fullpath'));
    dataRoot = resolveDataRoot(string(dataLocation), scriptDir);

    sameSignFile = fullfile(dataRoot, ...
        'N=2,sys,g=0.3', 'scan_summary.csv');
    mixedSignFile = fullfile(dataRoot, ...
        'N=2,asys,g=0.3,-0.3', 'scan_summary.csv');

    sameSign = readG2G3Data(sameSignFile);
    mixedSign = readG2G3Data(mixedSignFile);

    blue = [0.03, 0.06, 0.72];
    red = [0.80, 0.03, 0.02];
    chineseFont = chooseChineseFont();

    fig = figure( ...
        'Color', 'w', ...
        'Position', [60, 80, 1760, 740], ...
        'Renderer', 'painters');

    layout = tiledlayout(fig, 1, 2, ...
        'TileSpacing', 'compact', ...
        'Padding', 'compact');

    ax1 = nexttile(layout, 1);
    plotPanel(ax1, sameSign, blue, red);
    title(ax1, 'N = 2 same-sign', ...
        'Interpreter', 'none', ...
        'FontName', chineseFont, ...
        'FontSize', 24, ...
        'FontWeight', 'normal');
    xlim(ax1, [0.24, 1.10]);
    ylim(ax1, [-0.12, 0.02]);
    xticks(ax1, [0.4, 0.6, 0.8, 1.0]);
    yticks(ax1, [-0.10, -0.05, 0]);
    yticklabels(ax1, {'$-0.1$', '$-5\times10^{-2}$', '$0$'});

    ax2 = nexttile(layout, 2);
    plotPanel(ax2, mixedSign, blue, red);
    title(ax2, 'N = 2 mixed-sign barrier–well dimer', ...
        'Interpreter', 'none', ...
        'FontName', chineseFont, ...
        'FontSize', 24, ...
        'FontWeight', 'normal');
    xlim(ax2, [0.24, 1.10]);
    ylim(ax2, [-0.05, 0.025]);
    xticks(ax2, [0.4, 0.6, 0.8, 1.0]);
    yticks(ax2, [-0.04, -0.02, 0, 0.02]);
    yticklabels(ax2, { ...
        '$-4\times10^{-2}$', ...
        '$-2\times10^{-2}$', ...
        '$0$', ...
        '$2\times10^{-2}$'});

    drawnow;

    outputBase = string(fullfile(scriptDir, ...
        'chapter6_G2_G3_symmetry_comparison'));
    pngFile = outputBase + ".png";
    pdfFile = outputBase + ".pdf";
    figFile = outputBase + ".fig";

    exportgraphics(fig, pngFile, 'Resolution', 400);
    exportgraphics(fig, pdfFile, 'ContentType', 'vector');
    savefig(fig, figFile);

    outputFiles = struct( ...
        'png', char(pngFile), ...
        'pdf', char(pdfFile), ...
        'fig', char(figFile), ...
        'dataRoot', char(dataRoot));

    fprintf('Created:\n  %s\n  %s\n  %s\n', ...
        outputFiles.png, outputFiles.pdf, outputFiles.fig);
end

function plotPanel(ax, data, blue, red)
    hold(ax, 'on');

    plot(ax, data.energy, data.G2DeltaT, ...
        '-', ...
        'Color', blue, ...
        'LineWidth', 2.8, ...
        'DisplayName', '$G_2$');

    plot(ax, data.energy, data.G3DeltaT, ...
        '--', ...
        'Color', red, ...
        'LineWidth', 2.8, ...
        'DisplayName', '$G_3$');

    grid(ax, 'on');
    box(ax, 'on');

    ax.FontName = 'Times New Roman';
    ax.FontSize = 16;
    ax.LineWidth = 1.0;
    ax.TickDir = 'in';
    ax.TickLabelInterpreter = 'latex';
    ax.GridColor = [0.78, 0.78, 0.78];
    ax.GridAlpha = 0.42;
    ax.MinorGridAlpha = 0.16;
    ax.Layer = 'top';

    xlabel(ax, '$E=p^0$', ...
        'Interpreter', 'latex', ...
        'FontSize', 22);
    ylabel(ax, '$\Delta T_{G_j}$', ...
        'Interpreter', 'latex', ...
        'FontSize', 22);

    legend(ax, ...
        'Interpreter', 'latex', ...
        'Location', 'northeast', ...
        'FontSize', 17, ...
        'Box', 'off');

    hold(ax, 'off');
end

function data = readG2G3Data(scanFile)
    if ~isfile(scanFile)
        error('Chapter6Plot:MissingScanFile', ...
            'Could not find the production scan file:\n%s', scanFile);
    end

    scan = readtable(scanFile, 'VariableNamingRule', 'preserve');
    energy = readNumericColumn(scan, 'externalEnergy', scanFile);
    G2DeltaT = readNumericColumn(scan, 'G2DeltaTLeft', scanFile);
    G3DeltaT = readNumericColumn(scan, 'G3DeltaTLeft', scanFile);

    keep = isfinite(energy) & isfinite(G2DeltaT) & isfinite(G3DeltaT);
    energy = energy(keep);
    G2DeltaT = G2DeltaT(keep);
    G3DeltaT = G3DeltaT(keep);

    [energy, order] = sort(energy);

    data = struct( ...
        'energy', energy, ...
        'G2DeltaT', G2DeltaT(order), ...
        'G3DeltaT', G3DeltaT(order));
end

function dataRoot = resolveDataRoot(dataLocation, scriptDir)
    if strlength(dataLocation) == 0
        candidateFolders = [ ...
            string(fullfile(scriptDir, 'chapter6数据')); ...
            string(fullfile(pwd, 'chapter6数据'))];
        candidateArchives = [ ...
            string(fullfile(scriptDir, 'chapter6数据.zip')); ...
            string(fullfile(pwd, 'chapter6数据.zip'))];

        for k = 1:numel(candidateFolders)
            if isfolder(candidateFolders(k))
                dataRoot = candidateFolders(k);
                return;
            end
        end

        for k = 1:numel(candidateArchives)
            if isfile(candidateArchives(k))
                dataRoot = unpackArchive(candidateArchives(k));
                return;
            end
        end

        error('Chapter6Plot:DataNotFound', ...
            ['No chapter6数据 folder or chapter6数据.zip archive was found. ', ...
             'Pass its full path as the function input.']);
    end

    if isfile(dataLocation)
        [~, ~, extension] = fileparts(dataLocation);
        if strcmpi(extension, '.zip')
            dataRoot = unpackArchive(dataLocation);
            return;
        end
        error('Chapter6Plot:UnsupportedFile', ...
            'The input file must be chapter6数据.zip, not:\n%s', dataLocation);
    end

    if isfolder(dataLocation)
        nestedRoot = fullfile(dataLocation, 'chapter6数据');
        if isfolder(nestedRoot)
            dataRoot = nestedRoot;
        else
            dataRoot = dataLocation;
        end
        return;
    end

    error('Chapter6Plot:InvalidDataLocation', ...
        'The supplied data location does not exist:\n%s', dataLocation);
end

function dataRoot = unpackArchive(archivePath)
    extractionRoot = fullfile(fileparts(archivePath), ...
        'chapter6_data_extracted');
    dataRoot = fullfile(extractionRoot, 'chapter6数据');

    if isfolder(dataRoot)
        return;
    end

    if ~isfolder(extractionRoot)
        mkdir(extractionRoot);
    end

    unzip(archivePath, extractionRoot);

    if ~isfolder(dataRoot)
        error('Chapter6Plot:ArchiveLayout', ...
            ['The archive was unpacked but the expected chapter6数据 ', ...
             'folder was not found in:\n%s'], extractionRoot);
    end
end

function values = readNumericColumn(scan, columnName, scanFile)
    if ~ismember(columnName, scan.Properties.VariableNames)
        error('Chapter6Plot:MissingColumn', ...
            'The column "%s" is missing from:\n%s', columnName, scanFile);
    end

    values = scan.(columnName);
    if ~isnumeric(values)
        error('Chapter6Plot:NonNumericColumn', ...
            'The column "%s" is not numeric in:\n%s', columnName, scanFile);
    end

    values = double(values(:));
end

function fontName = chooseChineseFont()
    preferredFonts = { ...
        'Microsoft YaHei', ...
        'Microsoft YaHei UI', ...
        'SimHei', ...
        'Noto Sans CJK SC', ...
        'PingFang SC', ...
        'Arial Unicode MS'};

    installedFonts = listfonts;
    fontName = 'Helvetica';

    for k = 1:numel(preferredFonts)
        if any(strcmpi(installedFonts, preferredFonts{k}))
            fontName = preferredFonts{k};
            return;
        end
    end
end
