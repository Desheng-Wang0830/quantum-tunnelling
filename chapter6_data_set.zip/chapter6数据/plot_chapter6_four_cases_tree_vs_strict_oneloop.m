function outputFiles = plot_chapter6_four_cases_tree_vs_strict_oneloop(dataLocation)
%PLOT_CHAPTER6_FOUR_CASES_TREE_VS_STRICT_ONELOOP
% Overlay the four Chapter 6 production cases on one transmission plot.
%
% Solid line  : tree-level transmission T0Left.
% Dashed line : strict-O(mu^2) corrected transmission TLeftStrictOmu2
%               (= T0Left + totalDeltaTLeft).
%
% The four cases are read only from the primary scan_summary.csv files:
%   N=1,g=0.3
%   N=2,sys,g=0.3
%   N=3,g=0.3
%   N=2,asys,g=0.3,-0.3
% This deliberately excludes all results_replot_v1.3.0 folders.
%
% USAGE
%   plot_chapter6_four_cases_tree_vs_strict_oneloop
%   plot_chapter6_four_cases_tree_vs_strict_oneloop('C:\path\chapter6数据.zip')
%   plot_chapter6_four_cases_tree_vs_strict_oneloop('C:\path\chapter6数据')
%
% Place chapter6数据.zip next to this script for the no-input form.  The
% script will unpack it once into chapter6_data_extracted.  It exports PNG,
% vector PDF, and MATLAB FIG files next to this script.

    if nargin < 1
        dataLocation = "";
    end

    scriptDir = fileparts(mfilename('fullpath'));
    dataRoot = resolveDataRoot(string(dataLocation), scriptDir);

    caseFolders = [ ...
        "N=1,g=0.3", ...
        "N=2,sys,g=0.3", ...
        "N=3,g=0.3", ...
        "N=2,asys,g=0.3,-0.3"];

    caseLabels = { ...
        '$N=1$', ...
        '$N=2$, same sign', ...
        '$N=3$, same sign', ...
        '$N=2$, mixed sign'};

    % Dark, print-safe colour families.  In particular, the symmetric N=2
    % case is ochre/yellow for both of its curves.
    caseColours = [ ...
        0.10, 0.10, 0.10;  % N=1: charcoal
        0.80, 0.52, 0.03;  % N=2 same-sign: deep yellow/ochre
        0.72, 0.10, 0.12;  % N=3 same-sign: dark red
        0.00, 0.42, 0.38]; % N=2 mixed-sign: dark teal-green

    fig = figure( ...
        'Color', 'w', ...
        'Position', [120, 100, 1180, 690], ...
        'Renderer', 'painters');
    ax = axes(fig);
    hold(ax, 'on');

    treeHandles = gobjects(numel(caseFolders), 1);
    allTransmission = [];

    for k = 1:numel(caseFolders)
        scanFile = fullfile(dataRoot, caseFolders(k), 'scan_summary.csv');
        if ~isfile(scanFile)
            error('Chapter6Plot:MissingScanFile', ...
                'Could not find the production scan file:\n%s', scanFile);
        end

        scan = readtable(scanFile, 'VariableNamingRule', 'preserve');
        energy = readNumericColumn(scan, 'externalEnergy', scanFile);
        treeTransmission = readNumericColumn(scan, 'T0Left', scanFile);

        if ismember('TLeftStrictOmu2', scan.Properties.VariableNames)
            correctedTransmission = readNumericColumn( ...
                scan, 'TLeftStrictOmu2', scanFile);
        else
            % Backward-compatible reconstruction for older export files.
            correctedTransmission = treeTransmission + readNumericColumn( ...
                scan, 'totalDeltaTLeft', scanFile);
        end

        keep = isfinite(energy) & isfinite(treeTransmission) ...
             & isfinite(correctedTransmission);
        energy = energy(keep);
        treeTransmission = treeTransmission(keep);
        correctedTransmission = correctedTransmission(keep);

        [energy, order] = sort(energy);
        treeTransmission = treeTransmission(order);
        correctedTransmission = correctedTransmission(order);

        treeHandles(k) = plot(ax, energy, treeTransmission, ...
            '-', ...
            'Color', caseColours(k, :), ...
            'LineWidth', 2.75, ...
            'DisplayName', caseLabels{k});

        plot(ax, energy, correctedTransmission, ...
            '--', ...
            'Color', caseColours(k, :), ...
            'LineWidth', 2.15, ...
            'HandleVisibility', 'off');

        allTransmission = [allTransmission; treeTransmission; correctedTransmission]; %#ok<AGROW>
    end

    % Two neutral proxy lines explain the solid/dashed convention without
    % duplicating all four colour labels in the legend.
    styleTree = plot(ax, nan, nan, 'k-', 'LineWidth', 2.75, ...
        'DisplayName', 'solid: $T_0$');
    styleCorrected = plot(ax, nan, nan, 'k--', 'LineWidth', 2.15, ...
        'DisplayName', 'dashed: $T_0+\Delta T$');

    transmissionRange = max(allTransmission) - min(allTransmission);
    padding = max(0.025, 0.06 * transmissionRange);
    yLower = min(0, min(allTransmission) - padding);
    yUpper = max(1.02, max(allTransmission) + padding);

    xlim(ax, [0.24, 1.10]);
    ylim(ax, [yLower, yUpper]);
    grid(ax, 'on');
    grid(ax, 'minor');
    box(ax, 'on');

    ax.FontName = 'Times New Roman';
    ax.FontSize = 15;
    ax.LineWidth = 1.0;
    ax.TickLabelInterpreter = 'latex';
    ax.GridAlpha = 0.20;
    ax.MinorGridAlpha = 0.10;

    xlabel(ax, 'External energy $E=p^0$', ...
        'Interpreter', 'latex', 'FontSize', 20);
    ylabel(ax, 'Left-incidence transmission $T_{\mathrm{L}}$', ...
        'Interpreter', 'latex', 'FontSize', 20);

    legend(ax, [treeHandles; styleTree; styleCorrected], ...
        [caseLabels, {'solid: $T_0$', 'dashed: $T_0+\Delta T$'}], ...
        'Interpreter', 'latex', ...
        'Location', 'southoutside', ...
        'NumColumns', 3, ...
        'FontSize', 12, ...
        'Box', 'off');

    drawnow;

    outputBase = string(fullfile(scriptDir, ...
        'chapter6_four_cases_tree_vs_strict_oneloop'));
    pngFile = outputBase + ".png";
    pdfFile = outputBase + ".pdf";
    figFile = outputBase + ".fig";

    exportgraphics(fig, pngFile, 'Resolution', 400);
    exportgraphics(fig, pdfFile, 'ContentType', 'vector');
    savefig(fig, figFile);

    outputFiles = struct( ...
        'png', char(pngFile), ...
        'pdf', char(pdfFile), ...
        'fig', char(figFile), ...
        'dataRoot', char(dataRoot));

    fprintf('Created:\n  %s\n  %s\n  %s\n', ...
        outputFiles.png, outputFiles.pdf, outputFiles.fig);
end

function dataRoot = resolveDataRoot(dataLocation, scriptDir)
    if strlength(dataLocation) == 0
        candidateFolders = [ ...
            string(fullfile(scriptDir, 'chapter6数据')); ...
            string(fullfile(pwd, 'chapter6数据'))];
        candidateArchives = [ ...
            string(fullfile(scriptDir, 'chapter6数据.zip')); ...
            string(fullfile(pwd, 'chapter6数据.zip'))];

        for k = 1:numel(candidateFolders)
            if isfolder(candidateFolders(k))
                dataRoot = candidateFolders(k);
                return;
            end
        end

        for k = 1:numel(candidateArchives)
            if isfile(candidateArchives(k))
                dataRoot = unpackArchive(candidateArchives(k));
                return;
            end
        end

        error('Chapter6Plot:DataNotFound', ...
            ['No chapter6数据 folder or chapter6数据.zip archive was found. ', ...
             'Pass its full path as the function input.']);
    end

    if isfile(dataLocation)
        [~, ~, extension] = fileparts(dataLocation);
        if strcmpi(extension, '.zip')
            dataRoot = unpackArchive(dataLocation);
            return;
        end
        error('Chapter6Plot:UnsupportedFile', ...
            'The input file must be chapter6数据.zip, not:\n%s', dataLocation);
    end

    if isfolder(dataLocation)
        nestedRoot = fullfile(dataLocation, 'chapter6数据');
        if isfolder(nestedRoot)
            dataRoot = nestedRoot;
        else
            dataRoot = dataLocation;
        end
        return;
    end

    error('Chapter6Plot:InvalidDataLocation', ...
        'The supplied data location does not exist:\n%s', dataLocation);
end

function dataRoot = unpackArchive(archivePath)
    extractionRoot = fullfile(fileparts(archivePath), ...
        'chapter6_data_extracted');
    dataRoot = fullfile(extractionRoot, 'chapter6数据');

    if isfolder(dataRoot)
        return;
    end

    if ~isfolder(extractionRoot)
        mkdir(extractionRoot);
    end

    unzip(archivePath, extractionRoot);

    if ~isfolder(dataRoot)
        error('Chapter6Plot:ArchiveLayout', ...
            ['The archive was unpacked but the expected chapter6数据 ', ...
             'folder was not found in:\n%s'], extractionRoot);
    end
end

function values = readNumericColumn(scan, columnName, scanFile)
    if ~ismember(columnName, scan.Properties.VariableNames)
        error('Chapter6Plot:MissingColumn', ...
            'The column "%s" is missing from:\n%s', columnName, scanFile);
    end

    values = scan.(columnName);
    if ~isnumeric(values)
        error('Chapter6Plot:NonNumericColumn', ...
            'The column "%s" is not numeric in:\n%s', columnName, scanFile);
    end

    values = double(values(:));
end
