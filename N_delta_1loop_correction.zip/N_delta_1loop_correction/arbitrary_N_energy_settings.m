function settings = arbitrary_N_energy_settings()
%ARBITRARY_N_ENERGY_SETTINGS The only user-editable input file.
%
% The horizontal axis is the external on-shell incident energy E=p^0.
% The distinct internal loop-energy q^0 has already been integrated in
% every complete G1--G4 result.  All plotted and exported term/source/pole
% values use left incidence.  In paired mode, right incidence is evaluated
% only for the complete 2-by-2 S-matrix audit.

%% ================= USER-EDITABLE SETTINGS ==========================

% 1. Scalar-field model.
settings.model.mphi = 0.2;
settings.model.mPhi = 1.4;
settings.model.mu = 0.1;

% 2. N-delta geometry.
%
% mode = 'fixed_support_trapezoidal'
%   The code generates N equally spaced centres on support and distributes
%   totalStrength with trapezoidal weights.  N=1 is represented by one
%   centre at the support midpoint carrying the full strength.
%
% mode = 'explicit'
%   positions and strengths below are used directly; their common length
%   is N.  This supports nonuniform and asymmetric configurations.
settings.geometry.mode = 'fixed_support_trapezoidal';
settings.geometry.N = 5;
settings.geometry.support = [-0.5, 0.5];
settings.geometry.totalStrength = -0.30;

settings.geometry.positions = [-0.6, -0.1, 0.8];
settings.geometry.strengths = [-0.08, -0.12, -0.10];

% 3. External on-shell energy scan E=p^0.  Values must increase and
% satisfy the geometry-dependent closed elastic window.  The driver finds
% the collective-mode threshold before starting the expensive scan.
settings.scan.energyValues = ...
    [0.24, 0.30, 0.40, 0.50, 0.65, 0.80, 1.10, 1.40];

% 4. Genuine complex-q^0-plane singularity plots.
%
% The branch points, branch cuts and mapped collective/barrier poles all
% depend on qPerp.  The complete G1--G4 results integrate qPerp out, so a
% singularity map must explicitly choose one fixed diagnostic slice.  The
% fixed-qPerp energy locus is drawn directly as Im(q^0) versus Re(q^0), so
% its quadrants remain visible; it is not split into separate Re/Im-versus-E
% panels.  E is retained as the ordered parameter along that complex locus.
settings.singularity.referenceQPerp = 0.10;

% s parameterises each exact finite-epsilon outward branch cut.  Increasing
% cutParameterMax extends the displayed tails; cutSamples changes only the
% plotting resolution and never changes a G1--G4 integral.
settings.singularity.cutParameterMax = 2.5;
settings.singularity.cutSamples = 401;

% The selected-E complex-plane locus follows branch endpoints and mapped
% poles while qPerp runs from zero through the largest contour-relevant
% support boundary.  This is plotting-only and does not repeat an integral.
settings.singularity.qPerpTrajectorySamples = 301;

% Empty selects the first, middle and last accepted scan energies.  Supply
% explicit integer indices, for example [1,4,8], to choose other snapshots.
settings.singularity.snapshotEnergyIndices = [];

% 5. Numerical profile.
%
% 'production' : one validated production-order left-incidence calculation
%                at every external energy E.  This is the practical default
%                for curves.
% 'paired'     : production plus independent higher order.  Right incidence
%                is also evaluated only for the complete 2-by-2 S-matrix,
%                reciprocity and unitarity audit.  This mode exports and
%                plots U_L, U_R and complex V_12 over the full energy grid.
%                For a centred mirror-symmetric array it also verifies the
%                reduced real U,V formulas used in the thesis.  The other
%                plotted and exported
%                term/source/pole values remain the higher-order left-
%                incidence result.  Use this for final publication tables
%                when runtime permits.
settings.numerics.mode = 'production';

% Multiplies all six production quadrature orders.  Keep 1.0 for the
% validated v1.9.6 production settings.  Values are rounded and bounded
% below by the supported order floor 4.
settings.numerics.orderFactor = 1.0;

% 6. Execution.  Every completed external-energy point is saved atomically.
% A compatible rerun resumes; changed physical or numerical settings start
% a fresh scan.
settings.execution.resume = true;
settings.execution.retryFailedOnResume = true;
settings.execution.showProgress = true;
settings.execution.continueOnPointFailure = true;
settings.execution.requireAllPointsAccepted = true;

% 7. Left-incidence outputs.  directoryName must be relative to this
% package directory.
settings.output.directoryName = 'results';
settings.output.writeCsv = true;
settings.output.writePng = true;
settings.output.writeFig = true;
settings.output.writeMat = true;
settings.output.writeReport = true;
settings.output.imageResolution = 200;
settings.output.figureVisible = 'off';

%% ================= END USER-EDITABLE SETTINGS ======================

settings.driverVersion = '1.3.0';
settings = nqscan.validate_settings(settings);
end
