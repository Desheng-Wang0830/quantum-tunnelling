# Final frozen-code validation report

- Overall status: **FAIL**
- Generated fresh: **true**
- Started (MATLAB `datestr(now,30)`): `20260831T144730`
- Completed: `20260831T163802`
- Duration: 6632.4747885999996 s
- MATLAB: `25.2.0.3177638 (R2025b) Update 5` (`2025b`)
- Computer: `PCWIN64 / win64`
- Strict perturbative scope: `O(mu^2)`
- Preflight accepted: **true**

- Validation hardening contract present: **true**
- Validation hardening accepted: **true**

## Mandatory results

| ID | Status | Duration (s) | Requirement |
|---|---:|---:|---|
| R00 | **PASS** | 192.81349800000001 | Frozen v1.9.6 Stage 0--12 suite rerun |
| R01 | **PASS** | 0.29346990000000001 | T0+R0=1 |
| R02 | **PASS** | 1944.1984359 | deltaT+deltaR=0 at strict O(mu^2) |
| R03 | **FAIL** | 5.1031497999999997 | N=1 analytic reductions |
| R04 | **PASS** | 0.0162992 | G2=G3 for a mirror-symmetric array |
| R05 | **PASS** | 281.38618480000002 | Small-mu mu^2 scaling |
| R06 | **FAIL** | 3145.1824732 | Large-mPhi decoupling |
| R07 | **PASS** | 1009.8064499 | Quadrature-order convergence |
| R08 | **FAIL** | 48.425334200000002 | Mapped-infinite versus finite-cutoff integration |
| R09 | **PASS** | 1.8281167 | Endpoint, pole, branch-cut and physical-sheet tests |
| R10 | **PASS** | 1.8804117 | Gamma_N invertibility and condition-number guard |
| R99 | **PASS** | 1.1974871 | Frozen source identity and validation-suite integrity |

## Acceptance metrics

| Test | Metric | Value | Tolerance | Pass |
|---|---|---:|---:|---:|
| R00 | legacy_tests_not_passed | 0 | 0 | true |
| R00 | legacy_test_discovery_difference | 0 | 0 | true |
| R01 | max_abs_T0_plus_R0_minus_1 | 7.7715611723760958e-16 | 9.9999999999999998e-13 | true |
| R01 | max_normalised_Gamma_inverse_residual | 8.7056379260905866e-17 | 9.9999999999999998e-13 | true |
| R01 | minimum_external_Gamma_rcond_shortfall | 0 | 0 | true |
| R02 | tree_closure | 2.2204460492503131e-16 | 9.9999999999999998e-13 | true |
| R02 | abs_deltaT2_plus_deltaR2 | 2.3122508768791405e-10 | 1e-08 | true |
| R02 | maximum_source_ledger_closure | 4.3261040893461065e-19 | 1e-08 | true |
| R02 | strict_order_contract_violation | 0 | 0 | true |
| R03 | N1_tree_complex_amplitude_error | 5.5511151231257827e-17 | 9.9999999999999998e-13 | true |
| R03 | N1_Gamma_tau_closed_form_error | 0 | 9.9999999999999998e-13 | true |
| R03 | N1_G2_G3_G4_compact_kernel_error | 1.8378751752606929e-17 | 9.9999999999999998e-13 | true |
| R03 | N1_G1_numeric_golden_kernel_error | 2.4668442516997997e-07 | 9.9999999999999995e-08 | false |
| R03 | N1_G1_numeric_probability_error | 5.9537920768984302e-10 | 1e-08 | true |
| R03 | N1_collective_alpha_error | 1.1898815266420115e-13 | 2.0000000000000001e-10 | true |
| R03 | N1_full_chain_regression_failure | 0 | 0 | true |
| R04 | integrated_G2_G3_kernel_mixed_error | 8.97091310810504e-16 | 1e-08 | true |
| R04 | integrated_G2_G3_source_mixed_error | 8.777351522691382e-16 | 1e-08 | true |
| R04 | integrated_G2_G3_amplitude_mixed_error | 5.7826109888242367e-16 | 1e-08 | true |
| R04 | asymmetric_G2_G3_difference_shortfall | 0 | 0 | true |
| R05 | delta_amplitude_over_mu2_mixed_error | 0 | 1e-08 | true |
| R05 | delta_probability_over_mu2_mixed_error | 0 | 1e-08 | true |
| R05 | log_log_probability_slope_error_from_2 | 3.5527136788005009e-15 | 1e-08 | true |
| R05 | tree_amplitude_mu_dependence | 0 | 9.9999999999999998e-13 | true |
| R05 | maximum_conditional_loop_ratio | 0.00030206384994170023 | 0.050000000000000003 | true |
| R06 | positive_finite_decoupling_norms_missing | 0 | 0 | true |
| R06 | maximum_effective_heavy_mass_slope | -1.8466050912559084 | -1.5 | true |
| R06 | maximum_adjacent_heavy_mass_slope | -1.8322316721018486 | -1.5 | true |
| R06 | nonmonotone_decoupling_observable_count | 0 | 0 | true |
| R06 | maximum_masswise_quadrature_error | 1.2676687703951012e-06 | 9.9999999999999995e-07 | false |
| R06 | largest_mass_mapping_scale_error | 4.1718004117636499e-07 | 9.9999999999999995e-07 | true |
| R06 | phase_reference_amplitude_shortfall | 0 | 0 | true |
| R06 | qperp_hard_band_node_shortfall | 0 | 0 | true |
| R06 | tree_amplitude_mPhi_dependence | 0 | 9.9999999999999998e-13 | true |
| R06 | maximum_decoupling_loop_closure | 3.1854805963426203e-14 | 1e-08 | true |
| R07 | final_pair_complete_observable_mixed_error | 4.8303855702799134e-07 | 9.9999999999999995e-07 | true |
| R07 | final_pair_sourceTensor_mixed_error | 4.8303855702799134e-07 | 9.9999999999999995e-07 | true |
| R07 | final_pair_termAmplitudes_mixed_error | 2.6914459447298524e-07 | 9.9999999999999995e-07 | true |
| R07 | final_pair_totalAmplitudes_mixed_error | 1.6785876690061442e-07 | 9.9999999999999995e-07 | true |
| R07 | final_pair_probabilities_mixed_error | 5.0407600223253766e-08 | 9.9999999999999995e-07 | true |
| R07 | final_refinement_progression_error | 4.8303855702799134e-07 | 3.6014636828172584e-06 | true |
| R07 | nonincreasing_effective_quadrature_orders | 0 | 0 | true |
| R07 | maximum_order_level_loop_closure | 1.5607158967978485e-10 | 1e-08 | true |
| R08 | fixed_q4_mapped_vs_finite_cutoff_mixed_error | 1.5352858200437922e-08 | 9.9999999999999995e-07 | true |
| R08 | fixed_q4_finite_cutoff_tail_mixed_error | 2.295484888141519e-07 | 9.9999999999999995e-07 | true |
| R08 | outer_qperp_mapped_vs_finite_cutoff_mixed_error | 4.0368968476317958e-05 | 9.9999999999999995e-07 | false |
| R08 | outer_qperp_finite_cutoff_tail_mixed_error | 0.00013155176841383925 | 9.9999999999999995e-07 | false |
| R08 | maximum_mapping_tau_equation_residual | 1.2412670766236368e-16 | 9.9999999999999998e-13 | true |
| R08 | mapping_tau_scaled_rcond_shortfall | 0 | 0 | true |
| R09 | explicit_q0_plus_minus_iQ_root_residual | 3.0734379303354557e-16 | 9.9999999999999998e-13 | true |
| R09 | physical_feynman_half_plane_contract_failure | 0 | 0 | true |
| R09 | branch_endpoint_and_cut_residual | 1.8452460243077395e-16 | 9.9999999999999998e-13 | true |
| R09 | portable_sheet_contract_failures | 0 | 0 | true |
| R09 | mixed_sign_collective_mode_count_failure | 0 | 0 | true |
| R09 | mixed_sign_collective_alpha_error | 2.1250778914350121e-12 | 2.0000000000000001e-10 | true |
| R09 | mixed_sign_collective_equation_residual | 2.6455608537201414e-11 | 2.0000000000000001e-10 | true |
| R09 | collective_physical_sheet_topology_failure | 0 | 0 | true |
| R09 | collective_unsquared_sheet_residual | 4.8362027362724099e-17 | 1e-08 | true |
| R09 | ordinary_mixed_candidate_rejection_failure | 0 | 0 | true |
| R09 | five_source_reconstruction_residual | 1.4488756721278664e-17 | 1e-08 | true |
| R09 | keyhole_exactly_once_failure | 0 | 0 | true |
| R09 | channel_sigma_and_phase_formula_error | 0 | 9.9999999999999998e-13 | true |
| R09 | translation_phase_covariance_error | 1.2412670766236366e-16 | 9.9999999999999998e-13 | true |
| R09 | collective_residue_route_failure | 0 | 0 | true |
| R09 | maximum_collective_residue_null_residual | 5.7621224820813974e-12 | 2.0000000000000001e-10 | true |
| R09 | collective_projected_condition_shortfall | 0 | 0 | true |
| R09 | collective_residue_nonzero_failure | 0 | 0 | true |
| R09 | independent_endpoint_oracle_error | 0 | 9.9999999999999998e-13 | true |
| R09 | wrong_endpoint_half_factor_not_rejected | 0 | 0 | true |
| R09 | collective_projected_condition_injection_failure | 0 | 0 | true |
| R10 | maximum_normalised_inverse_residual | 6.7085599218788309e-17 | 9.9999999999999998e-13 | true |
| R10 | maximum_internal_tau_equation_residual | 6.770258255314032e-17 | 9.9999999999999998e-13 | true |
| R10 | maximum_external_internal_tau_disagreement | 0 | 9.9999999999999998e-13 | true |
| R10 | external_physical_rcond_shortfall | 0 | 0 | true |
| R10 | ordinary_P_node_scaled_rcond_shortfall | 0 | 0 | true |
| R10 | live_contour_node_scaled_rcond_shortfall | 0 | 0 | true |
| R10 | maximum_live_contour_condition_amplification | 4266.0090144688211 | 1000000 | true |
| R10 | live_contour_aggregation_identity_error | 1.1102230246251565e-16 | 9.9999999999999998e-13 | true |
| R10 | maximum_live_contour_tau_equation_residual | 6.0990220444249721e-16 | 9.9999999999999998e-13 | true |
| R10 | condition_amplification_identity_error | 1.1102230246251565e-16 | 9.9999999999999998e-13 | true |
| R10 | external_exact_near_guard_failure | 0 | 0 | true |
| R10 | stage12_external_near_guard_failure | 0 | 0 | true |
| R10 | internal_exact_near_guard_failure | 0 | 0 | true |
| R10 | K0_orthogonal_projection_residual | 0 | 9.9999999999999998e-13 | true |
| R10 | K0_positive_negative_control_failure | 0 | 0 | true |
| R10 | production_guard_forwarding_failure | 0 | 0 | true |
| R10 | engine_inv_call_count | 0 | 0 | true |
| R10 | hardening_provenance_failure | 0 | 0 | true |
| R10 | per_term_live_diagnostic_failure | 0 | 0 | true |
| R10 | per_term_global_aggregation_error | 0 | 9.9999999999999998e-13 | true |
| R10 | live_collective_condition_shortfall | 0 | 0 | true |
| R10 | runtime_G1_G4_leaf_guard_failure | 0 | 0 | true |
| R10 | runtime_stage12_internal_guard_failure | 0 | 0 | true |
| R99 | source_file_count_changed | 0 | 0 | true |
| R99 | source_aggregate_hash_changed | 0 | 0 | true |
| R99 | source_manifest_entries_changed | 0 | 0 | true |
| R99 | frozen_baseline_manifest_mismatch | 0 | 0 | true |
| R99 | mandatory_test_set_or_schema_failure | 0 | 0 | true |

## Non-PASS details

### R03: FAIL

The exact claim is tree Gamma/tau/amplitudes plus compact pointwise G2--G4 formulas.  The integrated G1 check is reported as numerical.

### R06: FAIL

Converged complete G1--G4 complex amplitudes, phase-shift coefficients and probability corrections must all decouple. The rate permits logarithmic enhancement of mPhi^(-2).

### R08: FAIL

G1 Euclidean T/R is checked at both integration layers.  The q4 finite comparator explicitly integrates both imaginary half-axes; the qPerp finite comparator independently applies qPerp*dqPerp on finite segments while sharing only the inner physical q4 route.

## Source freeze

- Before SHA-256: `d50a575a254cf31e1f9c94bcadc0b8734a315abfd150f7301008f6d5c3244f9d`
- After SHA-256: `d50a575a254cf31e1f9c94bcadc0b8734a315abfd150f7301008f6d5c3244f9d`
- Counts: PASS=9, FAIL=3, INCOMPLETE=0, ERROR=0, TOTAL=12

This report was generated from fresh computation. No historical MAT result is used as an acceptance gate.
