function prescan = run_erman_tree_prescan(preset)
%RUN_ERMAN_TREE_PRESCAN Dense exact Gamma/tau scan with zero loop integrals.
%
%   PRESCAN = RUN_ERMAN_TREE_PRESCAN() uses the balanced one-loop pilot.
%   PRESCAN = RUN_ERMAN_TREE_PRESCAN('strong_tree_demo') uses the stronger
%   tree-level illustration.  This function calls
%   ndelta.tree.tree_amplitudes_N at every momentum.  It never calls a
%   G1--G4 quadrature evaluator.

narginchk(0, 1);
if nargin < 1
    preset = 'balanced_one_loop';
end

packageRoot = fileparts(mfilename('fullpath'));
engineRoot = fullfile(packageRoot, 'engine');
addpath(packageRoot, '-begin');
addpath(engineRoot, '-begin');

settings = erman_feature_settings(preset);
profile = nqscan.build_profile(settings);
baseCfg = nqscan.build_configuration(settings, profile);
geometry = ndelta.geometry.build_geometry( ...
    profile.positions, baseCfg.tolerances.distanceMerge);

P = linspace(settings.erman.treeMomentumRange(1), ...
    settings.erman.treeMomentumRange(2), ...
    settings.erman.treeSamples);
P = P(:);
numberOfPoints = numel(P);
t0 = complex(NaN(numberOfPoints, 1));
r0 = complex(NaN(numberOfPoints, 1));
T0 = NaN(numberOfPoints, 1);
R0 = NaN(numberOfPoints, 1);
closure = NaN(numberOfPoints, 1);
gammaRcond = NaN(numberOfPoints, 1);
gammaCondition2 = NaN(numberOfPoints, 1);
accepted = false(numberOfPoints, 1);
status = repmat({'not_evaluated'}, numberOfPoints, 1);

for pointIndex = 1:numberOfPoints
    try
        tree = ndelta.tree.tree_amplitudes_N( ...
            P(pointIndex), geometry, profile.strengths, ...
            baseCfg.tolerances.nearSingularRcond);
        t0(pointIndex) = tree.t0;
        r0(pointIndex) = tree.r0;
        T0(pointIndex) = tree.T0;
        R0(pointIndex) = tree.R0;
        closure(pointIndex) = tree.probabilityClosureResidual;
        gammaRcond(pointIndex) = ...
            tree.background.solveDiagnostics.rcond;
        gammaCondition2(pointIndex) = ...
            tree.background.solveDiagnostics.conditionNumber2;
        accepted(pointIndex) = ...
            ~tree.background.solveDiagnostics.nearSingular && ...
            abs(closure(pointIndex)) <= ...
            20 .* baseCfg.tolerances.unitarity;
        if accepted(pointIndex)
            status{pointIndex} = 'accepted';
        elseif tree.background.solveDiagnostics.nearSingular
            status{pointIndex} = 'near_singular_gamma';
        else
            status{pointIndex} = 'tree_unitarity_rejected';
        end
    catch cause
        status{pointIndex} = [ ...
            'evaluation_exception: ' cause.identifier];
    end
end

externalEnergy = sqrt(P.^2 + settings.model.mphi.^2);
[elasticUpper, elasticEventTolerance, elasticSource, ...
    preflightStatus] = resolve_elastic_upper(baseCfg, settings);
usableElasticUpper = elasticUpper - elasticEventTolerance;
elasticMomentumUpper = sqrt(max( ...
    usableElasticUpper.^2 - settings.model.mphi.^2, 0));
insideElasticWindow = externalEnergy < usableElasticUpper;

[isPeak, isDip] = locate_local_extrema(T0, accepted);
isElasticPeak = isPeak & insideElasticWindow;
isElasticDip = isDip & insideElasticWindow;

prescan = struct();
prescan.addonVersion = settings.erman.addonVersion;
prescan.preset = settings.erman.preset;
prescan.method = ['Exact resummed tree background from ' ...
    'Gamma_N and tau_N=Gamma_N\I; no G1--G4 integrals'];
prescan.loopIntegralEvaluations = 0;
prescan.settings = settings;
prescan.profile = profile;
prescan.P = P;
prescan.externalEnergy = externalEnergy;
prescan.t0 = t0;
prescan.r0 = r0;
prescan.T0 = T0;
prescan.R0 = R0;
prescan.treeClosureResidual = closure;
prescan.gammaRcond = gammaRcond;
prescan.gammaConditionNumber2 = gammaCondition2;
prescan.accepted = accepted;
prescan.status = status;
prescan.isPeak = isPeak;
prescan.isDip = isDip;
prescan.isElasticPeak = isElasticPeak;
prescan.isElasticDip = isElasticDip;
prescan.insideElasticWindow = insideElasticWindow;
prescan.elasticUpperEnergy = usableElasticUpper;
prescan.elasticUpperMomentum = elasticMomentumUpper;
prescan.elasticUpperSource = elasticSource;
prescan.elasticPreflightStatus = preflightStatus;
prescan.maximumAbsoluteTreeClosure = ...
    max(abs(closure(isfinite(closure))));
prescan.minimumGammaRcond = min(gammaRcond(isfinite(gammaRcond)));
prescan.numberOfElasticPeaks = nnz(isElasticPeak);
prescan.numberOfElasticDips = nnz(isElasticDip);

outputDirectory = fullfile(packageRoot, ...
    settings.output.directoryName, 'tree_prescan');
ensure_directory(outputDirectory);
prescan.outputFiles = write_prescan_outputs( ...
    prescan, outputDirectory, settings.output);

fprintf('\nErman-feature exact tree prescan complete.\n');
fprintf('  preset: %s\n', settings.erman.preset);
fprintf('  positions: %s\n', mat2str(profile.positions, 8));
fprintf('  strengths: %s\n', mat2str(profile.strengths, 8));
fprintf('  elastic P upper: %.10g (%s)\n', ...
    elasticMomentumUpper, elasticSource);
fprintf('  elastic peaks/dips: %d / %d\n', ...
    prescan.numberOfElasticPeaks, prescan.numberOfElasticDips);
fprintf('  max |T0+R0-1|: %.3e\n', ...
    prescan.maximumAbsoluteTreeClosure);
fprintf('  loop-integral evaluations: 0\n\n');
end

function [upper, eventTolerance, source, status] = ...
        resolve_elastic_upper(baseCfg, settings)
freeUpper = settings.model.mphi + settings.model.mPhi;
upper = freeUpper;
eventTolerance = 0;
source = 'free_phi_plus_Phi_threshold';
status = 'free_threshold_fallback';
try
    state = ndelta.stage12.prepare_direction_state(baseCfg);
    upper = state.elasticWindow.upper;
    if isfield(state.elasticWindow, 'eventTolerance')
        eventTolerance = state.elasticWindow.eventTolerance;
    end
    source = 'geometry_dependent_closed_elastic_window';
    status = 'preflight_accepted';
catch cause
    status = ['preflight_unavailable: ' cause.identifier];
end
end

function [isPeak, isDip] = locate_local_extrema(values, accepted)
numberOfPoints = numel(values);
isPeak = false(numberOfPoints, 1);
isDip = false(numberOfPoints, 1);
for index = 2:(numberOfPoints - 1)
    localAccepted = all(accepted((index - 1):(index + 1)));
    if ~localAccepted
        continue;
    end
    isPeak(index) = values(index) > values(index - 1) && ...
        values(index) >= values(index + 1);
    isDip(index) = values(index) < values(index - 1) && ...
        values(index) <= values(index + 1);
end
end

function files = write_prescan_outputs(prescan, directory, output)
files = struct('table', '', 'features', '', 'png', '', 'fig', '', ...
    'mat', '');

if output.writeCsv
    scanTable = table(prescan.P, prescan.externalEnergy, ...
        real(prescan.t0), imag(prescan.t0), ...
        real(prescan.r0), imag(prescan.r0), ...
        prescan.T0, prescan.R0, prescan.treeClosureResidual, ...
        prescan.gammaRcond, prescan.gammaConditionNumber2, ...
        prescan.insideElasticWindow, prescan.isPeak, prescan.isDip, ...
        prescan.accepted, prescan.status, ...
        'VariableNames', {'P', 'externalEnergy', 'realT0Amplitude', ...
        'imagT0Amplitude', 'realR0Amplitude', 'imagR0Amplitude', ...
        'T0', 'R0', 'treeClosureResidual', 'gammaRcond', ...
        'gammaConditionNumber2', 'insideElasticWindow', 'isPeak', ...
        'isDip', 'accepted', 'status'});
    files.table = fullfile(directory, 'tree_only_dense_scan.csv');
    writetable(scanTable, files.table);

    featureMask = (prescan.isElasticPeak | prescan.isElasticDip) & ...
        prescan.accepted;
    featureKind = repmat({'dip'}, nnz(featureMask), 1);
    peakWithinFeatures = prescan.isElasticPeak(featureMask);
    featureKind(peakWithinFeatures) = {'peak'};
    featureTable = table(featureKind, prescan.P(featureMask), ...
        prescan.externalEnergy(featureMask), prescan.T0(featureMask), ...
        prescan.R0(featureMask), prescan.gammaRcond(featureMask), ...
        'VariableNames', {'kind', 'P', 'externalEnergy', 'T0', 'R0', ...
        'gammaRcond'});
    files.features = fullfile(directory, ...
        'tree_only_elastic_peaks_and_dips.csv');
    writetable(featureTable, files.features);
end

if output.writePng || output.writeFig
    figureHandle = make_prescan_figure(prescan, output.figureVisible);
    if output.writePng
        files.png = fullfile(directory, ...
            'tree_only_erman_feature_prescan.png');
        print(figureHandle, files.png, '-dpng', ...
            sprintf('-r%d', output.imageResolution));
    end
    if output.writeFig
        files.fig = fullfile(directory, ...
            'tree_only_erman_feature_prescan.fig');
        savefig(figureHandle, files.fig);
    end
    close(figureHandle);
end

files.mat = fullfile(directory, 'tree_only_erman_feature_prescan.mat');
payload = prescan;
payload.outputFiles = files;
ndelta.stage12.atomic_save(files.mat, struct('prescan', payload));
end

function figureHandle = make_prescan_figure(prescan, visibility)
figureHandle = figure('Visible', visibility, 'Color', 'w', ...
    'Position', [80, 80, 1120, 820]);

topAxes = subplot(2, 1, 1);
draw_tree_curve(topAxes, prescan, false);
title(topAxes, sprintf([ ...
    'Exact tree transmission from \Gamma_N/\tau_N: %s'], ...
    strrep(prescan.preset, '_', '\_')), 'FontWeight', 'normal');

bottomAxes = subplot(2, 1, 2);
draw_tree_curve(bottomAxes, prescan, true);
title(bottomAxes, sprintf([ ...
    'Closed-elastic zoom: %d peaks and %d dips'], ...
    prescan.numberOfElasticPeaks, prescan.numberOfElasticDips), ...
    'FontWeight', 'normal');
end

function draw_tree_curve(axesHandle, prescan, elasticZoom)
hold(axesHandle, 'on');
curveHandle = plot(axesHandle, prescan.P, prescan.T0, ...
    'Color', [0.00, 0.35, 0.75], 'LineWidth', 1.35);
peakHandle = plot(axesHandle, prescan.P(prescan.isElasticPeak), ...
    prescan.T0(prescan.isElasticPeak), '^', ...
    'Color', [0.00, 0.55, 0.20], 'MarkerFaceColor', [0.00, 0.55, 0.20], ...
    'MarkerSize', 5, 'LineStyle', 'none');
dipHandle = plot(axesHandle, prescan.P(prescan.isElasticDip), ...
    prescan.T0(prescan.isElasticDip), 'v', ...
    'Color', [0.85, 0.20, 0.10], 'MarkerFaceColor', [0.85, 0.20, 0.10], ...
    'MarkerSize', 5, 'LineStyle', 'none');
thresholdHandle = plot(axesHandle, ...
    [prescan.elasticUpperMomentum, prescan.elasticUpperMomentum], ...
    [0, 1.05], 'k--', 'LineWidth', 1.2);
grid(axesHandle, 'on');
box(axesHandle, 'on');
xlabel(axesHandle, 'External momentum P');
ylabel(axesHandle, 'T_0');
ylim(axesHandle, [0, 1.05]);
if elasticZoom
    xlim(axesHandle, [prescan.P(1), prescan.elasticUpperMomentum]);
else
    xlim(axesHandle, [prescan.P(1), prescan.P(end)]);
end
legend(axesHandle, [curveHandle, peakHandle, dipHandle, thresholdHandle], ...
    {'exact tree T_0', 'elastic-window peaks', ...
    'elastic-window dips', 'one-loop elastic upper P'}, ...
    'Location', 'best');
hold(axesHandle, 'off');
end

function ensure_directory(path)
if ~exist(path, 'dir')
    [created, message] = mkdir(path);
    if ~created
        error('nqscanErman:OutputDirectoryCreationFailed', ...
            'Could not create %s: %s', path, message);
    end
end
end
