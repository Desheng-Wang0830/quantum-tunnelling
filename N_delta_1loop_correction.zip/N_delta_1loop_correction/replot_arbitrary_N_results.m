function [result, files] = replot_arbitrary_N_results(resultOrMatPath, ...
        outputDirectory)
%REPLOT_ARBITRARY_N_RESULTS Correct plots using an existing v1.0--v1.3 MAT.
%
%   REPLOT_ARBITRARY_N_RESULTS() loads the normal MAT result under results.
%   REPLOT_ARBITRARY_N_RESULTS(PATH) loads a specified result MAT and writes
%   corrected figures/tables into a separate results_replot_v1.3.0 folder.
%   REPLOT_ARBITRARY_N_RESULTS(RESULT, DIRECTORY) accepts an in-memory
%   result and an explicit output directory.
%
% No G1--G4 integration is repeated.  Branch cuts and q^0 pole positions
% are reconstructed from the stored model, epsilon, mode alpha and energy
% arrays by the verified physical-sheet helper functions.

narginchk(0, 2);
packageRoot = fileparts(mfilename('fullpath'));
engineRoot = fullfile(packageRoot, 'engine');
addpath(packageRoot, '-begin');
addpath(engineRoot, '-begin');
assert_bundled_engine(engineRoot);

if nargin < 1 || isempty(resultOrMatPath)
    resultOrMatPath = fullfile(packageRoot, 'results', ...
        'arbitrary_N_energy_G1_G4_pole_scan_results.mat');
end

inputWasPath = ischar(resultOrMatPath) || ...
    (isstring(resultOrMatPath) && isscalar(resultOrMatPath));
if inputWasPath
    matPath = char(resultOrMatPath);
    if ~exist(matPath, 'file')
        error('nqscan:MissingResultMat', ...
            'Could not find result MAT file %s.', matPath);
    end
    payload = load(matPath, 'result');
    if ~isfield(payload, 'result')
        error('nqscan:MissingResultVariable', ...
            'MAT file %s does not contain variable result.', matPath);
    end
    result = payload.result;
    if nargin < 2 || isempty(outputDirectory)
        outputDirectory = fullfile(fileparts(matPath), ...
            'results_replot_v1.3.0');
    end
else
    result = resultOrMatPath;
    if nargin < 2 || isempty(outputDirectory)
        outputDirectory = fullfile(packageRoot, ...
            'results_replot_v1.3.0');
    end
end

if isstring(outputDirectory) && isscalar(outputDirectory)
    outputDirectory = char(outputDirectory);
end
if ~ischar(outputDirectory) || isempty(strtrim(outputDirectory))
    error('nqscan:InvalidReplotDirectory', ...
        'outputDirectory must be nonempty text.');
end
if ~exist(outputDirectory, 'dir')
    [created, message] = mkdir(outputDirectory);
    if ~created
        error('nqscan:ReplotDirectoryCreationFailed', ...
            'Could not create %s: %s', outputDirectory, message);
    end
end

result = nqscan.prepare_postprocessing(result);
files = struct();
files.outputDirectory = outputDirectory;
files.tables = struct();
files.figures = struct();
files.report = '';
files.mat = '';
if result.settings.output.writeCsv
    files.tables = nqscan.write_tables(result, outputDirectory);
end
if result.settings.output.writePng || result.settings.output.writeFig
    files.figures = nqscan.make_plots(result, outputDirectory);
end
if result.settings.output.writeReport
    files.report = fullfile(outputDirectory, 'REPLOT_REPORT_v1.3.0.txt');
    nqscan.write_report(files.report, result, files);
end
if result.settings.output.writeMat
    files.mat = fullfile(outputDirectory, ...
        'arbitrary_N_energy_G1_G4_replotted_v1.3.0.mat');
end
if isfield(result, 'outputFiles') && ...
        ~isfield(result, 'originalOutputFiles')
    result.originalOutputFiles = result.outputFiles;
end
result.replotOutputFiles = files;
result.outputFiles = files;
if result.settings.output.writeMat
    ndelta.stage12.atomic_save(files.mat, struct('result', result));
end
end

function assert_bundled_engine(engineRoot)
expectedPath = fullfile(engineRoot, '+ndelta', '+config', ...
    'release_contract.m');
actualPath = which('ndelta.config.release_contract');
if ~same_path(actualPath, expectedPath)
    error('nqscan:WrongEngineOnPath', ...
        ['ndelta.config.release_contract resolves outside the bundled ' ...
         'engine. Run "clear functions; rehash" and retry.']);
end
release = ndelta.config.release_contract();
if ~isfield(release, 'releaseVersion') || ...
        ~strcmp(char(release.releaseVersion), '1.9.6')
    error('nqscan:EngineReleaseMismatch', ...
        'The replotter requires bundled engine release 1.9.6.');
end
end

function accepted = same_path(left, right)
if isempty(left) || isempty(right)
    accepted = false;
    return;
end
left = strrep(left, '\', '/');
right = strrep(right, '\', '/');
if ispc
    accepted = strcmpi(left, right);
else
    accepted = strcmp(left, right);
end
end
