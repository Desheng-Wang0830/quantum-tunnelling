function result = run_uv_unitarity_audit(settings)
%RUN_UV_UNITARITY_AUDIT Run the full U_L, U_R, V_12 energy-window audit.
%
%   RESULT = RUN_UV_UNITARITY_AUDIT() uses the physical model, geometry and
%   energy grid in arbitrary_N_energy_settings.m, forces paired mode and
%   writes to results_UV_unitarity_audit.
%
%   RESULT = RUN_UV_UNITARITY_AUDIT(SETTINGS) preserves the supplied output
%   directory but still forces paired mode, because V_12 cannot be inferred
%   from a generic left-incidence production scan.

narginchk(0, 1);
if nargin < 1
    settings = arbitrary_N_energy_settings();
    settings.output.directoryName = 'results_UV_unitarity_audit';
end
settings.numerics.mode = 'paired';
% An audit must preserve and display a failed residual rather than aborting
% before the caller can inspect it.  Overall acceptance remains recorded in
% result.accepted and every rejected point remains explicitly flagged.
settings.execution.requireAllPointsAccepted = false;
settings = nqscan.validate_settings(settings);

result = run_arbitrary_N_energy_scan(settings);
tested = logical(result.data.uvAuditTested);
if ~all(tested)
    error('nqscan:IncompleteUVAuditEnergyWindow', ...
        ['The run completed without retaining both incidence directions ' ...
         'at every requested energy. Inspect scan_failures.csv; no missing ' ...
         'V_12 value may be replaced by zero or interpolation.']);
end

fprintf(['U/V audit completed at %d/%d energies. ' ...
    'Maximum gate ratio: %.10e.\n'], ...
    nnz(tested), numel(tested), max(result.data.uvGateRatio(tested)));
if any(result.data.uvOneLoopAccepted(tested) ~= 1)
    warning('nqscan:UVGateRejected', ...
        ['At least one tested energy failed the U/V gate. The finite ' ...
         'residuals were retained in CSV/MAT and were not normalised away.']);
end
end
