function result = run_n_comparison_fixed_parameters()
%RUN_N_COMPARISON_FIXED_PARAMETERS Compare strict one-loop Delta T for N=1:5.
%
%   RESULT = RUN_N_COMPARISON_FIXED_PARAMETERS keeps the external on-shell
%   energy p^0, the scalar-field model, the finite-epsilon prescription,
%   the quadrature orders and the geometric support fixed.  Only N changes.
%   Every active delta centre has the same signed coupling
%
%       g_a = fixedPerBarrierG,
%
%   so the total signed strength is N*fixedPerBarrierG.  This is deliberately
%   different from the fixed-total-strength trapezoidal continuum scan.
%
%   IMPORTANT: a complete G1--G4 transmission correction has already
%   integrated the internal loop variables q^0 and q_perp.  Therefore the
%   fixedReferenceQ0 and fixedReferenceQPerp settings below only keep the
%   pointwise diagnostic nodes identical for every N; they do not replace
%   the production q^0 or q_perp integrations.
%
%   Run from this package directory with
%
%       clear functions
%       rehash
%       result = run_n_comparison_fixed_parameters();
%
%   The primary observable is read DIRECTLY from the completed engine field
%
%       point.combined.totalDeltaProbabilities(1).
%
%   The engine has already integrated the loop variables and converted the
%   summed G1--G4 amplitude correction into the strict O(mu^2) probability
%   correction.  This driver does not apply 2*Re(conj(t0)*delta_t_loop) a
%   second time and does not include an O(mu^4) amplitude-squared term.

%% ================= USER-EDITABLE SETTINGS ==========================

% The requested discrete scan.  Keep this at 1:5 for the direct comparison.
NValues = 1:5;

% Fixed external on-shell incident energy p^0 and model parameters.
fixedP0 = 0.30;
mphi = 0.20;
mPhi = 1.40;
mu = 0.10;

% Identical signed strength of EVERY delta centre for EVERY N.
% The default -0.06 makes the N=5 total strength equal to -0.30, while all
% five configurations still use the same per-centre value g_a=-0.06.
% Positive values are repulsive; negative values are attractive.
fixedPerBarrierG = -0.06;

% Fixed geometric support.  N=1 is at the midpoint; N>=2 is equally spaced
% from the left endpoint to the right endpoint.  The support does not grow
% with N, although the necessary centre spacing changes when N changes.
fixedSupport = [-0.50, 0.50];

% Fixed pointwise diagnostics only.  The complete Delta T still integrates
% over q^0 and q_perp using the original contour and quadrature contract.
fixedReferenceQ0 = 0.30;
fixedReferenceQPerp = 0.10;

% 1.0 retains the validated production quadrature orders of engine v1.9.6.
orderFactor = 1.0;

% Output controls.
outputDirectoryName = 'results_N_comparison_fixed_parameters';
figureVisible = 'off';
imageResolution = 200;
showProgress = true;

%% ================= END USER-EDITABLE SETTINGS ======================

validate_user_settings(NValues, fixedP0, mphi, mPhi, mu, ...
    fixedPerBarrierG, fixedSupport, fixedReferenceQ0, ...
    fixedReferenceQPerp, orderFactor, outputDirectoryName, ...
    figureVisible, imageResolution, showProgress);

packageRoot = fileparts(mfilename('fullpath'));
engineRoot = fullfile(packageRoot, 'engine');
addpath(packageRoot, '-begin');
addpath(engineRoot, '-begin');
assert_bundled_engine(engineRoot);

release = ndelta.config.release_contract();
if ~isstruct(release) || ~isscalar(release) || ...
        ~isfield(release, 'releaseVersion') || ...
        ~strcmp(char(release.releaseVersion), '1.9.6')
    error('nqscanN:EngineReleaseMismatch', ...
        'This N comparison requires the bundled engine release 1.9.6.');
end

outputDirectory = fullfile(packageRoot, outputDirectoryName);
ensure_directory(outputDirectory);

numberOfCases = numel(NValues);
accepted = false(numberOfCases, 1);
status = repmat({''}, numberOfCases, 1);
errorIdentifier = repmat({''}, numberOfCases, 1);
errorMessage = repmat({''}, numberOfCases, 1);
P = NaN(numberOfCases, 1);
T0 = NaN(numberOfCases, 1);
R0 = NaN(numberOfCases, 1);
termDeltaT = NaN(numberOfCases, 4);
termDeltaR = NaN(numberOfCases, 4);
totalDeltaT = NaN(numberOfCases, 1);
totalDeltaR = NaN(numberOfCases, 1);
correctedT = NaN(numberOfCases, 1);
correctedR = NaN(numberOfCases, 1);
relativeDeltaT = NaN(numberOfCases, 1);
relativeDeltaR = NaN(numberOfCases, 1);
oneLoopClosure = NaN(numberOfCases, 1);
treeClosure = NaN(numberOfCases, 1);
elasticUpper = NaN(numberOfCases, 1);
numberOfCollectiveModes = NaN(numberOfCases, 1);
maximumSourceClosure = NaN(numberOfCases, 1);
maximumTauEquationResidual = NaN(numberOfCases, 1);
interferenceAssemblyResidual = NaN(numberOfCases, 1);
minimumExternalGammaRcond = NaN(numberOfCases, 1);
points = cell(numberOfCases, 1);
configurations = cell(numberOfCases, 1);
productionOptions = cell(numberOfCases, 1);

profileN = zeros(sum(NValues), 1);
profileCentreIndex = zeros(sum(NValues), 1);
profilePosition = zeros(sum(NValues), 1);
profileStrength = zeros(sum(NValues), 1);
profileCursor = 0;

baseSettings = arbitrary_N_energy_settings();
baseSettings.model.mphi = mphi;
baseSettings.model.mPhi = mPhi;
baseSettings.model.mu = mu;
baseSettings.scan.energyValues = fixedP0;
baseSettings.singularity.referenceQPerp = fixedReferenceQPerp;
baseSettings.numerics.mode = 'production';
baseSettings.numerics.orderFactor = orderFactor;

fprintf(['N comparison: fixed p^0=%.10g, fixed per-centre g_a=%.10g, ' ...
    'support=[%.10g, %.10g]\n'], fixedP0, fixedPerBarrierG, ...
    fixedSupport(1), fixedSupport(2));
fprintf(['Diagnostic node fixed at q0=%.10g, qPerp=%.10g.  Complete ' ...
    'Delta T still integrates both loop variables.\n'], ...
    fixedReferenceQ0, fixedReferenceQPerp);

for caseIndex = 1:numberOfCases
    N = NValues(caseIndex);
    positions = equal_support_positions(N, fixedSupport);
    strengths = fixedPerBarrierG .* ones(1, N);

    rows = profileCursor + (1:N);
    profileN(rows) = N;
    profileCentreIndex(rows) = (1:N).';
    profilePosition(rows) = positions(:);
    profileStrength(rows) = strengths(:);
    profileCursor = profileCursor + N;

    settings = baseSettings;
    settings.geometry.mode = 'explicit';
    settings.geometry.positions = positions;
    settings.geometry.strengths = strengths;
    settings = nqscan.validate_settings(settings);
    profile = nqscan.build_profile(settings);

    if showProgress
        fprintf('  N=%d (%d/%d): total strength=%+.10g ...\n', ...
            N, caseIndex, numberOfCases, sum(strengths));
    end

    try
        cfg = nqscan.build_configuration(settings, profile);

        % Keep every pointwise diagnostic node fixed across N.  These fields
        % are not substitutes for the production contour integrations.
        cfg.sheet.referenceQPerp = fixedReferenceQPerp;
        cfg.g1.referenceQ0 = fixedReferenceQ0;
        cfg.g1.referenceQPerp = fixedReferenceQPerp;
        cfg.stage11.referenceQ0 = fixedReferenceQ0;
        cfg.stage11.referenceQPerp = fixedReferenceQPerp;
        cfg = ndelta.config.finalize_configuration(cfg);

        options = nqscan.resolve_options(cfg, orderFactor);
        preparedState = ndelta.stage12.prepare_direction_state(cfg);
        point = ndelta.stage12.evaluate_direction( ...
            cfg, options, preparedState);

        configurations{caseIndex} = cfg;
        productionOptions{caseIndex} = options;
        points{caseIndex} = point;
        status{caseIndex} = point.status;
        accepted(caseIndex) = point.accepted;
        P(caseIndex) = point.P;
        T0(caseIndex) = point.tree.T0;
        R0(caseIndex) = point.tree.R0;
        treeClosure(caseIndex) = point.tree.probabilityClosureResidual;
        elasticUpper(caseIndex) = point.elasticWindow.upper;
        numberOfCollectiveModes(caseIndex) = numel(point.spectrum.modes);

        if isfield(point.tree, 'background') && ...
                isfield(point.tree.background, 'solveDiagnostics') && ...
                isfield(point.tree.background.solveDiagnostics, 'rcond')
            minimumExternalGammaRcond(caseIndex) = ...
                point.tree.background.solveDiagnostics.rcond;
        end

        if ~point.accepted
            errorIdentifier{caseIndex} = point.rejectionIdentifier;
            errorMessage{caseIndex} = ...
                'The engine completed the case but rejected its validation gate.';
            if showProgress
                fprintf('      rejected: %s\n', point.status);
            end
            continue;
        end

        termDeltaT(caseIndex, :) = ...
            point.combined.termDeltaProbabilityMatrix(:, 1).';
        termDeltaR(caseIndex, :) = ...
            point.combined.termDeltaProbabilityMatrix(:, 2).';
        totalDeltaT(caseIndex) = ...
            point.combined.totalDeltaProbabilities(1);
        totalDeltaR(caseIndex) = ...
            point.combined.totalDeltaProbabilities(2);
        correctedT(caseIndex) = ...
            point.combined.truncatedProbabilities(1);
        correctedR(caseIndex) = ...
            point.combined.truncatedProbabilities(2);
        relativeDeltaT(caseIndex) = totalDeltaT(caseIndex) ./ T0(caseIndex);
        relativeDeltaR(caseIndex) = totalDeltaR(caseIndex) ./ R0(caseIndex);
        oneLoopClosure(caseIndex) = ...
            totalDeltaT(caseIndex) + totalDeltaR(caseIndex);
        maximumSourceClosure(caseIndex) = point.maximumSourceClosure;
        maximumTauEquationResidual(caseIndex) = ...
            point.maximumTauEquationResidual;
        interferenceAssemblyResidual(caseIndex) = ...
            point.combined.maximumInterferenceAssemblyResidual;

        if showProgress
            fprintf(['      accepted: T0=%.10g, DeltaT=%+.10e, ' ...
                'DeltaT/T0=%+.10e\n'], T0(caseIndex), ...
                totalDeltaT(caseIndex), relativeDeltaT(caseIndex));
        end
    catch cause
        if is_user_interrupt(cause)
            rethrow(cause);
        end
        accepted(caseIndex) = false;
        status{caseIndex} = 'evaluation_exception';
        errorIdentifier{caseIndex} = cause.identifier;
        errorMessage{caseIndex} = cause.message;
        if showProgress
            fprintf('      failed: %s\n', cause.message);
        end
    end
end

totalStrength = NValues(:) .* fixedPerBarrierG;
summaryTable = table(NValues(:), ...
    repmat(fixedPerBarrierG, numberOfCases, 1), totalStrength, ...
    repmat(fixedP0, numberOfCases, 1), P, ...
    repmat(fixedReferenceQ0, numberOfCases, 1), ...
    repmat(fixedReferenceQPerp, numberOfCases, 1), ...
    T0, R0, termDeltaT(:, 1), termDeltaT(:, 2), ...
    termDeltaT(:, 3), termDeltaT(:, 4), totalDeltaT, ...
    relativeDeltaT, correctedT, totalDeltaR, relativeDeltaR, ...
    correctedR, treeClosure, oneLoopClosure, elasticUpper, ...
    numberOfCollectiveModes, minimumExternalGammaRcond, ...
    maximumSourceClosure, maximumTauEquationResidual, ...
    interferenceAssemblyResidual, accepted, status, errorIdentifier, ...
    errorMessage, ...
    'VariableNames', {'N', 'perBarrierG', 'totalStrength', 'p0', 'P', ...
    'referenceQ0Diagnostic', 'referenceQPerpDiagnostic', 'T0', 'R0', ...
    'deltaT_G1', 'deltaT_G2', 'deltaT_G3', 'deltaT_G4', ...
    'deltaT_total', 'deltaT_over_T0', 'T_strictOneLoop', ...
    'deltaR_total', 'deltaR_over_R0', 'R_strictOneLoop', ...
    'treeClosure', 'oneLoopClosure', 'elasticUpper', ...
    'numberCollectiveModes', 'externalGammaRcond', ...
    'maximumSourceClosure', 'maximumTauEquationResidual', ...
    'interferenceAssemblyResidual', 'accepted', 'status', ...
    'errorIdentifier', 'errorMessage'});

profileTable = table(profileN, profileCentreIndex, profilePosition, ...
    profileStrength, 'VariableNames', ...
    {'N', 'centreIndex', 'position', 'strength'});

result = struct();
result.driver = 'run_n_comparison_fixed_parameters';
result.engineRelease = release;
result.observable = ['strict O(mu^2) left-incidence transmission ' ...
    'interference correction DeltaT'];
result.observableSource = ...
    'point.combined.totalDeltaProbabilities(1)';
result.q0Convention = ['The complete G1--G4 DeltaT integrates internal ' ...
    'q^0; referenceQ0 is a fixed pointwise diagnostic only.'];
result.qPerpConvention = ['The complete G1--G4 DeltaT integrates q_perp; ' ...
    'referenceQPerp is a fixed pointwise diagnostic only.'];
result.geometryConvention = ['Fixed support with equally spaced centres; ' ...
    'every centre has identical fixed strength; total strength=N*g_a.'];
result.fixedSettings = struct('NValues', NValues, 'p0', fixedP0, ...
    'mphi', mphi, 'mPhi', mPhi, 'mu', mu, ...
    'perBarrierG', fixedPerBarrierG, 'support', fixedSupport, ...
    'referenceQ0Diagnostic', fixedReferenceQ0, ...
    'referenceQPerpDiagnostic', fixedReferenceQPerp, ...
    'orderFactor', orderFactor);
result.summary = summaryTable;
result.barrierProfiles = profileTable;
result.configurations = configurations;
result.productionOptions = productionOptions;
result.points = points;
result.accepted = all(accepted);
if result.accepted
    result.status = 'all_N_1_to_5_cases_accepted';
else
    result.status = 'one_or_more_N_cases_rejected';
end

files = struct();
files.summaryCsv = fullfile(outputDirectory, ...
    'N_comparison_fixed_parameters.csv');
files.profileCsv = fullfile(outputDirectory, ...
    'N_comparison_barrier_profiles.csv');
files.png = fullfile(outputDirectory, ...
    'N_comparison_fixed_parameters.png');
files.fig = fullfile(outputDirectory, ...
    'N_comparison_fixed_parameters.fig');
files.report = fullfile(outputDirectory, ...
    'N_comparison_fixed_parameters_report.txt');
files.mat = fullfile(outputDirectory, ...
    'N_comparison_fixed_parameters.mat');

writetable(summaryTable, files.summaryCsv);
writetable(profileTable, files.profileCsv);
make_comparison_figure(NValues, totalDeltaT, relativeDeltaT, ...
    T0, correctedT, termDeltaT, accepted, fixedP0, ...
    fixedPerBarrierG, fixedSupport, figureVisible, ...
    imageResolution, files.png, files.fig);
write_text_report(files.report, result);
result.outputFiles = files;
ndelta.stage12.atomic_save(files.mat, struct('result', result));

fprintf('\nSaved N-comparison outputs in:\n  %s\n', outputDirectory);
disp(summaryTable(:, {'N', 'perBarrierG', 'totalStrength', 'T0', ...
    'deltaT_total', 'deltaT_over_T0', 'T_strictOneLoop', 'accepted'}));
if ~result.accepted
    warning('nqscanN:RejectedCases', ...
        ['At least one N case was rejected.  Inspect the status and error ' ...
         'columns; rejected DeltaT values remain NaN and are not connected.']);
end
end

function positions = equal_support_positions(N, support)
if N == 1
    positions = mean(support);
else
    positions = linspace(support(1), support(2), N);
end
positions = positions(:).';
end

function make_comparison_figure(NValues, totalDeltaT, relativeDeltaT, ...
        T0, correctedT, termDeltaT, accepted, fixedP0, ...
        fixedPerBarrierG, fixedSupport, figureVisible, ...
        imageResolution, pngPath, figPath)
fig = figure('Visible', figureVisible, 'Color', 'w', ...
    'Position', [60, 60, 1180, 850]);
NColumn = NValues(:);

ax1 = subplot(2, 2, 1);
hold(ax1, 'on');
plot(ax1, NColumn, totalDeltaT, '-o', 'Color', [0, 0.4470, 0.7410], ...
    'LineWidth', 1.8, 'MarkerFaceColor', [0, 0.4470, 0.7410]);
plot_zero_line(ax1, NColumn);
mark_rejected(ax1, NColumn, totalDeltaT, accepted);
xlabel(ax1, 'Number of barriers N');
ylabel(ax1, '\Delta T');
title(ax1, sprintf('Total transmission correction, p^0=%.3g', fixedP0), ...
    'FontWeight', 'normal');
format_n_axis(ax1, NValues);
hold(ax1, 'off');

ax2 = subplot(2, 2, 2);
bar(ax2, NColumn, termDeltaT, 'grouped');
hold(ax2, 'on');
plot_zero_line(ax2, NColumn);
xlabel(ax2, 'Number of barriers N');
ylabel(ax2, '\Delta T_j');
title(ax2, 'G1--G4 contributions', 'FontWeight', 'normal');
legend(ax2, {'G1', 'G2', 'G3', 'G4'}, 'Location', 'best');
format_n_axis(ax2, NValues);
hold(ax2, 'off');

ax3 = subplot(2, 2, 3);
hold(ax3, 'on');
plot(ax3, NColumn, T0, '-o', 'LineWidth', 1.6, ...
    'Color', [0.25, 0.25, 0.25], 'MarkerFaceColor', 'w');
plot(ax3, NColumn, correctedT, '-s', 'LineWidth', 1.6, ...
    'Color', [0.8500, 0.3250, 0.0980], ...
    'MarkerFaceColor', [0.8500, 0.3250, 0.0980]);
xlabel(ax3, 'Number of barriers N');
ylabel(ax3, 'Transmission probability');
title(ax3, 'Tree and strict one-loop transmission', ...
    'FontWeight', 'normal');
legend(ax3, {'T_0', 'T_0+\Delta T'}, 'Location', 'best');
format_n_axis(ax3, NValues);
hold(ax3, 'off');

ax4 = subplot(2, 2, 4);
hold(ax4, 'on');
plot(ax4, NColumn, 100 .* relativeDeltaT, '-d', ...
    'Color', [0.4940, 0.1840, 0.5560], 'LineWidth', 1.8, ...
    'MarkerFaceColor', [0.4940, 0.1840, 0.5560]);
plot_zero_line(ax4, NColumn);
xlabel(ax4, 'Number of barriers N');
ylabel(ax4, '100\Delta T/T_0 (percent)');
title(ax4, sprintf(['Relative correction; g_a=%+.3g, ' ...
    'support=[%.2g,%.2g]'], fixedPerBarrierG, ...
    fixedSupport(1), fixedSupport(2)), 'FontWeight', 'normal');
format_n_axis(ax4, NValues);
hold(ax4, 'off');

resolutionFlag = sprintf('-r%d', imageResolution);
print(fig, pngPath, '-dpng', resolutionFlag);
savefig(fig, figPath);
close(fig);
end

function format_n_axis(axesHandle, NValues)
grid(axesHandle, 'on');
box(axesHandle, 'on');
set(axesHandle, 'XTick', NValues(:).');
xlim(axesHandle, [min(NValues) - 0.35, max(NValues) + 0.35]);
end

function plot_zero_line(axesHandle, NValues)
plot(axesHandle, [min(NValues), max(NValues)], [0, 0], ...
    'k:', 'LineWidth', 0.8, 'HandleVisibility', 'off');
end

function mark_rejected(axesHandle, NValues, values, accepted)
rejected = ~accepted(:);
if ~any(rejected)
    return;
end
finiteValues = values(isfinite(values));
if isempty(finiteValues)
    markerY = 0;
else
    markerY = min(finiteValues);
end
plot(axesHandle, NValues(rejected), ...
    repmat(markerY, nnz(rejected), 1), 'rx', 'LineWidth', 1.5, ...
    'MarkerSize', 8, 'DisplayName', 'rejected');
end

function write_text_report(path, result)
fileId = fopen(path, 'w');
if fileId < 0
    error('nqscanN:ReportOpenFailure', ...
        'Could not open the N-comparison report for writing: %s', path);
end
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fixed = result.fixedSettings;
fprintf(fileId, 'Fixed-parameter N=1--5 transmission comparison\n');
fprintf(fileId, 'Engine release: %s\n', ...
    char(result.engineRelease.releaseVersion));
fprintf(fileId, 'Observable: %s\n', result.observable);
fprintf(fileId, 'Engine field used directly: %s\n', ...
    result.observableSource);
fprintf(fileId, 'p0 = %.17g\n', fixed.p0);
fprintf(fileId, 'mphi = %.17g, mPhi = %.17g, mu = %.17g\n', ...
    fixed.mphi, fixed.mPhi, fixed.mu);
fprintf(fileId, 'per-barrier g_a = %+.17g\n', fixed.perBarrierG);
fprintf(fileId, 'support = [%.17g, %.17g]\n', ...
    fixed.support(1), fixed.support(2));
fprintf(fileId, 'reference q0 diagnostic = %.17g\n', ...
    fixed.referenceQ0Diagnostic);
fprintf(fileId, 'reference qPerp diagnostic = %.17g\n', ...
    fixed.referenceQPerpDiagnostic);
fprintf(fileId, ['q0 note: complete DeltaT integrates internal q0; ' ...
    'the value above is diagnostic only.\n']);
fprintf(fileId, ['strength convention: every centre has the same g_a; ' ...
    'total signed strength is N*g_a.\n\n']);
fprintf(fileId, ['N  totalStrength             T0             DeltaT' ...
    '        DeltaT/T0        T0+DeltaT      assemblyResidual' ...
    '  accepted  status\n']);
tableData = result.summary;
for row = 1:height(tableData)
    fprintf(fileId, ...
        ['%d  %+.10e  %.10e  %+.10e  %+.10e  %.10e  %.3e' ...
         '  %d  %s\n'], ...
        tableData.N(row), tableData.totalStrength(row), ...
        tableData.T0(row), tableData.deltaT_total(row), ...
        tableData.deltaT_over_T0(row), ...
        tableData.T_strictOneLoop(row), ...
        tableData.interferenceAssemblyResidual(row), ...
        tableData.accepted(row), ...
        tableData.status{row});
end
fprintf(fileId, '\nOverall status: %s\n', result.status);
end

function assert_bundled_engine(engineRoot)
assert_bundled_function('run_stage0', ...
    fullfile(engineRoot, 'run_stage0.m'));
assert_bundled_function('ndelta.config.release_contract', ...
    fullfile(engineRoot, '+ndelta', '+config', 'release_contract.m'));
assert_bundled_function('ndelta.stage12.evaluate_direction', ...
    fullfile(engineRoot, '+ndelta', '+stage12', 'evaluate_direction.m'));
end

function assert_bundled_function(functionName, expectedPath)
resolvedPath = which(functionName);
if ~same_path(resolvedPath, expectedPath)
    if isempty(resolvedPath)
        resolvedPath = '<not found>';
    end
    error('nqscanN:WrongEngineOnPath', ...
        ['%s resolves to %s, not the bundled engine %s. Run ' ...
         '"clear functions; rehash" from this package directory.'], ...
        functionName, resolvedPath, expectedPath);
end
end

function accepted = same_path(left, right)
if isempty(left) || isempty(right)
    accepted = false;
    return;
end
left = strrep(left, '\', '/');
right = strrep(right, '\', '/');
if ispc
    accepted = strcmpi(left, right);
else
    accepted = strcmp(left, right);
end
end

function ensure_directory(path)
if exist(path, 'dir')
    return;
end
[created, message] = mkdir(path);
if ~created
    error('nqscanN:OutputDirectoryFailure', ...
        'Could not create output directory %s: %s', path, message);
end
end

function validate_user_settings(NValues, fixedP0, mphi, mPhi, mu, ...
        fixedPerBarrierG, fixedSupport, fixedReferenceQ0, ...
        fixedReferenceQPerp, orderFactor, outputDirectoryName, ...
        figureVisible, imageResolution, showProgress)
if ~isnumeric(NValues) || ~isequal(NValues(:).', 1:5)
    error('nqscanN:InvalidNValues', ...
        'NValues must be exactly 1:5 for this comparison.');
end
validateattributes(mphi, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'mphi');
validateattributes(mPhi, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'mPhi');
validateattributes(mu, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'mu');
validateattributes(fixedP0, {'numeric'}, ...
    {'real', 'finite', 'scalar', '>', mphi, '<', mphi + mPhi}, ...
    mfilename, 'fixedP0');
validateattributes(fixedPerBarrierG, {'numeric'}, ...
    {'real', 'finite', 'nonzero', 'scalar'}, ...
    mfilename, 'fixedPerBarrierG');
if ~isnumeric(fixedSupport) || ~isreal(fixedSupport) || ...
        ~isequal(size(fixedSupport), [1, 2]) || ...
        any(~isfinite(fixedSupport)) || fixedSupport(2) <= fixedSupport(1)
    error('nqscanN:InvalidSupport', ...
        'fixedSupport must be a finite increasing 1-by-2 vector.');
end
validateattributes(fixedReferenceQ0, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'fixedReferenceQ0');
validateattributes(fixedReferenceQPerp, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, ...
    mfilename, 'fixedReferenceQPerp');
validateattributes(orderFactor, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'orderFactor');
if ~(ischar(outputDirectoryName) && ~isempty(strtrim(outputDirectoryName)))
    error('nqscanN:InvalidOutputDirectory', ...
        'outputDirectoryName must be nonempty text.');
end
normalised = strrep(outputDirectoryName, '\', '/');
segments = regexp(normalised, '/', 'split');
if normalised(1) == '/' || ...
        ~isempty(regexp(normalised, '^[A-Za-z]:', 'once')) || ...
        any(strcmp(segments, '.')) || any(strcmp(segments, '..'))
    error('nqscanN:UnsafeOutputDirectory', ...
        'outputDirectoryName must be a safe relative path.');
end
if ~any(strcmp(figureVisible, {'on', 'off'}))
    error('nqscanN:InvalidFigureVisibility', ...
        'figureVisible must be ''on'' or ''off''.');
end
validateattributes(imageResolution, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 72, 'scalar'}, ...
    mfilename, 'imageResolution');
if ~islogical(showProgress) || ~isscalar(showProgress)
    error('nqscanN:InvalidProgressSwitch', ...
        'showProgress must be a logical scalar.');
end
end

function accepted = is_user_interrupt(cause)
identifier = lower(cause.identifier);
message = lower(cause.message);
accepted = ~isempty(strfind(identifier, 'operationterminated')) || ...
    ~isempty(strfind(identifier, 'executioninterrupted')) || ...
    ~isempty(strfind(message, 'operation terminated by user')) || ...
    ~isempty(strfind(message, 'execution interrupted by user'));
end
