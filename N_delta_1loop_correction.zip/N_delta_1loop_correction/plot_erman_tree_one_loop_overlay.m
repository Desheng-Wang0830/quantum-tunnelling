function files = plot_erman_tree_one_loop_overlay(prescan, result)
%PLOT_ERMAN_TREE_ONE_LOOP_OVERLAY Dense tree curve plus sparse loop points.
%
%   The corrected one-loop points are intentionally markers only.  The
%   function never interpolates sparse G1--G4 results into a fake dense
%   one-loop curve.

narginchk(2, 2);
if ~isstruct(prescan) || ~isscalar(prescan) || ...
        ~all(isfield(prescan, {'P', 'T0', 'elasticUpperMomentum'}))
    error('nqscanErman:InvalidPrescan', ...
        'prescan must be returned by run_erman_tree_prescan.');
end
if ~isstruct(result) || ~isscalar(result) || ~isfield(result, 'data')
    error('nqscanErman:InvalidLoopResult', ...
        'result must be returned by run_arbitrary_N_energy_scan.');
end

data = result.data;
required = {'externalEnergy', 'treeProbabilities', ...
    'correctedProbabilities', 'totalDeltaProbabilities', 'accepted'};
if ~all(isfield(data, required))
    error('nqscanErman:IncompleteLoopResult', ...
        'The loop result is missing required probability fields.');
end

loopEnergy = data.externalEnergy(:);
if isfield(data, 'P')
    loopP = data.P(:);
else
    loopP = sqrt(max(loopEnergy.^2 - ...
        result.settings.model.mphi.^2, 0));
end
treeAtLoop = data.treeProbabilities(:, 1);
correctedAtLoop = data.correctedProbabilities(:, 1);
deltaT = data.totalDeltaProbabilities(:, 1);
acceptedMask = logical(data.accepted(:));
relativePercent = 100 .* deltaT ./ treeAtLoop;

if isfield(result, 'outputFiles') && ...
        isfield(result.outputFiles, 'outputDirectory')
    outputDirectory = result.outputFiles.outputDirectory;
else
    packageRoot = fileparts(mfilename('fullpath'));
    outputDirectory = fullfile(packageRoot, ...
        result.settings.output.directoryName);
end
ensure_directory(outputDirectory);

figureHandle = figure('Visible', result.settings.output.figureVisible, ...
    'Color', 'w', 'Position', [90, 90, 1120, 820]);

topAxes = subplot(2, 1, 1);
hold(topAxes, 'on');
denseMask = prescan.P <= prescan.elasticUpperMomentum;
denseHandle = plot(topAxes, prescan.P(denseMask), ...
    prescan.T0(denseMask), '-', 'Color', [0.00, 0.35, 0.75], ...
    'LineWidth', 1.5);
loopTreeHandle = plot(topAxes, loopP(acceptedMask), ...
    treeAtLoop(acceptedMask), 'x', 'Color', [0.10, 0.10, 0.10], ...
    'MarkerSize', 7, 'LineWidth', 1.2, 'LineStyle', 'none');
correctedHandle = plot(topAxes, loopP(acceptedMask), ...
    correctedAtLoop(acceptedMask), 'o', 'Color', [0.85, 0.20, 0.10], ...
    'MarkerFaceColor', 'none', 'MarkerSize', 6, 'LineWidth', 1.4, ...
    'LineStyle', 'none');
grid(topAxes, 'on');
box(topAxes, 'on');
xlabel(topAxes, 'External momentum P');
ylabel(topAxes, 'Transmission probability');
ylim(topAxes, [0, 1.05]);
xlim(topAxes, [prescan.P(1), prescan.elasticUpperMomentum]);
title(topAxes, [ ...
    'Dense exact tree curve and sparse one-loop evaluations'], ...
    'FontWeight', 'normal');
legend(topAxes, [denseHandle, loopTreeHandle, correctedHandle], ...
    {'dense exact T_0', 'T_0 at loop nodes', ...
    'T_0+\Delta T at loop nodes (no interpolation)'}, ...
    'Location', 'best');
hold(topAxes, 'off');

bottomAxes = subplot(2, 1, 2);
hold(bottomAxes, 'on');
relativeHandle = plot(bottomAxes, loopP(acceptedMask), ...
    relativePercent(acceptedMask), 'o', ...
    'Color', [0.45, 0.10, 0.65], 'MarkerFaceColor', [0.45, 0.10, 0.65], ...
    'MarkerSize', 5, 'LineStyle', 'none');
plot(bottomAxes, [min(loopP), max(loopP)], [0, 0], 'k:', ...
    'LineWidth', 0.9, 'HandleVisibility', 'off');
grid(bottomAxes, 'on');
box(bottomAxes, 'on');
xlabel(bottomAxes, 'External momentum P');
ylabel(bottomAxes, '100\Delta T/T_0 (percent)');
title(bottomAxes, [ ...
    'Strict O(\mu^2) loop correction at the selected nodes'], ...
    'FontWeight', 'normal');
legend(bottomAxes, relativeHandle, {'relative one-loop correction'}, ...
    'Location', 'best');
hold(bottomAxes, 'off');

files = struct('png', '', 'fig', '');
if result.settings.output.writePng
    files.png = fullfile(outputDirectory, ...
        'erman_dense_tree_sparse_one_loop_overlay.png');
    print(figureHandle, files.png, '-dpng', sprintf('-r%d', ...
        result.settings.output.imageResolution));
end
if result.settings.output.writeFig
    files.fig = fullfile(outputDirectory, ...
        'erman_dense_tree_sparse_one_loop_overlay.fig');
    savefig(figureHandle, files.fig);
end
close(figureHandle);
end

function ensure_directory(path)
if ~exist(path, 'dir')
    [created, message] = mkdir(path);
    if ~created
        error('nqscanErman:OutputDirectoryCreationFailed', ...
            'Could not create %s: %s', path, message);
    end
end
end
