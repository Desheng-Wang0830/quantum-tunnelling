function config = final_validation_config()
%FINAL_VALIDATION_CONFIG Frozen cases and cross-machine acceptance gates.
%
% The tests distinguish exact algebraic identities from numerical
% quadrature comparisons.  Never replace these tolerances by the smallest
% residual observed on one machine.

validationRoot = fileparts(mfilename('fullpath'));
config.validationRoot = validationRoot;
config.solverRoot = fileparts(validationRoot);
config.engineRoot = fullfile(config.solverRoot, 'engine');
config.testsRoot = fullfile(validationRoot, 'tests');
config.stageSuiteRoot = fullfile(validationRoot, 'stage_suite_v196');
config.defaultOutputDirectory = fullfile( ...
    config.solverRoot, 'final_validation_output');

config.expectedEngineRelease = '1.9.6';
config.expectedValidationHardening = '1.0.0';
config.expectedLegacyUnitTests = 196;
config.strictPerturbativeOrder = 'O(mu^2)';

% Exact/analytic gates.
config.tol.analytic = 1e-12;
config.tol.matrixResidual = 1e-12;
config.tol.treeClosure = 1e-12;

% Integrated quantities.  These are deliberately 1e-6--1e-8, not the
% approximately 1e-15 residuals seen in one saved data set.
config.tol.loopClosurePerMu2 = 1e-8;
config.tol.integratedSymmetryAbs = 1e-10;
config.tol.integratedSymmetryRel = 1e-8;
config.tol.muScalingAbs = 1e-12;
config.tol.muScalingRel = 1e-8;
config.tol.quadratureAbs = 1e-10;
config.tol.quadratureRel = 1e-6;
config.tol.mappingAbs = 1e-10;
config.tol.mappingRel = 1e-6;
config.tol.sheetContract = 1e-12;
config.tol.gammaGuardResidual = 1e-12;
config.tol.n1G1Kernel = 1e-7;
config.tol.n1G1Probability = 1e-8;

% Physics-asymptotic gates are not floating-point tolerances.
% Heavy-field decoupling is allowed to carry the logarithmic enhancement
% expected of a four-dimensional loop.  Therefore the final gate tests a
% negative effective power safely below -1 (rather than over-claiming an
% exact pure mPhi^(-2) law from three points).
config.tol.decouplingMaximumSlope = -1.5;
config.tol.decouplingConvergenceAbs = 1e-8;
config.tol.decouplingConvergenceRel = 1e-6;
config.tol.perturbativeRatio = 5e-2;

config.cases.symmetricN2 = struct( ...
    'name', 'symmetric_N2', 'mphi', 0.2, 'mPhi', 1.4, ...
    'mu', 0.05, 'energy', 0.8, ...
    'positions', [-0.5, 0.5], 'strengths', [0.15, 0.15]);
config.cases.symmetricN3 = struct( ...
    'name', 'symmetric_N3', 'mphi', 0.2, 'mPhi', 1.4, ...
    'mu', 0.05, 'energy', 0.8, ...
    'positions', [-0.5, 0, 0.5], ...
    'strengths', [0.075, 0.15, 0.075]);
config.cases.n1Repulsive = struct( ...
    'name', 'N1_repulsive', 'mphi', 0.2, 'mPhi', 1.4, ...
    'mu', 0.05, 'energy', 0.3, ...
    'positions', 0, 'strengths', 0.3);
config.cases.mixedN2 = struct( ...
    'name', 'mixed_sign_N2', 'mphi', 0.2, 'mPhi', 1.4, ...
    'mu', 0.05, 'energy', 0.3, ...
    'positions', [-6, 6], 'strengths', [0.3, -0.3]);
% The asymmetric route-separation gate is deliberately many orders above
% roundoff but far below the independently observed O(1e-3) difference.
config.minimumAsymmetricG2G3Difference = 1e-6;

config.muValues = [0.025, 0.05, 0.10, 0.20];
% These masses are already 500--5000 times the light mass, while avoiding
% the artificial dynamic range of the previous 1e4--1e5 scan.  Every mass
% is recomputed at both orders below.  The q4 and qPerp mapping scales are
% set in R06 to geometric means of the light and heavy scales, so neither
% the low-momentum region nor q~mPhi is silently discarded.
config.decouplingMasses = [100, 300, 1000];
config.decouplingOrderFactors = [4.0, 5.6];
config.decouplingScaleCrosscheckFactor = 2.0;
config.minimumPhaseReferenceAmplitude = 1e-3;
config.minimumDecouplingBandNodes = 4;
% Four levels make the final progression test independent of the final
% tolerance gate.  The last pair is the actual acceptance comparison.
config.quadratureFactors = [2.0, 2.8, 4.0, 5.6];
config.productionOrderFactor = 2.0;
config.mappingQPerp = 0.1;
config.mappingOrder = 64;
config.mappingQPerpOrder = 48;
config.cutoffSegmentEdges = ...
    [0, 0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64];
config.cutoffSegmentOrder = 32;
config.cutoffQPerpSegmentEdges = ...
    [0, 0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64, 128];
config.cutoffQPerpSegmentOrder = 24;
% Conditioning gates.  The external tree Gamma is comfortably conditioned
% in the frozen production cases.  Internal contour nodes are assessed with
% the balanced scaled system near K=0.  The explicit 1e-6 final gate caps
% accepted-node condition amplification at 1e6; R10 measures the actual
% margin afresh instead of assuming a value from historical output.
config.minimumExternalGammaRcond = 1e-2;
config.minimumInternalTauScaledRcond = 1e-6;

config.requireLegacySuite = true;
config.requireAllMandatoryTests = true;
config.writeRawMat = true;
config.frozenManifestPath = fullfile(config.validationRoot, ...
    'FROZEN_SOURCE_MANIFEST.json');
end
