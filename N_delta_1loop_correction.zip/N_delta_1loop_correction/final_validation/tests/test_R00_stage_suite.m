function result = test_R00_stage_suite(config)
%TEST_R00_STAGE_SUITE Rerun the frozen v1.9.6 matlab.unittest suite.

suite = testsuite(fullfile(config.stageSuiteRoot, 'tests'), ...
    'IncludeSubfolders', true);
rawResults = run(suite);
discovered = numel(rawResults);
passed = sum([rawResults.Passed]);
failed = sum([rawResults.Failed]);
incomplete = sum([rawResults.Incomplete]);
metrics(1) = fv.metric('legacy_tests_not_passed', ...
    discovered - passed, 0, discovered == passed, ...
    'Every discovered Stage 0--12 test must pass in this run.');
metrics(2) = fv.metric('legacy_test_discovery_difference', ...
    abs(discovered - config.expectedLegacyUnitTests), 0, ...
    discovered == config.expectedLegacyUnitTests, ...
    'The frozen release contract requires exactly 196 tests.');
% Keep matlab.unittest objects out of the persistent report.  TestResult
% objects are useful interactively but are not portable JSON/MAT payloads
% across MATLAB releases.  The scalar outcome table preserves everything
% required to identify and rerun a failing legacy test.
testNames = cell(discovered, 1);
testPassed = false(discovered, 1);
testFailed = false(discovered, 1);
testIncomplete = false(discovered, 1);
testDurations = zeros(discovered, 1);
for index = 1:discovered
    testNames{index} = rawResults(index).Name;
    testPassed(index) = rawResults(index).Passed;
    testFailed(index) = rawResults(index).Failed;
    testIncomplete(index) = rawResults(index).Incomplete;
    % TestResult.Duration has appeared as both a numeric seconds value and
    % a duration scalar across supported MATLAB releases.  Normalise it
    % without constructing a duration from an already numeric value.
    durationValue = rawResults(index).Duration;
    if isa(durationValue, 'duration')
        testDurations(index) = seconds(durationValue);
    else
        testDurations(index) = double(durationValue);
    end
end
raw = struct('numberDiscovered', discovered, ...
    'numberPassed', passed, 'numberFailed', failed, ...
    'numberIncomplete', incomplete, 'testNames', {testNames}, ...
    'passed', testPassed, 'failed', testFailed, ...
    'incomplete', testIncomplete, 'durationSeconds', testDurations);
notPassedNames = testNames(testFailed | testIncomplete);
if isempty(notPassedNames)
    details = sprintf('Fresh matlab.unittest result: %d/%d.', ...
        passed, discovered);
else
    details = sprintf(['Fresh matlab.unittest result: %d/%d. ' ...
        'Not passed: %s'], passed, discovered, ...
        strjoin(notPassedNames, '; '));
end
result = fv.test_result('R00', ...
    'Frozen v1.9.6 Stage 0--12 suite rerun', metrics, ...
    details, raw);
end
