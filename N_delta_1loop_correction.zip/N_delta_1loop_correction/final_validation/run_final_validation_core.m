function validation = run_final_validation_core(outputDirectory)
%RUN_FINAL_VALIDATION_CORE Run mandatory frozen-code validation and report it.
%
%   VALIDATION = RUN_FINAL_VALIDATION() runs R00--R10 in order, verifies
%   that the frozen source tree did not change during the run (R99), and
%   writes machine-readable and human-readable evidence under the default
%   final_validation_output directory.
%
%   VALIDATION = RUN_FINAL_VALIDATION(OUTPUTDIRECTORY) selects a different
%   report directory.  Numerical failures do not throw here: reports are
%   always written first.  Use RUN_FINAL_VALIDATION_CI for a throwing CI
%   entry point.

validationRoot = fileparts(mfilename('fullpath'));
addpath(fileparts(validationRoot));
addpath(validationRoot);
config = final_validation_config();

% Add the bundled paths in increasing precedence.  The frozen engine is
% deliberately last so run_stage0 and +ndelta cannot be shadowed by a
% different checkout already present on the user's MATLAB path.
addpath(config.solverRoot);
addpath(config.validationRoot);
addpath(config.testsRoot);
addpath(config.stageSuiteRoot);
addpath(config.engineRoot);
rehash;

if nargin < 1 || isempty(outputDirectory)
    outputDirectory = config.defaultOutputDirectory;
end
outputDirectory = canonical_path(outputDirectory);
validate_output_directory(outputDirectory, config);
manifestExclusionDirectory = manifest_exclusion_directory( ...
    outputDirectory, config);
if exist(outputDirectory, 'dir') ~= 7
    [created, message] = mkdir(outputDirectory);
    if ~created
        error('finalval:OutputDirectoryCreationFailure', ...
            'Cannot create output directory %s: %s', ...
            outputDirectory, message);
    end
end

startedAt = datestr(now, 30);
runClock = tic;
fv.live_point();

% Capture source state before any numerical work.  The output directory is
% excluded even when it lies inside the bundled solver directory.
[manifestBefore, manifestBeforeError] = safe_manifest( ...
    config.solverRoot, manifestExclusionDirectory);
[preflight, preflightError] = safe_preflight(config);
environment = fv.environment(config, preflight);
if ~isempty(preflightError.identifier)
    environment.preflightErrorIdentifier = preflightError.identifier;
    environment.preflightErrorMessage = preflightError.message;
else
    environment.preflightErrorIdentifier = '';
    environment.preflightErrorMessage = '';
end

ids = {'R00', 'R01', 'R02', 'R03', 'R04', 'R05', ...
    'R06', 'R07', 'R08', 'R09', 'R10'};
requirements = { ...
    'Frozen v1.9.6 Stage 0--12 suite rerun', ...
    'T0+R0=1', ...
    'deltaT+deltaR=0 at strict O(mu^2)', ...
    'N=1 analytic reductions', ...
    'G2=G3 for a mirror-symmetric array', ...
    'Small-mu mu^2 scaling', ...
    'Large-mPhi decoupling', ...
    'Quadrature-order convergence', ...
    'Mapped-infinite versus finite-cutoff integration', ...
    'Endpoint, pole, branch-cut and physical-sheet tests', ...
    'Gamma_N invertibility and condition-number guard'};
testFunctions = {@test_R00_stage_suite, @test_R01_tree_unitarity, ...
    @test_R02_loop_closure, @test_R03_n1_analytic, ...
    @test_R04_g2_g3_symmetry, @test_R05_mu2_scaling, ...
    @test_R06_heavy_mass_decoupling, ...
    @test_R07_quadrature_convergence, ...
    @test_R08_mapping_vs_cutoff, ...
    @test_R09_singularity_sheet, ...
    @test_R10_gamma_guard};

emptyResult = fv.error_result('', '', ...
    struct('identifier', 'finalval:NotRun', 'message', 'Not run.'));
results = repmat(emptyResult, 1, numel(testFunctions) + 1);
for index = 1:numel(testFunctions)
    testClock = tic;
    try
        % A failed preflight means the frozen implementation is not the
        % implementation MATLAB would execute.  Record an ERROR for every
        % mandatory numerical item instead of silently testing shadow code.
        if ~isempty(preflightError.identifier)
            error(preflightError.identifier, '%s', preflightError.message);
        end
        result = testFunctions{index}(config);
        result = normalise_result(result, ids{index}, ...
            requirements{index});
    catch cause
        result = fv.error_result(ids{index}, ...
            requirements{index}, cause);
    end
    result.durationSeconds = toc(testClock);
    results(index) = result;
end

% The final manifest is taken after all tests but before writing reports.
% Therefore generated evidence cannot hide an in-run source modification.
manifestClock = tic;
[manifestAfter, manifestAfterError] = safe_manifest( ...
    config.solverRoot, manifestExclusionDirectory);
if ~isempty(manifestBeforeError.identifier)
    sourceResult = fv.error_result('R99', ...
        'Frozen source manifest unchanged during validation', ...
        manifestBeforeError);
elseif ~isempty(manifestAfterError.identifier)
    sourceResult = fv.error_result('R99', ...
        'Frozen source manifest unchanged during validation', ...
        manifestAfterError);
else
    sameCount = manifestBefore.numberOfFiles == ...
        manifestAfter.numberOfFiles;
    sameAggregate = strcmp(manifestBefore.aggregateSha256, ...
        manifestAfter.aggregateSha256);
    sameEntries = isequal(manifestBefore.entries, manifestAfter.entries);
    unchanged = sameCount && sameAggregate && sameEntries;
    [baseline, baselineError] = safe_baseline(config.frozenManifestPath);
    if isempty(baselineError.identifier)
        baselineCount = manifestBefore.numberOfFiles == ...
            baseline.numberOfFiles;
        baselineAggregate = strcmp(manifestBefore.aggregateSha256, ...
            baseline.aggregateSha256);
        baselineEntries = manifest_entries_equal( ...
            manifestBefore.entries, baseline.entries);
    else
        baselineCount = false;
        baselineAggregate = false;
        baselineEntries = false;
    end
    baselineAccepted = baselineCount && baselineAggregate && ...
        baselineEntries;
    [suiteAccepted, suiteAudit] = mandatory_suite_integrity( ...
        results(1:numel(testFunctions)), ids, ...
        config.requireAllMandatoryTests);
    metrics(1) = fv.metric('source_file_count_changed', ...
        double(~sameCount), 0, sameCount, ...
        'File count before and after the numerical run.');
    metrics(2) = fv.metric('source_aggregate_hash_changed', ...
        double(~sameAggregate), 0, sameAggregate, ...
        'SHA-256 aggregate over paths and per-file SHA-256 values.');
    metrics(3) = fv.metric('source_manifest_entries_changed', ...
        double(~sameEntries), 0, sameEntries, ...
        'Exact path/hash manifest comparison.');
    metrics(4) = fv.metric('frozen_baseline_manifest_mismatch', ...
        double(~baselineAccepted), 0, baselineAccepted, ...
        sprintf('Baseline read error: %s.', baselineError.identifier));
    metrics(5) = fv.metric('mandatory_test_set_or_schema_failure', ...
        double(~suiteAccepted), 0, suiteAccepted, ...
        ['IDs must be exactly R00--R10 plus prospective R99; every ' ...
        'result and metric must satisfy the frozen schema.']);
    raw = struct('unchanged', unchanged, ...
        'beforeAggregateSha256', manifestBefore.aggregateSha256, ...
        'afterAggregateSha256', manifestAfter.aggregateSha256, ...
        'baselineAggregateSha256', baseline_hash(baseline), ...
        'baselineError', baselineError, ...
        'baselineAccepted', baselineAccepted, ...
        'suiteAudit', suiteAudit, ...
        'numberOfFiles', manifestAfter.numberOfFiles);
    sourceResult = fv.test_result('R99', ...
        'Frozen source identity and validation-suite integrity', ...
        metrics, ['The reserved report directory and the self-referential ' ...
        'baseline file are excluded.  All other MATLAB/source ' ...
        'documentation files must match the shipped SHA-256 baseline and ' ...
        'remain unchanged during the run.'], raw);
end
sourceResult.durationSeconds = toc(manifestClock);
results(end) = sourceResult;

overallStatus = aggregate_status(results);
validation = struct();
validation.schemaVersion = 'final-validation-1.0';
validation.generatedFresh = true;
validation.startedAt = startedAt;
validation.completedAt = datestr(now, 30);
validation.durationSeconds = toc(runClock);
validation.overallStatus = overallStatus;
validation.passed = strcmp(overallStatus, 'PASS');
validation.strictPerturbativeOrder = config.strictPerturbativeOrder;
validation.outputDirectory = outputDirectory;
validation.environment = environment;
validation.preflight = preflight;
validation.manifestBefore = manifestBefore;
validation.manifestAfter = manifestAfter;
validation.results = results;
validation.counts = status_counts(results);
validation = fv.write_reports(validation, outputDirectory);

fprintf('Final validation: %s (%d PASS, %d FAIL, %d INCOMPLETE, %d ERROR)\n', ...
    validation.overallStatus, validation.counts.PASS, ...
    validation.counts.FAIL, validation.counts.INCOMPLETE, ...
    validation.counts.ERROR);
fprintf('Report: %s\n', validation.artifacts.markdownReport);
end

function validate_output_directory(outputDirectory, config)
solverRoot = canonical_path(config.solverRoot);
reservedRoot = canonical_path(config.defaultOutputDirectory);
if is_under_path(outputDirectory, solverRoot) && ...
        ~is_under_path(outputDirectory, reservedRoot)
    error('finalval:UnsafeInTreeOutputDirectory', ...
        ['An output directory inside the frozen package is allowed only ' ...
        'under final_validation_output.  Otherwise it could exclude ' ...
        'engine or test sources from R99.']);
end
end

function value = manifest_exclusion_directory(outputDirectory, config)
reservedRoot = canonical_path(config.defaultOutputDirectory);
% The reserved in-package output tree must always be excluded.  An
% external output directory is already outside solverRoot; returning it
% here would accidentally re-include reports from an earlier default run.
value = reservedRoot;
end

function value = canonical_path(path)
value = char(java.io.File(path).getCanonicalPath());
end

function accepted = is_under_path(path, parent)
if ispc
    path = lower(strrep(path, '\', '/'));
    parent = lower(strrep(parent, '\', '/'));
else
    path = strrep(path, '\', '/');
    parent = strrep(parent, '\', '/');
end
accepted = strcmp(path, parent) || ...
    strncmp(path, [parent, '/'], numel(parent) + 1);
end

function [baseline, cause] = safe_baseline(path)
cause = empty_cause();
baseline = struct();
try
    if exist(path, 'file') ~= 2
        error('finalval:FrozenBaselineMissing', ...
            'Frozen source baseline is missing: %s', path);
    end
    baseline = jsondecode(fileread(path));
    required = {'algorithm', 'numberOfFiles', ...
        'aggregateSha256', 'entries'};
    if ~isstruct(baseline) || ~isscalar(baseline) || ...
            ~all(isfield(baseline, required)) || ...
            ~valid_baseline_schema(baseline)
        error('finalval:InvalidFrozenBaseline', ...
            'Frozen source baseline has an invalid schema.');
    end
catch caught
    cause = cause_struct(caught);
    baseline = struct();
end
end

function accepted = valid_baseline_schema(baseline)
validAlgorithm = ischar(baseline.algorithm) && ...
    strcmp(baseline.algorithm, 'SHA-256');
validCount = isnumeric(baseline.numberOfFiles) && ...
    isscalar(baseline.numberOfFiles) && ...
    isfinite(baseline.numberOfFiles) && ...
    baseline.numberOfFiles >= 0 && ...
    baseline.numberOfFiles == floor(baseline.numberOfFiles);
validAggregate = valid_sha256(baseline.aggregateSha256);
validEntries = isstruct(baseline.entries) && ...
    numel(baseline.entries) == baseline.numberOfFiles;
if validEntries && ~isempty(baseline.entries)
    validEntries = all(isfield(baseline.entries, ...
        {'relativePath', 'sha256'}));
end
if validEntries
    paths = reshape({baseline.entries.relativePath}, [], 1);
    hashes = reshape({baseline.entries.sha256}, [], 1);
    validEntries = all(cellfun(@(value) ischar(value) && ...
        isrow(value) && ~isempty(value), paths)) && ...
        all(cellfun(@valid_sha256, hashes)) && ...
        numel(unique(paths)) == numel(paths) && ...
        isequal(paths, sort(paths));
end
accepted = validAlgorithm && validCount && validAggregate && validEntries;
end

function accepted = valid_sha256(value)
accepted = ischar(value) && isrow(value) && ...
    ~isempty(regexp(value, '^[0-9a-f]{64}$', 'once'));
end

function value = baseline_hash(baseline)
if isstruct(baseline) && isscalar(baseline) && ...
        isfield(baseline, 'aggregateSha256')
    value = baseline.aggregateSha256;
else
    value = '';
end
end

function accepted = manifest_entries_equal(left, right)
required = {'relativePath', 'sha256'};
accepted = isstruct(left) && isstruct(right) && ...
    all(isfield(left, required)) && all(isfield(right, required)) && ...
    numel(left) == numel(right);
if ~accepted
    return;
end
leftPaths = reshape({left.relativePath}, [], 1);
rightPaths = reshape({right.relativePath}, [], 1);
leftHashes = reshape({left.sha256}, [], 1);
rightHashes = reshape({right.sha256}, [], 1);
accepted = isequal(leftPaths, rightPaths) && ...
    isequal(leftHashes, rightHashes);
end

function [accepted, audit] = mandatory_suite_integrity( ...
        results, expectedIds, required)
actualIds = {results.id};
prospectiveIds = [actualIds, {'R99'}];
expectedFull = [expectedIds, {'R99'}];
idsAccepted = isequal(prospectiveIds, expectedFull) && ...
    numel(unique(prospectiveIds)) == numel(expectedFull);
resultFields = {'id', 'requirement', 'mandatory', 'status', 'passed', ...
    'worstNormalisedMetric', 'metrics', 'details', 'durationSeconds', ...
    'errorIdentifier', 'errorMessage', 'raw'};
metricFields = {'name', 'value', 'tolerance', 'passed', 'note'};
resultSchemaAccepted = true;
metricSchemaAccepted = true;
mandatoryAccepted = true;
for index = 1:numel(results)
    item = results(index);
    resultSchemaAccepted = resultSchemaAccepted && ...
        isstruct(item) && isscalar(item) && ...
        all(isfield(item, resultFields));
    mandatoryAccepted = mandatoryAccepted && ...
        islogical(item.mandatory) && isscalar(item.mandatory) && ...
        item.mandatory;
    metricSchemaAccepted = metricSchemaAccepted && ...
        isstruct(item.metrics) && ~isempty(item.metrics) && ...
        all(isfield(item.metrics, metricFields));
end
accepted = (~required) || (idsAccepted && resultSchemaAccepted && ...
    metricSchemaAccepted && mandatoryAccepted);
audit = struct('required', required, 'expectedIds', {expectedFull}, ...
    'actualProspectiveIds', {prospectiveIds}, ...
    'idsAccepted', idsAccepted, ...
    'resultSchemaAccepted', resultSchemaAccepted, ...
    'metricSchemaAccepted', metricSchemaAccepted, ...
    'mandatoryFlagsAccepted', mandatoryAccepted, ...
    'accepted', accepted);
end

function [manifest, cause] = safe_manifest(rootDirectory, outputDirectory)
cause = empty_cause();
try
    manifest = fv.freeze_manifest(rootDirectory, outputDirectory);
catch caught
    cause = cause_struct(caught);
    manifest = struct('available', false, ...
        'errorIdentifier', caught.identifier, ...
        'errorMessage', caught.message);
end
end

function [report, cause] = safe_preflight(config)
cause = empty_cause();
try
    report = fv.preflight(config);
catch caught
    cause = cause_struct(caught);
    report = struct('accepted', false, ...
        'errorIdentifier', caught.identifier, ...
        'errorMessage', caught.message);
end
end

function value = empty_cause()
value = struct('identifier', '', 'message', '');
end

function value = cause_struct(cause)
value = struct('identifier', cause.identifier, 'message', cause.message);
end

function result = normalise_result(result, id, requirement)
requiredFields = {'id', 'requirement', 'mandatory', 'status', 'passed', ...
    'worstNormalisedMetric', 'metrics', 'details', 'durationSeconds', ...
    'errorIdentifier', 'errorMessage', 'raw'};
if ~isstruct(result) || ~isscalar(result) || ...
        ~all(isfield(result, requiredFields))
    error('finalval:InvalidTestResult', ...
        '%s did not return the required scalar result structure.', id);
end
if ~strcmp(result.id, id)
    error('finalval:InvalidTestIdentifier', ...
        'Expected %s but test returned %s.', id, result.id);
end
result.requirement = requirement;
result.mandatory = true;
valid = {'PASS', 'FAIL', 'INCOMPLETE', 'ERROR'};
if ~any(strcmp(result.status, valid))
    error('finalval:InvalidTestStatus', ...
        '%s returned unsupported status %s.', id, result.status);
end
result.passed = strcmp(result.status, 'PASS');
end

function status = aggregate_status(results)
statuses = {results.status};
if any(strcmp(statuses, 'ERROR'))
    status = 'ERROR';
elseif any(strcmp(statuses, 'FAIL'))
    status = 'FAIL';
elseif any(strcmp(statuses, 'INCOMPLETE'))
    status = 'INCOMPLETE';
else
    status = 'PASS';
end
end

function counts = status_counts(results)
statuses = {results.status};
counts = struct('PASS', sum(strcmp(statuses, 'PASS')), ...
    'FAIL', sum(strcmp(statuses, 'FAIL')), ...
    'INCOMPLETE', sum(strcmp(statuses, 'INCOMPLETE')), ...
    'ERROR', sum(strcmp(statuses, 'ERROR')), ...
    'TOTAL', numel(results));
end
