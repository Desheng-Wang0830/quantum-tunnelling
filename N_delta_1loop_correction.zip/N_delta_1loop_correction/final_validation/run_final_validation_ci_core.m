function validation = run_final_validation_ci_core(outputDirectory)
%RUN_FINAL_VALIDATION_CI_CORE Report first, then fail CI on non-PASS.

if nargin < 1
    validation = run_final_validation_core();
else
    validation = run_final_validation_core(outputDirectory);
end
if ~strcmp(validation.overallStatus, 'PASS')
    error('finalval:MandatoryValidationDidNotPass', ...
        ['Final validation finished with status %s. Evidence was written ' ...
         'to %s before this CI error was raised.'], ...
        validation.overallStatus, validation.outputDirectory);
end
end
