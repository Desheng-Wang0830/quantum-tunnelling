function result = run_quick_check(cfg)
%RUN_QUICK_CHECK Fast non-writing Stage 0--12 smoke profile.

if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end

quickCfg = cfg;
quickCfg.collective.scanSamples = max(201, ...
    min(cfg.collective.scanSamples, 401));
quickCfg.integration.q4Order = 8;
quickCfg.integration.qPerpOrder = 8;
quickCfg.integration.collectiveOrder = 10;
quickCfg.integration.cutRadialOrder = 8;
quickCfg.integration.cutAngleOrder = 8;
quickCfg.integration.endpointOrder = 8;
% The quick profile owns these reduced orders.  Cap the comparison factor so
% integer rounding cannot collapse its Stage 11 comparison to the baseline.
quickCfg.stage11.comparisonOrderFactor = min( ...
    cfg.stage11.comparisonOrderFactor, 0.75);
quickCfg.stage10.orderMultipliers = [0.75, 1.0, 1.25];
quickCfg.stage10.mappingScaleFactors = [0.8, 1.0, 1.25];
quickCfg.stage10.mappingPowers = quickCfg.integration.q4MapPower .* ...
    [0.875, 1.0, 1.125];
quickCfg.stage10.endpointSwitchFactors = [0.5, 1.0, 2.0];
quickCfg.stage10.collectiveScanSamples = [201, 301, 401];
quickCfg.stage10.collectiveRootTolerances = [2e-9, 5e-10, 1e-10];
quickCfg.stage10.directDiagnosticEpsilon = max(1e-4, ...
    10 .* quickCfg.stage10.epsilonPlateau(1));
quickCfg.stage10.directOrder = 64;
quickCfg.stage10.directComparisonOrder = 48;
quickCfg.stage10.directMWROrder = 64;
quickCfg.stage10.directMWRComparisonOrder = 48;
quickCfg.stage10.plateauOrder = 32;
quickCfg.tolerances.stage10OrderConvergence = 0.2;
quickCfg.tolerances.stage10MappingSensitivity = 0.2;
quickCfg.tolerances.stage10RootStability = 2e-5;
quickCfg.tolerances.stage10EndpointSwitch = 2e-2;
quickCfg.tolerances.stage10DirectSelf = 2e-2;
quickCfg.tolerances.stage10MWRSelf = 2e-2;
quickCfg.tolerances.stage10ContourIdentity = 2e-2;
quickCfg.tolerances.stage10EpsilonTotal = 2e-2;
quickCfg.tolerances.stage10EpsilonSource = 2e-2;
quickCfg.tolerances.stage11Convergence = 3e-1;
quickCfg.tolerances.stage11Unitarity = 1e-1;
quickCfg.tolerances.stage12Convergence = 3e-1;
quickCfg.tolerances.stage12Unitarity = 1e-1;
quickCfg.tolerances.stage12SMatrix = 1e-1;
% Pool startup can dominate this smoke profile; production remains auto.
quickCfg.execution.parallel.mode = 'serial';
quickCfg.execution.parallel.showProgress = false;
quickCfg = ndelta.config.finalize_configuration(quickCfg);
result = struct();
result.requestedConfiguration = cfg;
result.configuration = quickCfg;
result.effectiveConfiguration = quickCfg;
result.quickProfileApplied = true;
result.stage1 = run_stage1(quickCfg);
result.stage2 = run_stage2(quickCfg, result.stage1);
result.stage3 = run_stage3(quickCfg);
result.stage4 = run_stage4(quickCfg);
result.stage5 = run_stage5(quickCfg, result.stage1);
result.stage6 = run_stage6(quickCfg, result.stage1);
result.stage7 = run_stage7(quickCfg, result.stage1);
result.stage8 = run_stage8(quickCfg, result.stage1, result.stage7);
result.stage9 = run_stage9(quickCfg, result.stage2, result.stage8);
result.stage10 = run_stage10( ...
    quickCfg, result.stage1, result.stage7, result.stage8);
result.stage11 = run_stage11(quickCfg, result.stage1, result.stage2, ...
    result.stage7, result.stage8, result.stage9, result.stage10);
result.stage12 = run_stage12(quickCfg, result.stage11, ...
    struct('profile', 'quick'));
result.accepted = result.stage3.accepted && ...
    result.stage4.accepted && result.stage5.accepted && ...
    result.stage6.accepted && result.stage7.accepted && ...
    result.stage8.accepted && result.stage9.accepted && ...
    result.stage10.accepted && result.stage11.accepted && ...
    result.stage12.accepted && ...
    abs(result.stage2.tree.probabilityClosureResidual) <= ...
    cfg.tolerances.unitarity;

fprintf(['Quick check: N=%d, T0=%.12g, R0=%.12g, ' ...
    'closure=%+.3e, tree=%s, sheet=%s, G1-q3=%s, G1-pairs=%s, ' ...
     'contour=%s, integral=%s, amplitude=%s, validation=%s, ' ...
     'complete=%s, scans=%s.\n'], ...
    cfg.derived.N, result.stage2.tree.T0, result.stage2.tree.R0, ...
    result.stage2.tree.probabilityClosureResidual, ...
    ndelta.reporting.pass_fail(result.stage3.accepted), ...
    ndelta.reporting.pass_fail(result.stage4.accepted), ...
    ndelta.reporting.pass_fail(result.stage5.accepted), ...
    ndelta.reporting.pass_fail(result.stage6.accepted), ...
    ndelta.reporting.pass_fail(result.stage7.accepted), ...
    ndelta.reporting.pass_fail(result.stage8.accepted), ...
    ndelta.reporting.pass_fail(result.stage9.accepted), ...
    ndelta.reporting.pass_fail(result.stage10.accepted), ...
    ndelta.reporting.pass_fail(result.stage11.accepted), ...
    ndelta.reporting.pass_fail(result.stage12.accepted));
end
