function [value, diagnostics] = g1_longitudinal_kernel( ...
        d, q0, qPerp, channel, cfg)
%G1_LONGITUDINAL_KERNEL User-facing Stage 5 convenience wrapper.
%
%   This is an alias of ndelta.g1.longitudinal_kernel.  Its exact public
%   interface is retained for the Stage 4--12 roadmap.

narginchk(5, 5);
[value, diagnostics] = ndelta.g1.longitudinal_kernel( ...
    d, q0, qPerp, channel, cfg);
end
