function audits = run_stage12_audits(cfg)
%RUN_STAGE12_AUDITS Run/cache the two production contour audit phases only.
%
%   AUDITS = RUN_STAGE12_AUDITS(CFG) runs the finite-epsilon G2--G4
%   raw/MWR identity and the production-epsilon Cauchy plateau.  A later
%   RUN_STAGE12 or RUN_ALL_STAGES with the exact same finalised
%   configuration and numerical plan reuses both phase checkpoints.

narginchk(0, 1);
if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end
scanOptions = ndelta.stage12.resolve_scan_options( ...
    cfg, struct('profile', 'production'));
[parallelExecution, parallelPool] = ...
    ndelta.execution.prepare_parallel_execution(cfg);
fprintf(['Stage 12 audit-only backend: requested=%s, effective=%s, ' ...
    'workers=%d, fallback=%d.\n'], ...
    parallelExecution.requestedMode, ...
    parallelExecution.effectiveMode, ...
    parallelExecution.workerCount, parallelExecution.fallbackUsed);

contourPlan = ndelta.stage12.phase_checkpoint_plan( ...
    cfg, scanOptions, 'contourAudit');
contourProducer = @() ndelta.stage12.term_contour_audit( ...
    cfg, parallelExecution, parallelPool);
[contourAudit, contourCheckpoint] = ...
    ndelta.stage12.checkpoint_phase(cfg, scanOptions, ...
    'contourAudit', contourPlan, contourProducer);

epsilonPlan = ndelta.stage12.phase_checkpoint_plan( ...
    cfg, scanOptions, 'epsilonPlateau');
epsilonProducer = @() ndelta.stage12.term_epsilon_plateau( ...
    cfg, parallelExecution, parallelPool);
[epsilonPlateau, epsilonCheckpoint] = ...
    ndelta.stage12.checkpoint_phase(cfg, scanOptions, ...
    'epsilonPlateau', epsilonPlan, epsilonProducer);

audits = struct();
audits.options = scanOptions;
audits.parallelExecution = parallelExecution;
audits.termContourAudit = contourAudit;
audits.termEpsilonPlateau = epsilonPlateau;
audits.checkpoints = struct('contourAudit', contourCheckpoint, ...
    'epsilonPlateau', epsilonCheckpoint);
audits.accepted = contourAudit.accepted && epsilonPlateau.accepted;
if audits.accepted
    audits.status = 'stage12_audit_phases_accepted_and_checkpointed';
else
    audits.status = 'stage12_audit_phase_rejected_but_checkpointed';
end
fprintf(['Stage 12 audit-only result: %s; contour=%d, ' ...
    'epsilon=%d.\n'], audits.status, contourAudit.accepted, ...
    epsilonPlateau.accepted);
end
