function [value, diagnostics] = g1_pair_contraction_reference( ...
        q0, qPerp, channel, cfg)
%G1_PAIR_CONTRACTION_REFERENCE User-facing explicit Stage 6 double loop.

narginchk(4, 4);
[value, diagnostics] = ndelta.g1.pair_contraction_reference( ...
    q0, qPerp, channel, cfg);
end
