function stage5 = run_stage5(cfg, stage1)
%RUN_STAGE5 Evaluate and validate the directed G1 longitudinal kernel.
%
%   This stage performs the q3/(2*pi) integral analytically at one
%   diagnostic (q0,qPerp) point and at every unique directed distance in
%   the configured geometry.  It does not contract centre indices, call
%   tau_N, or integrate over q0 or qPerp.

if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end
if nargin < 2
    stage1 = run_stage1(cfg);
end
narginchk(0, 2);
validate_stage1_matches_configuration(stage1, cfg);

distances = stage1.geometry.uniqueDirectedDistances;
q0 = cfg.g1.referenceQ0;
qPerp = cfg.g1.referenceQPerp;
[transmission, transmissionDetails] = ...
    ndelta.g1.longitudinal_kernel( ...
    distances, q0, qPerp, 'T', cfg);
[reflection, reflectionDetails] = ...
    ndelta.g1.longitudinal_kernel( ...
    distances, q0, qPerp, 'R', cfg);

stage5 = struct();
stage5.q0 = q0;
stage5.qPerp = qPerp;
stage5.E = cfg.referenceEnergy;
stage5.P = cfg.derived.P;
stage5.epsilon = cfg.sheet.epsilon;
stage5.roots = transmissionDetails.roots;
stage5.directedDistances = distances;
stage5.directedDistanceConvention = 'd=z_b-z_a';
stage5.transmission = transmission;
stage5.reflection = reflection;
stage5.transmissionDetails = transmissionDetails;
stage5.reflectionDetails = reflectionDetails;
stage5.validation = ndelta.g1.validate_contract(cfg);
stage5.accepted = stage5.validation.accepted;
stage5.performsLongitudinalQ3Integration = true;
stage5.performsQ0Integration = false;
stage5.performsQPerpIntegration = false;
stage5.contractsCentrePairs = false;
stage5.includesTauN = false;
stage5.includesCentrePhase = false;
stage5.includesMuSquared = false;
stage5.includesLSZ = false;
stage5.includesOneOverTwoP = false;
stage5.sameSideMergersUseGroupedResidues = true;
stage5.crossSidePinchesDeferredToStage7 = true;
stage5.nextStage = ...
    'Stage 6 is implemented by run_stage6 in the cumulative release';

if cfg.execution.failOnBenchmarkFailure && ~stage5.accepted
    error('ndelta:g1:ContractRejected', ...
        ['Stage 5 G1 longitudinal-kernel validation failed. Maximum ' ...
         'normalised error: %.3e.'], ...
        stage5.validation.maximumNormalisedError);
end
end

function validate_stage1_matches_configuration(stage1, cfg)
requiredTop = {'geometry', 'kinematics'};
if ~isstruct(stage1) || ~isscalar(stage1) || ...
        ~all(isfield(stage1, requiredTop)) || ...
        ~isstruct(stage1.geometry) || ~isscalar(stage1.geometry) || ...
        ~isstruct(stage1.kinematics) || ~isscalar(stage1.kinematics) || ...
        ~all(isfield(stage1.geometry, ...
            {'positions', 'N', 'uniqueDirectedDistances', ...
             'directedDistanceIndex', ...
             'distanceMergeRelativeTolerance'})) || ...
        ~isfield(stage1.kinematics, 'P')
    error('ndelta:g1:Stage1ConfigurationMismatch', ...
        'stage1 must be a complete result produced from the same cfg.');
end

expectedPositions = cfg.barriers.positions(:);
actualPositions = stage1.geometry.positions(:);
expectedGeometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
positionScale = max(1, max(abs(expectedPositions)));
positionTolerance = 64 .* eps(positionScale);
positionsMatch = isnumeric(actualPositions) && isreal(actualPositions) && ...
    all(isfinite(actualPositions)) && ...
    numel(actualPositions) == numel(expectedPositions) && ...
    all(abs(actualPositions - expectedPositions) <= positionTolerance);
pScale = max(1, abs(cfg.derived.P));
pMatches = isnumeric(stage1.kinematics.P) && ...
    isscalar(stage1.kinematics.P) && ...
    isfinite(stage1.kinematics.P) && ...
    abs(stage1.kinematics.P - cfg.derived.P) <= 64 .* eps(pScale);
nMatches = isequal(stage1.geometry.N, cfg.derived.N);
mergeToleranceMatches = ...
    isequal(stage1.geometry.distanceMergeRelativeTolerance, ...
    cfg.tolerances.distanceMerge);
indexMapMatches = isequal(stage1.geometry.directedDistanceIndex, ...
    expectedGeometry.directedDistanceIndex);
expectedUnique = expectedGeometry.uniqueDirectedDistances(:);
actualUnique = stage1.geometry.uniqueDirectedDistances(:);
distanceScale = max(1, max(abs(expectedUnique)));
uniqueDistancesMatch = isnumeric(actualUnique) && isreal(actualUnique) && ...
    all(isfinite(actualUnique)) && ...
    numel(actualUnique) == numel(expectedUnique) && ...
    all(abs(actualUnique - expectedUnique) <= 64 .* eps(distanceScale));
if ~(positionsMatch && pMatches && nMatches && ...
        mergeToleranceMatches && indexMapMatches && ...
        uniqueDistancesMatch)
    error('ndelta:g1:Stage1ConfigurationMismatch', ...
        ['stage1 geometry/kinematics do not belong to cfg; rebuild it ' ...
         'with run_stage1(cfg).']);
end
end
