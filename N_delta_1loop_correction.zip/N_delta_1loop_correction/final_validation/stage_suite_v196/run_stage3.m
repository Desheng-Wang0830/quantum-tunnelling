function stage3 = run_stage3(cfg)
%RUN_STAGE3 Run all non-integrating N=1 and N=2 reference benchmarks.

narginchk(1, 1);

stage3 = ndelta.benchmarks.run_all(cfg);
if cfg.execution.failOnBenchmarkFailure && ~stage3.accepted
    error('ndelta:benchmark:Rejected', ...
        ['Stage 3 rejected the implementation.  Maximum normalised ' ...
         'error metric: %.3e.'], stage3.maximumNormalisedError);
end
end
