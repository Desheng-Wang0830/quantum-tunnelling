function results = run_contract_tests
%RUN_CONTRACT_TESTS Run the MATLAB unit-test suite for Stages 0--12.

projectRoot = fileparts(mfilename('fullpath'));
addpath(projectRoot);
suite = testsuite(fullfile(projectRoot, 'tests'), ...
    'IncludeSubfolders', true);
results = run(suite);
release = ndelta.config.release_contract();
expectedNumberOfTests = release.unitTestCount;
if numel(results) ~= expectedNumberOfTests
    error('ndelta:test:DiscoveryMismatch', ...
        ['Expected %d cumulative Stage 0--12 tests, but MATLAB ' ...
         'discovered %d. Check the extracted tests directory.'], ...
        expectedNumberOfTests, numel(results));
end
if ~all([results.Passed])
    error('ndelta:test:Failure', ...
        '%d of %d Stage 0--12 tests failed.', ...
        sum(~[results.Passed]), numel(results));
end
fprintf('N-delta Stage 0--12 tests passed: %d/%d.\n', ...
    sum([results.Passed]), numel(results));
end
