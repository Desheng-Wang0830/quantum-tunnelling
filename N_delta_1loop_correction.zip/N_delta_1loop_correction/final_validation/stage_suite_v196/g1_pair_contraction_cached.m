function [value, diagnostics] = g1_pair_contraction_cached( ...
        q0, qPerp, channel, cfg)
%G1_PAIR_CONTRACTION_CACHED User-facing cached Stage 6 contraction.

narginchk(4, 4);
[value, diagnostics] = ndelta.g1.pair_contraction_cached( ...
    q0, qPerp, channel, cfg);
end
