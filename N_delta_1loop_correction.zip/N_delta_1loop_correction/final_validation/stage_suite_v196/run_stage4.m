function stage4 = run_stage4(cfg)
%RUN_STAGE4 Validate and expose the outward-cut physical-sheet component.
%
%   Stage 4 performs no q0/qPerp integration, no residue calculation and
%   no Gamma_N pole search.  Collective singularities remain Stage 7.

if nargin < 1
    cfg = run_stage0(false);
else
    narginchk(1, 1);
end
cfg = ndelta.config.finalize_configuration(cfg);
E = cfg.referenceEnergy;
qPerp = cfg.sheet.referenceQPerp;
epsilon = cfg.sheet.epsilon;

stage4 = struct();
stage4.scales = ndelta.sheet.transverse_energies(qPerp, cfg.model);
stage4.branchPoints = ndelta.sheet.branch_points( ...
    qPerp, E, cfg.model, epsilon);
stage4.branchGeometry = ndelta.sheet.branch_geometry( ...
    qPerp, E, cfg.model, epsilon);

s = linspace(0, cfg.sheet.cutParameterMax, cfg.sheet.cutSamples);
stage4.cutCurves = ndelta.sheet.outward_cut_points( ...
    s, qPerp, E, cfg.model, epsilon);

displaySpan = max([stage4.scales.EPhi + cfg.sheet.cutParameterMax, ...
    E + stage4.scales.Ephi + cfg.sheet.cutParameterMax, 1]);
q0Real = linspace(-displaySpan, displaySpan, ...
    cfg.sheet.realAxisSamples);
stage4.realAxisRoots = ndelta.sheet.physical_roots( ...
    q0Real, qPerp, E, cfg.model, epsilon);
stage4.referenceRootsAtQ0Zero = ndelta.sheet.physical_roots( ...
    0, qPerp, E, cfg.model, epsilon);
stage4.validation = ndelta.sheet.validate_contract(cfg);
stage4.accepted = stage4.validation.accepted;
stage4.performsIntegration = false;
stage4.evaluatesPoleResidues = false;
stage4.evaluatesCollectivePoles = false;
stage4.nextStage = ...
    'Stage 5: directed G1 longitudinal kernel I_1(d) (implemented)';

if cfg.execution.failOnBenchmarkFailure && ~stage4.accepted
    error('ndelta:sheet:ContractRejected', ...
        ['Stage 4 physical-sheet validation failed. Maximum ' ...
         'normalised error: %.3e.'], ...
        stage4.validation.maximumNormalisedError);
end
end
