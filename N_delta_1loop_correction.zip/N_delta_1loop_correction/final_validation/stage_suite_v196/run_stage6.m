function stage6 = run_stage6(cfg, stage1)
%RUN_STAGE6 Contract G1 centre pairs at one fixed (q0,qPerp) node.
%
%   The explicit ordered-pair reference and directed-distance cached
%   implementation are both evaluated.  This stage includes tau_N at
%   K=kappaI and the external channel phases, but no q0/qPerp integration,
%   mu^2, LSZ or 1/(2P).

narginchk(0, 2);
if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end
if nargin < 2
    stage1 = run_stage1(cfg);
end
validate_stage1(stage1, cfg);

q0 = cfg.g1.referenceQ0;
qPerp = cfg.g1.referenceQPerp;
geometry = stage1.geometry;
[referenceT, referenceDetailsT] = ...
    ndelta.g1.pair_contraction_reference( ...
    q0, qPerp, 'T', cfg, geometry);
[cachedT, cachedDetailsT] = ndelta.g1.pair_contraction_cached( ...
    q0, qPerp, 'T', cfg, geometry);
[referenceR, referenceDetailsR] = ...
    ndelta.g1.pair_contraction_reference( ...
    q0, qPerp, 'R', cfg, geometry);
[cachedR, cachedDetailsR] = ndelta.g1.pair_contraction_cached( ...
    q0, qPerp, 'R', cfg, geometry);

relativeErrors = [relative(cachedT, referenceT), ...
    relative(cachedR, referenceR), ...
    max(relative(cachedDetailsT.termMatrix(:), ...
    referenceDetailsT.termMatrix(:))), ...
    max(relative(cachedDetailsR.termMatrix(:), ...
    referenceDetailsR.termMatrix(:)))];
maximumConfiguredError = max(relativeErrors);
validation = ndelta.g1.validate_pointwise_contract(cfg);

stage6 = struct();
stage6.q0 = q0;
stage6.qPerp = qPerp;
stage6.E = cfg.referenceEnergy;
stage6.P = cfg.derived.P;
stage6.epsilon = cfg.sheet.epsilon;
stage6.roots = cachedDetailsT.roots;
stage6.geometry = geometry;
stage6.reference = struct('transmission', referenceT, ...
    'reflection', referenceR, 'transmissionDetails', referenceDetailsT, ...
    'reflectionDetails', referenceDetailsR);
stage6.cached = struct('transmission', cachedT, ...
    'reflection', cachedR, 'transmissionDetails', cachedDetailsT, ...
    'reflectionDetails', cachedDetailsR);
stage6.transmission = cachedT;
stage6.reflection = cachedR;
stage6.configuredReferenceCachedRelativeErrors = relativeErrors;
stage6.maximumConfiguredReferenceCachedRelativeError = ...
    maximumConfiguredError;
stage6.validation = validation;
stage6.accepted = validation.accepted && ...
    maximumConfiguredError <= cfg.tolerances.g1Contraction;
stage6.numberOfOrderedPairs = geometry.N.^2;
stage6.numberOfActiveOrderedPairs = ...
    cachedDetailsT.numberOfActiveOrderedPairs;
stage6.numberOfSkippedInactivePairs = ...
    cachedDetailsT.numberOfSkippedInactivePairs;
stage6.numberOfUniqueDirectedDistances = ...
    geometry.numberOfUniqueDirectedDistances;
stage6.numberOfUsedCacheKeys = numel(cachedDetailsT.cacheKeys);
stage6.cacheGeometry = cachedDetailsT.cacheGeometry;
stage6.numberOfCachedKernelEvaluations = ...
    cachedDetailsT.numberOfKernelEvaluations;
stage6.directedDistanceConvention = 'D(a,b)=z_b-z_a';
stage6.indexContract = 'E(a,b)*tau(b,a)*I(D(a,b))';
stage6.performsLongitudinalQ3Integration = true;
stage6.contractsCentrePairs = true;
stage6.includesTauNAtKappaI = true;
stage6.includesCentrePhase = true;
stage6.includesMuSquared = false;
stage6.includesLSZ = false;
stage6.includesOneOverTwoP = false;
stage6.performsQ0Integration = false;
stage6.performsQPerpIntegration = false;
stage6.searchesCollectivePoles = false;
stage6.massDimension = -4;
stage6.nextStage = ...
    'Stage 7: singularity classification and modified Wick rotation';

if cachedDetailsT.background.solveDiagnostics.nearSingular || ...
        cachedDetailsR.background.solveDiagnostics.nearSingular
    warning('ndelta:g1:NearCollectivePoleAtStage6Node', ...
        ['Gamma_N(kappaI) is ill-conditioned at the configured Stage 6 ' ...
         'reference node. Stage 7 must classify this candidate.']);
end
if cfg.execution.failOnBenchmarkFailure && ~stage6.accepted
    error('ndelta:g1:PointwiseContractRejected', ...
        ['Stage 6 pointwise contraction validation failed. Portable ' ...
         'maximum normalised error %.3e; configured reference/cache ' ...
         'relative error %.3e.'], ...
        validation.maximumNormalisedError, maximumConfiguredError);
end
end

function validate_stage1(stage1, cfg)
required = {'geometry', 'kinematics'};
if ~isstruct(stage1) || ~isscalar(stage1) || ...
        ~all(isfield(stage1, required)) || ...
        ~isstruct(stage1.kinematics) || ...
        ~isscalar(stage1.kinematics) || ...
        ~isfield(stage1.kinematics, 'P')
    error('ndelta:g1:Stage1ConfigurationMismatch', ...
        'stage1 must be a complete result produced from the same cfg.');
end
ndelta.g1.resolve_pair_geometry(cfg, stage1.geometry);
P = stage1.kinematics.P;
scale = max(1, abs(cfg.derived.P));
if ~isnumeric(P) || ~isscalar(P) || ~isreal(P) || ~isfinite(P) || ...
        abs(P - cfg.derived.P) > 64 .* eps(scale)
    error('ndelta:g1:Stage1ConfigurationMismatch', ...
        'stage1 kinematics do not belong to cfg.');
end
end

function value = relative(left, right)
value = abs(left - right) ./ (1 + abs(right));
end
