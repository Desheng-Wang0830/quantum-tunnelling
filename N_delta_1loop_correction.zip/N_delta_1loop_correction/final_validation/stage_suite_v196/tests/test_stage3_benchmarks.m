function tests = test_stage3_benchmarks
%TEST_STAGE3_BENCHMARKS N=1, Rose N=2 and generic-N physics tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
end

function testCompleteBenchmarkGate(testCase)
report = ndelta.benchmarks.run_all(testCase.TestData.cfg);
verifyTrue(testCase, report.accepted);
verifyEqual(testCase, report.numberPassed, report.numberOfChecks);
verifyLessThanOrEqual(testCase, report.maximumNormalisedError, 1);
end

function testSingleDeltaComplexAmplitude(testCase)
cfg = testCase.TestData.cfg;
P = 0.55;
for g = [-0.3, 0.3]
    for z0 = [0, 1.37]
        geometry = ndelta.geometry.build_geometry(z0, 1e-12);
        actual = ndelta.tree.tree_amplitudes_N(P, geometry, g, ...
            cfg.tolerances.nearSingularRcond);
        expected = ndelta.benchmarks.single_delta_amplitudes(P, g, z0);
        verifyEqual(testCase, actual.t0, expected.t0, ...
            'AbsTol', cfg.tolerances.amplitude);
        verifyEqual(testCase, actual.r0, expected.r0, ...
            'AbsTol', cfg.tolerances.amplitude);
    end
end
end

function testRoseComplexAmplitudes(testCase)
cfg = testCase.TestData.cfg;
cases = [0.7, 0.4, 1.20; 0.7, -0.3, 1.20; ...
    1.1, 0.25, 0.37; 0.31, 0.6, 2.00];
for index = 1:size(cases, 1)
    P = cases(index, 1);
    g = cases(index, 2);
    b = cases(index, 3);
    geometry = ndelta.geometry.build_geometry([-b ./ 2, b ./ 2], 1e-12);
    actual = ndelta.tree.tree_amplitudes_N(P, geometry, ...
        [g ./ 2, g ./ 2], cfg.tolerances.nearSingularRcond);
    expected = ndelta.benchmarks.rose_double_amplitudes(P, g, b);
    verifyEqual(testCase, actual.t0, expected.t0, ...
        'AbsTol', cfg.tolerances.amplitude);
    verifyEqual(testCase, actual.r0, expected.r0, ...
        'AbsTol', cfg.tolerances.amplitude);
end
end

function testExactBZeroReduction(testCase)
cfg = testCase.TestData.cfg;
P = 0.7;
g = 0.4;
z0 = 0.41;
geometry = ndelta.geometry.build_geometry([z0, z0], 1e-12);
actual = ndelta.tree.tree_amplitudes_N(P, geometry, ...
    [g ./ 2, g ./ 2], cfg.tolerances.nearSingularRcond);
expected = ndelta.benchmarks.single_delta_amplitudes(P, g, z0);
verifyEqual(testCase, actual.t0, expected.t0, ...
    'AbsTol', cfg.tolerances.coalescence);
verifyEqual(testCase, actual.r0, expected.r0, ...
    'AbsTol', cfg.tolerances.coalescence);
end

function testTranslationAndPermutation(testCase)
cfg = testCase.TestData.cfg;
P = 0.67;
z = [-1.1, 0.2, 1.7];
g = [0.30, -0.18, 0.25];
base = ndelta.tree.tree_amplitudes_N(P, ...
    ndelta.geometry.build_geometry(z, 1e-12), g, ...
    cfg.tolerances.nearSingularRcond);

shift = 0.83;
moved = ndelta.tree.tree_amplitudes_N(P, ...
    ndelta.geometry.build_geometry(z + shift, 1e-12), g, ...
    cfg.tolerances.nearSingularRcond);
verifyEqual(testCase, moved.t0, base.t0, ...
    'AbsTol', cfg.tolerances.amplitude);
verifyEqual(testCase, moved.r0, ...
    exp(2i .* P .* shift) .* base.r0, ...
    'AbsTol', cfg.tolerances.amplitude);

permutation = [3, 1, 2];
permuted = ndelta.tree.tree_amplitudes_N(P, ...
    ndelta.geometry.build_geometry(z(permutation), 1e-12), ...
    g(permutation), cfg.tolerances.nearSingularRcond);
verifyEqual(testCase, permuted.t0, base.t0, ...
    'AbsTol', cfg.tolerances.amplitude);
verifyEqual(testCase, permuted.r0, base.r0, ...
    'AbsTol', cfg.tolerances.amplitude);
end

function testTreeIndependentOfFutureLoopParameters(testCase)
cfgA = testCase.TestData.cfg;
cfgB = cfgA;
cfgB.model.mPhi = 3.7;
cfgB.model.mu = -0.83;
cfgA = ndelta.config.finalize_configuration(cfgA);
cfgB = ndelta.config.finalize_configuration(cfgB);
treeA = run_stage2(cfgA, run_stage1(cfgA)).tree;
treeB = run_stage2(cfgB, run_stage1(cfgB)).tree;
verifyEqual(testCase, treeA.t0, treeB.t0);
verifyEqual(testCase, treeA.r0, treeB.r0);
end
