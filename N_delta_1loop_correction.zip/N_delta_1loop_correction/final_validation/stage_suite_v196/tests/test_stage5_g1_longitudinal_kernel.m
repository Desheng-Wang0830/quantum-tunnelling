function tests = test_stage5_g1_longitudinal_kernel
%TEST_STAGE5_G1_LONGITUDINAL_KERNEL Directed q3-kernel contract tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.P = 0.9;
data.omega = 0.4 + 1.2i;
data.kappaI = 0.3 + 0.7i;
data.d = 0.7;
data.order = 256;
testCase.TestData.data = data;
end

function testRawTransmissionIntegrandDefinition(testCase)
d = testCase.TestData.data;
q3 = [-1.1, 0.2 + 0.3i, 1.7];
actual = ndelta.g1.q3_integrand( ...
    q3, d.d, d.omega, d.kappaI, d.P, 'T');
expected = -1i .* exp(1i .* q3 .* d.d) ./ ( ...
    (d.omega.^2 - q3.^2) ...
    .* (d.kappaI.^2 - (d.P - q3).^2).^2);
verifyLessThanOrEqual(testCase, ...
    max(abs(actual - expected)), 5e-15);
end

function testRawReflectionIntegrandDefinition(testCase)
d = testCase.TestData.data;
q3 = [-1.1, 0.2 + 0.3i, 1.7];
actual = ndelta.g1.q3_integrand( ...
    q3, -d.d, d.omega, d.kappaI, d.P, 'R');
expected = -1i .* exp(-1i .* q3 .* d.d) ./ ( ...
    (d.omega.^2 - q3.^2) ...
    .* (d.kappaI.^2 - (d.P - q3).^2) ...
    .* (d.kappaI.^2 - (d.P + q3).^2));
verifyLessThanOrEqual(testCase, ...
    max(abs(actual - expected)), 5e-15);
end

function testPoleTablesKeepPhysicalSeedLabels(testCase)
d = testCase.TestData.data;
t = ndelta.g1.q3_poles('T', d.omega, d.kappaI, d.P);
r = ndelta.g1.q3_poles('R', d.omega, d.kappaI, d.P);
verifyLessThanOrEqual(testCase, max(abs( ...
    t.positiveDistanceLocations - ...
    [d.omega, d.P + d.kappaI])), 5e-15);
verifyEqual(testCase, t.positiveDistanceOrders, [1, 2]);
verifyEqual(testCase, t.negativeDistanceOrders, [1, 2]);
verifyEqual(testCase, r.positiveDistanceOrders, [1, 1, 1]);
verifyEqual(testCase, r.negativeDistanceOrders, [1, 1, 1]);
verifyTrue(testCase, t.doNotReclassifyAfterAnalyticContinuation);
end

function testTransmissionAgainstIndependentRealAxisQuadrature(testCase)
d = testCase.TestData.data;
distances = [-d.d, 0, d.d];
actual = ndelta.g1.longitudinal_kernel_from_roots( ...
    distances, d.omega, d.kappaI, d.P, 'T');
reference = complex(zeros(size(distances)));
for index = 1:numel(distances)
    reference(index) = ndelta.g1.numerical_real_axis_reference( ...
        distances(index), d.omega, d.kappaI, d.P, 'T', d.order);
end
verifyLessThanOrEqual(testCase, max(relative(actual, reference)), 2e-9);
end

function testReflectionAgainstIndependentRealAxisQuadrature(testCase)
d = testCase.TestData.data;
distances = [-d.d, 0, d.d];
actual = ndelta.g1.longitudinal_kernel_from_roots( ...
    distances, d.omega, d.kappaI, d.P, 'R');
reference = complex(zeros(size(distances)));
for index = 1:numel(distances)
    reference(index) = ndelta.g1.numerical_real_axis_reference( ...
        distances(index), d.omega, d.kappaI, d.P, 'R', d.order);
end
verifyLessThanOrEqual(testCase, max(relative(actual, reference)), 2e-9);
end

function testSeparatedResidueComponentsMatchGroupedValue(testCase)
d = testCase.TestData.data;
[~, t] = ndelta.g1.longitudinal_kernel_from_roots( ...
    [-d.d, 0, d.d], d.omega, d.kappaI, d.P, 'T');
[~, r] = ndelta.g1.longitudinal_kernel_from_roots( ...
    [-d.d, 0, d.d], d.omega, d.kappaI, d.P, 'R');
verifyLessThanOrEqual(testCase, ...
    t.maximumComponentAssemblyResidual, 5e-11);
verifyLessThanOrEqual(testCase, ...
    r.maximumComponentAssemblyResidual, 5e-11);
end

function testBothOneSidedZeroLimits(testCase)
d = testCase.TestData.data;
h = 1e-4;
for channel = {'T', 'R'}
    values = ndelta.g1.longitudinal_kernel_from_roots( ...
        [-h, -h ./ 2, 0, h ./ 2, h], ...
        d.omega, d.kappaI, d.P, channel{1});
    left = 2 .* values(2) - values(1);
    right = 2 .* values(4) - values(5);
    verifyLessThanOrEqual(testCase, ...
        max(relative([left, right], values(3))), 5e-9);
end
end

function testReflectionIsExactlyEven(testCase)
d = testCase.TestData.data;
values = ndelta.g1.longitudinal_kernel_from_roots( ...
    [-d.d, d.d], d.omega, d.kappaI, d.P, 'R');
verifyLessThanOrEqual(testCase, relative(values(1), values(2)), 5e-12);
end

function testTransmissionRetainsDirectionAndIsNotConjugated(testCase)
d = testCase.TestData.data;
values = ndelta.g1.longitudinal_kernel_from_roots( ...
    [-d.d, d.d], d.omega, d.kappaI, d.P, 'T');
verifyGreaterThan(testCase, abs(values(1) - values(2)), 1e-3);
verifyGreaterThan(testCase, abs(values(1) - conj(values(2))), 1e-3);
end

function testArrayShapeAndExactDistanceClasses(testCase)
d = testCase.TestData.data;
distances = [-1e-12, 0; d.d, -d.d];
[values, details] = ndelta.g1.longitudinal_kernel_from_roots( ...
    distances, d.omega, d.kappaI, d.P, 'T');
verifySize(testCase, values, size(distances));
verifySize(testCase, details.distanceBranches, size(distances));
verifyEqual(testCase, details.distanceBranches{1, 1}, 'negative');
verifyEqual(testCase, details.distanceBranches{1, 2}, 'zero');
verifyEqual(testCase, details.distanceBranches{2, 1}, 'positive');
verifyEqual(testCase, details.distanceBranches{2, 2}, 'negative');
end

function testPublicWrapperAndTopLevelAliasMatchRootLeaf(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
distances = [-0.4, 0, 0.6];
[public, details] = ndelta.g1.longitudinal_kernel( ...
    distances, cfg.g1.referenceQ0, cfg.g1.referenceQPerp, 'T', cfg);
alias = g1_longitudinal_kernel( ...
    distances, cfg.g1.referenceQ0, cfg.g1.referenceQPerp, 'T', cfg);
leaf = ndelta.g1.longitudinal_kernel_from_roots( ...
    distances, details.roots.omega, details.roots.kappaI, ...
    cfg.derived.P, 'T', cfg.tolerances.g1Coalescence);
verifyLessThanOrEqual(testCase, max(relative(public, leaf)), 5e-12);
verifyLessThanOrEqual(testCase, max(relative(alias, leaf)), 5e-12);
end

function testKernelIsIndependentOfMuNPositionsAndStrengths(testCase)
d = testCase.TestData.data;
cfgA = d.cfg;
cfgB = cfgA;
cfgB.model.mu = -7.3;
cfgB.barriers.positions = [-2, -0.3, 0.8, 4.1];
cfgB.barriers.strengths = [0.4, 0, -0.1, 2.2];
cfgB = ndelta.config.finalize_configuration(cfgB);
distances = [-0.6, 0, 0.6];
valueA = ndelta.g1.longitudinal_kernel(distances, ...
    cfgA.g1.referenceQ0, cfgA.g1.referenceQPerp, 'R', cfgA);
valueB = ndelta.g1.longitudinal_kernel(distances, ...
    cfgB.g1.referenceQ0, cfgB.g1.referenceQPerp, 'R', cfgB);
verifyLessThanOrEqual(testCase, max(relative(valueA, valueB)), 5e-15);
end

function testSingleDeltaInternalKernelRegression(testCase)
d = testCase.TestData.data;
g = -0.3;
tauOne = -2i .* g .* d.kappaI ./ ...
    (2 .* d.kappaI + 1i .* g);
tZero = ndelta.g1.longitudinal_kernel_from_roots( ...
    0, d.omega, d.kappaI, d.P, 'T');
rZero = ndelta.g1.longitudinal_kernel_from_roots( ...
    0, d.omega, d.kappaI, d.P, 'R');
[oldT, oldR] = old_internal(d.omega, d.kappaI, d.P, g);
verifyLessThanOrEqual(testCase, relative(tauOne .* tZero, oldT), 5e-12);
verifyLessThanOrEqual(testCase, relative(tauOne .* rZero, oldR), 5e-12);
end

function testExactPositiveTransmissionMergerIsFinite(testCase)
d = testCase.TestData.data;
omegaMerged = d.P + d.kappaI;
[actual, details] = ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, omegaMerged, d.kappaI, d.P, 'T', 1e-8);
reference = ndelta.g1.numerical_real_axis_reference( ...
    d.d, omegaMerged, d.kappaI, d.P, 'T', 512);
verifyTrue(testCase, isfinite(actual));
verifyTrue(testCase, details.nearSameSideMerger);
verifyTrue(testCase, ...
    details.groupedResidueDiagnostics{1}.usedConfluentTaylor);
verifyLessThanOrEqual(testCase, relative(actual, reference), 1e-9);
end

function testExactNegativeTransmissionMergerIsFinite(testCase)
d = testCase.TestData.data;
omegaMerged = -d.P + d.kappaI;
[actual, details] = ndelta.g1.longitudinal_kernel_from_roots( ...
    -d.d, omegaMerged, d.kappaI, d.P, 'T', 1e-8);
reference = ndelta.g1.numerical_real_axis_reference( ...
    -d.d, omegaMerged, d.kappaI, d.P, 'T', 512);
verifyTrue(testCase, isfinite(actual));
verifyTrue(testCase, details.nearSameSideMerger);
verifyLessThanOrEqual(testCase, relative(actual, reference), 1e-9);
end

function testExactReflectionMergerIsFinite(testCase)
d = testCase.TestData.data;
omegaMergers = [d.P + d.kappaI, -d.P + d.kappaI];
distances = [-d.d, d.d];
for mergerIndex = 1:numel(omegaMergers)
    omegaMerged = omegaMergers(mergerIndex);
    [actual, details] = ndelta.g1.longitudinal_kernel_from_roots( ...
        distances, omegaMerged, d.kappaI, d.P, 'R', 1e-8);
    reference = complex(zeros(size(distances)));
    for distanceIndex = 1:numel(distances)
        reference(distanceIndex) = ...
            ndelta.g1.numerical_real_axis_reference( ...
            distances(distanceIndex), omegaMerged, ...
            d.kappaI, d.P, 'R', 512);
    end
    verifyTrue(testCase, all(isfinite(actual)));
    verifyTrue(testCase, details.nearSameSideMerger);
    verifyLessThanOrEqual(testCase, ...
        max(relative(actual, reference)), 1e-9);
    verifyLessThanOrEqual(testCase, ...
        relative(actual(1), actual(2)), 5e-12);
end
end

function testCrossSidePinchesAreRejected(testCase)
d = testCase.TestData.data;
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, d.P - d.kappaI, d.kappaI, d.P, 'T'), ...
    'ndelta:g1:PinchedTransmissionPoint');
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, d.omega, d.P, d.P, 'R'), ...
    'ndelta:g1:PinchedReflectionPoint');

scale = 1e12;
separated = ndelta.g1.pole_separation( ...
    'T', d.omega, d.kappaI, d.P);
scaled = ndelta.g1.pole_separation( ...
    'T', scale .* d.omega, scale .* d.kappaI, scale .* d.P);
smallScale = 1e-13;
smallScaled = ndelta.g1.pole_separation( ...
    'T', smallScale .* d.omega, smallScale .* d.kappaI, ...
    smallScale .* d.P);
verifyFalse(testCase, separated.hasMachineScaleCrossSidePinch);
verifyFalse(testCase, scaled.hasMachineScaleCrossSidePinch);
verifyFalse(testCase, smallScaled.hasMachineScaleCrossSidePinch);
verifyEqual(testCase, scaled.machineThreshold, ...
    separated.machineThreshold);
verifyLessThanOrEqual(testCase, abs( ...
    smallScaled.minimumCrossSideNormalisedSeparation - ...
    scaled.minimumCrossSideNormalisedSeparation), 5e-15);
end

function testNearSameSideMergerIsNumericallyStable(testCase)
d = testCase.TestData.data;
omegaNear = d.P + d.kappaI + 1e-9;
[actual, details] = ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, omegaNear, d.kappaI, d.P, 'T', 1e-8);
reference = ndelta.g1.numerical_real_axis_reference( ...
    d.d, omegaNear, d.kappaI, d.P, 'T', 512);
verifyTrue(testCase, isfinite(actual));
verifyTrue(testCase, details.nearSameSideMerger);
verifyFalse(testCase, details.nearCrossSidePinch);
verifyFalse(testCase, details.hardDegenerate);
verifyLessThanOrEqual(testCase, relative(actual, reference), 1e-9);

% Regression for a rapidly varying exponential across a small pole
% cluster: a fixed low-order Taylor series is invalid here, while the
% phase-aware recursive branch agrees with the separated analytic sum.
largeDistance = 1e4;
kappaSmallImaginary = 0.3 + 1e-5i;
omegaSmallCluster = d.P + kappaSmallImaginary + 0.003;
[largeValue, largeDetails] = ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    largeDistance, omegaSmallCluster, kappaSmallImaginary, ...
    d.P, 'T', 1e-8);
separatedValue = largeDetails.heavyPoleContribution + ...
    largeDetails.firstShiftedPoleContribution;
verifyLessThanOrEqual(testCase, ...
    relative(largeValue, separatedValue), 2e-8);
verifyGreaterThan(testCase, ...
    largeDetails.groupedResidueDiagnostics{1}.clusterPhaseSpan, 1);

% The default physical model has two q0 values at which the selected
% transmission poles coalesce almost on the real q3 axis.  Real-axis
% quadrature is ill-conditioned there, so compare at and near both values
% with an independent Cauchy circle around the complete selected cluster.
cfg = d.cfg;
E = cfg.referenceEnergy;
mphi = cfg.model.mphi;
mPhi = cfg.model.mPhi;
qPerp = cfg.g1.referenceQPerp;
P = cfg.derived.P;
C = E.^2 + mPhi.^2 ./ 2 - mphi.^2;
qStars = roots([mphi.^2, -E .* mPhi.^2, ...
    C.^2 - P.^2 .* (P.^2 - qPerp.^2 + 1i .* cfg.sheet.epsilon)]);
[~, ordering] = sort(real(qStars));
qStars = qStars(ordering);
starDistances = [-d.d, d.d];
offsets = [0, 1e-6, 1e-4];
for starIndex = 1:2
    for offsetIndex = 1:numel(offsets)
        q0 = qStars(starIndex) + offsets(offsetIndex);
        physicalRoots = ndelta.sheet.physical_roots( ...
            q0, qPerp, E, cfg.model, cfg.sheet.epsilon);
        distance = starDistances(starIndex);
        starValue = ndelta.g1.longitudinal_kernel_from_roots( ...
            distance, physicalRoots.omega, physicalRoots.kappaI, ...
            P, 'T', cfg.tolerances.g1Coalescence);
        cauchyValue = cauchy_selected_cluster_reference( ...
            distance, physicalRoots.omega, physicalRoots.kappaI, ...
            P, 'T', 2048);
        verifyLessThanOrEqual(testCase, ...
            mixed_error(starValue, cauchyValue, 2e-12, 2e-8), 1);
    end
end
end

function testInvalidChannelsAndDistancesAreRejected(testCase)
d = testCase.TestData.data;
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, d.omega, d.kappaI, d.P, 'X'), ...
    'ndelta:g1:InvalidChannel');
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    1 + 1i, d.omega, d.kappaI, d.P, 'T'), ...
    'ndelta:g1:InvalidDirectedDistance');
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    NaN, d.omega, d.kappaI, d.P, 'T'), ...
    'ndelta:g1:InvalidDirectedDistance');
end

function testInvalidWrapperAndRootInputsAreRejected(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
verifyError(testCase, @() ndelta.g1.longitudinal_kernel( ...
    d.d, [0, 1], 0.1, 'T', cfg), 'ndelta:g1:Q0MustBeScalar');
verifyError(testCase, @() ndelta.g1.longitudinal_kernel( ...
    d.d, 0, -0.1, 'T', cfg), 'ndelta:g1:InvalidQPerp');
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, NaN, d.kappaI, d.P, 'T'), 'ndelta:g1:InvalidOmega');
verifyError(testCase, @() ...
    ndelta.g1.longitudinal_kernel_from_roots( ...
    d.d, d.omega, d.kappaI, 0, 'T'), 'ndelta:g1:InvalidP');
end

function testStage5ScopeFlagsAndFactorBoundary(testCase)
d = testCase.TestData.data;
stage1 = run_stage1(d.cfg);
stage5 = run_stage5(d.cfg, stage1);
verifyTrue(testCase, stage5.accepted);
verifyTrue(testCase, stage5.performsLongitudinalQ3Integration);
verifyFalse(testCase, stage5.performsQ0Integration);
verifyFalse(testCase, stage5.performsQPerpIntegration);
verifyFalse(testCase, stage5.contractsCentrePairs);
verifyFalse(testCase, stage5.includesTauN);
verifyFalse(testCase, stage5.includesMuSquared);
verifyFalse(testCase, stage5.includesLSZ);
verifyEqual(testCase, stage5.transmissionDetails.massDimension, -5);

distances = [-d.d, 0, d.d];
for lambda = [1e-12, 3.7, 1e12]
    for channel = {'T', 'R'}
        base = ndelta.g1.longitudinal_kernel_from_roots( ...
            distances, d.omega, d.kappaI, d.P, channel{1});
        scaled = ndelta.g1.longitudinal_kernel_from_roots( ...
            distances ./ lambda, lambda .* d.omega, ...
            lambda .* d.kappaI, lambda .* d.P, channel{1});
        verifyLessThanOrEqual(testCase, max(abs( ...
            lambda.^5 .* scaled - base) ./ ...
            (1 + abs(base))), 2e-10);
    end
end

staleStage1 = stage1;
staleStage1.geometry.positions(1) = ...
    staleStage1.geometry.positions(1) + 0.1;
verifyError(testCase, @() run_stage5(d.cfg, staleStage1), ...
    'ndelta:g1:Stage1ConfigurationMismatch');

staleToleranceStage1 = stage1;
changedToleranceCfg = d.cfg;
changedToleranceCfg.tolerances.distanceMerge = ...
    10 .* changedToleranceCfg.tolerances.distanceMerge;
changedToleranceCfg = ndelta.config.finalize_configuration( ...
    changedToleranceCfg);
verifyError(testCase, @() run_stage5( ...
    changedToleranceCfg, staleToleranceStage1), ...
    'ndelta:g1:Stage1ConfigurationMismatch');
end

function value = relative(left, right)
value = abs(left - right) ./ (1 + abs(right));
end

function value = mixed_error(actual, reference, absoluteTolerance, ...
        relativeTolerance)
value = abs(actual - reference) ./ ...
    (absoluteTolerance + relativeTolerance .* abs(reference));
end

function value = cauchy_selected_cluster_reference( ...
        distance, omega, kappaI, P, channel, numberOfPoints)
poleTable = ndelta.g1.q3_poles(channel, omega, kappaI, P);
if distance > 0
    locations = poleTable.positiveDistanceLocations;
    orders = poleTable.positiveDistanceOrders;
    excluded = poleTable.negativeDistanceLocations;
    multiplier = poleTable.positiveDistanceIntegralMultiplier;
else
    locations = poleTable.negativeDistanceLocations;
    orders = poleTable.negativeDistanceOrders;
    excluded = poleTable.positiveDistanceLocations;
    multiplier = poleTable.negativeDistanceIntegralMultiplier;
end

expanded = complex(zeros(1, sum(orders)));
cursor = 1;
for index = 1:numel(locations)
    expanded(cursor:(cursor + orders(index) - 1)) = locations(index);
    cursor = cursor + orders(index);
end
centre = mean(expanded);
clusterRadius = max(abs(expanded - centre));
excludedRadius = min(abs(excluded - centre));
if clusterRadius >= 0.04 .* excludedRadius
    error('ndelta:test:CauchyClusterNotIsolated', ...
        'The selected poles do not form one isolated Cauchy cluster.');
end
radius = max(8 .* clusterRadius, 0.15 .* excludedRadius);
radius = min(radius, 0.35 .* excludedRadius);
angles = 2 .* pi .* (0:(numberOfPoints - 1)) ./ numberOfPoints;
unitCircle = exp(1i .* angles);
q3 = centre + radius .* unitCircle;
integrand = ndelta.g1.q3_integrand( ...
    q3, distance, omega, kappaI, P, channel);
residueSum = mean(radius .* unitCircle .* integrand);
value = multiplier .* residueSum;
end

function [internalT, internalR] = old_internal(omega, kappaI, P, g)
numerator = omega.^3 + 4 .* kappaI .* omega.^2 ...
    + (5 .* kappaI.^2 - P.^2) .* omega + 2 .* kappaI.^3;
dMinus = omega + kappaI - P;
dPlus = omega + kappaI + P;
F = numerator ./ ((2 .* kappaI + 1i .* g) .* omega ...
    .* kappaI.^2 .* dMinus.^2 .* dPlus.^2);
internalT = (1i .* g ./ 2) .* F;
internalR = -1i .* g .* (omega + 2 .* kappaI) ./ ( ...
    2 .* omega .* (2 .* kappaI + 1i .* g) ...
    .* (P.^2 - kappaI.^2) .* ((omega + kappaI).^2 - P.^2));
end
