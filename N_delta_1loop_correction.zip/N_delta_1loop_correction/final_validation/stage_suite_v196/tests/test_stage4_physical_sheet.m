function tests = test_stage4_physical_sheet
%TEST_STAGE4_PHYSICAL_SHEET Outward cuts and continuous-root tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
topology = struct();
topology.model = struct('mphi', 0.2, 'mPhi', 1.4, 'mu', 0);
topology.E = 0.3;
topology.qPerp = 0.1;
topology.epsilon = 1e-9;
topology.P = sqrt(topology.E.^2 - topology.model.mphi.^2);
testCase.TestData.topology = topology;
end

function testTransverseEnergiesAndIndependentRootContract(testCase)
cfg = testCase.TestData.cfg;
qPerp = 0.31;
scales = ndelta.sheet.transverse_energies(qPerp, cfg.model);
verifyEqual(testCase, scales.Ephi, hypot(qPerp, cfg.model.mphi), ...
    'AbsTol', 5e-16);
verifyEqual(testCase, scales.EPhi, hypot(qPerp, cfg.model.mPhi), ...
    'AbsTol', 5e-16);
roots = ndelta.sheet.physical_roots(0.17 + 0.2i, qPerp, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
verifyEqual(testCase, roots.numberOfIndependentRoots, 2);
verifyEqual(testCase, roots.independentRootNames, {'omega', 'kappaI'});
verifyFalse(testCase, isfield(roots, 'kappaB'));
verifyLessThanOrEqual(testCase, ...
    abs(roots.kappaBOfPMinusQ - roots.kappaI), ...
    cfg.tolerances.rootResidual);
verifyLessThanOrEqual(testCase, ...
    abs(roots.kappaI - 1i .* roots.decayConventionKappaI), ...
    cfg.tolerances.rootResidual);
end

function testPhysicalRootEquations(testCase)
cfg = testCase.TestData.cfg;
q0 = [-1.1 + 0.2i, -0.2, 0.13 + 0.4i, 0.9 - 0.3i];
roots = ndelta.sheet.physical_roots(q0, 0.27, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
verifyLessThanOrEqual(testCase, ...
    roots.maximumOmegaRelativeResidual, ...
    cfg.tolerances.rootResidual);
verifyLessThanOrEqual(testCase, ...
    roots.maximumKappaIRelativeResidual, ...
    cfg.tolerances.rootResidual);
end

function testRealAxisFeynmanSigns(testCase)
cfg = testCase.TestData.cfg;
q0 = linspace(-3, 3, 501);
roots = ndelta.sheet.physical_roots(q0, 0.1, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
verifyGreaterThan(testCase, min(imag(roots.omega)), 0);
verifyGreaterThan(testCase, min(imag(roots.kappaI)), 0);
end

function testBranchPointsSolveRadicands(testCase)
cfg = testCase.TestData.cfg;
q = 0.1;
points = ndelta.sheet.branch_points(q, cfg.referenceEnergy, ...
    cfg.model, cfg.sheet.epsilon);
residuals = [ ...
    points.omega.left.^2 - points.scales.EPhi.^2 + ...
        1i .* cfg.sheet.epsilon, ...
    points.omega.right.^2 - points.scales.EPhi.^2 + ...
        1i .* cfg.sheet.epsilon, ...
    (cfg.referenceEnergy - points.kappaI.left).^2 - ...
        points.scales.Ephi.^2 + 1i .* cfg.sheet.epsilon, ...
    (cfg.referenceEnergy - points.kappaI.right).^2 - ...
        points.scales.Ephi.^2 + 1i .* cfg.sheet.epsilon];
verifyLessThanOrEqual(testCase, max(abs(residuals)), ...
    cfg.tolerances.rootResidual);
verifyEqual(testCase, points.types.omegaLeft, ...
    'branch_point_not_pole');
verifyEqual(testCase, points.types.kappaIRight, ...
    'branch_point_not_pole');
end

function testExactCutsStartAtBranchPoints(testCase)
cfg = testCase.TestData.cfg;
q = 0.1;
points = ndelta.sheet.branch_points(q, cfg.referenceEnergy, ...
    cfg.model, cfg.sheet.epsilon);
cuts = ndelta.sheet.outward_cut_points(0, q, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
errors = [cuts.omega.left - points.omega.left, ...
    cuts.omega.right - points.omega.right, ...
    cuts.kappaI.left - points.kappaI.left, ...
    cuts.kappaI.right - points.kappaI.right];
verifyLessThanOrEqual(testCase, max(abs(errors)), ...
    cfg.tolerances.cutResidual);
end

function testExactCutRadicands(testCase)
cfg = testCase.TestData.cfg;
s = linspace(0, 1.3, 101);
cuts = ndelta.sheet.outward_cut_points(s, 0.1, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
residuals = [cuts.omegaLeftResidual(:); ...
    cuts.omegaRightResidual(:); cuts.kappaILeftResidual(:); ...
    cuts.kappaIRightResidual(:)];
verifyLessThanOrEqual(testCase, max(abs(residuals)), ...
    cfg.tolerances.cutResidual);
end

function testOutwardCutBankSigns(testCase)
cfg = testCase.TestData.cfg;
epsilon = 1e-12;
s = 0.2;
delta = 1e-6;
cuts = ndelta.sheet.outward_cut_points(s, 0.1, ...
    cfg.referenceEnergy, cfg.model, epsilon);

omegaLeftUpper = root_at(cuts.omega.left + 1i .* delta, 'omega');
omegaLeftLower = root_at(cuts.omega.left - 1i .* delta, 'omega');
omegaRightUpper = root_at(cuts.omega.right + 1i .* delta, 'omega');
omegaRightLower = root_at(cuts.omega.right - 1i .* delta, 'omega');
kappaLeftUpper = root_at(cuts.kappaI.left + 1i .* delta, 'kappaI');
kappaLeftLower = root_at(cuts.kappaI.left - 1i .* delta, 'kappaI');
kappaRightUpper = root_at(cuts.kappaI.right + 1i .* delta, 'kappaI');
kappaRightLower = root_at(cuts.kappaI.right - 1i .* delta, 'kappaI');

verifyLessThan(testCase, real(omegaLeftUpper), 0);
verifyGreaterThan(testCase, real(omegaLeftLower), 0);
verifyGreaterThan(testCase, real(omegaRightUpper), 0);
verifyLessThan(testCase, real(omegaRightLower), 0);
verifyLessThan(testCase, real(kappaLeftUpper), 0);
verifyGreaterThan(testCase, real(kappaLeftLower), 0);
verifyGreaterThan(testCase, real(kappaRightUpper), 0);
verifyLessThan(testCase, real(kappaRightLower), 0);
verifyLessThanOrEqual(testCase, ...
    max(abs(abs([omegaLeftUpper, omegaLeftLower, ...
    omegaRightUpper, omegaRightLower, kappaLeftUpper, ...
    kappaLeftLower, kappaRightUpper, kappaRightLower]) - s)), 2e-5);

    function value = root_at(q0, fieldName)
        values = ndelta.sheet.physical_roots(q0, 0.1, ...
            cfg.referenceEnergy, cfg.model, epsilon);
        value = values.(fieldName);
    end
end

function testWickConditionAndFiniteEpsilonQuadrants(testCase)
topology = testCase.TestData.topology;
P = topology.P;
below = ndelta.sheet.branch_geometry(0.8 .* P, ...
    topology.E, topology.model, topology.epsilon);
at = ndelta.sheet.branch_geometry(P, topology.E, ...
    topology.model, topology.epsilon);
above = ndelta.sheet.branch_geometry(1.2 .* P, ...
    topology.E, topology.model, topology.epsilon);
largeEpsilon = 0.2;
largeEpsilonGeometry = ndelta.sheet.branch_geometry(0.8 .* P, ...
    topology.E, topology.model, largeEpsilon);
largeEpsilonPoints = ndelta.sheet.branch_points(0.8 .* P, ...
    topology.E, topology.model, largeEpsilon);
verifyTrue(testCase, below.hasKappaILeftSegmentInQI);
verifyFalse(testCase, at.hasKappaILeftSegmentInQI);
verifyFalse(testCase, above.hasKappaILeftSegmentInQI);
verifyEqual(testCase, ...
    largeEpsilonGeometry.hasKappaILeftSegmentInQI, ...
    real(largeEpsilonPoints.kappaI.left) > 0 && ...
    imag(largeEpsilonPoints.kappaI.left) > 0);
verifyTrue(testCase, ...
    largeEpsilonGeometry.zeroEpsilonKappaLeftCriterion);
verifyEqual(testCase, below.branchPointQuadrants.omegaLeft, "QII");
verifyEqual(testCase, below.branchPointQuadrants.omegaRight, "QIV");
verifyEqual(testCase, below.branchPointQuadrants.kappaILeft, "QI");
verifyEqual(testCase, below.branchPointQuadrants.kappaIRight, "QIV");
verifyTrue(testCase, below.thirdQuadrantClearForRootRotation);
verifyFalse(testCase, below.poleClassificationPerformed);
end

function testNoCutFirstQuadrantPathStaysPhysical(testCase)
topology = testCase.TestData.topology;
q = topology.P + 0.25;
theta = linspace(0, pi ./ 2, 301);
path = 0.15 .* exp(1i .* theta);
lifted = ndelta.sheet.continue_roots(path, q, ...
    topology.E, topology.model, topology.epsilon);
verifyEqual(testCase, lifted.diagnostics.endParityOmega, +1);
verifyEqual(testCase, lifted.diagnostics.endParityKappaI, +1);
verifyTrue(testCase, all(lifted.diagnostics.physicalMatchOmega));
verifyTrue(testCase, all(lifted.diagnostics.physicalMatchKappaI));
end

function testCrossingKappaCutChangesOnlyKappaSheet(testCase)
topology = testCase.TestData.topology;
q = topology.qPerp;
scales = ndelta.sheet.transverse_energies(q, topology.model);
s = min(0.04, 0.15 .* scales.Ephi);
cut = ndelta.sheet.outward_cut_points(s, q, ...
    topology.E, topology.model, topology.epsilon);
path = cut.kappaI.left + 1i .* linspace(-2e-3, 2e-3, 240);
lifted = ndelta.sheet.continue_roots(path, q, ...
    topology.E, topology.model, topology.epsilon);
verifyEqual(testCase, lifted.diagnostics.endParityOmega, +1);
verifyEqual(testCase, lifted.diagnostics.endParityKappaI, -1);
end

function testThirdQuadrantPathStaysPhysical(testCase)
topology = testCase.TestData.topology;
theta = linspace(-pi, -pi ./ 2, 301);
path = 0.25 .* exp(1i .* theta);
lifted = ndelta.sheet.continue_roots(path, topology.qPerp, ...
    topology.E, topology.model, topology.epsilon);
verifyEqual(testCase, lifted.diagnostics.endParityOmega, +1);
verifyEqual(testCase, lifted.diagnostics.endParityKappaI, +1);
end

function testOneOmegaLoopChangesOnlyOmegaSheet(testCase)
topology = testCase.TestData.topology;
q = topology.qPerp;
points = ndelta.sheet.branch_points(q, topology.E, ...
    topology.model, topology.epsilon);
theta = linspace(pi ./ 2, 5 .* pi ./ 2, 400);
path = points.omega.right + 0.04 .* exp(1i .* theta);
lifted = ndelta.sheet.continue_roots(path, q, ...
    topology.E, topology.model, topology.epsilon);
verifyEqual(testCase, lifted.diagnostics.endParityOmega, -1);
verifyEqual(testCase, lifted.diagnostics.endParityKappaI, +1);
end

function testTwoOmegaLoopsReturnToPhysicalSheet(testCase)
topology = testCase.TestData.topology;
q = topology.qPerp;
points = ndelta.sheet.branch_points(q, topology.E, ...
    topology.model, topology.epsilon);
theta = linspace(pi ./ 2, 9 .* pi ./ 2, 800);
path = points.omega.right + 0.04 .* exp(1i .* theta);
lifted = ndelta.sheet.continue_roots(path, q, ...
    topology.E, topology.model, topology.epsilon);
verifyEqual(testCase, lifted.diagnostics.endParityOmega, +1);
verifyEqual(testCase, lifted.diagnostics.endParityKappaI, +1);
end

function testPathShapeAndRefinementStability(testCase)
cfg = testCase.TestData.cfg;
topology = testCase.TestData.topology;
q = topology.P + 0.25;
coarsePath = 0.15 .* exp(1i .* linspace(0, pi ./ 2, 101));
finePath = 0.15 .* exp(1i .* linspace(0, pi ./ 2, 401));
coarse = ndelta.sheet.continue_roots(coarsePath, q, ...
    topology.E, topology.model, topology.epsilon);
fine = ndelta.sheet.continue_roots(finePath(:), q, ...
    topology.E, topology.model, topology.epsilon);
verifySize(testCase, coarse.omega, size(coarsePath));
verifySize(testCase, fine.omega, size(finePath(:)));
verifyLessThanOrEqual(testCase, abs(coarse.omega(end) - fine.omega(end)), ...
    cfg.tolerances.rootResidual);
verifyLessThanOrEqual(testCase, ...
    abs(coarse.kappaI(end) - fine.kappaI(end)), ...
    cfg.tolerances.rootResidual);
end

function testPathHittingBranchPointIsRejected(testCase)
topology = testCase.TestData.topology;
q = topology.qPerp;
points = ndelta.sheet.branch_points(q, topology.E, ...
    topology.model, topology.epsilon);
path = [0, points.omega.right, 0.2i];
verifyError(testCase, @() ndelta.sheet.continue_roots(path, q, ...
    topology.E, topology.model, topology.epsilon), ...
    'ndelta:sheet:PathHitsBranchPoint');
end

function testInvalidInputsAreRejected(testCase)
topology = testCase.TestData.topology;
verifyError(testCase, @() ndelta.sheet.physical_roots(0, -0.1, ...
    topology.E, topology.model, topology.epsilon), ...
    'ndelta:sheet:InvalidQPerp');
verifyError(testCase, @() ndelta.sheet.physical_roots(0, 0.1, ...
    topology.E, topology.model, 0), ...
    'ndelta:sheet:InvalidEpsilon');
verifyError(testCase, @() ndelta.sheet.physical_roots(NaN, 0.1, ...
    topology.E, topology.model, topology.epsilon), ...
    'ndelta:sheet:InvalidQ0');
verifyError(testCase, @() ndelta.sheet.continue_roots([0, NaN], 0.1, ...
    topology.E, topology.model, topology.epsilon), ...
    'ndelta:sheet:InvalidPath');
verifyError(testCase, @() ndelta.sheet.outward_cut_points(-1, 0.1, ...
    topology.E, topology.model, topology.epsilon), ...
    'ndelta:sheet:InvalidCutParameter');
cut = ndelta.sheet.outward_cut_points(0.2, 0.1, ...
    topology.E, topology.model, topology.epsilon);
verifyError(testCase, @() ndelta.sheet.continue_roots( ...
    [cut.omega.right, cut.omega.right + 0.1i], 0.1, ...
    topology.E, topology.model, topology.epsilon), ...
    'ndelta:sheet:PathStartsOnCut');
smallEpsilon = 1e-14;
lane = ndelta.sheet.continue_roots([2, 2 + 0.1i], 0.1, ...
    topology.E, topology.model, smallEpsilon);
verifyEqual(testCase, lane.epsilon, smallEpsilon);
scales = ndelta.sheet.transverse_energies(0.1, topology.model);
thresholdLane = ndelta.sheet.continue_roots( ...
    [scales.EPhi, scales.EPhi + 0.01i], 0.1, ...
    topology.E, topology.model, smallEpsilon);
verifyEqual(testCase, thresholdLane.epsilon, smallEpsilon);
end

function testStage4IsIndependentOfNAndPerformsNoIntegration(testCase)
cfgA = testCase.TestData.cfg;
cfgB = cfgA;
cfgB.barriers.positions = [-1.2, -0.1, 0.7, 2.0];
cfgB.barriers.strengths = [0.3, 0, -0.2, 0.17];
cfgB.model.mu = -3.4;
cfgB = ndelta.config.finalize_configuration(cfgB);
stageA = run_stage4(cfgA);
stageB = run_stage4(cfgB);
verifyEqual(testCase, stageA.referenceRootsAtQ0Zero.omega, ...
    stageB.referenceRootsAtQ0Zero.omega);
verifyEqual(testCase, stageA.referenceRootsAtQ0Zero.kappaI, ...
    stageB.referenceRootsAtQ0Zero.kappaI);
verifyFalse(testCase, stageA.performsIntegration);
verifyFalse(testCase, stageA.evaluatesPoleResidues);
verifyFalse(testCase, stageA.evaluatesCollectivePoles);
verifyTrue(testCase, stageA.accepted);
end
