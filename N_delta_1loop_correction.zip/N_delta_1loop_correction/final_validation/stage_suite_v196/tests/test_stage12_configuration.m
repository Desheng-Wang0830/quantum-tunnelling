function tests = test_stage12_configuration
%TEST_STAGE12_CONFIGURATION Frozen scan-plan and profile contracts.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
end

function testDefaultPhysicalScanPlan(testCase)
cfg = testCase.TestData.cfg;
verifyEqual(testCase, cfg.configurationVersion, 1.9);
verifyEqual(testCase, cfg.stage12.energyValues, ...
    [0.24, 0.30, 0.50, 0.80, 1.10, 1.40]);
verifyEqual(testCase, cfg.stage12.nValues, [2, 3, 4]);
verifyEqual(testCase, cfg.stage12.support, [-0.5, 0.5]);
verifyEqual(testCase, cfg.stage12.totalStrength, -0.30);
verifyEqual(testCase, cfg.stage12.discretisation, ...
    'fixed_support_trapezoidal');
verifyGreaterThan(testCase, cfg.stage12.referenceOrderFactor, 1);
verifyEqual(testCase, cfg.stage12.perturbativeEtaLimit, 0.10);
end

function testReferenceEnergyMayBeATemporaryDiagnosticPoint(testCase)
cfg = testCase.TestData.cfg;
cfg.referenceEnergy = 0.37;
cfg = ndelta.config.finalize_configuration(cfg);
verifyEqual(testCase, cfg.referenceEnergy, 0.37);
verifyGreaterThan(testCase, min(abs( ...
    cfg.stage12.energyValues - cfg.referenceEnergy)), 1e-3);

% Frozen plan vectors retain the same meaning in either MATLAB vector
% orientation; the resolved runner contract canonicalises them to rows.
columnCfg = testCase.TestData.cfg;
columnCfg.stage12.energyValues = columnCfg.stage12.energyValues(:);
columnCfg.stage12.nValues = columnCfg.stage12.nValues(:);
columnCfg = ndelta.config.finalize_configuration(columnCfg);
options = ndelta.stage12.resolve_scan_options( ...
    columnCfg, struct('profile', 'production'));
verifyEqual(testCase, options.energyValues, ...
    testCase.TestData.cfg.stage12.energyValues);
verifyEqual(testCase, options.nValues, ...
    testCase.TestData.cfg.stage12.nValues);
portable = ndelta.stage12.resolve_scan_options( ...
    columnCfg, struct('profile', 'portable'));
verifyEqual(testCase, portable.energyValues, ...
    [columnCfg.referenceEnergy, columnCfg.stage12.energyValues(end)]);
verifyEqual(testCase, portable.nValues, 3);
quick = ndelta.stage12.resolve_scan_options( ...
    columnCfg, struct('profile', 'quick'));
verifyEqual(testCase, quick.energyValues, columnCfg.referenceEnergy);
verifyEqual(testCase, quick.nValues, 3);
end

function testRunStage12RequiresTheSelectedScanToContainItsAnchor(testCase)
cfg = testCase.TestData.cfg;
stage11 = struct('accepted', true, ...
    'configurationFingerprint', ndelta.config.physics_fingerprint(cfg), ...
    'integrated', struct(), 'combined', struct(), ...
    'termKernelMatrix', complex(zeros(4, 2)));
options = struct('profile', 'quick', 'energyValues', 0.50);
verifyError(testCase, @() run_stage12(cfg, stage11, options), ...
    'ndelta:stage12:ScanMissesReferenceEnergy');
end

function testMalformedEnergyAndCentreGridsAreRejected(testCase)
cfg = testCase.TestData.cfg;
cfg.stage12.energyValues = [0.24, 0.50, 0.50];
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:InvalidStage12EnergyGrid');

cfg = testCase.TestData.cfg;
cfg.stage12.nValues = [2, 2, 3];
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:InvalidStage12NGrid');
end

function testN3TrapezoidPreservesSupportAndSignedStrength(testCase)
cfg = testCase.TestData.cfg;
profile = ndelta.stage12.trapezoidal_profile( ...
    3, cfg.stage12.support, cfg.stage12.totalStrength);
verifyEqual(testCase, profile.positions, [-0.5, 0, 0.5]);
verifyEqual(testCase, profile.strengths, ...
    [-0.075, -0.15, -0.075], 'AbsTol', 5e-16);
verifyEqual(testCase, profile.totalStrength, -0.30, ...
    'AbsTol', 5e-16);
verifyTrue(testCase, profile.exactSupportEndpoints);
verifyTrue(testCase, profile.mirrorSymmetric);
auditCfg = ndelta.stage12.n3_audit_configuration(cfg);
verifyEqual(testCase, auditCfg.derived.N, 3);
verifyEqual(testCase, auditCfg.barriers.positions, profile.positions);
verifyEqual(testCase, auditCfg.barriers.strengths, profile.strengths);
end

function testN4TrapezoidPreservesSupportAndSignedStrength(testCase)
cfg = testCase.TestData.cfg;
profile = ndelta.stage12.trapezoidal_profile( ...
    4, cfg.stage12.support, cfg.stage12.totalStrength);
verifyEqual(testCase, profile.positions, ...
    [-0.5, -1 ./ 6, 1 ./ 6, 0.5], 'AbsTol', 5e-16);
verifyEqual(testCase, profile.strengths, ...
    [-0.05, -0.10, -0.10, -0.05], 'AbsTol', 5e-16);
verifyEqual(testCase, profile.totalStrength, -0.30, ...
    'AbsTol', 5e-16);
verifyTrue(testCase, profile.exactSupportEndpoints);
verifyTrue(testCase, profile.mirrorSymmetric);
end

function testHigherOrderReferenceRaisesEveryQuadratureOrder(testCase)
cfg = testCase.TestData.cfg;
names = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
low = struct();
for index = 1:numel(names)
    low.(names{index}) = 4;
end
low = ndelta.integration.resolve_options(cfg, low);
high = ndelta.stage12.higher_order_options(cfg, low);
for index = 1:numel(names)
    verifyGreaterThan(testCase, high.(names{index}), ...
        low.(names{index}));
end
end
