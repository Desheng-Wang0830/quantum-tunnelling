function tests = test_stage12_threshold_topology_provenance
%TEST_STAGE12_THRESHOLD_TOPOLOGY_PROVENANCE Threshold and identity gates.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.geometry = ndelta.geometry.build_geometry( ...
    data.cfg.barriers.positions, data.cfg.tolerances.distanceMerge);
data.spectrum = ndelta.singularity.find_collective_modes( ...
    data.cfg, data.geometry);
testCase.TestData.data = data;
end

function testCollectiveBoundModeLowersTheClosedElasticCeiling(testCase)
d = testCase.TestData.data;
verifyGreaterThan(testCase, d.spectrum.numberOfModes, 0);
expectedMasses = sqrt(d.cfg.model.mphi.^2 - ...
    [d.spectrum.modes.alpha].^2);
expectedThresholds = d.cfg.model.mPhi + expectedMasses;
window = ndelta.stage12.closed_elastic_window(d.cfg, d.spectrum);
verifyEqual(testCase, d.spectrum.boundModeMasses, expectedMasses, ...
    'AbsTol', 5e-14);
verifyEqual(testCase, d.spectrum.boundModeInelasticThresholds, ...
    expectedThresholds, 'AbsTol', 5e-14);
verifyEqual(testCase, d.spectrum.implementedElasticUpperBound, ...
    min([d.cfg.model.mphi + d.cfg.model.mPhi, expectedThresholds]), ...
    'AbsTol', 5e-14);
verifyEqual(testCase, d.spectrum.implementedElasticUpperBound, ...
    1.5426426, 'AbsTol', 3e-7);
verifyLessThan(testCase, d.spectrum.implementedElasticUpperBound, ...
    d.cfg.model.mphi + d.cfg.model.mPhi);
verifyGreaterThan(testCase, d.spectrum.limitingInelasticModeIndex, 0);
verifyEqual(testCase, window.upper, ...
    d.spectrum.implementedElasticUpperBound, 'AbsTol', 5e-14);
verifyTrue(testCase, window.includesPhiPlusBoundModeThresholds);
verifyTrue(testCase, window.qPerpCriticalIsNotProductionThreshold);
verifyTrue(testCase, ...
    d.spectrum.qPerpCriticalIsNotInelasticProductionThreshold);
end

function testAboveBoundModeThresholdIsRejectedBeforeIntegration(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.referenceEnergy = d.spectrum.implementedElasticUpperBound + 0.01;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyFalse(testCase, spectrum.accepted);
verifyFalse(testCase, ...
    spectrum.referenceEnergyBelowImplementedElasticUpperBound);

window = ndelta.stage12.closed_elastic_window(cfg, spectrum);
verifyFalse(testCase, window.accepted);
verifyEqual(testCase, window.classification, ...
    'inelastic_channel_not_implemented');
point = ndelta.stage12.evaluate_direction(cfg, low_options());
verifyFalse(testCase, point.accepted);
verifyEqual(testCase, point.rejectionIdentifier, ...
    'ndelta:stage12:InelasticChannelNotImplemented');
verifyEmpty(testCase, fieldnames(point.reduced));
end

function testNoCollectiveModeLeavesTheFreeTwoParticleCeiling(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.strengths = abs(cfg.barriers.strengths);
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
window = ndelta.stage12.closed_elastic_window(cfg, spectrum);
verifyEqual(testCase, spectrum.numberOfModes, 0);
verifyEqual(testCase, window.upper, cfg.model.mphi + cfg.model.mPhi);
verifyEqual(testCase, window.limitingModeIndex, 0);
verifyTrue(testCase, window.accepted);
end

function testTopologySamplerTracksTheExactActiveModeSet(testCase)
cfg = testCase.TestData.data.cfg;
modes = repmat(struct('stable', true, ...
    'hasOpenTransverseSupport', true, 'qPerpCritical', 0), 1, 2);
modes(1).qPerpCritical = 0.20;
modes(2).qPerpCritical = 0.50;
topology = ndelta.stage12.topology_qperp_points( ...
    cfg, struct('modes', modes));
verifyEqual(testCase, numel(topology.records), 4);
verifyEqual(testCase, [topology.records.cutActive], ...
    [true, true, false, false]);
verifyEqual(testCase, ...
    topology.records(1).collectiveModeIndices, [1, 2]);
verifyEqual(testCase, ...
    topology.records(2).collectiveModeIndices, 2);
verifyEqual(testCase, ...
    topology.records(3).collectiveModeIndices, 2);
verifyEmpty(testCase, topology.records(4).collectiveModeIndices);
verifySize(testCase, ...
    topology.records(4).collectiveModeIndices, [1, 0]);
verifyEqual(testCase, topology.records(4).qPerp, ...
    1.2 .* topology.boundaries(end));
verifyTrue(testCase, topology.coversEveryOpenTopologyInterval);
verifyTrue(testCase, topology.tracksModeIndexSetsNotOnlyAnyMode);
end

function testCoincidentTopologyEventsDoNotCreateZeroWidthSamples(testCase)
cfg = testCase.TestData.data.cfg;
qCut = sqrt(cfg.derived.P.^2 - ...
    (cfg.sheet.epsilon ./ (2 .* cfg.referenceEnergy)).^2);
modes = repmat(struct('stable', true, ...
    'hasOpenTransverseSupport', true, ...
    'qPerpCritical', qCut), 1, 2);
topology = ndelta.stage12.topology_qperp_points( ...
    cfg, struct('modes', modes));
verifyEqual(testCase, numel(topology.boundaries), 1);
verifyEqual(testCase, numel(topology.records), 2);
verifyEqual(testCase, ...
    topology.records(1).collectiveModeIndices, [1, 2]);
verifyEmpty(testCase, topology.records(2).collectiveModeIndices);
verifySize(testCase, ...
    topology.records(2).collectiveModeIndices, [1, 0]);
verifyEqual(testCase, topology.records(2).qPerp, 1.2 .* qCut);
verifyTrue(testCase, topology.records(1).cutActive);
verifyFalse(testCase, topology.records(2).cutActive);
end

function testObservableFingerprintIncludesMu(testCase)
d = testCase.TestData.data;
options = ndelta.integration.resolve_options(d.cfg, low_options());
first = ndelta.stage12.observable_fingerprint( ...
    d.cfg, options, d.spectrum);
changedCfg = d.cfg;
changedCfg.model.mu = 2 .* changedCfg.model.mu;
changedCfg = ndelta.config.finalize_configuration(changedCfg);
second = ndelta.stage12.observable_fingerprint( ...
    changedCfg, options, d.spectrum);
verifyEqual(testCase, first.physics, second.physics);
verifyEqual(testCase, first.integration, second.integration);
verifyEqual(testCase, first.spectrum, second.spectrum);
verifyNotEqual(testCase, first.mu, second.mu);
verifyNotEqual(testCase, first, second);
verifyEqual(testCase, second.strictOrder, 'O(mu^2)');
end

function testDirectionFlagsDoNotRelabelAUnitarityFailureAsThreshold(testCase)
d = testCase.TestData.data;
direction = synthetic_integrated_direction(d);
direction.accepted = false;
flags = ndelta.stage12.direction_contract_flags(direction);
verifyTrue(testCase, flags.thresholdIntegrationSafe);
verifyTrue(testCase, flags.observableProvenanceAccepted);
verifyTrue(testCase, flags.strictOrderAccepted);

skipped = direction;
skipped.elasticWindow.accepted = false;
skipped.reduced = struct();
skipped.combined = struct();
skipped.observableFingerprint = struct();
skippedFlags = ndelta.stage12.direction_contract_flags(skipped);
verifyTrue(testCase, skippedFlags.thresholdIntegrationSafe);
verifyTrue(testCase, skippedFlags.observableProvenanceAccepted);
verifyTrue(testCase, skippedFlags.strictOrderAccepted);

silentlyIntegrated = direction;
silentlyIntegrated.elasticWindow.accepted = false;
silentFlags = ndelta.stage12.direction_contract_flags(silentlyIntegrated);
verifyFalse(testCase, silentFlags.thresholdIntegrationSafe);
end

function testDirectionFlagsRequireExactObservableProvenance(testCase)
d = testCase.TestData.data;
direction = synthetic_integrated_direction(d);
flags = ndelta.stage12.direction_contract_flags(direction);
verifyTrue(testCase, flags.observableProvenanceAccepted);

mutated = direction;
mutated.observableFingerprint.version = 2;
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.observableProvenanceAccepted);
mutated = direction;
mutated.observableFingerprint.physics.referenceEnergy = ...
    mutated.observableFingerprint.physics.referenceEnergy + 0.01;
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.observableProvenanceAccepted);
mutated = direction;
mutated.observableFingerprint.integration.effectiveOptions.q4Order = ...
    mutated.observableFingerprint.integration.effectiveOptions.q4Order + 1;
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.observableProvenanceAccepted);
mutated = direction;
mutated.observableFingerprint.spectrum.numberOfModes = ...
    mutated.observableFingerprint.spectrum.numberOfModes + 1;
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.observableProvenanceAccepted);
mutated = direction;
mutated.observableFingerprint.strictOrder = 'O(mu^4)';
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.strictOrderAccepted);
mutated = direction;
mutated.observableFingerprint.lszConvention = 'stale';
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.strictOrderAccepted);
mutated = direction;
mutated.observableFingerprint.amplitudeSquaredIncluded = true;
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.strictOrderAccepted);
mutated = direction;
mutated.combined.mu4TermsIncluded = true;
flags = ndelta.stage12.direction_contract_flags(mutated);
verifyFalse(testCase, flags.strictOrderAccepted);
end

function testFreshMirrorContractChecksProductionAndHigherOrder(testCase)
item = struct('centredMirrorSymmetry', struct('accepted', false), ...
    'mirrorReusedByExactParity', false, ...
    'rightIncidenceObtainedFromMirroredPotential', true, ...
    'fullTwoByTwoSMatrixTested', true);
anchor = struct('pair', struct('production', item, ...
    'higherOrder', item));
verifyTrue(testCase, ndelta.stage12.asymmetric_mirror_contract(anchor));
anchor.pair.production.mirrorReusedByExactParity = true;
verifyFalse(testCase, ndelta.stage12.asymmetric_mirror_contract(anchor));
anchor.pair.production.mirrorReusedByExactParity = false;
anchor.pair.higherOrder.fullTwoByTwoSMatrixTested = false;
verifyFalse(testCase, ndelta.stage12.asymmetric_mirror_contract(anchor));
anchor.pair.higherOrder.fullTwoByTwoSMatrixTested = [true, true];
verifyFalse(testCase, ndelta.stage12.asymmetric_mirror_contract(anchor));
end

function testG2RejectsAStaleCollectiveSolverFingerprint(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.collective.scanSamples = 1001;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
verifyError(testCase, @() ndelta.integration.integrate_g2( ...
    cfg, geometry, d.spectrum, context, low_options()), ...
    'ndelta:stage11:SpectrumSolverConfigurationMismatch');
end

function options = low_options()
options = struct('q4Order', 4, 'qPerpOrder', 4, ...
    'collectiveOrder', 4, 'cutRadialOrder', 4, ...
    'cutAngleOrder', 4, 'endpointOrder', 4);
end

function direction = synthetic_integrated_direction(data)
options = ndelta.integration.resolve_options(data.cfg, low_options());
direction = struct();
direction.accepted = true;
direction.elasticWindow = struct('accepted', true);
direction.reduced = struct('G1', struct('value', 0));
direction.combined = struct('amplitudeSquaredIncluded', false, ...
    'mu4TermsIncluded', false);
direction.configuration = data.cfg;
direction.configurationFingerprint = ...
    ndelta.config.physics_fingerprint(data.cfg);
direction.effectiveOptions = options;
direction.spectrum = data.spectrum;
direction.observableFingerprint = ndelta.stage12.observable_fingerprint( ...
    data.cfg, options, data.spectrum);
direction.unresolvedNearDegeneracy = false;
end
