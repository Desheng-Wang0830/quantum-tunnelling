function tests = test_stage12_recovery
%TEST_STAGE12_RECOVERY Cheap regression tests for conservative recovery.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.projectRoot = projectRoot;
end

function testRunStage12ReturnsRejectedEnvelopeInsteadOfThrowing(testCase)
source = fileread(which('run_stage12'));
verifyEmpty(testCase, strfind(source, ...
    'ndelta:stage12:ValidationRejected')); %#ok<STREMP>
verifyEmpty(testCase, strfind(source, ...
    'cfg.execution.failOnBenchmarkFailure && ~stage12.accepted')); %#ok<STREMP>
end

function testDiagnosticsNameEveryFailedValidationRecord(testCase)
stage12 = synthetic_rejected_stage12();
text = evalc('ndelta.stage12.print_diagnostics(stage12);');
verifyNotEmpty(testCase, strfind(text, ...
    'all_term_channel_sources_converge_at_higher_order')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(text, ...
    'all_full_S_one_loop_unitarity_gates_pass')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(text, '2/4')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(text, '[FAIL]')); %#ok<STREMP>
end

function testCheckpointKeyIsStableAndExact(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
options = ndelta.stage12.resolve_scan_options( ...
    cfg, struct('profile', 'production'));
plan = struct('jobIds', {{'energy_1', 'energy_2'}}, ...
    'orders', [18, 24], 'epsilon', 1e-9);
key1 = ndelta.stage12.checkpoint_key( ...
    cfg, options, 'scan_points', plan);
key2 = ndelta.stage12.checkpoint_key( ...
    cfg, options, 'scan_points', plan);
verifyTrue(testCase, isequaln(key2, key1));

changedPlan = plan;
changedPlan.orders(2) = changedPlan.orders(2) + 1;
changedKey = ndelta.stage12.checkpoint_key( ...
    cfg, options, 'scan_points', changedPlan);
verifyFalse(testCase, isequaln(changedKey, key1));

changedCfg = cfg;
changedCfg.model.mu = 2 .* changedCfg.model.mu;
changedCfg = ndelta.config.finalize_configuration(changedCfg);
changedPhysicsKey = ndelta.stage12.checkpoint_key( ...
    changedCfg, options, 'scan_points', plan);
verifyFalse(testCase, isequaln(changedPhysicsKey, key1));
end

function testCheckpointSaveThenExactHitSkipsProducer(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
options = ndelta.stage12.resolve_scan_options( ...
    cfg, struct('profile', 'production'));
plan = struct('caseIds', {{'one', 'two'}}, 'order', 8);
producerCalls = 0;

[firstPayload, firstReport] = ndelta.stage12.checkpoint_phase( ...
    cfg, options, 'unit_exact_hit', plan, @producer);
[secondPayload, secondReport] = ndelta.stage12.checkpoint_phase( ...
    cfg, options, 'unit_exact_hit', plan, @producer);

verifyEqual(testCase, producerCalls, 1);
verifyEqual(testCase, firstPayload, struct('marker', 1, ...
    'values', [2, 3, 5]));
verifyEqual(testCase, secondPayload, firstPayload);
verifyTrue(testCase, firstReport.enabled);
verifyFalse(testCase, firstReport.hit);
verifyTrue(testCase, firstReport.saved);
verifyEqual(testCase, firstReport.status, ...
    'checkpoint_saved_after_complete_phase');
verifyTrue(testCase, secondReport.enabled);
verifyTrue(testCase, secondReport.hit);
verifyFalse(testCase, secondReport.saved);
verifyEqual(testCase, secondReport.status, 'checkpoint_hit_exact_key');
verifyEqual(testCase, secondReport.key, firstReport.key);
verifyEqual(testCase, secondReport.path, firstReport.path);
verifyEqual(testCase, exist(firstReport.path, 'file'), 2);

    function payload = producer()
        producerCalls = producerCalls + 1;
        payload = struct('marker', producerCalls, ...
            'values', [2, 3, 5]);
    end
end

function testCheckpointKeyMismatchRecomputes(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
options = ndelta.stage12.resolve_scan_options( ...
    cfg, struct('profile', 'production'));
plan1 = struct('caseIds', {{'one', 'two'}}, 'order', 8);
plan2 = plan1;
plan2.order = 10;
producerCalls = 0;

[payload1, report1] = ndelta.stage12.checkpoint_phase( ...
    cfg, options, 'unit_mismatch', plan1, @producer);
[payload2, report2] = ndelta.stage12.checkpoint_phase( ...
    cfg, options, 'unit_mismatch', plan2, @producer);

verifyEqual(testCase, producerCalls, 2);
verifyEqual(testCase, payload1.marker, 1);
verifyEqual(testCase, payload2.marker, 2);
verifyFalse(testCase, report1.hit);
verifyFalse(testCase, report2.hit);
verifyEqual(testCase, report2.path, report1.path);
verifyFalse(testCase, isequaln(report2.key, report1.key));

    function payload = producer()
        producerCalls = producerCalls + 1;
        payload = struct('marker', producerCalls);
    end
end

function testCorruptCheckpointFallsBackToFreshProducer(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
options = ndelta.stage12.resolve_scan_options( ...
    cfg, struct('profile', 'production'));
plan = struct('caseIds', {{'only'}}, 'order', 6);
producerCalls = 0;

[payload1, report1] = ndelta.stage12.checkpoint_phase( ...
    cfg, options, 'unit_corrupt', plan, @producer);
fileId = fopen(report1.path, 'wb');
verifyGreaterThanOrEqual(testCase, fileId, 0);
fwrite(fileId, uint8('not a MAT file'), 'uint8');
fclose(fileId);
[payload2, report2] = ndelta.stage12.checkpoint_phase( ...
    cfg, options, 'unit_corrupt', plan, @producer);

verifyEqual(testCase, producerCalls, 2);
verifyEqual(testCase, payload1.marker, 1);
verifyEqual(testCase, payload2.marker, 2);
verifyFalse(testCase, report2.hit);
verifyTrue(testCase, report2.saved);
verifyEqual(testCase, report2.status, ...
    'checkpoint_saved_after_complete_phase');
verifyEqual(testCase, exist(report2.path, 'file'), 2);

    function payload = producer()
        producerCalls = producerCalls + 1;
        payload = struct('marker', producerCalls);
    end
end

function testNonProductionProfilesBypassCheckpointByDefault(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
profiles = {'portable', 'quick'};
producerCalls = 0;
for index = 1:numel(profiles)
    options = ndelta.stage12.resolve_scan_options( ...
        cfg, struct('profile', profiles{index}));
    phase = sprintf('unit_nonproduction_%s', profiles{index});
    [payload, report] = ndelta.stage12.checkpoint_phase( ...
        cfg, options, phase, struct('index', index), @producer);
    verifyEqual(testCase, payload.marker, index);
    verifyFalse(testCase, report.enabled);
    verifyFalse(testCase, report.hit);
    verifyFalse(testCase, report.saved);
    verifyEqual(testCase, report.status, ...
        'checkpoint_disabled_nonproduction');
end
verifyEqual(testCase, producerCalls, 2);
checkpointDirectory = fullfile(cfg.projectRoot, ...
    cfg.output.directoryName, 'stage12_checkpoints');
verifyEqual(testCase, exist(checkpointDirectory, 'dir'), 0);

    function payload = producer()
        producerCalls = producerCalls + 1;
        payload = struct('marker', producerCalls);
    end
end

function testRejectedStage12SnapshotIsSavedAndInspectable(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
result = struct('release', 'synthetic_recovery_test', ...
    'configuration', cfg, 'stage12', synthetic_rejected_stage12());
path = ndelta.reporting.save_rejected_stage12_result(cfg, result);
verifyEqual(testCase, exist(path, 'file'), 2);
variables = whos('-file', path);
verifyNotEmpty(testCase, variables);
loaded = load(path);
verifyTrue(testCase, isfield(loaded, 'result'));
verifyTrue(testCase, isfield(loaded.result, 'stage12'));
verifyFalse(testCase, loaded.result.stage12.accepted);
verifyEqual(testCase, loaded.result.stage12.status, ...
    'stage12_validation_rejected');
verifyTrue(testCase, isfield(loaded, 'recoveryMetadata'));
verifyEqual(testCase, loaded.recoveryMetadata.status, ...
    loaded.result.stage12.status);
end

function testRunAllSavesAndPrintsRejectedResultBeforeThrow(testCase)
source = fileread(which('run_all_stages'));
saveIndex = first_index(source, ...
    'ndelta.reporting.save_rejected_stage12_result');
diagnosticIndex = first_index(source, ...
    'ndelta.stage12.print_diagnostics');
throwIndex = first_index(source, ...
    'ndelta:stage12:ValidationRejected');
outputRethrowIndex = first_index(source, ...
    'rethrow(outputWriteException)');
verifyGreaterThan(testCase, saveIndex, 0);
verifyGreaterThan(testCase, diagnosticIndex, 0);
verifyGreaterThan(testCase, outputRethrowIndex, saveIndex);
verifyGreaterThan(testCase, throwIndex, ...
    max(saveIndex, diagnosticIndex));
end

function testPortableSelfTestSavesAndPrintsBeforeAssert(testCase)
source = fileread(which('run_self_tests'));
saveIndex = first_index(source, ...
    'ndelta.reporting.save_rejected_portable_self_test');
diagnosticIndex = first_index(source, ...
    'ndelta.stage12.print_diagnostics');
assertIndex = first_index(source, 'assert(stage12.accepted');
verifyGreaterThan(testCase, saveIndex, 0);
verifyGreaterThan(testCase, diagnosticIndex, saveIndex);
verifyGreaterThan(testCase, assertIndex, diagnosticIndex);
end

function testRejectedPortableSelfTestSnapshotIsInspectable(testCase)
[cfg, temporaryRoot, cleanup] = isolated_configuration(); %#ok<ASGLU>
stage11 = struct('accepted', true, 'marker', 'synthetic_stage11');
stage12 = synthetic_rejected_stage12();
stage12.options = struct('profile', 'portable');
path = ndelta.reporting.save_rejected_portable_self_test( ...
    cfg, stage11, stage12);
verifyEqual(testCase, exist(path, 'file'), 2);
loaded = load(path);
verifyEqual(testCase, loaded.stage11.marker, 'synthetic_stage11');
verifyFalse(testCase, loaded.stage12.accepted);
verifyEqual(testCase, loaded.recoveryMetadata.profile, 'portable');
verifyEqual(testCase, loaded.recoveryMetadata.validation, ...
    loaded.stage12.validation);
verifyEqual(testCase, numel(loaded.badRecords), 2);
verifyFalse(testCase, any([loaded.badRecords.passed]));
end

function [cfg, temporaryRoot, cleanup] = isolated_configuration()
cfg = run_stage0(false);
temporaryRoot = tempname;
mkdir(temporaryRoot);
cleanup = onCleanup(@() remove_temporary_root(temporaryRoot));
cfg.projectRoot = temporaryRoot;
cfg.output.directoryName = 'output';
cfg.output.saveMatFile = false;
cfg.output.writeTextReport = false;
cfg.output.writeStage4Figure = false;
cfg.output.writeStage9Figure = false;
cfg.output.writeStage10Figure = false;
cfg.output.writeStage12Figure = false;
cfg.execution.parallel.mode = 'serial';
cfg = ndelta.config.finalize_configuration(cfg);
end

function remove_temporary_root(path)
if exist(path, 'dir')
    rmdir(path, 's');
end
end

function stage12 = synthetic_rejected_stage12()
records = repmat(struct('name', '', 'error', 0, 'tolerance', 1, ...
    'normalisedError', 0, 'passed', true), 4, 1);
records(1).name = 'reference_Stage11_preflight_is_accepted';
records(2).name = ...
    'all_term_channel_sources_converge_at_higher_order';
records(2).error = 0.031;
records(2).tolerance = 0.020;
records(2).normalisedError = 1.55;
records(2).passed = false;
records(3).name = 'all_full_S_one_loop_unitarity_gates_pass';
records(3).error = 1.42;
records(3).tolerance = 1;
records(3).normalisedError = 1.42;
records(3).passed = false;
records(4).name = ...
    'N_profiles_preserve_total_signed_strength';
stage12 = struct();
stage12.accepted = false;
stage12.formalPhysicsResultsReleased = false;
stage12.status = 'stage12_validation_rejected';
stage12.validation = struct('records', records, ...
    'numberOfChecks', 4, 'numberPassed', 2, 'accepted', false, ...
    'maximumNormalisedError', 1.55, ...
    'maximumSourceConvergenceError', 0.031, ...
    'maximumTermConvergenceError', 0.012, ...
    'maximumFullSMatrixNormalisedError', 1.42);
stage12.termContourAudit = struct('accepted', false, ...
    'status', 'synthetic_contour_rejected', ...
    'maximumDirectSelfError', 3e-4, 'maximumMWRSelfError', 4e-4, ...
    'maximumIdentityError', 2.5e-4, 'topologyAccepted', true);
stage12.termEpsilonPlateau = struct('accepted', true, ...
    'status', 'synthetic_plateau_accepted', ...
    'maximumTotalCauchyError', 2e-4, ...
    'maximumSourceCauchyError', 8e-4, 'topologyAccepted', true);
stage12.energyPoints = cell(0, 1);
stage12.nPoints = cell(0, 1);
stage12.asymmetricN3Anchor = struct('id', 'synthetic_anchor', ...
    'family', 'asymmetric_anchor', 'accepted', false, ...
    'status', 'synthetic_rejected', 'pair', synthetic_rejected_pair());
end

function pair = synthetic_rejected_pair()
direction = struct('energy', 0.3, 'N', 3, 'accepted', false);
published = struct('left', direction, ...
    'rightFromMirroredPotential', direction, ...
    'oneLoopUnitarityNormalisedError', 1.42, ...
    'perturbativeEta', 0.02, ...
    'perturbativeInterpretationAccepted', true, ...
    'treeUnitarityResidual', 0, ...
    'oneLoopUnitarityResidualPerMu2', 1.42);
pair = struct('status', 'synthetic_pair_rejected', ...
    'accepted', false, ...
    'production', struct('accepted', false), ...
    'higherOrder', struct('accepted', false), ...
    'published', published, ...
    'comparison', struct('maximumSourceError', 0.031, ...
    'maximumTermError', 0.012));
end

function index = first_index(text, pattern)
matches = strfind(text, pattern); %#ok<STREMP>
if isempty(matches)
    index = 0;
else
    index = matches(1);
end
end
