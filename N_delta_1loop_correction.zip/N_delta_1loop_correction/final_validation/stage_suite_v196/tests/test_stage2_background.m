function tests = test_stage2_background
%TEST_STAGE2_BACKGROUND Gamma_N, tau_N and conditioning tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
end

function testGammaDefinitionAtComplexK(testCase)
K = 0.71 + 0.23i;
z = [-0.8, 0.1, 1.4];
g = [0.30, -0.22, 0.17];
actual = ndelta.background.build_gamma_N(K, z, g);
expected = complex(zeros(3, 3));
for a = 1:3
    for b = 1:3
        expected(a, b) = -exp(1i .* K .* abs(z(a) - z(b))) ./ ...
            (2 .* K);
        if a == b
            expected(a, b) = expected(a, b) + 1i ./ g(a);
        end
    end
end
verifyEqual(testCase, actual, expected, 'AbsTol', 5e-15);
verifyEqual(testCase, actual, actual.', 'AbsTol', 5e-15);
verifyGreaterThan(testCase, norm(actual - actual', 'fro'), 1e-3);
end

function testBuildGammaRejectsZeroStrength(testCase)
verifyError(testCase, ...
    @() ndelta.background.build_gamma_N(0.7, [0, 1], [0.2, 0]), ...
    'ndelta:background:ZeroActiveStrength');
end

function testExplicitTau2AtComplexK(testCase)
cfg = testCase.TestData.cfg;
Kvalues = [0.71 + 0.23i, -0.52 + 0.31i, 0.90 - 0.15i];
g = 0.4;
b = 1.1;
for K = Kvalues
    gamma = ndelta.background.build_gamma_N( ...
        K, [-b ./ 2, b ./ 2], [g ./ 2, g ./ 2]);
    actual = ndelta.background.solve_tau_N( ...
        gamma, cfg.tolerances.nearSingularRcond);
    expected = ndelta.benchmarks.explicit_tau2(K, g, b);
    verifyEqual(testCase, actual.tau, expected, ...
        'AbsTol', cfg.tolerances.matrix);
    verifyLessThanOrEqual(testCase, actual.inverseResidualFro, ...
        cfg.tolerances.matrix);
    verifyLessThanOrEqual(testCase, actual.rightInverseResidualFro, ...
        cfg.tolerances.matrix);
end
end

function testUnequalStrengthTwoByTwoInverse(testCase)
cfg = testCase.TestData.cfg;
K = 0.62 + 0.11i;
z = [-0.4, 0.8];
g = [0.3, -0.2];
gamma = ndelta.background.build_gamma_N(K, z, g);
actual = ndelta.background.solve_tau_N( ...
    gamma, cfg.tolerances.nearSingularRcond);
a = gamma(1, 1);
b = gamma(1, 2);
d = gamma(2, 2);
expected = [d, -b; -b, a] ./ (a .* d - b.^2);
verifyEqual(testCase, actual.tau, expected, ...
    'AbsTol', cfg.tolerances.matrix);
end

function testInvalidKIsRejected(testCase)
for invalid = {0, NaN, Inf, [0.5, 0.7]}
    verifyError(testCase, ...
        @() ndelta.background.build_gamma_N( ...
            invalid{1}, 0, 0.2), ...
        'ndelta:background:InvalidK');
end
end

function testExactZeroAndPartiallyInactiveCentres(testCase)
cfg = testCase.TestData.cfg;
geometry = ndelta.geometry.build_geometry([-1, 0, 1], 1e-12);
free = ndelta.tree.tree_amplitudes_N(0.7, geometry, [0, 0, 0], ...
    cfg.tolerances.nearSingularRcond);
% Compare mathematical values rather than MATLAB's real/complex storage
% flag.  Some releases simplify 1+0i and all-zero complex slices to real
% arrays, which is immaterial for the inactive-centre contract.
verifyEqual(testCase, abs(free.t0 - 1), 0);
verifyEqual(testCase, real(free.r0), 0);
verifyEqual(testCase, imag(free.r0), 0);
verifyEqual(testCase, free.background.numberOfActiveCentres, 0);

withInactive = ndelta.background.background_kernel_N( ...
    0.7 + 0.1i, 0.7, geometry, [0.2, 0, -0.1], ...
    cfg.tolerances.nearSingularRcond);
verifyEqual(testCase, withInactive.activeIndices, [1; 3]);
verifyEqual(testCase, abs(withInactive.tau(2, :)), zeros(1, 3));
verifyEqual(testCase, abs(withInactive.tau(:, 2)), zeros(3, 1));
verifyLessThanOrEqual(testCase, ...
    withInactive.gammaVsZeroSafeRelativeResidual, ...
    cfg.tolerances.matrix);
end

function testNearSingularAndSingularDiagnostics(testCase)
cfg = testCase.TestData.cfg;
z = [0, 0];
g = [0.2, 0.2];
K0 = -0.2i;
gamma0 = ndelta.background.build_gamma_N(K0, z, g);
verifyError(testCase, ...
    @() ndelta.background.solve_tau_N( ...
        gamma0, cfg.tolerances.nearSingularRcond), ...
    'ndelta:background:NumericallySingularGamma');

Knear = K0 .* (1 + 1e-10);
gammaNear = ndelta.background.build_gamma_N(Knear, z, g);
near = ndelta.background.solve_tau_N( ...
    gammaNear, cfg.tolerances.nearSingularRcond);
verifyTrue(testCase, near.nearSingular);
verifyGreaterThan(testCase, near.rcond, near.hardSingularFloor);

gammaWell = ndelta.background.build_gamma_N(0.7 + 0.2i, z, g);
well = ndelta.background.solve_tau_N( ...
    gammaWell, cfg.tolerances.nearSingularRcond);
verifyFalse(testCase, well.nearSingular);
verifyGreaterThan(testCase, well.rcond, 0.1);
end

function testTraceContractionUsesTauBA(testCase)
cfg = testCase.TestData.cfg;
P = 0.67;
geometry = ndelta.geometry.build_geometry( ...
    [-1.1, 0.2, 1.7], cfg.tolerances.distanceMerge);
background = ndelta.background.background_kernel_N( ...
    P, P, geometry, [0.3, -0.18, 0.25], ...
    cfg.tolerances.nearSingularRcond);
verifyEqual(testCase, background.contractionTransmission, ...
    background.explicitContractionTransmission, ...
    'AbsTol', cfg.tolerances.matrix);
verifyEqual(testCase, background.contractionReflection, ...
    background.explicitContractionReflection, ...
    'AbsTol', cfg.tolerances.matrix);
verifyEqual(testCase, background.BT, ...
    background.BNTransmission, 'AbsTol', cfg.tolerances.matrix);
verifyEqual(testCase, background.BR, ...
    background.BNReflection, 'AbsTol', cfg.tolerances.matrix);
verifyEqual(testCase, background.transmissionAmplitudeCorrection, ...
    background.BNTransmission ./ (2 .* P), ...
    'AbsTol', cfg.tolerances.matrix);
verifyEqual(testCase, background.reflectionAmplitudeCorrection, ...
    background.BNReflection ./ (2 .* P), ...
    'AbsTol', cfg.tolerances.matrix);
end
