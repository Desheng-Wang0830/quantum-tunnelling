function tests = test_stage12_parallel_execution
%TEST_STAGE12_PARALLEL_EXECUTION Optional backend and deterministic merge.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
end

function testDefaultAndLegacyConfiguration(testCase)
cfg = testCase.TestData.cfg;
verifyEqual(testCase, cfg.execution.parallel.mode, 'auto');
verifyEqual(testCase, cfg.execution.parallel.profile, 'local');
verifyEqual(testCase, cfg.execution.parallel.workerCount, 4);
verifyTrue(testCase, cfg.execution.parallel.autoStartPool);
verifyTrue(testCase, cfg.execution.parallel.attachProjectFiles);
verifyTrue(testCase, cfg.execution.parallel.showProgress);
legacy = cfg;
legacy.execution = rmfield(legacy.execution, 'parallel');
legacy = ndelta.config.finalize_configuration(legacy);
verifyEqual(testCase, legacy.execution.parallel, ...
    ndelta.execution.default_parallel_settings());
end

function testInvalidModeAndWorkerCount(testCase)
cfg = testCase.TestData.cfg;
cfg.execution.parallel.mode = 'sometimes';
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:InvalidParallelMode');
cfg = testCase.TestData.cfg;
cfg.execution.parallel.workerCount = 2.5;
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:InvalidParallelWorkerCount');
end

function testSerialPolicyNeverRequestsParallel(testCase)
settings = testCase.TestData.cfg.execution.parallel;
settings.mode = 'serial';
capabilities = unavailable_capabilities();
plan = ndelta.execution.resolve_parallel_policy(settings, capabilities);
verifyFalse(testCase, plan.useParallel);
verifyEqual(testCase, plan.effectiveMode, 'serial');
verifyFalse(testCase, plan.fallbackUsed);
verifyEqual(testCase, plan.status, 'serial_requested');
end

function testAutoUnavailableFallsBackExplicitly(testCase)
settings = testCase.TestData.cfg.execution.parallel;
settings.mode = 'auto';
capabilities = unavailable_capabilities();
plan = ndelta.execution.resolve_parallel_policy(settings, capabilities);
verifyFalse(testCase, plan.useParallel);
verifyTrue(testCase, plan.fallbackUsed);
verifyEqual(testCase, plan.fallbackReason, capabilities.reason);
verifyEqual(testCase, plan.status, 'auto_fallback_to_serial');
end

function testRequiredUnavailableIsRejected(testCase)
settings = testCase.TestData.cfg.execution.parallel;
settings.mode = 'required';
verifyError(testCase, @() ndelta.execution.resolve_parallel_policy( ...
    settings, unavailable_capabilities()), ...
    'ndelta:parallel:Unavailable');
end

function testCapabilityDetectionMatchesInstalledProductCatalogue(testCase)
capabilities = ndelta.execution.detect_parallel_capabilities();
installedProducts = ver;
expectedInstalled = any(strcmp( ...
    {installedProducts.Name}, 'Parallel Computing Toolbox'));
verifyEqual(testCase, capabilities.toolboxInstalled, expectedInstalled);
verifyEqual(testCase, capabilities.available, ...
    capabilities.toolboxInstalled && ...
    capabilities.licenseAvailable && ...
    capabilities.functionsAvailable);
verifyEqual(testCase, capabilities.missingFunctions(:), ...
    capabilities.missingFunctions);
end

function testCapabilityDetectorAvoidsDeprecatedFolderAlias(testCase)
sourcePath = which('ndelta.execution.detect_parallel_capabilities');
verifyNotEmpty(testCase, sourcePath);
sourceText = fileread(sourcePath);
verifyEmpty(testCase, strfind(sourceText, ...
    ['ver(' char(39) 'distcomp' char(39) ')'])); %#ok<STREMP>
probePath = which('ndelta.execution.worker_dependency_probe');
verifyNotEmpty(testCase, probePath);
probeText = fileread(probePath);
verifyNotEmpty(testCase, strfind(probeText, ...
    'ndelta.integration.cut_polar_rule')); %#ok<STREMP>
end

function testSerialIndexedMapPreservesOrder(testCase)
plan = ndelta.execution.serial_plan(testCase.TestData.cfg);
plan.showProgress = false;
[outputs, report] = ndelta.execution.map_indexed( ...
    8, @(index) ndelta.execution.probe_job(index), plan, [], 'test');
indices = cellfun(@(item) item.index, outputs);
values = cellfun(@(item) item.value, outputs);
expected = arrayfun(@(index) complex( ...
    index.^2 + 0.5 .* index, -index ./ 7), 1:8);
verifyEqual(testCase, indices(:).', 1:8);
verifyEqual(testCase, values(:).', expected);
verifyTrue(testCase, report.canonicalOrderingPreserved);
verifyFalse(testCase, report.usedParallel);
end

function testExecutionPolicyDoesNotChangePhysicsFingerprintAndRelease(testCase)
serialCfg = testCase.TestData.cfg;
serialCfg.execution.parallel.mode = 'serial';
serialCfg = ndelta.config.finalize_configuration(serialCfg);
requiredCfg = testCase.TestData.cfg;
requiredCfg.execution.parallel.mode = 'required';
requiredCfg = ndelta.config.finalize_configuration(requiredCfg);
verifyEqual(testCase, ndelta.config.physics_fingerprint(serialCfg), ...
    ndelta.config.physics_fingerprint(requiredCfg));
release = ndelta.config.release_contract();
verifyEqual(testCase, release.releaseVersion, '1.9.6');
verifyEqual(testCase, release.configurationVersion, 1.9);
verifyEqual(testCase, release.unitTestCount, 196);
verifyEqual(testCase, release.minimumMatlabRelease, 'R2016b');
verifyTrue(testCase, release.stage12Parallel.supported);
verifyTrue(testCase, release.stage12Parallel.toolboxOptional);
verifyEqual(testCase, release.stage12Parallel.poolType, ...
    'process_or_cluster');
verifyEqual(testCase, release.stage12Parallel.defaultProductionMode, ...
    'auto');
verifyEqual(testCase, release.stage12Parallel.defaultWorkerCount, 4);
verifyEqual(testCase, release.stage12Parallel.fallbackMode, ...
    'serial_with_warning');
verifyTrue(testCase, release.stage12Parallel.deterministicIndexedMerge);
verifyTrue(testCase, ...
    release.stage12Parallel.innerQuadratureRemainsSerial);

basePreparation = ndelta.stage12.preparation_fingerprint(serialCfg);
for nameCell = {'nearSingularRcond', 'matrix', 'unitarity'}
    changedCfg = serialCfg;
    name = nameCell{1};
    changedCfg.tolerances.(name) = 2 .* changedCfg.tolerances.(name);
    changedCfg = ndelta.config.finalize_configuration(changedCfg);
    verifyFalse(testCase, isequaln( ...
        ndelta.stage12.preparation_fingerprint(changedCfg), ...
        basePreparation));
end

[nodes4a, weights4a] = ndelta.numerics.gauss_legendre_rule(4);
ndelta.numerics.gauss_legendre_rule(8);
[nodes4b, weights4b] = ndelta.numerics.gauss_legendre_rule(4);
verifyEqual(testCase, nodes4b, nodes4a);
verifyEqual(testCase, weights4b, weights4a);
end

function capabilities = unavailable_capabilities()
capabilities = struct('available', false, ...
    'status', 'parallel_toolbox_not_installed', ...
    'reason', 'Parallel Computing Toolbox is not installed.');
end
