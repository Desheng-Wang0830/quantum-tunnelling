function tests = test_stage9_amplitudes
%TEST_STAGE9_AMPLITUDES LSZ, mu^2 and strict interference tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
cfg = run_stage0(false);
stage1 = run_stage1(cfg);
tree = run_stage2(cfg, stage1).tree;
reduced = synthetic_reduced();
stage9 = ndelta.amplitude.assemble_g1(cfg, tree, reduced);
testCase.TestData.data = struct( ...
    'cfg', cfg, 'tree', tree, 'reduced', reduced, 'stage9', stage9);
end

function testPortableStage9Contract(testCase)
d = testCase.TestData.data;
report = ndelta.amplitude.validate_contract( ...
    d.cfg, d.tree, d.reduced, d.stage9);
verifyTrue(testCase, report.accepted);
verifyEqual(testCase, report.numberPassed, 8);
verifyEqual(testCase, report.numberOfChecks, 8);
rejected = d.reduced;
rejected.accepted = false;
rejected.configurationFingerprint = ...
    ndelta.config.physics_fingerprint(d.cfg);
verifyError(testCase, @() run_stage9( ...
    d.cfg, struct('tree', d.tree), rejected), ...
    'ndelta:stage9:Stage8NotAccepted');
end

function testOneOverTwoPAndMuSquaredAppliedOnce(testCase)
d = testCase.TestData.data;
expectedCoefficient = 1 ./ (2 .* d.cfg.derived.P);
expected = d.cfg.model.mu.^2 .* expectedCoefficient .* d.reduced.values;
verifyEqual(testCase, d.stage9.lszCoefficient, expectedCoefficient, ...
    'AbsTol', 5e-15);
verifyEqual(testCase, d.stage9.deltaAmplitudes, expected, ...
    'AbsTol', 5e-15);
verifyTrue(testCase, d.stage9.oneOverTwoPAppliedExactlyOnce);
verifyTrue(testCase, d.stage9.muSquaredAppliedExactlyOnce);
end

function testProbabilityIsTreeLoopInterferenceOnly(testCase)
d = testCase.TestData.data;
expected = 2 .* real(conj([d.tree.t0, d.tree.r0]) .* ...
    d.stage9.deltaAmplitudes);
verifyEqual(testCase, d.stage9.deltaProbabilities, expected, ...
    'AbsTol', 5e-15);
verifyFalse(testCase, d.stage9.amplitudeSquaredIncluded);
verifyFalse(testCase, d.stage9.mu4TermsIncluded);
verifyEqual(testCase, d.stage9.truncatedProbabilities, ...
    [d.tree.T0, d.tree.R0] + expected, 'AbsTol', 5e-15);
end

function testComponentAndSourceProbabilityLedgersClose(testCase)
d = testCase.TestData.data;
verifyEqual(testCase, sum( ...
    d.stage9.componentDeltaProbabilitiesPerMu2, 2).', ...
    d.stage9.deltaProbabilitiesPerMu2, 'AbsTol', 5e-15);
verifyEqual(testCase, sum( ...
    d.stage9.sourceDeltaProbabilitiesPerMu2, 2).', ...
    d.stage9.deltaProbabilitiesPerMu2, 'AbsTol', 5e-15);
end

function testCorrectionsScaleQuadraticallyWithMu(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.model.mu = -3 .* cfg.model.mu;
cfg = ndelta.config.finalize_configuration(cfg);
scaled = ndelta.amplitude.assemble_g1(cfg, d.tree, d.reduced);
verifyEqual(testCase, scaled.deltaAmplitudes, ...
    9 .* d.stage9.deltaAmplitudes, 'AbsTol', 5e-14);
verifyEqual(testCase, scaled.deltaProbabilities, ...
    9 .* d.stage9.deltaProbabilities, 'AbsTol', 5e-14);
end

function testOldN1LSZAndProbabilityRegression(testCase)
cfg = testCase.TestData.data.cfg;
cfg.referenceEnergy = 0.8;
cfg.barriers.positions = 0;
cfg.barriers.strengths = -0.3;
cfg.model.mu = 0.1;
cfg = ndelta.config.finalize_configuration(cfg);
tree = run_stage2(cfg, run_stage1(cfg)).tree;
reduced = synthetic_reduced();
reduced.values = [ ...
    -1.4936260e-10 + 4.49250481860e-3i, ...
     8.5302119e-12 + 1.71157151372e-3i];
reduced.transmission.value = reduced.values(1);
reduced.reflection.value = reduced.values(2);
reduced.componentMatrix = [reduced.values(1), 0, 0, 0; ...
    reduced.values(2), 0, 0, 0];
reduced.sourceMatrix = [reduced.values(1), 0, 0, 0, 0; ...
    reduced.values(2), 0, 0, 0, 0];
actual = ndelta.amplitude.assemble_g1(cfg, tree, reduced);
verifyEqual(testCase, actual.transmission.deltaAmplitude, ...
    -9.64131437e-13 + 2.89989939e-5i, 'AbsTol', 2e-12);
verifyEqual(testCase, actual.reflection.deltaAmplitude, ...
    5.50622810e-14 + 1.10481466e-5i, 'AbsTol', 2e-12);
verifyEqual(testCase, actual.transmission.deltaProbability, ...
    1.08253109607105e-5, 'AbsTol', 2e-11);
verifyEqual(testCase, actual.reflection.deltaProbability, ...
    4.12426869481478e-6, 'AbsTol', 2e-11);
end

function testZeroMuMakesEveryCorrectionExactlyZero(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.model.mu = 0;
cfg = ndelta.config.finalize_configuration(cfg);
actual = ndelta.amplitude.assemble_g1(cfg, d.tree, d.reduced);
% Exact zero is the contract; MATLAB's real/complex storage flag is not.
verifyEqual(testCase, abs(actual.deltaAmplitudes), ...
    zeros(size(actual.deltaAmplitudes)));
verifyEqual(testCase, actual.deltaProbabilities, [0, 0]);
verifyEqual(testCase, actual.truncatedProbabilities, ...
    actual.treeProbabilities);
end

function testG1AloneDoesNotClaimOneLoopUnitarity(testCase)
u = testCase.TestData.data.stage9.partialUnitarityDiagnostic;
verifyFalse(testCase, u.g1AloneRequiredToClose);
verifyTrue(testCase, u.fullRoseG1ToG4RequiredForOneLoopClosure);
verifyEqual(testCase, testCase.TestData.data.stage9.perturbativeOrder, ...
    'strict_O(mu^2)');
end

function testNoAdditionalVertexSignOrImaginaryUnit(testCase)
s = testCase.TestData.data.stage9;
verifyTrue(testCase, s.vertexSignAlreadyInsideReducedKernel);
verifyFalse(testCase, s.additionalVertexMinusApplied);
verifyFalse(testCase, s.additionalImaginaryUnitApplied);
end

function reduced = synthetic_reduced()
component = [ ...
    0.10 + 0.20i, 0, -0.03 + 0.01i, 0.02 - 0.04i; ...
   -0.02 + 0.03i, 0,  0.04 + 0.01i, -0.01 + 0.02i];
source = [ ...
    component(1, 1), 0, component(1, 3), ...
        0.015 - 0.03i, 0.005 - 0.01i; ...
    component(2, 1), 0, component(2, 3), ...
       -0.01 + 0.02i, 0];
values = sum(component, 2).';
reduced = struct();
reduced.values = values;
reduced.transmission = struct('value', values(1));
reduced.reflection = struct('value', values(2));
reduced.componentNames = ...
    {'euclidean', 'ordinaryPole', 'collectivePole', 'cutTotal'};
reduced.sourceNames = {'euclidean', 'ordinaryPole', ...
    'collectivePole', 'cutBanks', 'endpointKeyhole'};
reduced.componentMatrix = component;
reduced.sourceMatrix = source;
end
