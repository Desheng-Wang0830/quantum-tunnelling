function tests = test_stage1_geometry
%TEST_STAGE1_GEOMETRY Directed-distance and phase-convention tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
end

function testDirectedDistanceSign(testCase)
z = [-1, 0.25, 2];
geometry = ndelta.geometry.build_geometry(z, 1e-12);
expected = [0, 1.25, 3.00; ...
           -1.25, 0, 1.75; ...
           -3.00, -1.75, 0];
verifyEqual(testCase, geometry.directedDistances, expected);
verifyEqual(testCase, geometry.absoluteDistances, abs(expected));
end

function testDistanceCacheReconstructsMatrix(testCase)
geometry = ndelta.geometry.build_geometry([-1, 0.25, 2], 1e-12);
reconstructed = geometry.uniqueDirectedDistances( ...
    geometry.directedDistanceIndex);
verifyEqual(testCase, reconstructed, geometry.directedDistances, ...
    'AbsTol', geometry.distanceMergeAbsoluteTolerance);
end

function testDistanceCacheNeverMergesSignsOrZero(testCase)
% Use a deliberately loose tolerance.  The cache may merge nearby
% positive values with positive values, but never 0,+d,-d.
geometry = ndelta.geometry.build_geometry([0, 1e-8], 1e-2);
zeroIndex = geometry.directedDistanceIndex(1, 1);
positiveIndex = geometry.directedDistanceIndex(1, 2);
negativeIndex = geometry.directedDistanceIndex(2, 1);
verifyNotEqual(testCase, positiveIndex, zeroIndex);
verifyNotEqual(testCase, negativeIndex, zeroIndex);
verifyNotEqual(testCase, positiveIndex, negativeIndex);
verifyEqual(testCase, sign(geometry.uniqueDirectedDistances( ...
    [zeroIndex, positiveIndex, negativeIndex])), [0; 1; -1]);
end

function testChannelPhases(testCase)
z = [-1, 0.25, 2];
P = 0.7;
phases = ndelta.geometry.build_channel_phases(z, P);
za = z(:);
zb = z(:).';
verifyEqual(testCase, phases.transmission, ...
    exp(1i .* P .* (za - zb)), 'AbsTol', 5e-15);
verifyEqual(testCase, phases.reflection, ...
    exp(1i .* P .* (za + zb)), 'AbsTol', 5e-15);
end

function testTranslationPhaseLaw(testCase)
z = [-1, 0.25, 2];
P = 0.7;
shift = 0.83;
base = ndelta.geometry.build_channel_phases(z, P);
moved = ndelta.geometry.build_channel_phases(z + shift, P);
verifyEqual(testCase, moved.transmission, base.transmission, ...
    'AbsTol', 5e-15);
verifyEqual(testCase, moved.reflection, ...
    exp(2i .* P .* shift) .* base.reflection, 'AbsTol', 5e-15);
end
