function tests = test_stage7_collective_contour
%TEST_STAGE7_COLLECTIVE_CONTOUR Collective spectrum and fixed-qPerp tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.stage1 = run_stage1(data.cfg);
data.stage7 = run_stage7(data.cfg, data.stage1);
testCase.TestData.data = data;
end

function testDefaultKPlaneSpectrumGolden(testCase)
d = testCase.TestData.data;
spectrum = d.stage7.spectrum;
verifyEqual(testCase, spectrum.numberOfModes, 1);
verifyEqual(testCase, spectrum.numberOfStableModes, 1);
verifyEqual(testCase, spectrum.numberOfSemisimpleModes, 1);
verifyTrue(testCase, spectrum.detUsedForProduction == false);
verifyTrue(testCase, spectrum.allPhysicalModesStable);
verifyTrue(testCase, spectrum.allModesSemisimple);
mode = spectrum.modes(1);
verifyEqual(testCase, mode.label, 'even');
verifyEqual(testCase, mode.alpha, 0.14018951227164128, ...
    'AbsTol', 2e-10);
verifyEqual(testCase, mode.qPerpCritical, 0.2639187362635716, ...
    'AbsTol', 2e-10);
end

function testCollectiveMatrixAndGammaNullspaceAgree(testCase)
d = testCase.TestData.data;
mode = d.stage7.spectrum.modes(1);
active = mode.activeIndices;
z = d.stage1.geometry.positions(active);
g = d.cfg.barriers.strengths(active);
matrix = ndelta.singularity.collective_matrix(mode.alpha, z, g);
gamma = ndelta.background.build_gamma_N(mode.K, z, g);
verifyLessThanOrEqual(testCase, norm(gamma - 1i .* matrix, 'fro'), 5e-13);
verifyLessThanOrEqual(testCase, ...
    norm(matrix * mode.nullVectorsActive, 'fro'), 2e-8);
end

function testN1AttractiveAndRepulsiveLimits(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.positions = 0;
cfg.barriers.strengths = -0.3;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry(0, ...
    cfg.tolerances.distanceMerge);
attractive = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyEqual(testCase, attractive.numberOfModes, 1);
verifyEqual(testCase, attractive.modes(1).alpha, 0.15, 'AbsTol', 2e-10);
verifyEqual(testCase, 2 .* attractive.modes(1).K + ...
    1i .* cfg.barriers.strengths, 0, 'AbsTol', 4e-10);

cfg.barriers.strengths = +0.3;
cfg = ndelta.config.finalize_configuration(cfg);
repulsive = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyEqual(testCase, repulsive.numberOfModes, 0);
verifyTrue(testCase, repulsive.accepted);
end

function testN2EvenAndOddAnalyticEquations(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.positions = [-10, 10];
cfg.barriers.strengths = [-0.15, -0.15];
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyEqual(testCase, spectrum.numberOfModes, 2);
for index = 1:2
    mode = spectrum.modes(index);
    parity = +1;
    if strcmp(mode.label, 'odd')
        parity = -1;
    end
    residual = mode.alpha - 0.075 .* ...
        (1 + parity .* exp(-20 .* mode.alpha));
    verifyLessThanOrEqual(testCase, abs(residual), 2e-9);
end
verifyEqual(testCase, sort({spectrum.modes.label}), {'even', 'odd'});

% The exponentially split b=300 roots are distinct, but the other
% eigenvalue is small enough that a generic residual mask would wrongly
% turn both records into the same two-dimensional nullspace.
cfg.barriers.positions = [-150, 150];
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
nearDegenerate = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyEqual(testCase, nearDegenerate.numberOfModes, 2);
verifyTrue(testCase, all([nearDegenerate.modes.simple]));
verifyEqual(testCase, [nearDegenerate.modes.nullity], [1, 1]);
verifyLessThanOrEqual(testCase, abs( ...
    nearDegenerate.modes(1).nullVectorsActive.' * ...
    nearDegenerate.modes(2).nullVectorsActive), 2e-12);
for index = 1:2
    residue = ndelta.g1.collective_pole_residue( ...
        nearDegenerate.modes(index), 0.1, 'T', cfg, geometry);
    verifyTrue(testCase, residue.accepted);
    verifyEqual(testCase, rank(residue.residueTau), 1);
end
end

function testUnstableCollectiveModeIsRejected(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.positions = 0;
cfg.barriers.strengths = -0.5;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry(0, ...
    cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyEqual(testCase, spectrum.numberOfModes, 1);
verifyFalse(testCase, spectrum.modes(1).stable);
verifyFalse(testCase, spectrum.allPhysicalModesStable);
verifyFalse(testCase, spectrum.accepted);

cfg.execution.rejectUnstableCollective = false;
cfg = ndelta.config.finalize_configuration(cfg);
diagnosticOnly = ndelta.singularity.find_collective_modes(cfg, geometry);
verifyTrue(testCase, diagnosticOnly.accepted);
verifyError(testCase, @() ndelta.integration.integrate_g1( ...
    cfg, geometry, diagnosticOnly, struct()), ...
    'ndelta:integration:UnstableCollectiveSpectrum');
end

function testZeroEnergyThresholdIsCompoundEndpoint(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.strengths = [-0.2, -0.2];
for relativeOffset = [-1e-10, 0, +1e-10]
    separation = 10 .* (1 + relativeOffset);
    cfg.barriers.positions = [-separation ./ 2, separation ./ 2];
    cfg = ndelta.config.finalize_configuration(cfg);
    geometry = ndelta.geometry.build_geometry( ...
        cfg.barriers.positions, cfg.tolerances.distanceMerge);
    diagnostic = ndelta.singularity.zero_energy_diagnostic( ...
        geometry, cfg.barriers.strengths, cfg.tolerances.zeroEnergy);
    spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
    verifyTrue(testCase, diagnostic.isZeroEnergyResonance);
    verifyLessThanOrEqual(testCase, ...
        diagnostic.normalisedMinimumSingularValue, ...
        cfg.tolerances.zeroEnergy);
    verifyEqual(testCase, diagnostic.classification, ...
        'compound_branch_endpoint_zero_energy_collective_threshold');
    verifyFalse(testCase, spectrum.accepted);
end
end

function testEndpointScaledTauMatchesDirectSolve(testCase)
d = testCase.TestData.data;
K = 1e-5i;
[stable, details] = ndelta.background.solve_tau_endpoint_stable( ...
    K, d.stage1.geometry, d.cfg.barriers.strengths, ...
    d.cfg.derived.endpointTauSwitch);
gamma = ndelta.background.build_gamma_N( ...
    K, d.stage1.geometry.positions, d.cfg.barriers.strengths);
direct = gamma \ eye(d.stage1.geometry.N);
verifyLessThanOrEqual(testCase, ...
    max(relative(stable(:), direct(:))), 2e-8);
verifyTrue(testCase, details.usedEndpointScaledSolve);
verifyGreaterThan(testCase, details.scaledRcond, rcond(gamma));
verifyLessThanOrEqual(testCase, ...
    details.normalisedEquationResidual, 2e-12);
end

function testCollectiveResidueBypassesSingularTauSolve(testCase)
d = testCase.TestData.data;
mode = d.stage7.spectrum.modes(1);
mapped = ndelta.singularity.map_collective_q0(mode, 0.1, d.cfg);
residue = ndelta.g1.collective_pole_residue( ...
    mode, 0.1, 'T', d.cfg, d.stage1.geometry);
verifyTrue(testCase, residue.accepted);
verifyLessThanOrEqual(testCase, residue.nullResidual, ...
    d.cfg.tolerances.collectiveResidual);
step = 1e-6;
roots = ndelta.sheet.physical_roots(mapped.left.q0 + step, 0.1, ...
    d.cfg.referenceEnergy, d.cfg.model, d.cfg.sheet.epsilon);
raw = ndelta.g1.contour_pair_contraction_from_roots( ...
    roots.omega, roots.kappaI, d.cfg.derived.P, 'T', ...
    d.stage1.geometry, d.cfg.barriers.strengths, d.cfg);
verifyLessThanOrEqual(testCase, relative( ...
    step .* (-raw), residue.vertexReducedResidue), 2e-5);
end

function testCollectiveQ0MappingUsesOpenQISupport(testCase)
d = testCase.TestData.data;
mode = d.stage7.spectrum.modes(1);
inside = ndelta.singularity.map_collective_q0(mode, 0.1, d.cfg);
outside = ndelta.singularity.map_collective_q0( ...
    mode, 1.001 .* mode.qPerpCritical, d.cfg);
verifyTrue(testCase, inside.left.accepted);
verifyFalse(testCase, inside.right.accepted);
verifyEqual(testCase, inside.left.quadrant, 'QI');
verifyFalse(testCase, outside.left.accepted);
verifyFalse(testCase, inside.thirdQuadrantAccepted);

largeEpsilonCfg = d.cfg;
largeEpsilonCfg.sheet.epsilon = 0.2;
largeEpsilonCfg = ndelta.config.finalize_configuration(largeEpsilonCfg);
largeEpsilonSpectrum = ndelta.singularity.find_collective_modes( ...
    largeEpsilonCfg, d.stage1.geometry);
largeMode = largeEpsilonSpectrum.modes(1);
verifyFalse(testCase, largeMode.hasOpenTransverseSupport);
verifyEqual(testCase, largeMode.qPerpCritical, 0);
largeMapped = ndelta.singularity.map_collective_q0( ...
    largeMode, 0, largeEpsilonCfg);
verifyFalse(testCase, largeMapped.left.accepted);
integrated = ndelta.integration.integrate_collective( ...
    'T', largeEpsilonCfg, d.stage1.geometry, ...
    largeEpsilonSpectrum, struct('collectiveOrder', 4));
verifyEqual(testCase, abs(integrated.value), 0);
end

function testFixedQPerpSourceLedgerAndGoldenValues(testCase)
d = testCase.TestData.data;
t = d.stage7.transmission;
r = d.stage7.reflection;
verifyTrue(testCase, d.stage7.accepted);
verifyLessThanOrEqual(testCase, d.stage7.maximumClosureResidual, ...
    d.cfg.tolerances.contourClosure);
verifyEqual(testCase, imag(t.value), 0.4593308, 'AbsTol', 3e-4);
verifyEqual(testCase, imag(r.value), 0.2639825, 'AbsTol', 3e-4);
verifyTrue(testCase, t.oldSingleDeltaBarrierCountedOnlyAsCollective);
verifyTrue(testCase, t.mixedPoleExactlyZero);
verifyEqual(testCase, abs(t.components.ordinaryPole), 0);
end

function testFullBranchKeyholeIsNotOrdinaryHalfIndentation(testCase)
d = testCase.TestData.data;
t = d.stage7.transmission.cut;
r = d.stage7.reflection.cut;
verifyEqual(testCase, t.keyholeQ0WindingFraction, 1);
verifyEqual(testCase, t.ordinarySimplePoleHalfIndentationFraction, 0.5);
verifyFalse(testCase, t.ordinaryHalfIndentationUsedHere);
verifyGreaterThan(testCase, abs(t.endpointContribution), 0);
verifyEqual(testCase, abs(r.endpointContribution), 0);
verifyFalse(testCase, d.stage7.ledger.branchEndpointsAreOrdinaryPoles);
verifyTrue(testCase, ...
    d.stage7.ledger.collectiveAndOrdinaryLedgersDisjoint);
end

function value = relative(left, right)
value = abs(left - right) ./ (1 + abs(right));
end
