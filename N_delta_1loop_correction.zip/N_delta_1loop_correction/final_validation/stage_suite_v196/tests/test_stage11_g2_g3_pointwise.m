function tests = test_stage11_g2_g3_pointwise
%TEST_STAGE11_G2_G3_POINTWISE Arbitrary-N G2/G3 pointwise contracts.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.roots = ndelta.sheet.physical_roots( ...
    data.cfg.stage11.referenceQ0, data.cfg.stage11.referenceQPerp, ...
    data.cfg.referenceEnergy, data.cfg.model, data.cfg.sheet.epsilon);
data.omega = 0.37 + 1.11i;
data.kappaI = 0.29 + 0.63i;
data.tol = data.cfg.tolerances.stage11Pointwise;
testCase.TestData.data = data;
end

function testN1CompactG2AndG3(testCase)
d = testCase.TestData.data;
[cfg, geometry, context] = make_system(d.cfg, 0, -0.3);
P = cfg.derived.P;
g = cfg.barriers.strengths;
tauI = -2i .* g .* d.kappaI ./ (2 .* d.kappaI + 1i .* g);
tauP = -2i .* g .* P ./ (2 .* P + 1i .* g);
Q = (P + 2 .* d.kappaI) .* d.omega.^2 ...
    + (P.^2 + 5 .* P .* d.kappaI + 6 .* d.kappaI.^2) ...
    .* d.omega + 4 .* d.kappaI.^2 .* (P + d.kappaI);
compactKernel = -Q ./ (16 .* P .* d.kappaI.^3 ...
    .* (P + d.kappaI) .* d.omega ...
    .* (d.omega + d.kappaI - P) ...
    .* (d.omega + d.kappaI + P).^2);
expectedRaw = tauI .* tauP .* compactKernel;

for channelCell = {'T', 'R'}
    channel = channelCell{1};
    [g2, details2] = ndelta.g2.pointwise_contraction_from_roots( ...
        d.omega, d.kappaI, channel, cfg, geometry, context);
    [g3, details3] = ndelta.g3.pointwise_contraction_from_roots( ...
        d.omega, d.kappaI, channel, cfg, geometry, context);
    verifyLessThanOrEqual(testCase, relative(g2, expectedRaw), d.tol);
    verifyLessThanOrEqual(testCase, relative(g3, expectedRaw), d.tol);
    verifyLessThanOrEqual(testCase, ...
        relative(details2.vertexReducedValue, -expectedRaw), d.tol);
    verifyLessThanOrEqual(testCase, ...
        relative(details3.vertexReducedValue, -expectedRaw), d.tol);
    verifyLessThanOrEqual(testCase, relative(details2.tauI, tauI), d.tol);
    verifyLessThanOrEqual(testCase, relative(details3.tauI, tauI), d.tol);
    verifyLessThanOrEqual(testCase, relative(details2.tauP, tauP), d.tol);
    verifyLessThanOrEqual(testCase, relative(details3.tauP, tauP), d.tol);
end
end

function testDefaultN2G2GoldenAndOptimisedReference(testCase)
d = testCase.TestData.data;
[cfg, geometry, context] = make_system(d.cfg, ...
    d.cfg.barriers.positions, d.cfg.barriers.strengths);
golden = [ ...
    2.8201969107997655 - 2.2080331040667858i, ...
    2.8563903279238145 - 2.1683497480590086i];
channels = {'T', 'R'};
for index = 1:numel(channels)
    channel = channels{index};
    [optimised, details] = ...
        ndelta.g2.pointwise_contraction_from_roots( ...
        d.roots.omega, d.roots.kappaI, channel, ...
        cfg, geometry, context);
    [reference, referenceDetails] = ...
        ndelta.g2.pointwise_reference_from_roots( ...
        d.roots.omega, d.roots.kappaI, channel, ...
        cfg, geometry, context);
    verifyEqual(testCase, optimised, golden(index), 'AbsTol', 5e-9);
    verifyLessThanOrEqual(testCase, ...
        relative(optimised, reference), d.tol);
    verifyEqual(testCase, details.numberOfActiveTerms, 8);
    verifyEqual(testCase, details.numberOfKernelEvaluations, 7);
    verifyEqual(testCase, referenceDetails.numberOfExplicitTerms, 16);
    verifyEqual(testCase, details.indexContract, ...
        '(E_chi*tauP)(a,c)*tauI(b,a)*I2(D_ab,D_bc)');
    verifyTrue(testCase, details.rawConvention);
    verifyEqual(testCase, details.vertexReducedValue, -optimised);
    endpoint = ndelta.g2.endpoint_data( ...
        d.cfg.stage11.referenceQPerp, channel, cfg, context);
    verifyGreaterThan(testCase, abs(endpoint.keyholeContribution), 0);
    verifyEqual(testCase, endpoint.keyholeContribution, ...
        1i .* endpoint.vertexReducedResidue);
    verifyEqual(testCase, endpoint.keyholeQ0WindingFraction, 1);
    verifyFalse(testCase, endpoint.ordinaryHalfIndentationUsed);
end
end

function testDefaultN2G3GoldenAndOptimisedReference(testCase)
d = testCase.TestData.data;
[cfg, geometry, context] = make_system(d.cfg, ...
    d.cfg.barriers.positions, d.cfg.barriers.strengths);
golden = [ ...
    2.8201969107997646 - 2.2080331040667862i, ...
    2.8563903279238145 - 2.1683497480590077i];
channels = {'T', 'R'};
for index = 1:numel(channels)
    channel = channels{index};
    [optimised, details] = ...
        ndelta.g3.pointwise_contraction_from_roots( ...
        d.roots.omega, d.roots.kappaI, channel, ...
        cfg, geometry, context);
    [reference, referenceDetails] = ...
        ndelta.g3.pointwise_reference_from_roots( ...
        d.roots.omega, d.roots.kappaI, channel, ...
        cfg, geometry, context);
    verifyEqual(testCase, optimised, golden(index), 'AbsTol', 5e-9);
    verifyLessThanOrEqual(testCase, ...
        relative(optimised, reference), d.tol);
    verifyEqual(testCase, details.numberOfActiveTerms, 8);
    verifyEqual(testCase, details.numberOfKernelEvaluations, 7);
    verifyEqual(testCase, referenceDetails.numberOfExplicitTerms, 16);
    verifyEqual(testCase, details.indexContract, ...
        '(tauP*E_chi)(b,d)*tauI(d,c)*I3(D_bc,D_cd)');
    verifyTrue(testCase, details.rawConvention);
    verifyEqual(testCase, details.vertexReducedValue, -optimised);
    endpoint = ndelta.g3.endpoint_data( ...
        d.cfg.stage11.referenceQPerp, channel, cfg, context);
    verifyGreaterThan(testCase, abs(endpoint.keyholeContribution), 0);
    verifyEqual(testCase, endpoint.keyholeContribution, ...
        1i .* endpoint.vertexReducedResidue);
    verifyEqual(testCase, endpoint.keyholeQ0WindingFraction, 1);
    verifyFalse(testCase, endpoint.ordinaryHalfIndentationUsed);
end
end

function testReflectionReciprocityForAsymmetricGeometry(testCase)
d = testCase.TestData.data;
positions = [-1.2, -0.15, 0.83];
strengths = [-0.27, 0.16, -0.09];
[cfg, geometry, context] = make_system(d.cfg, positions, strengths);
[g2, g3] = point_pair(d.roots, 'R', cfg, geometry, context);
verifyLessThanOrEqual(testCase, relative(g3, g2), d.tol);
end

function testTransmissionReciprocityStopsAtLeftRightBoundary(testCase)
d = testCase.TestData.data;
positions = [-1.2, -0.15, 0.83];
strengths = [-0.27, 0.16, -0.09];
[cfg, geometry, context] = make_system(d.cfg, positions, strengths);
[g2Left, g3Left] = point_pair( ...
    d.roots, 'T', cfg, geometry, context);
[mirrorCfg, mirrorGeometry, mirrorContext] = make_system( ...
    d.cfg, -positions, strengths);
[g2Mirror, g3Mirror] = point_pair( ...
    d.roots, 'T', mirrorCfg, mirrorGeometry, mirrorContext);

% G3(p,k)=G2(-k,-p): for transmission this exchanges left and right
% incidence.  It is not a same-geometry identity without parity.
verifyLessThanOrEqual(testCase, relative(g3Left, g2Mirror), d.tol);
verifyLessThanOrEqual(testCase, relative(g2Left, g3Mirror), d.tol);
verifyGreaterThan(testCase, abs(g2Left - g3Left), 1e-4);

symPositions = [-1.1, 0, 1.1];
symStrengths = [-0.2, 0.13, -0.2];
[symCfg, symGeometry, symContext] = make_system( ...
    d.cfg, symPositions, symStrengths);
[g2Symmetric, g3Symmetric] = point_pair( ...
    d.roots, 'T', symCfg, symGeometry, symContext);
verifyLessThanOrEqual(testCase, ...
    relative(g3Symmetric, g2Symmetric), d.tol);
end

function testTranslationCovarianceForG2AndG3(testCase)
d = testCase.TestData.data;
positions = [-1.2, -0.15, 0.83];
strengths = [-0.27, 0.16, -0.09];
shift = 0.37;
[cfg, geometry, context] = make_system(d.cfg, positions, strengths);
[movedCfg, movedGeometry, movedContext] = make_system( ...
    d.cfg, positions + shift, strengths);
for channelCell = {'T', 'R'}
    channel = channelCell{1};
    [base2, base3] = point_pair( ...
        d.roots, channel, cfg, geometry, context);
    [moved2, moved3] = point_pair( ...
        d.roots, channel, movedCfg, movedGeometry, movedContext);
    phase = 1;
    if channel == 'R'
        phase = exp(2i .* cfg.derived.P .* shift);
    end
    verifyLessThanOrEqual(testCase, ...
        relative(moved2, phase .* base2), d.tol);
    verifyLessThanOrEqual(testCase, ...
        relative(moved3, phase .* base3), d.tol);
end
end

function testPermutationInvarianceForG2AndG3(testCase)
d = testCase.TestData.data;
positions = [-1.2, -0.15, 0.83];
strengths = [-0.27, 0.16, -0.09];
permutation = [3, 1, 2];
[cfg, geometry, context] = make_system(d.cfg, positions, strengths);
[permutedCfg, permutedGeometry, permutedContext] = make_system( ...
    d.cfg, positions(permutation), strengths(permutation));
for channelCell = {'T', 'R'}
    channel = channelCell{1};
    [base2, base3] = point_pair( ...
        d.roots, channel, cfg, geometry, context);
    [permuted2, permuted3] = point_pair( ...
        d.roots, channel, permutedCfg, ...
        permutedGeometry, permutedContext);
    verifyLessThanOrEqual(testCase, relative(permuted2, base2), d.tol);
    verifyLessThanOrEqual(testCase, relative(permuted3, base3), d.tol);
end
end

function testInactiveCentresReduceAndAllInactiveIsZero(testCase)
d = testCase.TestData.data;
positions = [-0.9, 0.17, 1.2];
strengths = [-0.2, 0, 0.13];
[fullCfg, fullGeometry, fullContext] = make_system( ...
    d.cfg, positions, strengths);
[reducedCfg, reducedGeometry, reducedContext] = make_system( ...
    d.cfg, positions([1, 3]), strengths([1, 3]));
[movedCfg, movedGeometry, movedContext] = make_system( ...
    d.cfg, [-0.9, 17, 1.2], strengths);
for channelCell = {'T', 'R'}
    channel = channelCell{1};
    [full2, full3, details2, details3] = point_pair( ...
        d.roots, channel, fullCfg, fullGeometry, fullContext);
    [reduced2, reduced3] = point_pair( ...
        d.roots, channel, reducedCfg, reducedGeometry, reducedContext);
    [moved2, moved3] = point_pair( ...
        d.roots, channel, movedCfg, movedGeometry, movedContext);
    verifyLessThanOrEqual(testCase, relative(full2, reduced2), d.tol);
    verifyLessThanOrEqual(testCase, relative(full3, reduced3), d.tol);
    verifyLessThanOrEqual(testCase, relative(moved2, reduced2), d.tol);
    verifyLessThanOrEqual(testCase, relative(moved3, reduced3), d.tol);
    verifyEqual(testCase, details2.numberOfActiveTerms, 8);
    verifyEqual(testCase, details3.numberOfActiveTerms, 8);
    verifyEqual(testCase, abs(details2.tauI(2, :)), zeros(1, 3));
    verifyEqual(testCase, abs(details2.tauI(:, 2)), zeros(3, 1));
    verifyEqual(testCase, abs(details3.tauI(2, :)), zeros(1, 3));
    verifyEqual(testCase, abs(details3.tauI(:, 2)), zeros(3, 1));
end

[emptyCfg, emptyGeometry, emptyContext] = make_system( ...
    d.cfg, positions, zeros(size(positions)));
for channelCell = {'T', 'R'}
    channel = channelCell{1};
    [empty2, empty3, details2, details3] = point_pair( ...
        d.roots, channel, emptyCfg, emptyGeometry, emptyContext);
    reference2 = ndelta.g2.pointwise_reference_from_roots( ...
        d.roots.omega, d.roots.kappaI, channel, ...
        emptyCfg, emptyGeometry, emptyContext);
    reference3 = ndelta.g3.pointwise_reference_from_roots( ...
        d.roots.omega, d.roots.kappaI, channel, ...
        emptyCfg, emptyGeometry, emptyContext);
    verifyEqual(testCase, abs([empty2, empty3, reference2, reference3]), ...
        zeros(1, 4));
    verifyEqual(testCase, details2.numberOfActiveTerms, 0);
    verifyEqual(testCase, details3.numberOfActiveTerms, 0);
    verifyEqual(testCase, details2.numberOfKernelEvaluations, 0);
    verifyEqual(testCase, details3.numberOfKernelEvaluations, 0);
    endpoint2 = ndelta.g2.pointwise_reference_from_roots( ...
        d.roots.omega, 0, channel, emptyCfg, emptyGeometry, emptyContext);
    endpoint3 = ndelta.g3.pointwise_reference_from_roots( ...
        d.roots.omega, 0, channel, emptyCfg, emptyGeometry, emptyContext);
    verifyEqual(testCase, abs([endpoint2, endpoint3]), [0, 0]);
end
end

function [g2, g3, details2, details3] = point_pair( ...
        roots, channel, cfg, geometry, context)
[g2, details2] = ndelta.g2.pointwise_contraction_from_roots( ...
    roots.omega, roots.kappaI, channel, cfg, geometry, context);
[g3, details3] = ndelta.g3.pointwise_contraction_from_roots( ...
    roots.omega, roots.kappaI, channel, cfg, geometry, context);
end

function [cfg, geometry, context] = make_system( ...
        template, positions, strengths)
cfg = template;
cfg.barriers.positions = positions;
cfg.barriers.strengths = strengths;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
end

function value = relative(left, right)
entries = abs(left - right) ./ (1 + abs(right));
value = max(entries(:));
end
