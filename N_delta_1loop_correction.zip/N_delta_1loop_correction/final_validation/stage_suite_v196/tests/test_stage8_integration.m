function tests = test_stage8_integration
%TEST_STAGE8_INTEGRATION Source-resolved transverse integration tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.stage1 = run_stage1(data.cfg);
data.spectrum = ndelta.singularity.find_collective_modes( ...
    data.cfg, data.stage1.geometry);
stage7Stub = struct('accepted', true, 'spectrum', data.spectrum);
data.stage8 = run_stage8(data.cfg, data.stage1, stage7Stub);
testCase.TestData.data = data;
end

function testDefaultIntegratedGoldenValues(testCase)
d = testCase.TestData.data;
verifyTrue(testCase, d.stage8.accepted);
verifyEqual(testCase, d.stage8.transmission.value, ...
    -6.1927123e-11 + 4.0640237e-3i, 'AbsTol', 2e-5);
verifyEqual(testCase, d.stage8.reflection.value, ...
    1.4842966e-11 + 3.1731157e-3i, 'AbsTol', 2e-5);
end

function testFourComponentsAndFiveSourcesClose(testCase)
s = testCase.TestData.data.stage8;
verifySize(testCase, s.componentMatrix, [2, 4]);
verifySize(testCase, s.sourceMatrix, [2, 5]);
verifyEqual(testCase, s.componentNames, ...
    {'euclidean', 'ordinaryPole', 'collectivePole', 'cutTotal'});
verifyEqual(testCase, s.sourceNames, ...
    {'euclidean', 'ordinaryPole', 'collectivePole', ...
     'cutBanks', 'endpointKeyhole'});
verifyLessThanOrEqual(testCase, s.maximumClosureResidual, 5e-12);
verifyLessThanOrEqual(testCase, max(abs( ...
    s.values - sum(s.componentMatrix, 2).')), 5e-12);
verifyLessThanOrEqual(testCase, max(abs( ...
    s.values - sum(s.sourceMatrix, 2).')), 5e-12);
end

function testFactorBoundaryStopsBeforeMuAndLSZ(testCase)
s = testCase.TestData.data.stage8;
verifyEqual(testCase, s.massDimension, -1);
verifyTrue(testCase, s.muIndependent);
verifyFalse(testCase, s.includesMuSquared);
verifyFalse(testCase, s.includesLSZ);
verifyFalse(testCase, s.includesOneOverTwoP);
verifyEqual(testCase, s.kernelConvention, ...
    'vertex_reduced_per_mu2_F_code_equals_negative_Stage6_raw');
end

function testQPerpBreakpointsIncludePAndCollectiveSupport(testCase)
d = testCase.TestData.data;
breaks = d.stage8.transmission.euclidean.qPerpBreakpoints;
verifyLessThanOrEqual(testCase, min(abs(breaks - d.cfg.derived.P)), 5e-15);
for index = 1:numel(d.spectrum.modes)
    verifyLessThanOrEqual(testCase, min(abs( ...
        breaks - d.spectrum.modes(index).qPerpCritical)), 5e-15);
end
end

function testCollectivePoleIsNotDoubleCountedAsOldBarrier(testCase)
s = testCase.TestData.data.stage8;
verifyEqual(testCase, abs(s.transmission.ordinaryPole), 0);
verifyEqual(testCase, abs(s.reflection.ordinaryPole), 0);
verifyTrue(testCase, ...
    s.transmission.collectivePole.oldSingleDeltaBarrierIsIncludedHere);
verifyFalse(testCase, ...
    s.transmission.collectivePole.separateSingleDeltaBarrierTermAdded);
end

function testCutKeepsBanksAndFullKeyholeSeparate(testCase)
s = testCase.TestData.data.stage8;
verifyEqual(testCase, s.transmission.cut.keyholeQ0WindingFraction, 1);
verifyFalse(testCase, ...
    s.transmission.cut.ordinaryHalfIndentationUsedHere);
verifyGreaterThan(testCase, ...
    abs(s.transmission.cut.endpointContribution), 0);
verifyEqual(testCase, abs(s.reflection.cut.endpointContribution), 0);
verifyLessThanOrEqual(testCase, ...
    s.transmission.cut.cutClosureResidual, 5e-12);
end

function testCutUsesTheFrozenSharedPolarQuadratureFamily(testCase)
d = testCase.TestData.data;
t = d.stage8.transmission.cut;
r = d.stage8.reflection.cut;
verifyEqual(testCase, t.quadratureFamily, ...
    'shared_polar_quarter_disk_v1');
verifyEqual(testCase, r.quadratureFamily, t.quadratureFamily);
rule = ndelta.integration.cut_polar_rule(t.radialMaximum, ...
    t.radialOrder, t.angleOrder);
verifyEqual(testCase, rule.family, t.quadratureFamily);
verifyTrue(testCase, all(rule.rho > 0 & rule.rho < t.radialMaximum));
verifyTrue(testCase, all(rule.theta > 0 & rule.theta < 0.5 .* pi));
verifyEqual(testCase, t.numberOfBankPairEvaluations, ...
    2 .* t.radialOrder .* t.angleOrder);
verifyEqual(testCase, d.stage8.numericsFingerprint.version, 2);
verifyEqual(testCase, ...
    d.stage8.numericsFingerprint.cutBankQuadratureFamily, ...
    t.quadratureFamily);
end

function testAllInactiveSystemIsExactZeroIndependentOfStorage(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.strengths = zeros(size(cfg.barriers.strengths));
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
options = struct('q4Order', 4, 'qPerpOrder', 4, ...
    'collectiveOrder', 4, 'cutRadialOrder', 4, ...
    'cutAngleOrder', 4, 'endpointOrder', 4);
value = ndelta.integration.integrate_g1( ...
    cfg, geometry, spectrum, options);
% Compare mathematical values rather than MATLAB's real/complex storage
% flag.  Some releases canonicalise exact complex zeros as real zeros.
verifyEqual(testCase, abs(value.values), zeros(size(value.values)));
verifyEqual(testCase, abs(value.componentMatrix), ...
    zeros(size(value.componentMatrix)));
verifyEqual(testCase, abs(value.sourceMatrix), ...
    zeros(size(value.sourceMatrix)));
end

function testN1FullPipelineRegression(testCase)
cfg = testCase.TestData.data.cfg;
cfg.referenceEnergy = 0.8;
cfg.barriers.positions = 0;
cfg.barriers.strengths = -0.3;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry(0, ...
    cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
options = struct('q4Order', 32, 'qPerpOrder', 32, ...
    'collectiveOrder', 32, 'cutRadialOrder', 32, ...
    'cutAngleOrder', 32, 'endpointOrder', 32);
value = ndelta.integration.integrate_g1( ...
    cfg, geometry, spectrum, options);
verifyEqual(testCase, value.transmission.value, ...
    -7.20e-11 + 4.49275e-3i, 'AbsTol', 5e-6);
verifyEqual(testCase, value.reflection.value, ...
    4.53e-12 + 1.71158e-3i, 'AbsTol', 5e-6);
end

function testLowerOrderAuditConverges(testCase)
s = testCase.TestData.data.stage8;
verifyLessThanOrEqual(testCase, s.validation.convergenceError, ...
    testCase.TestData.data.cfg.tolerances.integrationConvergence);
verifyLessThanOrEqual(testCase, ...
    s.validation.componentConvergenceError, ...
    testCase.TestData.data.cfg.tolerances.integrationConvergence);
verifyLessThanOrEqual(testCase, s.validation.sourceConvergenceError, ...
    testCase.TestData.data.cfg.tolerances.integrationConvergence);
verifyTrue(testCase, s.validation.accepted);
verifyEqual(testCase, s.validation.numberPassed, ...
    s.validation.numberOfChecks);

% Custom maps and orders must be retained by the comparison audit rather
% than silently replaced by cfg.integration defaults.
d = testCase.TestData.data;
options = struct('q4Order', 4, 'qPerpOrder', 4, ...
    'collectiveOrder', 4, 'cutRadialOrder', 4, ...
    'cutAngleOrder', 4, 'endpointOrder', 4, ...
    'q4Scale', 0.73, 'q4MapPower', 1.5, ...
    'qPerpTailScale', 0.81);
stage7Stub = struct('accepted', true, 'spectrum', d.spectrum);
customCfg = d.cfg;
customCfg.execution.failOnBenchmarkFailure = false;
customCfg = ndelta.config.finalize_configuration(customCfg);
custom = run_stage8(customCfg, d.stage1, stage7Stub, options);
verifyEqual(testCase, custom.validation.effectiveOptions, options);
verifyEqual(testCase, custom.validation.auditOptions.q4Scale, ...
    options.q4Scale);
verifyEqual(testCase, custom.validation.auditOptions.q4MapPower, ...
    options.q4MapPower);
verifyEqual(testCase, custom.validation.auditOptions.qPerpTailScale, ...
    options.qPerpTailScale);
orderNames = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
for index = 1:numel(orderNames)
    verifyEqual(testCase, ...
        custom.validation.auditOptions.(orderNames{index}), 8);
end
end
