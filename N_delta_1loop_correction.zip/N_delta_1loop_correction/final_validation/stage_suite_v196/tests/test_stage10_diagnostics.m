function tests = test_stage10_diagnostics
%TEST_STAGE10_DIAGNOSTICS Convergence, contour and reporting contracts.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.stage1 = run_stage1(data.cfg);
data.stage2 = run_stage2(data.cfg, data.stage1);
data.stage3 = run_stage3(data.cfg);
data.stage4 = run_stage4(data.cfg);
data.stage5 = run_stage5(data.cfg, data.stage1);
data.stage6 = run_stage6(data.cfg, data.stage1);
data.stage7 = run_stage7(data.cfg, data.stage1);
data.stage8 = run_stage8(data.cfg, data.stage1, data.stage7);
data.stage9 = run_stage9(data.cfg, data.stage2, data.stage8);
data.stage10 = run_stage10( ...
    data.cfg, data.stage1, data.stage7, data.stage8);
testCase.TestData.data = data;
end

function testDefaultStage10Accepted(testCase)
d = testCase.TestData.data;
verifyTrue(testCase, d.stage10.accepted);
verifyTrue(testCase, d.stage10.validation.accepted);
verifyFalse(testCase, d.stage10.includesG2G3G4);
verifyFalse(testCase, d.stage10.changesStage8OrStage9CentralValues);
verifyEqual(testCase, d.stage10.baselineValues, d.stage8.values);
end

function testPortableStage10ContractHasFourteenChecks(testCase)
v = testCase.TestData.data.stage10.validation;
verifyEqual(testCase, v.numberOfChecks, 14);
verifyEqual(testCase, v.numberPassed, 14);
verifyEqual(testCase, numel(v.records), 14);
verifyTrue(testCase, all([v.records.passed]));
end

function testOrderScanChangesOneDimensionAtATime(testCase)
d = testCase.TestData.data;
scan = d.stage10.convergence;
verifyEqual(testCase, numel(scan.orderRecords), 18);
verifyTrue(testCase, scan.orderAccepted);
names = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
for index = 1:numel(scan.orderRecords)
    item = scan.orderRecords(index);
    changed = 0;
    for nameIndex = 1:numel(names)
        name = names{nameIndex};
        changed = changed + double( ...
            item.effectiveOptions.(name) ~= scan.baseOptions.(name));
    end
    verifyLessThanOrEqual(testCase, changed, 1);
    verifySize(testCase, item.sourceMatrix, [2, 5]);
    verifySize(testCase, item.componentMatrix, [2, 4]);
end
end

function testMappingScanPreservesAllOrders(testCase)
scan = testCase.TestData.data.stage10.convergence;
verifyEqual(testCase, numel(scan.mappingRecords), 9);
verifyTrue(testCase, scan.mappingAccepted);
orderNames = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
for index = 1:numel(scan.mappingRecords)
    for nameIndex = 1:numel(orderNames)
        name = orderNames{nameIndex};
        verifyEqual(testCase, ...
            scan.mappingRecords(index).effectiveOptions.(name), ...
            scan.baseOptions.(name));
    end
end
end

function testEndpointSolverSwitchIsNumericallyInvariant(testCase)
scan = testCase.TestData.data.stage10.convergence;
verifyEqual(testCase, numel(scan.endpointSwitchRecords), 3);
verifyTrue(testCase, scan.endpointSwitchAccepted);
verifyLessThanOrEqual(testCase, scan.maximumEndpointSwitchError, ...
    testCase.TestData.data.cfg.tolerances.stage10EndpointSwitch);
end

function testCollectiveRootScanKeepsModeIdentity(testCase)
scan = testCase.TestData.data.stage10.collectiveRootScan;
verifyTrue(testCase, scan.accepted);
verifyEqual(testCase, scan.numberOfRuns, 3);
verifyTrue(testCase, scan.allModeCountsMatch);
verifyTrue(testCase, scan.allModeLabelsMatch);
verifyTrue(testCase, scan.allModeIdentitiesMatch);
verifyTrue(testCase, scan.modeIdentityComparisonIsBoundsSafe);
verifyEqual(testCase, scan.modeCounts, ones(3, 1));
end

function testThresholdDiagnosticSeparatesThreeRegimes(testCase)
threshold = testCase.TestData.data.stage10.endpointThreshold;
verifyTrue(testCase, threshold.accepted);
verifyTrue(testCase, threshold.belowAccepted);
verifyTrue(testCase, threshold.thresholdAccepted);
verifyTrue(testCase, threshold.aboveAccepted);
verifyEqual(testCase, threshold.modeCounts(1), 1);
verifyTrue(testCase, threshold.samples(2).isZeroEnergyResonance);
verifyFalse(testCase, threshold.samples(2).spectrumAccepted);
verifyFalse(testCase, threshold.samples(2).rootResidualGateApplied);
verifyEqual(testCase, threshold.modeCounts(3), 2);
verifyFalse(testCase, threshold.performsStage8Integration);
verifyTrue(testCase, threshold.usesFrozenReferenceConfiguration);
end

function testDirectContourIdentityCoversAllTopologyRegions(testCase)
comparison = testCase.TestData.data.stage10.fixedQPerpComparison;
verifyTrue(testCase, comparison.accepted);
verifyTrue(testCase, comparison.topologyAccepted);
verifyEqual(testCase, numel(comparison.records), 6);
verifyEqual(testCase, comparison.regionLabels, ...
    {'cut_and_collective', 'collective_only', 'euclidean_only'});
verifyLessThanOrEqual(testCase, comparison.maximumIdentityError, ...
    testCase.TestData.data.cfg.tolerances.stage10ContourIdentity);
verifyTrue(testCase, any([comparison.records.hasCut]));
verifyTrue(testCase, any([comparison.records.hasCollectivePole]));
verifyTrue(testCase, any(~[comparison.records.hasCut] & ...
    ~[comparison.records.hasCollectivePole]));

cfg = testCase.TestData.data.cfg;
cfg.barriers.strengths = abs(cfg.barriers.strengths);
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
[~, labels] = ndelta.diagnostics.qperp_regions(cfg, spectrum);
verifyFalse(testCase, any(strcmp(labels, 'cut_and_collective')));
verifyTrue(testCase, any(strcmp(labels, 'cut_only')));
end

function testRawRealAxisPathDoesNotReuseMWRSources(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.sheet.epsilon = cfg.stage10.directDiagnosticEpsilon;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
raw = ndelta.diagnostics.real_axis_fixed(0.1, 'T', cfg, ...
    geometry, spectrum, struct('order', 8));
verifyFalse(testCase, raw.usesModifiedWickRotation);
verifyFalse(testCase, raw.usesMWRSourceValues);
verifyFalse(testCase, raw.usesCollectiveResidueValues);
verifyFalse(testCase, raw.usesCutBankValues);
verifyFalse(testCase, raw.usesEndpointKeyholeValues);
verifyTrue(testCase, raw.factorFlags.negativeStage6RawAppliedExactlyOnce);
verifyTrue(testCase, raw.factorFlags.q0OneOverTwoPiAppliedExactlyOnce);
end

function testEpsilonPlateauIsScopedWithoutExtrapolation(testCase)
plateau = testCase.TestData.data.stage10.epsilonPlateau;
verifyTrue(testCase, plateau.accepted);
verifyEqual(testCase, plateau.epsilons, [1e-7; 1e-8; 1e-9]);
verifyTrue(testCase, plateau.noExtrapolationUsed);
verifyFalse(testCase, plateau.directProductionEpsilonIdentityClaimed);
verifyTrue(testCase, plateau.mwrProductionEpsilonPlateauPassed);
verifySize(testCase, plateau.values, [3, 6]);
verifySize(testCase, plateau.sources, [3, 6, 5]);

cfg = testCase.TestData.data.cfg;
cfg.stage10.epsilonPlateau = [1e-8, 1e-9];
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:InvalidStage10EpsilonBridge');
cfg = testCase.TestData.data.cfg;
cfg.stage10.epsilonPlateau = [1e-6, 1e-7, 1e-8];
cfg = ndelta.config.finalize_configuration(cfg);
verifyError(testCase, @() ndelta.diagnostics.epsilon_plateau( ...
    cfg, testCase.TestData.data.stage7.spectrum), ...
    'ndelta:diagnostics:EpsilonPlateauMissesProduction');
end

function testN1FullChainRegressionRemainsAccepted(testCase)
regression = testCase.TestData.data.stage10.n1Regression;
verifyTrue(testCase, regression.accepted);
verifyEqual(testCase, regression.numberOfCollectiveModes, 1);
verifyEqual(testCase, regression.actualN1Alpha, 0.15, ...
    'AbsTol', 2e-10);
verifyLessThanOrEqual(testCase, regression.kernelAbsoluteError, ...
    testCase.TestData.data.cfg.tolerances.stage10N1Kernel);
verifyTrue(testCase, regression.usesFrozenReferenceConfiguration);
verifyEqual(testCase, regression.configuration.model.mphi, 0.2);
verifyEqual(testCase, regression.configuration.model.mPhi, 1.4);
verifyEqual(testCase, regression.configuration.sheet.epsilon, 1e-9);
verifyEqual(testCase, regression.configuration.integration.q4Scale, 1);
verifyEqual(testCase, ...
    regression.configuration.integration.qPerpTailScale, 1);
end

function testIntegrationAndContourOptionsAreStrict(testCase)
cfg = testCase.TestData.data.cfg;
verifyError(testCase, @() ndelta.integration.resolve_options( ...
    cfg, struct('unknown', 1)), 'ndelta:integration:UnknownOption');
legacy = ndelta.contour.resolve_options(cfg, struct('cutOrder', 7));
verifyEqual(testCase, legacy.cutRadialOrder, 7);
sameAlias = ndelta.contour.resolve_options(cfg, ...
    struct('cutOrder', 7, 'cutRadialOrder', 7));
verifyEqual(testCase, sameAlias.cutRadialOrder, 7);
verifyError(testCase, @() ndelta.contour.resolve_options(cfg, ...
    struct('cutOrder', 7, 'cutRadialOrder', 8)), ...
    'ndelta:contour:ConflictingCutOrderAliases');
verifyError(testCase, @() ndelta.contour.resolve_options( ...
    cfg, struct('unknown', 1)), 'ndelta:contour:UnknownOption');
cfg.stage10.orderMultipliers = [1, 1, 1];
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:IncompleteStage10Scan');
cfg = testCase.TestData.data.cfg;
cfg.stage10.collectiveScanSamples = [801, 801, 801];
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:InvalidStage10CollectiveScan');
cfg = testCase.TestData.data.cfg;
orderNames = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
for index = 1:numel(orderNames)
    cfg.integration.(orderNames{index}) = 4;
end
cfg.stage10.orderMultipliers = [0.9, 1.0, 1.1];
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:IncompleteStage10Scan');
end

function testOldOrMissingConfigurationVersionIsRejected(testCase)
cfg = testCase.TestData.data.cfg;
cfg.configurationVersion = 1.6;
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:ConfigurationVersionMismatch');
cfg.configurationVersion = 2.0;
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:ConfigurationVersionMismatch');
cfg = rmfield(cfg, 'configurationVersion');
verifyError(testCase, @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:ConfigurationVersionMismatch');
legacy = struct('configurationVersion', 1.6);
verifyError(testCase, @() ndelta.config.finalize_configuration(legacy), ...
    'ndelta:config:ConfigurationVersionMismatch');
verifyError(testCase, @() ndelta.config.finalize_configuration(struct()), ...
    'ndelta:config:ConfigurationVersionMismatch');
end

function testAllInactiveRawAxisIsExactZero(testCase)
cfg = testCase.TestData.data.cfg;
cfg.barriers.strengths = zeros(size(cfg.barriers.strengths));
cfg.sheet.epsilon = cfg.stage10.directDiagnosticEpsilon;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
raw = ndelta.diagnostics.real_axis_fixed(0.1, 'R', cfg, ...
    geometry, spectrum, struct('order', 8));
verifyEqual(testCase, abs(raw.value), 0);
verifyEqual(testCase, raw.numberOfPointEvaluations, 0);
verifyTrue(testCase, raw.allInactiveExactZero);
end

function testStaleUpstreamConfigurationIsRejected(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.barriers.positions = cfg.barriers.positions + [0, 0.1];
cfg = ndelta.config.finalize_configuration(cfg);
verifyError(testCase, @() run_stage10( ...
    cfg, d.stage1, d.stage7, d.stage8), ...
    'ndelta:g1:Stage1ConfigurationMismatch');

badStage1 = d.stage1;
badStage1.kinematics.P = NaN;
verifyError(testCase, @() run_stage10( ...
    d.cfg, badStage1, d.stage7, d.stage8), ...
    'ndelta:stage10:Stage1ConfigurationMismatch');

rootCfg = d.cfg;
rootCfg.collective.scanSamples = 1001;
rootCfg = ndelta.config.finalize_configuration(rootCfg);
verifyError(testCase, @() run_stage10( ...
    rootCfg, d.stage1, d.stage7, d.stage8), ...
    'ndelta:stage10:Stage7SolverConfigurationMismatch');

badStage8 = d.stage8;
badStage8.spectrumSignature.numberOfModes = ...
    badStage8.spectrumSignature.numberOfModes + 1;
verifyError(testCase, @() run_stage10( ...
    d.cfg, d.stage1, d.stage7, badStage8), ...
    'ndelta:stage10:Stage7Stage8SpectrumMismatch');

numericsCfg = d.cfg;
numericsCfg.integration.endpointTauSwitchRelative = ...
    2 .* numericsCfg.integration.endpointTauSwitchRelative;
numericsCfg = ndelta.config.finalize_configuration(numericsCfg);
verifyError(testCase, @() run_stage10( ...
    numericsCfg, d.stage1, d.stage7, d.stage8), ...
    'ndelta:stage10:Stage8NumericsConfigurationMismatch');

nearSingularCfg = d.cfg;
nearSingularCfg.tolerances.nearSingularRcond = ...
    2 .* nearSingularCfg.tolerances.nearSingularRcond;
nearSingularCfg = ndelta.config.finalize_configuration( ...
    nearSingularCfg);
verifyError(testCase, @() run_stage10( ...
    nearSingularCfg, d.stage1, d.stage7, d.stage8), ...
    'ndelta:stage10:Stage8NumericsConfigurationMismatch');

staleMuCfg = d.cfg;
staleMuCfg.model.mu = 2 .* staleMuCfg.model.mu;
staleMuCfg = ndelta.config.finalize_configuration(staleMuCfg);
verifyError(testCase, @() run_stage11(staleMuCfg, d.stage1, ...
    d.stage2, d.stage7, d.stage8, d.stage9, d.stage10), ...
    'ndelta:stage11:AmplitudeConfigurationMismatch');

badStage8For11 = d.stage8;
badStage8For11.spectrumSignature.numberOfModes = ...
    badStage8For11.spectrumSignature.numberOfModes + 1;
verifyError(testCase, @() run_stage11(d.cfg, d.stage1, ...
    d.stage2, d.stage7, badStage8For11, d.stage9, d.stage10), ...
    'ndelta:stage11:Stage7Stage8SpectrumMismatch');
end

function testReportingWritesStage10Artifacts(testCase)
d = testCase.TestData.data;
temporaryRoot = tempname;
mkdir(temporaryRoot);
cleanup = onCleanup(@() rmdir(temporaryRoot, 's')); %#ok<NASGU>
cfg = d.cfg;
cfg.projectRoot = temporaryRoot;
cfg.output.directoryName = 'stage10_test_output';
cfg.output.writeStage4Figure = false;
cfg.output.writeStage9Figure = false;
cfg.output.writeStage10Figure = false;
cfg.output.writeTextReport = true;
cfg.output.saveMatFile = true;
result = struct('stage1', d.stage1, 'stage2', d.stage2, ...
    'stage3', d.stage3, 'stage4', d.stage4, 'stage5', d.stage5, ...
    'stage6', d.stage6, 'stage7', d.stage7, 'stage8', d.stage8, ...
    'stage9', d.stage9, 'stage10', d.stage10);
files = ndelta.reporting.write_stage0_10_outputs(cfg, result);
paths = {files.stage10OrderCsv, files.stage10MappingCsv, ...
    files.stage10EndpointSwitchCsv, ...
    files.stage10RootCsv, files.stage10ContourCsv, ...
    files.stage10EpsilonCsv, files.stage10ThresholdCsv, ...
    files.stage10N1Csv, files.stage10ValidationCsv, ...
    files.report, files.mat};
for index = 1:numel(paths)
    verifyEqual(testCase, exist(paths{index}, 'file'), 2);
end
verifyNotEmpty(testCase, strfind(fileread(files.stage10ContourCsv), ...
    'identity_error')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(fileread(files.stage10OrderCsv), ...
    'collective_pole_real')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(fileread(files.stage10EpsilonCsv), ...
    'endpoint_keyhole_real')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(fileread(files.stage10N1Csv), ...
    'alpha_absolute_error')); %#ok<STREMP>
verifyNotEmpty(testCase, strfind(fileread(files.report), ...
    'direct production-epsilon identity: not_claimed')); %#ok<STREMP>
end

function testReleaseContractAndUnitarityBoundaryAreExplicit(testCase)
d = testCase.TestData.data;
release = ndelta.config.release_contract();
verifyEqual(testCase, release.releaseVersion, '1.9.6');
verifyEqual(testCase, release.configurationVersion, 1.9);
verifyEqual(testCase, release.maximumStage, 12);
verifyEqual(testCase, release.portableCheckCount, 168);
verifyEqual(testCase, release.unitTestCount, 196);
verifyFalse(testCase, d.stage10.unitarityPolicy.g1AloneRequiredToClose);
verifyTrue(testCase, ...
    d.stage10.unitarityPolicy.fullRoseG1ToG4RequiredForOneLoopClosure);
verifyFalse(testCase, d.stage10.unitarityPolicy.usedAsAcceptanceGate);
verifyFalse(testCase, d.stage10.directProductionEpsilonIdentityClaimed);
verifyEqual(testCase, d.stage10.directProductionEpsilonIdentityStatus, ...
    'not_claimed');
end
