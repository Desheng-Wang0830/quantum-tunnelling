function tests = test_stage11_g4
%TEST_STAGE11_G4 Arbitrary-N Rose G4 longitudinal and contour contracts.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
data = struct();
data.cfg = run_stage0(false);
data.geometry = ndelta.geometry.build_geometry( ...
    data.cfg.barriers.positions, data.cfg.tolerances.distanceMerge);
data.context = ndelta.stage11.build_context(data.cfg, data.geometry);
data.q0 = 0.30;
data.qPerp = 0.10;
data.roots = ndelta.sheet.physical_roots( ...
    data.q0, data.qPerp, data.cfg.referenceEnergy, ...
    data.cfg.model, data.cfg.sheet.epsilon);
for channelCell = {'T', 'R'}
    channel = channelCell{1};
    [optimised, optimisedDetails] = ...
        ndelta.g4.pointwise_contraction_from_roots( ...
        data.roots.omega, data.roots.kappaI, channel, ...
        data.cfg, data.geometry, data.context);
    [reference, referenceDetails] = ...
        ndelta.g4.pointwise_reference_from_roots( ...
        data.roots.omega, data.roots.kappaI, channel, ...
        data.cfg, data.geometry, data.context);
    if channel == 'T'
        data.optimisedRawT = optimised;
        data.referenceRawT = reference;
        data.optimisedDetailsT = optimisedDetails;
        data.referenceDetailsT = referenceDetails;
    else
        data.optimisedRawR = optimised;
        data.referenceRawR = reference;
        data.optimisedDetailsR = optimisedDetails;
        data.referenceDetailsR = referenceDetails;
    end
end
testCase.TestData.data = data;
end

function testN1CompactKernelForBothChannels(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.barriers.positions = 0;
cfg.barriers.strengths = -0.3;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
omega = 0.37 + 1.11i;
kappaI = 0.29 + 0.63i;
P = cfg.derived.P;
g = cfg.barriers.strengths;
tauP = -2i .* g .* P ./ (2 .* P + 1i .* g);
tauI = -2i .* g .* kappaI ./ (2 .* kappaI + 1i .* g);
c = P + kappaI;
I4 = -(omega + 2 .* c) ./ ( ...
    16 .* P.^2 .* kappaI.^2 .* omega .* c .* (omega + c).^2);
expectedCode = -tauP.^2 .* tauI .* I4;
for channelCell = {'T', 'R'}
    raw = ndelta.g4.pointwise_contraction_from_roots( ...
        omega, kappaI, channelCell{1}, cfg, geometry, context);
    verifyLessThanOrEqual(testCase, ...
        relative(-raw, expectedCode), 5e-10);
end
end

function testDefaultN2PointwiseIndependentGolden(testCase)
d = testCase.TestData.data;
% Independent real-q3 integration of the five propagators, with the
% vertex-reduced convention F_code=-F_raw and no q0/qPerp measure.
expectedCode = [ ...
    0.6770681590479 - 1.6155679490894i, ...
    0.6767559447600 - 1.6162331227945i];
actualCode = -[d.optimisedRawT, d.optimisedRawR];
verifyEqual(testCase, actualCode, expectedCode, 'AbsTol', 5e-8);
end

function testDefaultN2OptimisedEqualsSixCentreReference(testCase)
d = testCase.TestData.data;
verifyLessThanOrEqual(testCase, ...
    relative(d.optimisedRawT, d.referenceRawT), 5e-10);
verifyLessThanOrEqual(testCase, ...
    relative(d.optimisedRawR, d.referenceRawR), 5e-10);
verifyEqual(testCase, d.optimisedDetailsT.numberOfActiveTerms, 16);
verifyEqual(testCase, d.optimisedDetailsR.numberOfActiveTerms, 16);
verifyEqual(testCase, d.referenceDetailsT.numberOfExplicitTerms, 64);
verifyEqual(testCase, d.referenceDetailsR.numberOfExplicitTerms, 64);
end

function testTransmissionAndReflectionAreNotHardCodedEqual(testCase)
d = testCase.TestData.data;
separation = abs(d.optimisedRawT - d.optimisedRawR);
verifyGreaterThan(testCase, separation, 1e-5);
verifyTrue(testCase, ...
    d.optimisedDetailsT.twoExternalTauPSegmentsApplied);
verifyFalse(testCase, ...
    d.optimisedDetailsT.mixedMinusOrdinaryPolePresent);
end

function testTranslationCovariance(testCase)
d = testCase.TestData.data;
shift = 0.37;
cfg = d.cfg;
cfg.barriers.positions = cfg.barriers.positions + shift;
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
movedT = ndelta.g4.pointwise_contraction_from_roots( ...
    d.roots.omega, d.roots.kappaI, 'T', cfg, geometry, context);
movedR = ndelta.g4.pointwise_contraction_from_roots( ...
    d.roots.omega, d.roots.kappaI, 'R', cfg, geometry, context);
verifyLessThanOrEqual(testCase, ...
    relative(movedT, d.optimisedRawT), 2e-9);
verifyLessThanOrEqual(testCase, relative(movedR, ...
    exp(2i .* cfg.derived.P .* shift) .* d.optimisedRawR), 2e-9);
end

function testLabelPermutationInvariance(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.barriers.positions = [-0.83, 0.14, 1.07];
cfg.barriers.strengths = [-0.12, 0.05, -0.18];
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
base = evaluate_channels(d.roots, cfg, geometry, context);

permutation = [3, 1, 2];
permutedCfg = cfg;
permutedCfg.barriers.positions = cfg.barriers.positions(permutation);
permutedCfg.barriers.strengths = cfg.barriers.strengths(permutation);
permutedCfg = ndelta.config.finalize_configuration(permutedCfg);
permutedGeometry = ndelta.geometry.build_geometry( ...
    permutedCfg.barriers.positions, ...
    permutedCfg.tolerances.distanceMerge);
permutedContext = ndelta.stage11.build_context( ...
    permutedCfg, permutedGeometry);
permuted = evaluate_channels( ...
    d.roots, permutedCfg, permutedGeometry, permutedContext);
verifyLessThanOrEqual(testCase, ...
    max(relative(permuted, base)), 2e-9);
end

function testInactiveCentresAreExactlySkipped(testCase)
d = testCase.TestData.data;
cfg = d.cfg;
cfg.barriers.positions = [-3.0, -0.5, 0.5, 2.2];
cfg.barriers.strengths = [0, -0.15, -0.15, 0];
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
withInactive = evaluate_channels( ...
    d.roots, cfg, geometry, context);
verifyLessThanOrEqual(testCase, ...
    max(relative(withInactive, ...
    [d.optimisedRawT, d.optimisedRawR])), 2e-10);
verifyEqual(testCase, context.activeIndices, [2; 3]);

zeroCfg = d.cfg;
zeroCfg.barriers.strengths = [0, 0];
zeroCfg = ndelta.config.finalize_configuration(zeroCfg);
zeroGeometry = ndelta.geometry.build_geometry( ...
    zeroCfg.barriers.positions, zeroCfg.tolerances.distanceMerge);
zeroContext = ndelta.stage11.build_context(zeroCfg, zeroGeometry);
zeroValue = evaluate_channels( ...
    d.roots, zeroCfg, zeroGeometry, zeroContext);
verifyEqual(testCase, abs(zeroValue), zeros(size(zeroValue)));
endpointReference = ndelta.g4.pointwise_reference_from_roots( ...
    d.roots.omega, 0, 'T', zeroCfg, zeroGeometry, zeroContext);
verifyEqual(testCase, abs(endpointReference), 0);
end

function testEndpointKeyholeIsExactlyZero(testCase)
d = testCase.TestData.data;
for channelCell = {'T', 'R'}
    channel = channelCell{1};
    endpoint = ndelta.g4.endpoint_data( ...
        d.qPerp, channel, d.cfg, d.context);
    verifyTrue(testCase, endpoint.endpointIsZero);
    verifyEqual(testCase, abs(endpoint.vertexReducedResidue), 0);
    verifyEqual(testCase, abs(endpoint.keyholeContribution), 0);
    verifyEqual(testCase, endpoint.keyholeQ0WindingFraction, 0);
    verifyFalse(testCase, endpoint.ordinaryHalfIndentationUsed);

    cut = ndelta.stage11.cut_fixed('G4', ...
        @ndelta.g4.pointwise_contraction_from_roots, ...
        @ndelta.g4.endpoint_data, d.qPerp, channel, d.cfg, ...
        d.geometry, d.context, struct('cutRadialOrder', 4));
    verifyEqual(testCase, abs(cut.endpointContribution), 0);
    verifyEqual(testCase, cut.value, cut.bankContribution, ...
        'AbsTol', 5e-15);
end
end

function values = evaluate_channels(roots, cfg, geometry, context)
values = complex(zeros(1, 2));
values(1) = ndelta.g4.pointwise_contraction_from_roots( ...
    roots.omega, roots.kappaI, 'T', cfg, geometry, context);
values(2) = ndelta.g4.pointwise_contraction_from_roots( ...
    roots.omega, roots.kappaI, 'R', cfg, geometry, context);
end

function value = relative(left, right)
value = abs(left - right) ./ (1 + abs(right));
end
