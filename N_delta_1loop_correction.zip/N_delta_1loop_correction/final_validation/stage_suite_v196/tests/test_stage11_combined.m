function tests = test_stage11_combined
%TEST_STAGE11_COMBINED Complete Rose amplitude-level assembly contracts.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
cfg = run_stage0(false);
stage1 = run_stage1(cfg);
tree = run_stage2(cfg, stage1).tree;
reduced = { ...
    synthetic_reduced('G1', [0.12 + 0.08i, -0.03 + 0.05i]), ...
    synthetic_reduced('G2', [-0.04 + 0.03i, 0.02 - 0.01i]), ...
    synthetic_reduced('G3', [0.015 - 0.025i, -0.01 + 0.04i]), ...
    synthetic_reduced('G4', [0.03 + 0.012i, 0.01 - 0.018i])};
[terms, combined] = assemble_all(cfg, tree, reduced);
testCase.TestData.data = struct('cfg', cfg, 'tree', tree, ...
    'reduced', {reduced}, 'terms', {terms}, 'combined', combined);
end

function testAmplitudeLevelSumAndTermwiseInterferenceAgree(testCase)
d = testCase.TestData.data;
c = d.combined;
verifyEqual(testCase, c.totalReducedKernelsPerMu2, ...
    sum(c.termKernelMatrix, 1), 'AbsTol', 5e-15);
verifyEqual(testCase, c.totalAmplitudesPerMu2, ...
    sum(c.termAmplitudesPerMu2, 1), 'AbsTol', 5e-15);
verifyEqual(testCase, c.totalDeltaAmplitudes, ...
    sum(c.termDeltaAmplitudeMatrix, 1), 'AbsTol', 5e-15);
expectedProbability = 2 .* real(conj(c.treeAmplitudes) ...
    .* c.totalDeltaAmplitudes);
verifyEqual(testCase, c.totalDeltaProbabilities, ...
    expectedProbability, 'AbsTol', 5e-15);
verifyEqual(testCase, c.totalDeltaProbabilitiesByTermSum, ...
    expectedProbability, 'AbsTol', 5e-15);
verifyLessThanOrEqual(testCase, ...
    c.maximumInterferenceAssemblyResidual, 5e-15);
verifyTrue(testCase, c.amplitudeLevelSumUsed);
verifyTrue(testCase, c.termwiseInterferenceSumUsedAsCrossCheck);
end

function testStrictOMu2ExcludesEveryMu4Contribution(testCase)
c = testCase.TestData.data.combined;
expected = c.treeProbabilities + 2 .* real( ...
    conj(c.treeAmplitudes) .* c.totalDeltaAmplitudes);
verifyEqual(testCase, c.truncatedProbabilities, expected, ...
    'AbsTol', 5e-15);
verifyFalse(testCase, c.amplitudeSquaredIncluded);
verifyFalse(testCase, c.mu4TermsIncluded);
omittedMu4 = abs(c.totalDeltaAmplitudes).^2;
verifyGreaterThan(testCase, max(omittedMu4), 0);
verifyGreaterThan(testCase, max(abs( ...
    (expected + omittedMu4) - c.truncatedProbabilities)), 0);
end

function testCompleteCorrectionScalesAsMuSquaredNotMuFourth(testCase)
d = testCase.TestData.data;
scaledCfg = d.cfg;
scaledCfg.model.mu = -3 .* d.cfg.model.mu;
scaledCfg = ndelta.config.finalize_configuration(scaledCfg);
[~, scaled] = assemble_all(scaledCfg, d.tree, d.reduced);
verifyEqual(testCase, scaled.totalDeltaAmplitudes, ...
    9 .* d.combined.totalDeltaAmplitudes, 'AbsTol', 5e-14);
verifyEqual(testCase, scaled.totalDeltaProbabilities, ...
    9 .* d.combined.totalDeltaProbabilities, 'AbsTol', 5e-14);
verifyGreaterThan(testCase, max(abs( ...
    scaled.totalDeltaAmplitudes ...
    - 81 .* d.combined.totalDeltaAmplitudes)), 1e-8);
verifyFalse(testCase, scaled.amplitudeSquaredIncluded);
verifyFalse(testCase, scaled.mu4TermsIncluded);
end

function testZeroMuLeavesExactlyTheTreeProbabilities(testCase)
d = testCase.TestData.data;
zeroCfg = d.cfg;
zeroCfg.model.mu = 0;
zeroCfg = ndelta.config.finalize_configuration(zeroCfg);
[terms, combined] = assemble_all(zeroCfg, d.tree, d.reduced);
verifyEqual(testCase, abs(combined.totalDeltaAmplitudes), [0, 0]);
verifyEqual(testCase, combined.totalDeltaProbabilities, [0, 0]);
verifyEqual(testCase, combined.truncatedProbabilities, ...
    combined.treeProbabilities);
for index = 1:numel(terms)
    verifyEqual(testCase, abs(terms{index}.deltaAmplitudes), [0, 0]);
    verifyEqual(testCase, terms{index}.deltaProbabilities, [0, 0]);
end
verifyFalse(testCase, combined.amplitudeSquaredIncluded);
verifyFalse(testCase, combined.mu4TermsIncluded);
end

function testAllFourTermsRemainSeparateInTheAuditMatrix(testCase)
c = testCase.TestData.data.combined;
verifyEqual(testCase, c.termNames, {'G1', 'G2', 'G3', 'G4'});
verifySize(testCase, c.termKernelMatrix, [4, 2]);
verifySize(testCase, c.termDeltaAmplitudeMatrix, [4, 2]);
verifySize(testCase, c.termDeltaProbabilityMatrix, [4, 2]);
verifyGreaterThan(testCase, abs( ...
    c.termKernelMatrix(4, 1) - c.termKernelMatrix(4, 2)), 1e-3);
end

function [terms, combined] = assemble_all(cfg, tree, reduced)
terms = cell(1, 4);
terms{1} = ndelta.amplitude.assemble_g1(cfg, tree, reduced{1});
for index = 2:4
    terms{index} = ndelta.amplitude.assemble_stage11_term( ...
        cfg, tree, reduced{index});
end
combined = ndelta.amplitude.assemble_g1_g4( ...
    cfg, tree, terms{1}, terms{2}, terms{3}, terms{4});
end

function reduced = synthetic_reduced(term, values)
component = complex(zeros(2, 4));
component(:, 1) = values(:);
source = complex(zeros(2, 5));
source(:, 1) = values(:);
reduced = struct();
reduced.term = term;
reduced.values = values;
reduced.transmission = struct('value', values(1));
reduced.reflection = struct('value', values(2));
reduced.componentNames = ...
    {'euclidean', 'ordinaryPole', 'collectivePole', 'cutTotal'};
reduced.sourceNames = {'euclidean', 'ordinaryPole', ...
    'collectivePole', 'cutBanks', 'endpointKeyhole'};
reduced.componentMatrix = component;
reduced.sourceMatrix = source;
end
