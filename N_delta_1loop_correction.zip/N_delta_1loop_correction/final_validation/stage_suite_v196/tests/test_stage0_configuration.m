function tests = test_stage0_configuration
%TEST_STAGE0_CONFIGURATION Configuration and input-contract tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
end

function testDefaults(testCase)
cfg = testCase.TestData.cfg;
verifyEqual(testCase, cfg.configurationVersion, 1.9);
verifyEqual(testCase, cfg.derived.N, 2);
verifyEqual(testCase, cfg.derived.numberOfActiveCentres, 2);
verifyEqual(testCase, cfg.derived.P, sqrt(0.05), 'AbsTol', 5e-16);
verifyEqual(testCase, cfg.barriers.positions, [-0.5, 0.5]);
verifyEqual(testCase, cfg.barriers.strengths, [-0.15, -0.15]);
verifyEqual(testCase, cfg.sheet.epsilon, 1e-9);
verifyEqual(testCase, cfg.sheet.referenceQPerp, 0.1);
verifyEqual(testCase, cfg.g1.referenceQ0, 0.3);
verifyEqual(testCase, cfg.g1.referenceQPerp, 0.1);
verifyEqual(testCase, cfg.tolerances.g1Coalescence, 1e-8);
verifyEqual(testCase, cfg.tolerances.g1Contraction, 5e-11);
verifyEqual(testCase, cfg.collective.scanSamples, 801);
verifyEqual(testCase, cfg.integration.q4Order, 20);
verifyEqual(testCase, cfg.integration.qPerpOrder, 18);
verifyTrue(testCase, cfg.integration.cutEvenSubtraction);
verifyEqual(testCase, cfg.stage10.directDiagnosticEpsilon, 1e-5);
verifyEqual(testCase, cfg.stage10.epsilonPlateau, [1e-7, 1e-8, 1e-9]);
verifyEqual(testCase, cfg.stage11.referenceQ0, 0.3);
verifyEqual(testCase, cfg.stage11.referenceQPerp, 0.1);
verifyEqual(testCase, cfg.stage11.comparisonOrderFactor, 0.75);
verifyEqual(testCase, cfg.stage12.energyValues, ...
    [0.24, 0.30, 0.50, 0.80, 1.10, 1.40]);
verifyEqual(testCase, cfg.stage12.nValues, [2, 3, 4]);
verifyEqual(testCase, cfg.stage12.discretisation, ...
    'fixed_support_trapezoidal');
verifyEqual(testCase, cfg.stage12.perturbativeEtaLimit, 0.10);
verifyEqual(testCase, cfg.execution.parallel.mode, 'auto');
verifyEqual(testCase, cfg.execution.parallel.workerCount, 4);
verifyEqual(testCase, cfg.derived.endpointTauSwitch, 0.07, ...
    'AbsTol', 5e-16);
end

function testRowAndColumnInputsAreEquivalent(testCase)
rowCfg = testCase.TestData.cfg;
columnCfg = rowCfg;
columnCfg.barriers.positions = rowCfg.barriers.positions(:);
columnCfg.barriers.strengths = rowCfg.barriers.strengths(:);
columnCfg = ndelta.config.finalize_configuration(columnCfg);
verifyEqual(testCase, columnCfg.barriers.positions, ...
    rowCfg.barriers.positions);
verifyEqual(testCase, columnCfg.barriers.strengths, ...
    rowCfg.barriers.strengths);
end

function testExactZeroIsInactiveButTinyNonzeroIsActive(testCase)
cfg = testCase.TestData.cfg;
cfg.barriers.positions = [-1, 0, 1];
cfg.barriers.strengths = [0, 1e-14, -0.2];
cfg = ndelta.config.finalize_configuration(cfg);
verifyEqual(testCase, cfg.derived.activeMask, [false, true, true]);
verifyEqual(testCase, cfg.derived.numberOfActiveCentres, 2);
end

function testCoincidentCentresAreAllowed(testCase)
cfg = testCase.TestData.cfg;
cfg.barriers.positions = [0.4, 0.4];
cfg.barriers.strengths = [0.2, 0.2];
cfg = ndelta.config.finalize_configuration(cfg);
verifyEqual(testCase, cfg.derived.N, 2);
end

function testInvalidEnergyBoundaries(testCase)
cfg = testCase.TestData.cfg;
cfg.referenceEnergy = cfg.model.mphi;
verifyError(testCase, ...
    @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:EnergyOutsideElasticWindow');
cfg.referenceEnergy = cfg.model.mphi + cfg.model.mPhi;
verifyError(testCase, ...
    @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:EnergyOutsideElasticWindow');
end

function testBarrierLengthMismatch(testCase)
cfg = testCase.TestData.cfg;
cfg.barriers.strengths = [0.1, 0.2, 0.3];
verifyError(testCase, ...
    @() ndelta.config.finalize_configuration(cfg), ...
    'ndelta:config:BarrierSizeMismatch');
end
