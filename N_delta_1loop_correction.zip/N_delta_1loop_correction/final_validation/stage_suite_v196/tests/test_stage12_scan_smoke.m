function tests = test_stage12_scan_smoke
%TEST_STAGE12_SCAN_SMOKE Bounded-cost leaf and complete S-matrix smoke tests.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(projectRoot);
testCase.TestData.cfg = run_stage0(false);
end

function testQuickPlanRetainsTheReferenceAnchorAndFormalN3(testCase)
cfg = testCase.TestData.cfg;
options = ndelta.stage12.resolve_scan_options( ...
    cfg, struct('profile', 'quick'));
verifyEqual(testCase, options.energyValues, cfg.referenceEnergy);
verifyEqual(testCase, options.nValues, 3);
verifyFalse(testCase, options.runContourAudit);
verifyFalse(testCase, options.runEpsilonPlateau);
verifyFalse(testCase, options.formalReleaseRequested);
verifyEqual(testCase, options.integrationOptions, ...
    ndelta.integration.resolve_options(cfg, struct()));
end

function testN3PointwiseOptimisedAndExplicitOraclesAgree(testCase)
oracle = ndelta.stage12.pointwise_n3_oracle(testCase.TestData.cfg);
verifyTrue(testCase, oracle.accepted);
verifyLessThanOrEqual(testCase, oracle.maximumError, ...
    testCase.TestData.cfg.tolerances.stage11Pointwise);
verifySize(testCase, oracle.errors, [3, 2]);
verifyTrue(testCase, oracle.asymmetricRoutesDistinct);
verifyGreaterThan(testCase, oracle.asymmetricRouteDifference, 0);
verifyFalse(testCase, oracle.nodeSelection.usedFallback);
verifyEqual(testCase, oracle.nodeSelection.status, ...
    'configured_stage11_node_is_safe');
end

function testAsymmetricN3ProfileForcesFreshMirroredIncidence(testCase)
cfg = testCase.TestData.cfg;
profile = ndelta.stage12.asymmetric_n3_profile( ...
    cfg.stage12.support, cfg.stage12.totalStrength);
verifyEqual(testCase, profile.N, 3);
verifyEqual(testCase, profile.positions, [-0.5, -0.07, 0.5], ...
    'AbsTol', 5e-16);
verifyEqual(testCase, profile.strengths, [-0.06, -0.11, -0.13], ...
    'AbsTol', 5e-16);
verifyEqual(testCase, profile.totalStrength, ...
    cfg.stage12.totalStrength, 'AbsTol', 5e-16);
verifyTrue(testCase, profile.exactSupportEndpoints);
verifyFalse(testCase, profile.mirrorSymmetric);
verifyTrue(testCase, profile.requiresFreshMirroredRightIncidence);
end

function testCompleteTwoByTwoSMatrixUsesBothAsymmetricDirections(testCase)
cfg = testCase.TestData.cfg;
profile = ndelta.stage12.asymmetric_n3_profile( ...
    cfg.stage12.support, cfg.stage12.totalStrength);
cfg.barriers.positions = profile.positions;
cfg.barriers.strengths = profile.strengths;
% This smoke test checks construction and provenance, not production
% convergence.  Supplied low quadrature orders keep the one full G1--G4
% run bounded, while deliberately loose gates let both directions assemble.
cfg.tolerances.unitarity = 1e6;
cfg.tolerances.stage12SourceClosure = 1e6;
cfg.tolerances.stage12Unitarity = 1e6;
cfg.tolerances.stage12UnitarityAbsolute = 1e6;
cfg.tolerances.stage12SMatrix = 1e6;
cfg.tolerances.stage12SMatrixAbsolute = 1e6;
cfg.tolerances.stage12Anchor = 1e6;
cfg.execution.failOnBenchmarkFailure = false;
cfg = ndelta.config.finalize_configuration(cfg);
options = low_options();
result = ndelta.stage12.evaluate_bidirectional(cfg, options);

verifyTrue(testCase, result.left.accepted);
verifyTrue(testCase, result.rightFromMirroredPotential.accepted);
verifyFalse(testCase, result.centredMirrorSymmetry.accepted);
verifyFalse(testCase, result.mirrorReusedByExactParity);
verifyTrue(testCase, result.rightIncidenceObtainedFromMirroredPotential);
verifyTrue(testCase, result.fullTwoByTwoSMatrixTested);
verifyTrue(testCase, result.accepted);
verifyTrue(testCase, result.treeUnitarityAccepted);
verifyTrue(testCase, result.oneLoopUnitarityAccepted);
verifySize(testCase, result.S0, [2, 2]);
verifySize(testCase, result.deltaSPerMu2, [2, 2]);
for termCell = {'G1', 'G2', 'G3', 'G4'}
    reduced = result.left.reduced.(termCell{1});
    verifyEqual(testCase, reduced.cutQuadratureFamily, ...
        'shared_polar_quarter_disk_v1');
    verifyEqual(testCase, reduced.transmission.cut.mapping, ...
        'qPerp=rho*sin(theta),kappa=rho*cos(theta),rho_boundary_clustered');
    verifyEqual(testCase, reduced.reflection.cut.mapping, ...
        reduced.transmission.cut.mapping);
end
verifySize(testCase, result.treeUnitarityResidualMatrix, [2, 2]);
verifySize(testCase, ...
    result.oneLoopUnitarityResidualMatrixPerMu2, [2, 2]);
verifyEqual(testCase, result.S0, [ ...
    result.left.tree.r0, result.rightFromMirroredPotential.tree.t0; ...
    result.left.tree.t0, result.rightFromMirroredPotential.tree.r0]);
verifyEqual(testCase, result.deltaSPerMu2, [ ...
    result.left.combined.totalAmplitudesPerMu2(2), ...
    result.rightFromMirroredPotential.combined.totalAmplitudesPerMu2(1); ...
    result.left.combined.totalAmplitudesPerMu2(1), ...
    result.rightFromMirroredPotential.combined.totalAmplitudesPerMu2(2)]);
verifyEqual(testCase, result.deltaS, ...
    cfg.model.mu.^2 .* result.deltaSPerMu2);
verifyTrue(testCase, isfinite(result.offDiagonalClosurePerMu2));
end

function options = low_options()
options = struct('q4Order', 4, 'qPerpOrder', 4, ...
    'collectiveOrder', 4, 'cutRadialOrder', 4, ...
    'cutAngleOrder', 4, 'endpointOrder', 4);
end
