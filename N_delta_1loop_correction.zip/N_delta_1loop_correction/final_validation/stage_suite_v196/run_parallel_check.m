function report = run_parallel_check(cfg)
%RUN_PARALLEL_CHECK Verify pool preparation, worker route and indexed merge.

narginchk(0, 1);
if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end
[parallelPlan, pool] = ndelta.execution.prepare_parallel_execution(cfg);
serialPlan = ndelta.execution.serial_plan(cfg);
serialPlan.showProgress = false;
quietParallelPlan = parallelPlan;
quietParallelPlan.showProgress = false;
evaluator = @(index) ndelta.execution.probe_job(index);
[serialOutputs, serialExecution] = ndelta.execution.map_indexed( ...
    8, evaluator, serialPlan, [], 'serial probe');
if parallelPlan.useParallel
    [candidateOutputs, candidateExecution] = ...
        ndelta.execution.map_indexed(8, evaluator, quietParallelPlan, ...
        pool, 'parallel probe');
else
    candidateOutputs = serialOutputs;
    candidateExecution = serialExecution;
end
serialValues = cellfun(@(item) item.value, serialOutputs);
candidateValues = cellfun(@(item) item.value, candidateOutputs);
indices = cellfun(@(item) item.index, candidateOutputs);
workerFlags = cellfun(@(item) item.onWorker, candidateOutputs);
report = struct();
report.parallelExecution = parallelPlan;
report.serialExecution = serialExecution;
report.candidateExecution = candidateExecution;
report.parallelUsed = parallelPlan.useParallel;
report.valuesExactlyEqual = isequaln(serialValues, candidateValues);
report.canonicalOrderingPreserved = isequal(indices(:).', 1:8);
report.everyCandidateRanOnWorker = ...
    ~parallelPlan.useParallel || all(workerFlags);
report.accepted = report.valuesExactlyEqual && ...
    report.canonicalOrderingPreserved && ...
    report.everyCandidateRanOnWorker;
if report.accepted && report.parallelUsed
    report.status = 'parallel_runtime_and_indexed_merge_accepted';
elseif report.accepted
    report.status = 'serial_backend_accepted_parallel_not_used';
else
    report.status = 'parallel_runtime_probe_rejected';
end
fprintf(['Parallel check: requested=%s, effective=%s, workers=%d, ' ...
    'fallback=%d, ordered=%d, exact=%d, accepted=%d.\n'], ...
    parallelPlan.requestedMode, parallelPlan.effectiveMode, ...
    parallelPlan.workerCount, parallelPlan.fallbackUsed, ...
    report.canonicalOrderingPreserved, report.valuesExactlyEqual, ...
    report.accepted);
end
