function stage9 = run_stage9(cfg, stage2, stage8)
%RUN_STAGE9 Apply LSZ, mu^2 and strict O(mu^2) probability interference.

narginchk(0, 3);
if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end
if nargin < 2
    stage1 = run_stage1(cfg);
    stage2 = run_stage2(cfg, stage1);
end
if nargin < 3
    stage1 = run_stage1(cfg);
    stage7 = run_stage7(cfg, stage1);
    stage8 = run_stage8(cfg, stage1, stage7);
end
validate_stage2(stage2, cfg);
if ~isstruct(stage8) || ~isscalar(stage8) || ...
        ~all(isfield(stage8, {'accepted', 'configurationFingerprint'})) || ...
        ~islogical(stage8.accepted) || ~isscalar(stage8.accepted)
    error('ndelta:stage9:InvalidStage8Result', ...
        'stage8 must be a complete result produced by run_stage8(cfg).');
end
if ~stage8.accepted
    error('ndelta:stage9:Stage8NotAccepted', ...
        'Stage 9 requires an accepted Stage 8 integration result.');
end
ndelta.config.assert_physics_fingerprint( ...
    stage8.configurationFingerprint, cfg, ...
    'ndelta:stage9:Stage8ConfigurationMismatch');
stage9 = ndelta.amplitude.assemble_g1(cfg, stage2.tree, stage8);
stage9.accepted = all(isfinite(real(stage9.deltaAmplitudes))) && ...
    all(isfinite(imag(stage9.deltaAmplitudes))) && ...
    all(isfinite(stage9.deltaProbabilities));
stage9.validation = ndelta.amplitude.validate_contract( ...
    cfg, stage2.tree, stage8, stage9);
stage9.accepted = stage9.accepted && stage9.validation.accepted;
if cfg.execution.failOnBenchmarkFailure && ~stage9.accepted
    error('ndelta:stage9:AmplitudeAssemblyRejected', ...
        'The Stage 9 amplitude/probability assembly is non-finite.');
end

function validate_stage2(stage2, cfg)
if ~isstruct(stage2) || ~isscalar(stage2) || ...
        ~isfield(stage2, 'tree') || ...
        ~isstruct(stage2.tree) || ~isscalar(stage2.tree)
    error('ndelta:stage9:Stage2ConfigurationMismatch', ...
        'stage2 must be a complete result produced from the same cfg.');
end
required = {'t0', 'r0', 'T0', 'R0'};
if ~all(isfield(stage2.tree, required))
    error('ndelta:stage9:Stage2ConfigurationMismatch', ...
        'stage2.tree is incomplete.');
end
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
expected = ndelta.tree.tree_amplitudes_N( ...
    cfg.derived.P, geometry, cfg.barriers.strengths, ...
    cfg.tolerances.nearSingularRcond);
errorValue = max(abs([stage2.tree.t0 - expected.t0, ...
    stage2.tree.r0 - expected.r0, stage2.tree.T0 - expected.T0, ...
    stage2.tree.R0 - expected.R0]) ./ ...
    (1 + abs([expected.t0, expected.r0, expected.T0, expected.R0])));
if ~isfinite(errorValue) || errorValue > cfg.tolerances.matrix
    error('ndelta:stage9:Stage2ConfigurationMismatch', ...
        'stage2.tree does not belong to cfg.');
end
end
end
