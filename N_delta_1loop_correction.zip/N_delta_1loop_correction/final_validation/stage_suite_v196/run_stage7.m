function stage7 = run_stage7(cfg, stage1)
%RUN_STAGE7 Collective spectrum and fixed-qPerp modified Wick ledger.

narginchk(0, 2);
if nargin < 1
    cfg = run_stage0(false);
else
    cfg = ndelta.config.finalize_configuration(cfg);
end
if nargin < 2
    stage1 = run_stage1(cfg);
end
validate_stage1(stage1, cfg);
geometry = stage1.geometry;
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
if cfg.execution.failOnBenchmarkFailure && ~spectrum.accepted
    error('ndelta:stage7:CollectiveSpectrumRejected', ...
        ['The collective spectrum contains an unstable mode, a root ' ...
         'residual failure, a nonsemisimple/zero-energy root, or the ' ...
         'energy has reached an unimplemented Phi+bound-mode channel.']);
end
qPerp = cfg.g1.referenceQPerp;
ledger = ndelta.singularity.g1_ledger(qPerp, cfg, geometry, spectrum);
transmission = ndelta.contour.fixed_qperp_g1( ...
    qPerp, 'T', cfg, geometry, spectrum);
reflection = ndelta.contour.fixed_qperp_g1( ...
    qPerp, 'R', cfg, geometry, spectrum);

closure = max([transmission.fourPieceClosureResidual, ...
    transmission.cutClosureResidual, ...
    reflection.fourPieceClosureResidual, ...
    reflection.cutClosureResidual]);
stage7 = struct();
stage7.qPerp = qPerp;
stage7.spectrum = spectrum;
stage7.ledger = ledger;
stage7.transmission = transmission;
stage7.reflection = reflection;
stage7.maximumClosureResidual = closure;
stage7.accepted = spectrum.accepted && ...
    closure <= cfg.tolerances.contourClosure;
stage7.numberOfCollectiveModes = spectrum.numberOfModes;
stage7.numberOfStableCollectiveModes = spectrum.numberOfStableModes;
stage7.findsModesOnceInKPlane = true;
stage7.performsFixedQPerpQ0Contour = true;
stage7.performsQPerpIntegration = false;
stage7.includesMuSquared = false;
stage7.includesLSZ = false;
stage7.endpointRule = ...
    'square_root_keyhole_has_full_q0_winding_plus_iR';
stage7.nextStage = 'Stage 8: qPerp integration of every source';
stage7.validation = ndelta.singularity.validate_contract( ...
    cfg, geometry, spectrum, stage7);
stage7.accepted = stage7.accepted && stage7.validation.accepted;
if cfg.execution.failOnBenchmarkFailure && ~stage7.accepted
    error('ndelta:stage7:ContourLedgerRejected', ...
        'The fixed-qPerp singularity/contour ledger failed closure.');
end

function validate_stage1(stage1, cfg)
if ~isstruct(stage1) || ~isscalar(stage1) || ...
        ~all(isfield(stage1, {'geometry', 'kinematics'})) || ...
        ~isstruct(stage1.kinematics) || ...
        ~isscalar(stage1.kinematics) || ...
        ~isfield(stage1.kinematics, 'P')
    error('ndelta:stage7:Stage1ConfigurationMismatch', ...
        'stage1 must be a complete result produced from the same cfg.');
end
ndelta.g1.resolve_pair_geometry(cfg, stage1.geometry);
scale = max(1, abs(cfg.derived.P));
if ~isnumeric(stage1.kinematics.P) || ...
        ~isscalar(stage1.kinematics.P) || ...
        ~isreal(stage1.kinematics.P) || ...
        ~isfinite(stage1.kinematics.P) || ...
        abs(stage1.kinematics.P - cfg.derived.P) > 64 .* eps(scale)
    error('ndelta:stage7:Stage1ConfigurationMismatch', ...
        'stage1 kinematics do not belong to cfg.');
end
end
end
