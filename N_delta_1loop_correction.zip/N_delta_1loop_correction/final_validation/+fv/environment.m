function info = environment(config, preflight)
%ENVIRONMENT Collect reproducibility metadata without changing state.

info = struct();
info.generatedAt = datestr(now, 30);
info.matlabVersion = version;
info.matlabRelease = version('-release');
info.computer = computer;
info.architecture = computer('arch');
info.solverRoot = config.solverRoot;
info.engineRoot = config.engineRoot;
info.currentDirectory = pwd;
info.pathResolution = preflight;
if isfield(preflight, 'hardeningContractPresent')
    info.hardeningContractPresent = preflight.hardeningContractPresent;
else
    info.hardeningContractPresent = false;
end
if isfield(preflight, 'hardeningAccepted')
    info.hardeningAccepted = preflight.hardeningAccepted;
else
    info.hardeningAccepted = false;
end
try
    info.javaVersion = char(java.lang.System.getProperty('java.version'));
catch
    info.javaVersion = 'unavailable';
end
end
