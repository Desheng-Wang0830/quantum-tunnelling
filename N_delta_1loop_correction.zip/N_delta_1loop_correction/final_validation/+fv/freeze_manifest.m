function manifest = freeze_manifest(rootDirectory, excludedDirectory)
%FREEZE_MANIFEST SHA-256 manifest of solver, adapter, tests and documents.

narginchk(2, 2);
rootDirectory = absolute_path(rootDirectory);
excludedDirectory = absolute_path(excludedDirectory);
% The report directory may be a child of the solver root (the default) or
% live completely outside it.  It must never equal or contain the solver
% root: that would exclude every source file and allow an empty manifest to
% compare equal before and after the run.
if is_under(rootDirectory, excludedDirectory)
    error('finalval:UnsafeManifestExclusion', ...
        ['The output directory must not equal or contain the frozen ' ...
         'solver root.  Choose a child of the solver root or an ' ...
         'unrelated external directory.']);
end
files = recursive_files(rootDirectory);
baselineManifest = fullfile(rootDirectory, 'final_validation', ...
    'FROZEN_SOURCE_MANIFEST.json');
keep = false(size(files));
for index = 1:numel(files)
    path = files{index};
    [~, ~, extension] = fileparts(path);
    supported = any(strcmpi(extension, ...
        {'.m', '.p', '.md', '.txt', '.json'})) || ...
        ~isempty(regexp(extension, '^\.mex', 'once'));
    % The signed baseline cannot hash itself.  Every other supported file,
    % including this exclusion rule, remains inside the aggregate digest.
    isBaselineManifest = same_path(path, baselineManifest);
    keep(index) = supported && ~is_under(path, excludedDirectory) && ...
        ~isBaselineManifest;
end
files = sort(files(keep));
entries = repmat(struct('relativePath', '', 'sha256', ''), ...
    numel(files), 1);
aggregateText = '';
for index = 1:numel(files)
    relative = files{index}(numel(rootDirectory) + 2:end);
    relative = strrep(relative, '\', '/');
    digest = sha256_file(files{index});
    entries(index).relativePath = relative;
    entries(index).sha256 = digest;
    aggregateText = [aggregateText, relative, '  ', digest, char(10)]; %#ok<AGROW>
end
manifest = struct('rootDirectory', rootDirectory, ...
    'excludedDirectory', excludedDirectory, ...
    'baselineManifestExcluded', baselineManifest, ...
    'algorithm', 'SHA-256', 'numberOfFiles', numel(entries), ...
    'aggregateSha256', sha256_bytes( ...
    unicode2native(aggregateText, 'UTF-8')), 'entries', entries);
end

function accepted = same_path(left, right)
if ispc
    accepted = strcmpi(strrep(left, '\', '/'), strrep(right, '\', '/'));
else
    accepted = strcmp(strrep(left, '\', '/'), strrep(right, '\', '/'));
end
end

function files = recursive_files(directory)
listing = dir(directory);
files = cell(0, 1);
for index = 1:numel(listing)
    name = listing(index).name;
    if strcmp(name, '.') || strcmp(name, '..')
        continue;
    end
    path = fullfile(directory, name);
    if listing(index).isdir
        children = recursive_files(path);
        files = [files; children]; %#ok<AGROW>
    else
        files{end + 1, 1} = path; %#ok<AGROW>
    end
end
end

function value = sha256_file(path)
fileId = fopen(path, 'rb');
if fileId < 0
    error('finalval:ManifestReadFailure', 'Cannot read %s.', path);
end
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
bytes = fread(fileId, Inf, '*uint8');
value = sha256_bytes(bytes);
end

function value = sha256_bytes(bytes)
digest = java.security.MessageDigest.getInstance('SHA-256');
digest.update(typecast(uint8(bytes(:)), 'int8'));
raw = typecast(digest.digest(), 'uint8');
value = lower(reshape(dec2hex(raw, 2).', 1, []));
end

function value = absolute_path(path)
file = java.io.File(path);
value = char(file.getCanonicalPath());
end

function accepted = is_under(path, parent)
if ispc
    path = lower(strrep(path, '\', '/'));
    parent = lower(strrep(parent, '\', '/'));
else
    path = strrep(path, '\', '/');
    parent = strrep(parent, '\', '/');
end
accepted = strcmp(path, parent) || ...
    strncmp(path, [parent, '/'], numel(parent) + 1);
end
