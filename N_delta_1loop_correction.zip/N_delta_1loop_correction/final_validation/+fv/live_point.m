function point = live_point(spec, orderFactor)
%LIVE_POINT Recompute and cache one full G1--G4 point in this MATLAB run.
%
% No historical MAT file is read.  The cache only avoids repeating an
% identical live calculation within one invocation of run_final_validation.

% A zero-argument call is the runner's explicit per-invocation reset.  It
% avoids reusing a persistent value if the public runner is invoked twice in
% the same MATLAB session without `clear functions` in between.
persistent keys values
if nargin == 0
    keys = cell(0, 1);
    values = cell(0, 1);
    point = [];
    return;
end
narginchk(2, 2);
validateattributes(orderFactor, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'orderFactor');
key = case_key(spec, orderFactor);
if isempty(keys)
    keys = cell(0, 1);
    values = cell(0, 1);
end
index = find(strcmp(keys, key), 1);
if ~isempty(index)
    point = values{index};
    return;
end

cfg = fv.make_cfg(spec);
options = nqscan.resolve_options(cfg, orderFactor);
point = ndelta.stage12.evaluate_direction(cfg, options);
if ~point.accepted
    error('finalval:LivePointRejected', ...
        'Live point %s was rejected: %s (%s).', ...
        case_name(spec), point.status, point.rejectionIdentifier);
end
keys{end + 1, 1} = key;
values{end + 1, 1} = point;
end

function key = case_key(spec, factor)
% NAME is reporting metadata, not a physics input.  Excluding it allows
% R05/R07 and other requirements to share an identical calculation made
% earlier in this same MATLAB process without ever loading a saved result.
key = sprintf(['m=%.17g|M=%.17g|mu=%.17g|E=%.17g|' ...
    'z=%s|g=%s|f=%.17g'], spec.mphi, spec.mPhi, ...
    spec.mu, spec.energy, mat2str(spec.positions, 17), ...
    mat2str(spec.strengths, 17), factor);
end

function value = case_name(spec)
if isfield(spec, 'name')
    value = spec.name;
else
    value = 'unnamed_case';
end
end
