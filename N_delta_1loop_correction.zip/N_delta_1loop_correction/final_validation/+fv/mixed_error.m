function value = mixed_error( ...
        left, right, absoluteTolerance, relativeTolerance)
%MIXED_ERROR Scale-floored relative error for an abs-or-rel gate.
%
% VALUE <= RELATIVETOLERANCE is exactly equivalent elementwise to
%
%   abs(left-right) <= max(absoluteTolerance, ...
%       relativeTolerance*max(abs(left),abs(right))).
%
% Thus a near-zero component receives the stated absolute tolerance once,
% rather than the accidental product of the absolute and relative gates.

narginchk(4, 4);
validateattributes(absoluteTolerance, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'absoluteTolerance');
validateattributes(relativeTolerance, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'relativeTolerance');
denominator = max(absoluteTolerance ./ relativeTolerance, ...
    max(abs(left), abs(right)));
entries = abs(left - right) ./ denominator;
value = max(entries(:));
end
