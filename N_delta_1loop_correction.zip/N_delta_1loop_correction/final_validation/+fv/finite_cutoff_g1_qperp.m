function result = finite_cutoff_g1_qperp( ...
        cfg, geometry, spectrum, channelInput, segmentEdges, order, ...
        innerOptions)
%FINITE_CUTOFF_G1_QPERP Independent finite-qPerp comparator for G1 Wick.
%
% The outer transverse integral is evaluated directly on finite qPerp
% segments with Gauss--Legendre quadrature.  It deliberately does not call
% integrate_euclidean or positive_infinite_map.  The inner q4 integral is
% the production mapped implementation, euclidean_fixed, so this function
% isolates the outer mapped-infinite transformation while retaining the
% same physical-sheet and tau-solve prescription in both routes.

narginchk(7, 7);
channel = ndelta.g1.normalise_channel(channelInput);
if ~isnumeric(segmentEdges) || ~isreal(segmentEdges) || ...
        numel(segmentEdges) < 2 || segmentEdges(1) ~= 0 || ...
        any(~isfinite(segmentEdges)) || any(diff(segmentEdges) <= 0)
    error('finalval:InvalidQPerpCutoffSegments', ...
        ['segmentEdges must be finite, strictly increasing, contain at ' ...
         'least two entries and start at zero.']);
end
validateattributes(order, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'order');
if ~isstruct(innerOptions) || ~isscalar(innerOptions)
    error('finalval:InvalidQ4MappingOptions', ...
        'innerOptions must be a scalar structure.');
end
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~isfield(spectrum, 'modes')
    error('finalval:InvalidCollectiveSpectrum', ...
        'spectrum must contain the collective-mode records.');
end

% Match every finite topology breakpoint used by integrate_euclidean.
% Inserting a breakpoint changes only the quadrature partition, not the
% finite domain or the mathematical comparator.
cutoff = segmentEdges(end);
topologyBreaks = cfg.derived.P;
for modeIndex = 1:numel(spectrum.modes)
    mode = spectrum.modes(modeIndex);
    if mode.stable && mode.qPerpCritical > 0
        topologyBreaks(end + 1) = mode.qPerpCritical; %#ok<AGROW>
    end
end
topologyBreaks = topologyBreaks(isfinite(topologyBreaks) & ...
    topologyBreaks > 0 & topologyBreaks < cutoff);
effectiveEdges = unique(sort([segmentEdges(:); topologyBreaks(:)])).';

[nodes, weights] = ndelta.numerics.gauss_legendre_rule(order);
segmentValues = complex(zeros(1, numel(effectiveEdges) - 1));
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
numberOfFixedEvaluations = 0;
for segment = 1:(numel(effectiveEdges) - 1)
    lower = effectiveEdges(segment);
    upper = effectiveEdges(segment + 1);
    midpoint = 0.5 .* (lower + upper);
    halfWidth = 0.5 .* (upper - lower);
    qNodes = midpoint + halfWidth .* nodes;
    qWeights = halfWidth .* weights;
    contribution = complex(0);
    for index = 1:numel(qNodes)
        fixed = ndelta.contour.euclidean_fixed( ...
            qNodes(index), channel, cfg, geometry, innerOptions);
        contribution = contribution + qWeights(index) .* qNodes(index) ...
            .* fixed.value ./ (2 .* pi);
        maximumTauResidual = max(maximumTauResidual, ...
            fixed.maximumTauEquationResidual);
        minimumTauScaledRcond = min(minimumTauScaledRcond, ...
            fixed.minimumTauScaledRcond);
        maximumTauConditionAmplification = max( ...
            maximumTauConditionAmplification, ...
            fixed.maximumTauConditionAmplification);
        numberOfFixedEvaluations = numberOfFixedEvaluations + 1;
    end
    segmentValues(segment) = contribution;
end

result = struct();
result.value = complex(real(sum(segmentValues)), ...
    imag(sum(segmentValues)));
result.channel = channel;
result.requestedSegmentEdges = reshape(segmentEdges, 1, []);
result.segmentEdges = effectiveEdges;
result.segmentValues = segmentValues;
result.topologyBreakpointsInserted = topologyBreaks;
result.cutoff = cutoff;
result.orderPerSegment = order;
result.innerOptions = innerOptions;
result.numberOfFixedQPerpEvaluations = numberOfFixedEvaluations;
result.maximumTauEquationResidual = maximumTauResidual;
result.minimumTauScaledRcond = minimumTauScaledRcond;
result.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
result.includesQ0Measure = true;
result.includesQPerpMeasure = true;
result.outerMappingUsed = false;
result.innerQ4MappingUsed = true;
result.status = 'independent_finite_cutoff_G1_qperp_integral';
end
