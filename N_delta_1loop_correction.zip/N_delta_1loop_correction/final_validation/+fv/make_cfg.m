function cfg = make_cfg(spec)
%MAKE_CFG Build a non-writing serial configuration for one live case.

required = {'mphi', 'mPhi', 'mu', 'energy', 'positions', 'strengths'};
if ~isstruct(spec) || ~isscalar(spec) || ~all(isfield(spec, required))
    error('finalval:InvalidCase', ...
        'A case must define mphi, mPhi, mu, energy, positions and strengths.');
end

cfg = run_stage0(false);
cfg.model.mphi = spec.mphi;
cfg.model.mPhi = spec.mPhi;
cfg.model.mu = spec.mu;
cfg.referenceEnergy = spec.energy;
cfg.barriers.positions = spec.positions;
cfg.barriers.strengths = spec.strengths;

% finalize_configuration validates the internal Stage-12 placeholder even
% though the final tests call only leaf evaluators.
cfg.stage12.energyValues = cfg.model.mphi + cfg.model.mPhi .* ...
    [0.2, 0.5, 0.8];
cfg.output.saveMatFile = false;
cfg.output.writeTextReport = false;
cfg.output.writeStage4Figure = false;
cfg.output.writeStage9Figure = false;
cfg.output.writeStage10Figure = false;
cfg.output.writeStage12Figure = false;
cfg.execution.parallel.mode = 'serial';
cfg.execution.parallel.showProgress = false;
cfg.execution.failOnBenchmarkFailure = false;
cfg = ndelta.config.finalize_configuration(cfg);
end
