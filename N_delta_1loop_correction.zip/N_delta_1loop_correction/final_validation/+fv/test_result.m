function result = test_result(id, requirement, metrics, details, raw)
%TEST_RESULT Assemble one mandatory-test result.

if nargin < 5
    raw = struct();
end
if isempty(metrics)
    passed = false;
else
    passed = all([metrics.passed]);
end
if passed
    status = 'PASS';
else
    status = 'FAIL';
end
ratios = zeros(1, numel(metrics));
for index = 1:numel(metrics)
    if metrics(index).tolerance > 0
        ratios(index) = metrics(index).value ./ metrics(index).tolerance;
    elseif metrics(index).passed
        ratios(index) = 0;
    else
        ratios(index) = Inf;
    end
end
result = struct('id', id, 'requirement', requirement, ...
    'mandatory', true, 'status', status, 'passed', passed, ...
    'worstNormalisedMetric', max(ratios), 'metrics', metrics, ...
    'details', details, 'durationSeconds', NaN, ...
    'errorIdentifier', '', 'errorMessage', '', 'raw', raw);
end
