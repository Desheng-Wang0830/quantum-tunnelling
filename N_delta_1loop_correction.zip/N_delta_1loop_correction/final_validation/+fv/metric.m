function item = metric(name, value, tolerance, passed, note)
%METRIC Construct one serialisable validation metric.

if nargin < 5
    note = '';
end
item = struct('name', name, 'value', double(value), ...
    'tolerance', double(tolerance), 'passed', logical(passed), ...
    'note', note);
end
