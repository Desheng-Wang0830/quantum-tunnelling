function result = finite_cutoff_g1_fixed( ...
        cfg, geometry, qPerp, channelInput, segmentEdges, order)
%FINITE_CUTOFF_G1_FIXED Independent finite-q4 comparator for G1 Wick axis.
%
% This deliberately does not call positive_infinite_map or
% ndelta.contour.euclidean_fixed.  It evaluates the same public physical
% roots and pointwise G1 contraction on finite positive-q4 segments and
% adds both imaginary half-axes explicitly.

narginchk(6, 6);
channel = ndelta.g1.normalise_channel(channelInput);
validateattributes(qPerp, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, mfilename, 'qPerp');
if ~isnumeric(segmentEdges) || ~isreal(segmentEdges) || ...
        numel(segmentEdges) < 2 || segmentEdges(1) ~= 0 || ...
        any(~isfinite(segmentEdges)) || any(diff(segmentEdges) <= 0)
    error('finalval:InvalidCutoffSegments', ...
        'segmentEdges must be finite, strictly increasing and start at zero.');
end
validateattributes(order, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'order');

[nodes, weights] = ndelta.numerics.gauss_legendre_rule(order);
segmentValues = complex(zeros(1, numel(segmentEdges) - 1));
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
for segment = 1:(numel(segmentEdges) - 1)
    lower = segmentEdges(segment);
    upper = segmentEdges(segment + 1);
    midpoint = 0.5 .* (lower + upper);
    halfWidth = 0.5 .* (upper - lower);
    qNodes = midpoint + halfWidth .* nodes;
    qWeights = halfWidth .* weights;
    contribution = complex(0);
    for index = 1:numel(qNodes)
        q4 = qNodes(index);
        [positive, positiveDiagnostics] = evaluate_one(+q4);
        [negative, negativeDiagnostics] = evaluate_one(-q4);
        contribution = contribution + qWeights(index) .* ...
            (positive + negative);
        maximumTauResidual = max([maximumTauResidual, ...
            positiveDiagnostics.normalisedEquationResidual, ...
            negativeDiagnostics.normalisedEquationResidual]);
        minimumTauScaledRcond = min([minimumTauScaledRcond, ...
            positiveDiagnostics.scaledRcond, ...
            negativeDiagnostics.scaledRcond]);
        maximumTauConditionAmplification = max([ ...
            maximumTauConditionAmplification, ...
            positiveDiagnostics.conditionAmplification, ...
            negativeDiagnostics.conditionAmplification]);
    end
    segmentValues(segment) = contribution;
end

result = struct();
result.value = 1i .* sum(segmentValues) ./ (2 .* pi);
result.beforeQ0Measure = sum(segmentValues);
result.segmentEdges = segmentEdges;
result.segmentValuesBeforeMeasure = segmentValues;
result.cutoff = segmentEdges(end);
result.orderPerSegment = order;
result.channel = channel;
result.qPerp = qPerp;
result.maximumTauEquationResidual = maximumTauResidual;
result.minimumTauScaledRcond = minimumTauScaledRcond;
result.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
result.mappingUsed = false;
result.status = 'independent_finite_cutoff_G1_Wick_axis';

    function [value, tauDiagnostics] = evaluate_one(q4)
        roots = ndelta.sheet.physical_roots(1i .* q4, qPerp, ...
            cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
        [raw, details] = ...
            ndelta.g1.contour_pair_contraction_from_roots( ...
            roots.omega, roots.kappaI, cfg.derived.P, channel, ...
            geometry, cfg.barriers.strengths, cfg);
        value = -raw;
        tauDiagnostics = details.tauDiagnostics;
    end
end
