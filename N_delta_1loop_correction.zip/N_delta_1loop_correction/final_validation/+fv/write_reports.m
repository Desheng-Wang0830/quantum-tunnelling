function validation = write_reports(validation, outputDirectory)
%WRITE_REPORTS Persist final validation evidence in portable formats.

if exist(outputDirectory, 'dir') ~= 7
    [created, message] = mkdir(outputDirectory);
    if ~created
        error('finalval:OutputDirectoryCreationFailure', ...
            'Cannot create output directory %s: %s', ...
            outputDirectory, message);
    end
end

artifacts = struct();
artifacts.markdownReport = fullfile(outputDirectory, ...
    'FINAL_VALIDATION_REPORT.md');
artifacts.jsonSummary = fullfile(outputDirectory, ...
    'validation_results.json');
artifacts.testsCsv = fullfile(outputDirectory, ...
    'validation_tests.csv');
artifacts.metricsCsv = fullfile(outputDirectory, ...
    'validation_metrics.csv');
artifacts.rawMat = fullfile(outputDirectory, 'validation_raw.mat');
artifacts.manifestBeforeJson = fullfile(outputDirectory, ...
    'freeze_manifest_before.json');
artifacts.manifestAfterJson = fullfile(outputDirectory, ...
    'freeze_manifest_after.json');
artifacts.environmentJson = fullfile(outputDirectory, 'environment.json');
artifacts.completionMarker = fullfile(outputDirectory, ...
    'VALIDATION_COMPLETE.json');
validation.artifacts = artifacts;
validation.evidenceCommitContract = ...
    'completion_marker_written_only_after_JSON_CSV_MAT_readback';

% A stale marker from an earlier run must never certify a partial rewrite.
if exist(artifacts.completionMarker, 'file') == 2
    delete(artifacts.completionMarker);
end

write_text(artifacts.markdownReport, markdown_report(validation));
write_json(artifacts.jsonSummary, portable_summary(validation));
write_text(artifacts.testsCsv, tests_csv(validation.results));
write_text(artifacts.metricsCsv, metrics_csv(validation.results));
write_json(artifacts.manifestBeforeJson, validation.manifestBefore);
write_json(artifacts.manifestAfterJson, validation.manifestAfter);
write_json(artifacts.environmentJson, validation.environment);

% Write MAT last: it records all artifact paths and includes detailed raw
% numerical payloads, while JSON intentionally excludes them.
save(artifacts.rawMat, 'validation', '-v7.3');

verification = verify_artifacts(artifacts, validation);
marker = struct('schemaVersion', 'final-validation-completion-1.0', ...
    'verifiedAt', datestr(now, 30), ...
    'validationStartedAt', validation.startedAt, ...
    'validationCompletedAt', validation.completedAt, ...
    'overallStatus', validation.overallStatus, ...
    'numberOfTests', numel(validation.results), ...
    'readbackAccepted', verification.accepted, ...
    'verifiedArtifacts', {verification.verifiedArtifacts});
write_completion_marker(artifacts.completionMarker, marker, validation);
end

function write_completion_marker(path, marker, validation)
% Commit the marker by rename only after a complete JSON file exists.
temporaryPath = tempname(fileparts(path));
temporaryCleanup = onCleanup(@() delete_if_present(temporaryPath)); %#ok<NASGU>
write_json(temporaryPath, marker);
[moved, message] = movefile(temporaryPath, path, 'f');
if ~moved
    error('finalval:CompletionMarkerCommitFailure', ...
        'Cannot commit completion marker %s: %s', path, message);
end
try
    decoded = jsondecode(fileread(path));
    accepted = isstruct(decoded) && isscalar(decoded) && ...
        isfield(decoded, 'schemaVersion') && ...
        strcmp(decoded.schemaVersion, 'final-validation-completion-1.0') && ...
        isfield(decoded, 'readbackAccepted') && ...
        isequal(decoded.readbackAccepted, true) && ...
        isfield(decoded, 'overallStatus') && ...
        strcmp(decoded.overallStatus, validation.overallStatus) && ...
        isfield(decoded, 'numberOfTests') && ...
        isequal(decoded.numberOfTests, numel(validation.results));
    if ~accepted
        error('finalval:CompletionMarkerReadbackFailure', ...
            'Completion marker schema/readback mismatch.');
    end
catch cause
    delete_if_present(path);
    rethrow(cause);
end
end

function delete_if_present(path)
if exist(path, 'file') == 2
    delete(path);
end
end

function verification = verify_artifacts(artifacts, validation)
paths = {artifacts.markdownReport, artifacts.jsonSummary, ...
    artifacts.testsCsv, artifacts.metricsCsv, artifacts.rawMat, ...
    artifacts.manifestBeforeJson, artifacts.manifestAfterJson, ...
    artifacts.environmentJson};
for index = 1:numel(paths)
    info = dir(paths{index});
    if isempty(info) || info(1).bytes == 0
        error('finalval:ArtifactReadbackFailure', ...
            'Evidence artifact is missing or empty: %s', paths{index});
    end
end

summary = jsondecode(fileread(artifacts.jsonSummary));
before = jsondecode(fileread(artifacts.manifestBeforeJson));
after = jsondecode(fileread(artifacts.manifestAfterJson));
environment = jsondecode(fileread(artifacts.environmentJson)); %#ok<NASGU>
loaded = load(artifacts.rawMat, 'validation');
requiredSummary = {'schemaVersion', 'overallStatus', 'counts', 'tests'};
summaryAccepted = isstruct(summary) && isscalar(summary) && ...
    all(isfield(summary, requiredSummary)) && ...
    numel(summary.tests) == numel(validation.results) && ...
    strcmp(summary.overallStatus, validation.overallStatus);
manifestAccepted = isstruct(before) && isstruct(after) && ...
    isfield(before, 'aggregateSha256') && ...
    isfield(after, 'aggregateSha256');
matAccepted = isfield(loaded, 'validation') && ...
    isstruct(loaded.validation) && isscalar(loaded.validation) && ...
    numel(loaded.validation.results) == numel(validation.results) && ...
    strcmp(loaded.validation.overallStatus, validation.overallStatus);
testsText = fileread(artifacts.testsCsv);
metricsText = fileread(artifacts.metricsCsv);
testsHeader = 'id,mandatory,status';
metricsHeader = 'test_id,test_status,metric';
csvAccepted = strncmp(testsText, testsHeader, numel(testsHeader)) && ...
    strncmp(metricsText, metricsHeader, numel(metricsHeader));
accepted = summaryAccepted && manifestAccepted && matAccepted && ...
    csvAccepted;
if ~accepted
    error('finalval:ArtifactReadbackFailure', ...
        ['JSON, CSV or MAT evidence failed schema/readback validation.  ' ...
        'No completion marker was written.']);
end
verification = struct('accepted', true, ...
    'verifiedArtifacts', {paths});
end

function summary = portable_summary(validation)
summary = struct();
summary.schemaVersion = validation.schemaVersion;
summary.generatedFresh = validation.generatedFresh;
summary.startedAt = validation.startedAt;
summary.completedAt = validation.completedAt;
summary.durationSeconds = finite_value(validation.durationSeconds);
summary.overallStatus = validation.overallStatus;
summary.passed = validation.passed;
summary.strictPerturbativeOrder = validation.strictPerturbativeOrder;
summary.outputDirectory = validation.outputDirectory;
summary.counts = validation.counts;
summary.preflightAccepted = isfield(validation.preflight, 'accepted') && ...
    validation.preflight.accepted;
summary.hardeningContractPresent = ...
    preflight_flag(validation.preflight, 'hardeningContractPresent');
summary.hardeningAccepted = ...
    preflight_flag(validation.preflight, 'hardeningAccepted');
summary.sourceAggregateBefore = manifest_hash(validation.manifestBefore);
summary.sourceAggregateAfter = manifest_hash(validation.manifestAfter);
summary.tests = portable_tests(validation.results);
summary.artifacts = validation.artifacts;
end

function tests = portable_tests(results)
prototype = struct('id', '', 'requirement', '', 'mandatory', true, ...
    'status', '', 'passed', false, 'durationSeconds', 0, ...
    'worstNormalisedMetric', 0, 'details', '', ...
    'errorIdentifier', '', 'errorMessage', '', ...
    'metrics', struct([]));
tests = repmat(prototype, size(results));
for index = 1:numel(results)
    result = results(index);
    tests(index).id = result.id;
    tests(index).requirement = result.requirement;
    tests(index).mandatory = result.mandatory;
    tests(index).status = result.status;
    tests(index).passed = result.passed;
    tests(index).durationSeconds = finite_value(result.durationSeconds);
    tests(index).worstNormalisedMetric = ...
        finite_value(result.worstNormalisedMetric);
    tests(index).details = result.details;
    tests(index).errorIdentifier = result.errorIdentifier;
    tests(index).errorMessage = result.errorMessage;
    tests(index).metrics = portable_metrics(result.metrics);
end
end

function metrics = portable_metrics(inputMetrics)
prototype = struct('name', '', 'value', 0, 'tolerance', 0, ...
    'passed', false, 'note', '');
metrics = repmat(prototype, size(inputMetrics));
for index = 1:numel(inputMetrics)
    metrics(index).name = inputMetrics(index).name;
    metrics(index).value = finite_value(inputMetrics(index).value);
    metrics(index).tolerance = finite_value(inputMetrics(index).tolerance);
    metrics(index).passed = inputMetrics(index).passed;
    metrics(index).note = inputMetrics(index).note;
end
end

function value = finite_value(value)
if isnumeric(value) && isscalar(value) && ~isfinite(value)
    if isnan(value)
        value = 'NaN';
    elseif value > 0
        value = 'Inf';
    else
        value = '-Inf';
    end
end
end

function value = manifest_hash(manifest)
if isfield(manifest, 'aggregateSha256')
    value = manifest.aggregateSha256;
else
    value = '';
end
end

function text = tests_csv(results)
lines = {['id,mandatory,status,passed,duration_seconds,' ...
    'worst_normalised_metric,requirement,details,' ...
    'error_identifier,error_message']};
for index = 1:numel(results)
    result = results(index);
    fields = {result.id, logical_text(result.mandatory), result.status, ...
        logical_text(result.passed), numeric_text(result.durationSeconds), ...
        numeric_text(result.worstNormalisedMetric), result.requirement, ...
        result.details, result.errorIdentifier, result.errorMessage};
    lines{end + 1} = csv_row(fields); %#ok<AGROW>
end
text = join_lines(lines);
end

function text = metrics_csv(results)
lines = {'test_id,test_status,metric,value,tolerance,passed,note'};
for resultIndex = 1:numel(results)
    result = results(resultIndex);
    for metricIndex = 1:numel(result.metrics)
        metric = result.metrics(metricIndex);
        fields = {result.id, result.status, metric.name, ...
            numeric_text(metric.value), numeric_text(metric.tolerance), ...
            logical_text(metric.passed), metric.note};
        lines{end + 1} = csv_row(fields); %#ok<AGROW>
    end
end
text = join_lines(lines);
end

function text = markdown_report(validation)
lines = { ...
    '# Final frozen-code validation report', '', ...
    ['- Overall status: **', validation.overallStatus, '**'], ...
    ['- Generated fresh: **', logical_text(validation.generatedFresh), '**'], ...
    ['- Started (MATLAB `datestr(now,30)`): `', validation.startedAt, '`'], ...
    ['- Completed: `', validation.completedAt, '`'], ...
    ['- Duration: ', numeric_text(validation.durationSeconds), ' s'], ...
    ['- MATLAB: `', markdown_escape(validation.environment.matlabVersion), ...
        '` (`', markdown_escape(validation.environment.matlabRelease), '`)'], ...
    ['- Computer: `', markdown_escape(validation.environment.computer), ...
        ' / ', markdown_escape(validation.environment.architecture), '`'], ...
    ['- Strict perturbative scope: `', ...
        markdown_escape(validation.strictPerturbativeOrder), '`'], ...
    ['- Preflight accepted: **', ...
        logical_text(isfield(validation.preflight, 'accepted') && ...
        validation.preflight.accepted), '**'], '', ...
    ['- Validation hardening contract present: **', ...
        logical_text(preflight_flag(validation.preflight, ...
        'hardeningContractPresent')), '**'], ...
    ['- Validation hardening accepted: **', ...
        logical_text(preflight_flag(validation.preflight, ...
        'hardeningAccepted')), '**'], '', ...
    '## Mandatory results', '', ...
    '| ID | Status | Duration (s) | Requirement |', ...
    '|---|---:|---:|---|'};
for index = 1:numel(validation.results)
    result = validation.results(index);
    lines{end + 1} = sprintf('| %s | **%s** | %s | %s |', ... %#ok<AGROW>
        markdown_escape(result.id), markdown_escape(result.status), ...
        numeric_text(result.durationSeconds), ...
        markdown_escape(result.requirement));
end

lines{end + 1} = ''; %#ok<AGROW>
lines{end + 1} = '## Acceptance metrics'; %#ok<AGROW>
lines{end + 1} = ''; %#ok<AGROW>
lines{end + 1} = '| Test | Metric | Value | Tolerance | Pass |'; %#ok<AGROW>
lines{end + 1} = '|---|---|---:|---:|---:|'; %#ok<AGROW>
for resultIndex = 1:numel(validation.results)
    result = validation.results(resultIndex);
    for metricIndex = 1:numel(result.metrics)
        metric = result.metrics(metricIndex);
        lines{end + 1} = sprintf('| %s | %s | %s | %s | %s |', ... %#ok<AGROW>
            markdown_escape(result.id), markdown_escape(metric.name), ...
            numeric_text(metric.value), numeric_text(metric.tolerance), ...
            logical_text(metric.passed));
    end
end

errors = validation.results(~strcmp({validation.results.status}, 'PASS'));
if ~isempty(errors)
    lines{end + 1} = ''; %#ok<AGROW>
    lines{end + 1} = '## Non-PASS details'; %#ok<AGROW>
    lines{end + 1} = ''; %#ok<AGROW>
    for index = 1:numel(errors)
        item = errors(index);
        lines{end + 1} = ['### ', item.id, ': ', item.status]; %#ok<AGROW>
        lines{end + 1} = ''; %#ok<AGROW>
        lines{end + 1} = item.details; %#ok<AGROW>
        if ~isempty(item.errorIdentifier) || ~isempty(item.errorMessage)
            lines{end + 1} = ''; %#ok<AGROW>
            lines{end + 1} = ['- Error identifier: `', ...
                markdown_escape(item.errorIdentifier), '`']; %#ok<AGROW>
            lines{end + 1} = ['- Error message: ', ...
                markdown_escape(item.errorMessage)]; %#ok<AGROW>
        end
        lines{end + 1} = ''; %#ok<AGROW>
    end
end

lines{end + 1} = '## Source freeze'; %#ok<AGROW>
lines{end + 1} = ''; %#ok<AGROW>
lines{end + 1} = ['- Before SHA-256: `', ...
    manifest_hash(validation.manifestBefore), '`']; %#ok<AGROW>
lines{end + 1} = ['- After SHA-256: `', ...
    manifest_hash(validation.manifestAfter), '`']; %#ok<AGROW>
lines{end + 1} = ['- Counts: PASS=', num2str(validation.counts.PASS), ...
    ', FAIL=', num2str(validation.counts.FAIL), ...
    ', INCOMPLETE=', num2str(validation.counts.INCOMPLETE), ...
    ', ERROR=', num2str(validation.counts.ERROR), ...
    ', TOTAL=', num2str(validation.counts.TOTAL)]; %#ok<AGROW>
lines{end + 1} = ''; %#ok<AGROW>
lines{end + 1} = ['This report was generated from fresh computation. ' ...
    'No historical MAT result is used as an acceptance gate.']; %#ok<AGROW>
text = join_lines(lines);
end

function text = csv_row(fields)
encoded = cell(size(fields));
for index = 1:numel(fields)
    value = fields{index};
    if ~ischar(value)
        value = numeric_text(value);
    end
    value = strrep(value, '"', '""');
    value = strrep(value, sprintf('\r'), ' ');
    value = strrep(value, sprintf('\n'), ' ');
    encoded{index} = ['"', value, '"'];
end
text = encoded{1};
for index = 2:numel(encoded)
    text = [text, ',', encoded{index}]; %#ok<AGROW>
end
end

function text = numeric_text(value)
if ischar(value)
    text = value;
elseif islogical(value) && isscalar(value)
    text = logical_text(value);
elseif isnumeric(value) && isscalar(value)
    if isnan(value)
        text = 'NaN';
    elseif isinf(value)
        if value > 0
            text = 'Inf';
        else
            text = '-Inf';
        end
    else
        text = sprintf('%.17g', value);
    end
else
    text = '<non-scalar>';
end
end

function text = logical_text(value)
if value
    text = 'true';
else
    text = 'false';
end
end

function value = preflight_flag(preflight, field)
value = isfield(preflight, field) && ...
    isscalar(preflight.(field)) && logical(preflight.(field));
end

function value = markdown_escape(value)
if isempty(value)
    value = '';
elseif ~ischar(value)
    value = numeric_text(value);
end
value = strrep(value, '|', '\|');
value = strrep(value, sprintf('\r'), ' ');
value = strrep(value, sprintf('\n'), ' ');
end

function text = join_lines(lines)
text = '';
for index = 1:numel(lines)
    text = [text, lines{index}, sprintf('\n')]; %#ok<AGROW>
end
end

function write_json(path, payload)
try
    text = jsonencode(payload);
catch cause
    error('finalval:JsonEncodingFailure', ...
        'Cannot encode %s: %s', path, cause.message);
end
write_text(path, [text, sprintf('\n')]);
end

function write_text(path, text)
fileId = fopen(path, 'w', 'n', 'UTF-8');
if fileId < 0
    error('finalval:ReportWriteFailure', 'Cannot open %s.', path);
end
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
count = fwrite(fileId, unicode2native(text, 'UTF-8'), 'uint8');
if count ~= numel(unicode2native(text, 'UTF-8'))
    error('finalval:ReportWriteFailure', ...
        'Short write while creating %s.', path);
end
end
