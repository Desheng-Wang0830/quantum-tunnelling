function files = make_plots(result, outputDirectory)
%MAKE_PLOTS Draw observables, source decompositions and q^0 singularities.

narginchk(2, 2);
if ~isfield(result.data, 'analyticSourceGroups') || ...
        ~isfield(result.data, 'singularity') || ...
        ~isfield(result.data.singularity, 'qPerpBranchPoints')
    result = nqscan.prepare_postprocessing(result);
end
data = result.data;
settings = result.settings;
files = struct();
energy = data.externalEnergy(:);
acceptedMask = logical(data.accepted(:));
diagnosticMask = logical(data.numericalAccepted(:)) & ~acceptedMask & ...
    data.perturbativeInterpretationAccepted(:) == 0;
validate_masks(energy, acceptedMask, diagnosticMask);

fig = figure('Visible', settings.output.figureVisible, 'Color', 'w', ...
    'Position', [80, 80, 1120, 820]);
for channelIndex = 1:2
    axesHandle = subplot(2, 1, channelIndex);
    matrix = reshape(data.termDeltaProbabilities(:, :, channelIndex), ...
        numel(energy), 4);
    total = data.totalDeltaProbabilities(:, channelIndex);
    draw_term_lines(axesHandle, energy, matrix, total, data.termNames, ...
        acceptedMask, diagnosticMask);
    if channelIndex == 1
        ylabel(axesHandle, '\Delta T_{left}');
        title(axesHandle, sprintf( ...
            ['G_1--G_4 left-incidence transmission corrections ' ...
             'versus E=p^0, N=%d'], data.N), ...
            'FontWeight', 'normal');
    else
        ylabel(axesHandle, '\Delta R_{left}');
        title(axesHandle, ...
            'Left-incidence reflection corrections versus E=p^0', ...
            'FontWeight', 'normal');
    end
    xlabel(axesHandle, 'External energy E = p^0');
end
files.termProbabilities = save_figure(fig, outputDirectory, ...
    'G1_G4_delta_probability_vs_energy', settings.output);

% The complete channel-space audit is available only when paired mode has
% retained both incidence directions.  Production-mode results return empty
% paths rather than fabricating the missing off-diagonal residual V_12.
files.uvResiduals = nqscan.make_uv_plot(result, outputDirectory);

% Plot fixed G_j terms with the four analytic contour sources as the
% curves.  This is deliberately different from plotting G1--G4 as curves.
files.analyticSources = nqscan.make_source_plots( ...
    result, outputDirectory);

% The old v1.0 figure at this position showed integrated reduced kernels.
% The replacement figures show the actual internal-q^0 branch cuts,
% branch points, fixed-qPerp coordinate curves and selected-E qPerp loci.
files.singularities = nqscan.make_singularity_plots( ...
    result, outputDirectory);

collectiveIndex = find(strcmp(data.sourceNames, 'collectivePole'), 1);
poleData = data.sourceDeltaProbabilities(:, :, :, collectiveIndex);
fig = figure('Visible', settings.output.figureVisible, 'Color', 'w', ...
    'Position', [40, 40, 1320, 1220]);
maximumModes = size(data.modeDeltaProbabilities, 4);
for termIndex = 1:4
    for channelIndex = 1:2
        panelIndex = (termIndex - 1) .* 2 + channelIndex;
        axesHandle = subplot(4, 2, panelIndex);
        hold(axesHandle, 'on');
        labels = cell(0, 1);
        lineHandles = gobjects(0, 1);
        for modeIndex = 1:maximumModes
            values = reshape(data.modeDeltaProbabilities(:, termIndex, ...
                channelIndex, modeIndex), [], 1);
            formalValues = mask_formal_values(values, acceptedMask);
            lineHandles(end + 1, 1) = plot(axesHandle, energy, ...
                formalValues, '-o', ...
                'LineWidth', 1.2, 'MarkerSize', 3);
            labels{end + 1, 1} = sprintf( ...
                'mode %d formal', modeIndex); %#ok<AGROW>
        end
        aggregate = reshape(poleData(:, termIndex, channelIndex, 1), ...
            [], 1);
        formalAggregate = mask_formal_values(aggregate, acceptedMask);
        lineHandles(end + 1, 1) = plot(axesHandle, energy, ...
            formalAggregate, 'k--', 'LineWidth', 1.8);
        labels{end + 1, 1} = 'aggregate formal';
        if maximumModes > 0 && any(diagnosticMask)
            diagnosticX = repmat(energy(diagnosticMask), ...
                maximumModes, 1);
            diagnosticY = reshape(data.modeDeltaProbabilities( ...
                diagnosticMask, termIndex, channelIndex, :), [], 1);
            lineHandles(end + 1, 1) = plot(axesHandle, diagnosticX, ...
                diagnosticY, 'LineStyle', 'none', 'Marker', 'o', ...
                'MarkerEdgeColor', diagnostic_colour(), ...
                'MarkerFaceColor', 'none', 'MarkerSize', 6, ...
                'LineWidth', 1.2);
            labels{end + 1, 1} = ...
                'diagnostic-only modes (perturbative gate rejected)';
            lineHandles(end + 1, 1) = plot(axesHandle, ...
                energy(diagnosticMask), aggregate(diagnosticMask), ...
                'LineStyle', 'none', 'Marker', 'x', ...
                'Color', diagnostic_colour(), 'MarkerSize', 7, ...
                'LineWidth', 1.4);
            labels{end + 1, 1} = ...
                'diagnostic-only aggregate (perturbative gate rejected)';
        end
        draw_zero_line(axesHandle, energy);
        grid(axesHandle, 'on');
        box(axesHandle, 'on');
        xlabel(axesHandle, 'External energy E = p^0');
        if channelIndex == 1
            ylabel(axesHandle, '\Delta T_{left,pole,mode}');
            channelText = 'T_{left}';
        else
            ylabel(axesHandle, '\Delta R_{left,pole,mode}');
            channelText = 'R_{left}';
        end
        title(axesHandle, sprintf('%s, left-incidence %s channel', ...
            data.termNames{termIndex}, channelText), ...
            'FontWeight', 'normal');
        if maximumModes > 0
            legend(axesHandle, lineHandles, labels, 'Location', 'best');
        else
            text(axesHandle, mean(x_limits(energy)), 0, ...
                'No collective mode', 'HorizontalAlignment', 'center');
        end
        hold(axesHandle, 'off');
    end
end
files.collectivePoleModes = save_figure(fig, outputDirectory, ...
    'G1_G4_collective_pole_modes_vs_energy', settings.output);
end

function draw_term_lines(axesHandle, energy, matrix, total, termNames, ...
        acceptedMask, diagnosticMask)
colours = [ ...
    0.0000, 0.4470, 0.7410; ...
    0.8500, 0.3250, 0.0980; ...
    0.9290, 0.6940, 0.1250; ...
    0.4940, 0.1840, 0.5560];
hold(axesHandle, 'on');
termHandles = gobjects(4, 1);
labels = cell(0, 1);
for termIndex = 1:4
    values = mask_formal_values(matrix(:, termIndex), acceptedMask);
    termHandles(termIndex) = plot(axesHandle, energy, values, '-o', ...
        'Color', colours(termIndex, :), 'LineWidth', 1.4, ...
        'MarkerSize', 3);
    labels{end + 1, 1} = [termNames{termIndex} ' formal']; %#ok<AGROW>
end
formalTotal = mask_formal_values(total, acceptedMask);
totalHandle = plot(axesHandle, energy, formalTotal, 'k--', ...
    'LineWidth', 2.0);
lineHandles = [termHandles; totalHandle];
labels{end + 1, 1} = 'sum formal';
if any(diagnosticMask)
    diagnosticX = repmat(energy(diagnosticMask), 4, 1);
    diagnosticY = reshape(matrix(diagnosticMask, :), [], 1);
    diagnosticTermHandle = plot(axesHandle, diagnosticX, diagnosticY, ...
        'LineStyle', 'none', 'Marker', 'o', ...
        'MarkerEdgeColor', diagnostic_colour(), ...
        'MarkerFaceColor', 'none', 'MarkerSize', 6, 'LineWidth', 1.2);
    diagnosticTotalHandle = plot(axesHandle, energy(diagnosticMask), ...
        total(diagnosticMask), 'LineStyle', 'none', 'Marker', 'x', ...
        'Color', diagnostic_colour(), 'MarkerSize', 7, 'LineWidth', 1.4);
    lineHandles = [lineHandles; diagnosticTermHandle; ...
        diagnosticTotalHandle];
    labels{end + 1, 1} = ...
        'diagnostic-only terms (perturbative gate rejected)';
    labels{end + 1, 1} = ...
        'diagnostic-only sum (perturbative gate rejected)';
end
draw_zero_line(axesHandle, energy);
grid(axesHandle, 'on');
box(axesHandle, 'on');
legend(axesHandle, lineHandles, labels, 'Location', 'best');
hold(axesHandle, 'off');
end

function values = mask_formal_values(values, acceptedMask)
values = reshape(values, [], 1);
values(~acceptedMask) = NaN;
end

function colour = diagnostic_colour()
colour = [0.85, 0.10, 0.10];
end

function validate_masks(energy, acceptedMask, diagnosticMask)
numberOfPoints = numel(energy);
if numel(acceptedMask) ~= numberOfPoints || ...
        numel(diagnosticMask) ~= numberOfPoints
    error('nqscan:PlotMaskSizeMismatch', ...
        'Energy and acceptance masks must contain the same number of points.');
end
if any(acceptedMask & diagnosticMask)
    error('nqscan:OverlappingPlotMasks', ...
        'Formal and diagnostic-only plot masks must be disjoint.');
end
end

function draw_zero_line(axesHandle, energy)
limits = x_limits(energy);
plot(axesHandle, limits, [0, 0], 'k:', 'LineWidth', 0.8, ...
    'HandleVisibility', 'off');
xlim(axesHandle, limits);
end

function limits = x_limits(energy)
energy = energy(isfinite(energy));
if isempty(energy)
    limits = [0, 1];
elseif numel(energy) == 1 || max(energy) == min(energy)
    halfWidth = max(0.05 .* max(abs(energy(1)), 1), 1e-3);
    limits = [energy(1) - halfWidth, energy(1) + halfWidth];
else
    padding = 0.02 .* (max(energy) - min(energy));
    limits = [min(energy) - padding, max(energy) + padding];
end
end

function paths = save_figure(figureHandle, directory, stem, output)
paths = struct('png', '', 'fig', '');
if output.writePng
    paths.png = fullfile(directory, [stem '.png']);
    resolutionFlag = sprintf('-r%d', output.imageResolution);
    print(figureHandle, paths.png, '-dpng', resolutionFlag);
end
if output.writeFig
    paths.fig = fullfile(directory, [stem '.fig']);
    savefig(figureHandle, paths.fig);
end
close(figureHandle);
end
