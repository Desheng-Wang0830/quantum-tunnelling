function audit = build_uv_audit(mu, treeLeft, deltaLeftPerMu2, ...
        treeRight, deltaRightPerMu2, symmetricFormulaApplicable, ...
        absoluteTolerance, relativeTolerance)
%BUILD_UV_AUDIT Assemble the complete first-order 2-by-2 unitarity test.
%
% Vector conventions are
%
%   treeLeft            = [t_L, r_L],
%   treeRight           = [t_R, r_R],
%   deltaLeftPerMu2     = [delta t_L, delta r_L] / mu^2,
%   deltaRightPerMu2    = [delta t_R, delta r_R] / mu^2.
%
% The channel-space matrices are
%
%   S0       = [r_L, t_R; t_L, r_R],
%   deltaS   = [delta r_L, delta t_R;
%               delta t_L, delta r_R],
%
% and the strict O(mu^2) residual is
%
%   M = S0' * deltaS + deltaS' * S0.
%
% For a generic asymmetric array, the independent entries are U_L=M_11,
% U_R=M_22 and the complex V_12=M_12.  Only for a centred mirror-symmetric
% array does this reduce to the two real expressions
%
%   U = 2 Re(conj(t0) delta t + conj(r0) delta r),
%   V = 2 Re(conj(t0) delta r + conj(r0) delta t).

narginchk(8, 8);
validateattributes(mu, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'mu');
treeLeft = row_pair(treeLeft, 'treeLeft');
treeRight = row_pair(treeRight, 'treeRight');
deltaLeftPerMu2 = row_pair(deltaLeftPerMu2, 'deltaLeftPerMu2');
deltaRightPerMu2 = row_pair(deltaRightPerMu2, 'deltaRightPerMu2');
if ~islogical(symmetricFormulaApplicable) || ...
        ~isscalar(symmetricFormulaApplicable)
    error('nqscan:InvalidUVSymmetryFlag', ...
        'symmetricFormulaApplicable must be a logical scalar.');
end
validateattributes(absoluteTolerance, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, mfilename, ...
    'absoluteTolerance');
validateattributes(relativeTolerance, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, mfilename, ...
    'relativeTolerance');

tL = treeLeft(1);
rL = treeLeft(2);
tR = treeRight(1);
rR = treeRight(2);
dtL = deltaLeftPerMu2(1);
drL = deltaLeftPerMu2(2);
dtR = deltaRightPerMu2(1);
drR = deltaRightPerMu2(2);

S0 = [rL, tR; tL, rR];
deltaSPerMu2 = [drL, dtR; dtL, drR];
treeResidualMatrix = S0' * S0 - eye(2);
residualMatrixPerMu2 = S0' * deltaSPerMu2 + ...
    deltaSPerMu2' * S0;

uLeftPerMu2 = real(residualMatrixPerMu2(1, 1));
uRightPerMu2 = real(residualMatrixPerMu2(2, 2));
v12PerMu2 = residualMatrixPerMu2(1, 2);
v21PerMu2 = residualMatrixPerMu2(2, 1);

uLeftDirectPerMu2 = 2 .* real(conj(tL) .* dtL + ...
    conj(rL) .* drL);
uRightDirectPerMu2 = 2 .* real(conj(tR) .* dtR + ...
    conj(rR) .* drR);
v12DirectPerMu2 = conj(rL) .* dtR + conj(tL) .* drR + ...
    conj(drL) .* tR + conj(dtL) .* rR;
v21DirectPerMu2 = conj(v12DirectPerMu2);
directFormulaResidualPerMu2 = max(abs([ ...
    uLeftPerMu2 - uLeftDirectPerMu2, ...
    uRightPerMu2 - uRightDirectPerMu2, ...
    v12PerMu2 - v12DirectPerMu2, ...
    v21PerMu2 - v21DirectPerMu2]));

hermiticityResidualPerMu2 = norm( ...
    residualMatrixPerMu2 - residualMatrixPerMu2', 'fro');
frobeniusResidualPerMu2 = norm(residualMatrixPerMu2, 'fro');
scalePerMu2 = norm(S0' * deltaSPerMu2, 'fro') + ...
    norm(deltaSPerMu2' * S0, 'fro');
gateDenominatorPerMu2 = absoluteTolerance + ...
    relativeTolerance .* scalePerMu2;
if gateDenominatorPerMu2 == 0
    if frobeniusResidualPerMu2 == 0
        gateRatio = 0;
    else
        gateRatio = Inf;
    end
else
    gateRatio = frobeniusResidualPerMu2 ./ gateDenominatorPerMu2;
end

symmetricUPerMu2 = NaN;
symmetricVPerMu2 = NaN;
symmetricFormulaResidualPerMu2 = NaN;
if symmetricFormulaApplicable
    symmetricUPerMu2 = uLeftDirectPerMu2;
    symmetricVPerMu2 = 2 .* real(conj(tL) .* drL + ...
        conj(rL) .* dtL);
    symmetricFormulaResidualPerMu2 = max(abs([ ...
        uLeftPerMu2 - symmetricUPerMu2, ...
        uRightPerMu2 - symmetricUPerMu2, ...
        v12PerMu2 - symmetricVPerMu2, ...
        v21PerMu2 - symmetricVPerMu2]));
end

muSquared = mu.^2;
audit = struct();
audit.convention = ['S0=[rL,tR;tL,rR]; ' ...
    'deltaS=[drL,dtR;dtL,drR]; strict O(mu^2)'];
audit.treeLeft = treeLeft;
audit.treeRight = treeRight;
audit.deltaLeftPerMu2 = deltaLeftPerMu2;
audit.deltaRightPerMu2 = deltaRightPerMu2;
audit.deltaLeft = muSquared .* deltaLeftPerMu2;
audit.deltaRight = muSquared .* deltaRightPerMu2;
audit.S0 = S0;
audit.deltaSPerMu2 = deltaSPerMu2;
audit.deltaS = muSquared .* deltaSPerMu2;
audit.treeResidualMatrix = treeResidualMatrix;
audit.treeResidual = norm(treeResidualMatrix, 'fro');
audit.residualMatrixPerMu2 = residualMatrixPerMu2;
audit.residualMatrix = muSquared .* residualMatrixPerMu2;
audit.uLeftPerMu2 = uLeftPerMu2;
audit.uRightPerMu2 = uRightPerMu2;
audit.v12PerMu2 = v12PerMu2;
audit.v21PerMu2 = v21PerMu2;
audit.uLeft = muSquared .* uLeftPerMu2;
audit.uRight = muSquared .* uRightPerMu2;
audit.v12 = muSquared .* v12PerMu2;
audit.v21 = muSquared .* v21PerMu2;
audit.uLeftDirectPerMu2 = uLeftDirectPerMu2;
audit.uRightDirectPerMu2 = uRightDirectPerMu2;
audit.v12DirectPerMu2 = v12DirectPerMu2;
audit.v21DirectPerMu2 = v21DirectPerMu2;
audit.directFormulaResidualPerMu2 = directFormulaResidualPerMu2;
audit.hermiticityResidualPerMu2 = hermiticityResidualPerMu2;
audit.frobeniusResidualPerMu2 = frobeniusResidualPerMu2;
audit.frobeniusResidual = muSquared .* frobeniusResidualPerMu2;
audit.scalePerMu2 = scalePerMu2;
audit.scale = muSquared .* scalePerMu2;
audit.absoluteTolerance = absoluteTolerance;
audit.relativeTolerance = relativeTolerance;
audit.gateDenominatorPerMu2 = gateDenominatorPerMu2;
audit.gateRatio = gateRatio;
audit.accepted = gateRatio <= 1;
audit.symmetricFormulaApplicable = symmetricFormulaApplicable;
audit.symmetricUPerMu2 = symmetricUPerMu2;
audit.symmetricVPerMu2 = symmetricVPerMu2;
audit.symmetricU = muSquared .* symmetricUPerMu2;
audit.symmetricV = muSquared .* symmetricVPerMu2;
audit.symmetricFormulaResidualPerMu2 = ...
    symmetricFormulaResidualPerMu2;
audit.amplitudeSquaredIncluded = false;
audit.strictOrder = 'O(mu^2)';
end

function value = row_pair(value, name)
if ~isnumeric(value) || numel(value) ~= 2 || ...
        any(~isfinite(real(value(:)))) || ...
        any(~isfinite(imag(value(:))))
    error('nqscan:InvalidUVAmplitudePair', ...
        '%s must contain exactly two finite complex values.', name);
end
value = reshape(value, 1, 2);
end
