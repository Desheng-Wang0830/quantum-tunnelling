function data = extract(scanState, settings, profile, elasticWindow)
%EXTRACT Convert accepted point structures into stable scan arrays.

narginchk(4, 4);
termNames = {'G1', 'G2', 'G3', 'G4'};
channelNames = {'leftTransmission', 'leftReflection'};
sourceNames = {'euclidean', 'ordinaryPole', 'collectivePole', ...
    'cutBanks', 'endpointKeyhole'};
energyValues = settings.scan.energyValues(:);
numberOfPoints = numel(energyValues);

accepted = false(numberOfPoints, 1);
completed = reshape(scanState.completed, [], 1);
status = repmat({''}, numberOfPoints, 1);
errorIdentifier = repmat({''}, numberOfPoints, 1);
errorMessage = repmat({''}, numberOfPoints, 1);
evaluationMode = repmat({settings.numerics.mode}, numberOfPoints, 1);
numericalAccepted = false(numberOfPoints, 1);
perturbativeAccepted = NaN(numberOfPoints, 1);

P = NaN(numberOfPoints, 1);
treeProbabilities = NaN(numberOfPoints, 2);
treeAmplitudesLeft = complex( ...
    NaN(numberOfPoints, 2), NaN(numberOfPoints, 2));
treeAmplitudesRight = complex( ...
    NaN(numberOfPoints, 2), NaN(numberOfPoints, 2));
termDeltaProbabilities = NaN(numberOfPoints, 4, 2);
totalDeltaProbabilities = NaN(numberOfPoints, 2);
correctedProbabilities = NaN(numberOfPoints, 2);
termReducedKernels = complex( ...
    NaN(numberOfPoints, 4, 2), NaN(numberOfPoints, 4, 2));
termDeltaAmplitudes = complex( ...
    NaN(numberOfPoints, 4, 2), NaN(numberOfPoints, 4, 2));
totalDeltaAmplitudesLeft = complex( ...
    NaN(numberOfPoints, 2), NaN(numberOfPoints, 2));
totalDeltaAmplitudesRight = complex( ...
    NaN(numberOfPoints, 2), NaN(numberOfPoints, 2));
totalAmplitudesPerMu2Left = complex( ...
    NaN(numberOfPoints, 2), NaN(numberOfPoints, 2));
totalAmplitudesPerMu2Right = complex( ...
    NaN(numberOfPoints, 2), NaN(numberOfPoints, 2));
sourceReducedKernels = complex( ...
    NaN(numberOfPoints, 4, 2, 5), ...
    NaN(numberOfPoints, 4, 2, 5));
sourceDeltaProbabilities = NaN(numberOfPoints, 4, 2, 5);

elasticUpper = NaN(numberOfPoints, 1);
numberOfModes = zeros(numberOfPoints, 1);
maximumSourceClosure = NaN(numberOfPoints, 1);
maximumTauEquationResidual = NaN(numberOfPoints, 1);
minimumTauScaledRcond = NaN(numberOfPoints, 1);
maximumTauConditionAmplification = NaN(numberOfPoints, 1);
minimumCollectiveProjectedRcond = NaN(numberOfPoints, 1);
minimumCollectiveProjectedScaledRcond = NaN(numberOfPoints, 1);
collectiveConditionAccepted = false(numberOfPoints, 1);
leftUnitarityNormalisedError = NaN(numberOfPoints, 1);
maximumSourceConvergenceError = NaN(numberOfPoints, 1);
maximumTermConvergenceError = NaN(numberOfPoints, 1);
maximumCombinedConvergenceError = NaN(numberOfPoints, 1);
perturbativeEta = NaN(numberOfPoints, 1);
fullSMatrixTested = false(numberOfPoints, 1);
fullSMatrixAccepted = NaN(numberOfPoints, 1);
maximumDeltaAmplitude = NaN(numberOfPoints, 1);
maximumConditionalAmplitudeRatio = NaN(numberOfPoints, 1);
omittedAmplitudeSquaredScale = NaN(numberOfPoints, 1);
truncatedProbabilitiesInNominalRange = false(numberOfPoints, 1);
uvAuditTested = false(numberOfPoints, 1);
uvOneLoopAccepted = NaN(numberOfPoints, 1);
symmetricUVFormulaApplicable = false(numberOfPoints, 1);
uLeftResidual = NaN(numberOfPoints, 1);
uRightResidual = NaN(numberOfPoints, 1);
v12Residual = complex(NaN(numberOfPoints, 1), ...
    NaN(numberOfPoints, 1));
uLeftResidualPerMu2 = NaN(numberOfPoints, 1);
uRightResidualPerMu2 = NaN(numberOfPoints, 1);
v12ResidualPerMu2 = complex(NaN(numberOfPoints, 1), ...
    NaN(numberOfPoints, 1));
symmetricUResidual = NaN(numberOfPoints, 1);
symmetricVResidual = NaN(numberOfPoints, 1);
symmetricUResidualPerMu2 = NaN(numberOfPoints, 1);
symmetricVResidualPerMu2 = NaN(numberOfPoints, 1);
uvFrobeniusResidual = NaN(numberOfPoints, 1);
uvFrobeniusResidualPerMu2 = NaN(numberOfPoints, 1);
uvScale = NaN(numberOfPoints, 1);
uvScalePerMu2 = NaN(numberOfPoints, 1);
uvGateRatio = NaN(numberOfPoints, 1);
uvHermiticityResidualPerMu2 = NaN(numberOfPoints, 1);
uvDirectFormulaResidualPerMu2 = NaN(numberOfPoints, 1);
uvSymmetricFormulaResidualPerMu2 = NaN(numberOfPoints, 1);
uvEngineMatrixAgreementResidualPerMu2 = NaN(numberOfPoints, 1);
uvEngineAcceptanceAgreement = false(numberOfPoints, 1);
uLeftProbabilityAgreement = NaN(numberOfPoints, 1);
uRightProbabilityAgreement = NaN(numberOfPoints, 1);

maxModes = 0;
for pointIndex = 1:numberOfPoints
    if ~completed(pointIndex) || isempty(scanState.records{pointIndex})
        continue;
    end
    record = scanState.records{pointIndex};
    if record.numericalAccepted && isfield(record.point, 'spectrum')
        maxModes = max(maxModes, numel(record.point.spectrum.modes));
    end
end
if maxModes == 0
    modeReducedKernels = complex(zeros(numberOfPoints, 4, 2, 0));
    modeDeltaProbabilities = zeros(numberOfPoints, 4, 2, 0);
    modeAlpha = zeros(numberOfPoints, 0);
    modeQPerpCritical = zeros(numberOfPoints, 0);
    modeStable = false(numberOfPoints, 0);
    modeRootResidual = zeros(numberOfPoints, 0);
    modeLabel = cell(numberOfPoints, 0);
    modeBranchIndices = cell(numberOfPoints, 0);
    modeNullity = zeros(numberOfPoints, 0);
    modeMultiplicity = zeros(numberOfPoints, 0);
    modeSemisimple = false(numberOfPoints, 0);
else
    modeReducedKernels = complex( ...
        NaN(numberOfPoints, 4, 2, maxModes), ...
        NaN(numberOfPoints, 4, 2, maxModes));
    modeDeltaProbabilities = NaN(numberOfPoints, 4, 2, maxModes);
    modeAlpha = NaN(numberOfPoints, maxModes);
    modeQPerpCritical = NaN(numberOfPoints, maxModes);
    modeStable = false(numberOfPoints, maxModes);
    modeRootResidual = NaN(numberOfPoints, maxModes);
    modeLabel = repmat({''}, numberOfPoints, maxModes);
    modeBranchIndices = repmat({zeros(1, 0)}, ...
        numberOfPoints, maxModes);
    modeNullity = NaN(numberOfPoints, maxModes);
    modeMultiplicity = NaN(numberOfPoints, maxModes);
    modeSemisimple = false(numberOfPoints, maxModes);
end

maximumKernelSourceClosure = 0;
maximumProbabilitySourceClosure = 0;
maximumModePoleClosure = 0;
ordinaryPoleMaximum = 0;
ordinaryPoleKernelMaximum = 0;
mixedPoleExactlyZero = true;
maximumModePoleProbabilityClosure = 0;

for pointIndex = 1:numberOfPoints
    if ~completed(pointIndex) || isempty(scanState.records{pointIndex})
        status{pointIndex} = 'not_completed';
        continue;
    end
    record = scanState.records{pointIndex};
    status{pointIndex} = record.status;
    errorIdentifier{pointIndex} = record.errorIdentifier;
    errorMessage{pointIndex} = record.errorMessage;
    evaluationMode{pointIndex} = record.evaluationMode;
    numericalAccepted(pointIndex) = record.numericalAccepted;
    perturbativeAccepted(pointIndex) = ...
        double(record.perturbativeInterpretationAccepted);
    maximumSourceConvergenceError(pointIndex) = ...
        record.validation.maximumSourceError;
    maximumTermConvergenceError(pointIndex) = ...
        record.validation.maximumTermError;
    maximumCombinedConvergenceError(pointIndex) = ...
        record.validation.maximumCombinedError;
    perturbativeEta(pointIndex) = record.validation.perturbativeEta;
    fullSMatrixTested(pointIndex) = ...
        record.validation.fullSMatrixTested;
    fullSMatrixAccepted(pointIndex) = ...
        double(record.validation.fullSMatrixAccepted);
    maximumSourceClosure(pointIndex) = ...
        record.validation.maximumSourceClosure;
    maximumTauEquationResidual(pointIndex) = ...
        record.validation.maximumTauEquationResidual;
    minimumTauScaledRcond(pointIndex) = ...
        optional_scalar(record.validation, 'minimumTauScaledRcond', NaN);
    maximumTauConditionAmplification(pointIndex) = ...
        optional_scalar(record.validation, ...
        'maximumTauConditionAmplification', NaN);
    minimumCollectiveProjectedRcond(pointIndex) = ...
        optional_scalar(record.validation, ...
        'minimumCollectiveProjectedRcond', NaN);
    minimumCollectiveProjectedScaledRcond(pointIndex) = ...
        optional_scalar(record.validation, ...
        'minimumCollectiveProjectedScaledRcond', NaN);
    collectiveConditionAccepted(pointIndex) = logical(optional_scalar( ...
        record.validation, 'collectiveConditionAccepted', false));
    leftUnitarityNormalisedError(pointIndex) = ...
        record.validation.leftUnitarityNormalisedError;

    if isfield(record, 'uvAudit') && isstruct(record.uvAudit) && ...
            isscalar(record.uvAudit) && isfield(record.uvAudit, 'tested') && ...
            isequal(record.uvAudit.tested, true)
        audit = record.uvAudit;
        validate_uv_audit_schema(audit);
        uvAuditTested(pointIndex) = true;
        uvOneLoopAccepted(pointIndex) = double(audit.accepted);
        symmetricUVFormulaApplicable(pointIndex) = ...
            audit.symmetricFormulaApplicable;
        treeAmplitudesLeft(pointIndex, :) = audit.treeLeft;
        treeAmplitudesRight(pointIndex, :) = audit.treeRight;
        totalDeltaAmplitudesLeft(pointIndex, :) = audit.deltaLeft;
        totalDeltaAmplitudesRight(pointIndex, :) = audit.deltaRight;
        totalAmplitudesPerMu2Left(pointIndex, :) = ...
            audit.deltaLeftPerMu2;
        totalAmplitudesPerMu2Right(pointIndex, :) = ...
            audit.deltaRightPerMu2;
        uLeftResidual(pointIndex) = audit.uLeft;
        uRightResidual(pointIndex) = audit.uRight;
        v12Residual(pointIndex) = audit.v12;
        uLeftResidualPerMu2(pointIndex) = audit.uLeftPerMu2;
        uRightResidualPerMu2(pointIndex) = audit.uRightPerMu2;
        v12ResidualPerMu2(pointIndex) = audit.v12PerMu2;
        symmetricUResidual(pointIndex) = audit.symmetricU;
        symmetricVResidual(pointIndex) = audit.symmetricV;
        symmetricUResidualPerMu2(pointIndex) = ...
            audit.symmetricUPerMu2;
        symmetricVResidualPerMu2(pointIndex) = ...
            audit.symmetricVPerMu2;
        uvFrobeniusResidual(pointIndex) = audit.frobeniusResidual;
        uvFrobeniusResidualPerMu2(pointIndex) = ...
            audit.frobeniusResidualPerMu2;
        uvScale(pointIndex) = audit.scale;
        uvScalePerMu2(pointIndex) = audit.scalePerMu2;
        uvGateRatio(pointIndex) = audit.gateRatio;
        uvHermiticityResidualPerMu2(pointIndex) = ...
            audit.hermiticityResidualPerMu2;
        uvDirectFormulaResidualPerMu2(pointIndex) = ...
            audit.directFormulaResidualPerMu2;
        uvSymmetricFormulaResidualPerMu2(pointIndex) = ...
            audit.symmetricFormulaResidualPerMu2;
        uvEngineMatrixAgreementResidualPerMu2(pointIndex) = ...
            audit.engineMatrixAgreementResidualPerMu2;
        uvEngineAcceptanceAgreement(pointIndex) = ...
            audit.engineAcceptanceAgreement;
        uLeftProbabilityAgreement(pointIndex) = ...
            audit.uLeftProbabilityAgreement;
        uRightProbabilityAgreement(pointIndex) = ...
            audit.uRightProbabilityAgreement;
    end

    if ~record.numericalAccepted
        continue;
    end
    point = record.point;
    validate_point_schema(point, termNames);
    if strcmp(record.evaluationMode, 'paired')
        accepted(pointIndex) = record.numericalAccepted && ...
            isequal(record.perturbativeInterpretationAccepted, true);
    else
        accepted(pointIndex) = record.numericalAccepted;
    end
    P(pointIndex) = point.P;
    treeProbabilities(pointIndex, :) = ...
        [point.tree.T0, point.tree.R0];
    treeAmplitudesLeft(pointIndex, :) = ...
        [point.tree.t0, point.tree.r0];
    termReducedKernels(pointIndex, :, :) = reshape( ...
        point.combined.termKernelMatrix, [1, 4, 2]);
    termDeltaAmplitudes(pointIndex, :, :) = reshape( ...
        point.combined.termDeltaAmplitudeMatrix, [1, 4, 2]);
    termDeltaProbabilities(pointIndex, :, :) = reshape( ...
        point.combined.termDeltaProbabilityMatrix, [1, 4, 2]);
    totalDeltaProbabilities(pointIndex, :) = ...
        point.combined.totalDeltaProbabilities;
    totalDeltaAmplitudesLeft(pointIndex, :) = ...
        point.combined.totalDeltaAmplitudes;
    totalAmplitudesPerMu2Left(pointIndex, :) = ...
        point.combined.totalAmplitudesPerMu2;
    if ~uvAuditTested(pointIndex)
        uLeftResidual(pointIndex) = ...
            sum(point.combined.totalDeltaProbabilities);
        uLeftResidualPerMu2(pointIndex) = sum(2 .* real( ...
            conj([point.tree.t0, point.tree.r0]) .* ...
                point.combined.totalAmplitudesPerMu2));
    end
    uLeftProbabilityAgreement(pointIndex) = abs( ...
        uLeftResidual(pointIndex) - ...
        sum(point.combined.totalDeltaProbabilities));
    correctedProbabilities(pointIndex, :) = ...
        point.combined.truncatedProbabilities;
    maximumDeltaAmplitude(pointIndex) = point.maximumDeltaAmplitude;
    maximumConditionalAmplitudeRatio(pointIndex) = ...
        point.maximumConditionalAmplitudeRatio;
    omittedAmplitudeSquaredScale(pointIndex) = ...
        point.omittedAmplitudeSquaredScale;
    truncatedProbabilitiesInNominalRange(pointIndex) = ...
        point.truncatedProbabilitiesInNominalRange;
    elasticUpper(pointIndex) = point.elasticWindow.upper;
    modes = point.spectrum.modes;
    numberOfModes(pointIndex) = numel(modes);
    for modeIndex = 1:numel(modes)
        modeAlpha(pointIndex, modeIndex) = modes(modeIndex).alpha;
        modeQPerpCritical(pointIndex, modeIndex) = ...
            modes(modeIndex).qPerpCritical;
        modeStable(pointIndex, modeIndex) = modes(modeIndex).stable;
        modeRootResidual(pointIndex, modeIndex) = ...
            modes(modeIndex).rootResidual;
        modeLabel{pointIndex, modeIndex} = char(modes(modeIndex).label);
        modeBranchIndices{pointIndex, modeIndex} = ...
            modes(modeIndex).branchIndices(:).';
        modeNullity(pointIndex, modeIndex) = modes(modeIndex).nullity;
        modeMultiplicity(pointIndex, modeIndex) = ...
            modes(modeIndex).multiplicity;
        modeSemisimple(pointIndex, modeIndex) = ...
            modes(modeIndex).semisimple;
    end

    treeAmplitudes = [point.tree.t0, point.tree.r0];
    muSquared = settings.model.mu.^2;
    for termIndex = 1:4
        term = termNames{termIndex};
        reduced = point.reduced.(term);
        amplitude = point.amplitudes.(term);
        for sourceIndex = 1:numel(sourceNames)
            source = sourceNames{sourceIndex};
            reducedIndex = unique_source_index( ...
                reduced.sourceNames, source, term);
            amplitudeIndex = unique_source_index( ...
                amplitude.sourceNames, source, term);
            values = reduced.sourceMatrix(:, reducedIndex);
            probabilities = muSquared .* ...
                amplitude.sourceDeltaProbabilitiesPerMu2( ...
                :, amplitudeIndex);
            sourceReducedKernels(pointIndex, termIndex, :, ...
                sourceIndex) = reshape(values, [1, 1, 2, 1]);
            sourceDeltaProbabilities(pointIndex, termIndex, :, ...
                sourceIndex) = reshape(probabilities, [1, 1, 2, 1]);
            if strcmp(source, 'ordinaryPole')
                ordinaryPoleMaximum = max(ordinaryPoleMaximum, ...
                    max(abs(probabilities)));
                ordinaryPoleKernelMaximum = max( ...
                    ordinaryPoleKernelMaximum, max(abs(values)));
            end
        end

        for channelIndex = 1:2
            sourceKernelVector = reshape(sourceReducedKernels( ...
                pointIndex, termIndex, channelIndex, :), 1, []);
            kernelTotal = termReducedKernels( ...
                pointIndex, termIndex, channelIndex);
            kernelResidual = abs(sum(sourceKernelVector) - kernelTotal) ...
                ./ (1 + abs(kernelTotal));
            maximumKernelSourceClosure = max( ...
                maximumKernelSourceClosure, kernelResidual);

            sourceProbabilityVector = reshape(sourceDeltaProbabilities( ...
                pointIndex, termIndex, channelIndex, :), 1, []);
            probabilityTotal = termDeltaProbabilities( ...
                pointIndex, termIndex, channelIndex);
            probabilityResidual = abs(sum(sourceProbabilityVector) ...
                - probabilityTotal) ./ (1 + abs(probabilityTotal));
            maximumProbabilitySourceClosure = max( ...
                maximumProbabilitySourceClosure, probabilityResidual);

            if channelIndex == 1
                channelItem = reduced.transmission;
            else
                channelItem = reduced.reflection;
            end
            mixedPoleExactlyZero = mixedPoleExactlyZero && ...
                isfield(channelItem, 'mixedPoleExactlyZero') && ...
                channelItem.mixedPoleExactlyZero;
            modeKernels = ...
                channelItem.collectivePole.modeContributions(:);
            if numel(modeKernels) ~= numel(modes)
                error('nqscan:CollectiveModeCountMismatch', ...
                    ['%s channel %d has %d mode contributions but the ' ...
                     'spectrum contains %d modes.'], term, channelIndex, ...
                    numel(modeKernels), numel(modes));
            end
            collectiveIndex = unique_source_index( ...
                reduced.sourceNames, 'collectivePole', term);
            aggregatePole = reduced.sourceMatrix( ...
                channelIndex, collectiveIndex);
            modeResidual = abs(sum(modeKernels) - aggregatePole) ...
                ./ (1 + abs(aggregatePole));
            maximumModePoleClosure = max( ...
                maximumModePoleClosure, modeResidual);
            for modeIndex = 1:numel(modeKernels)
                modeKernel = modeKernels(modeIndex);
                modeReducedKernels(pointIndex, termIndex, ...
                    channelIndex, modeIndex) = modeKernel;
                modeDeltaProbabilities(pointIndex, termIndex, ...
                    channelIndex, modeIndex) = muSquared .* 2 .* real( ...
                    conj(treeAmplitudes(channelIndex)) .* modeKernel ...
                    ./ (2 .* point.P));
            end
            modeProbabilitySum = sum(reshape(modeDeltaProbabilities( ...
                pointIndex, termIndex, channelIndex, ...
                1:numel(modeKernels)), 1, []));
            canonicalCollectiveIndex = find(strcmp( ...
                sourceNames, 'collectivePole'));
            collectiveProbability = sourceDeltaProbabilities( ...
                pointIndex, termIndex, channelIndex, ...
                canonicalCollectiveIndex);
            modeProbabilityResidual = abs(modeProbabilitySum ...
                - collectiveProbability) ./ ...
                (1 + abs(collectiveProbability));
            maximumModePoleProbabilityClosure = max( ...
                maximumModePoleProbabilityClosure, ...
                modeProbabilityResidual);
        end
    end
end

continuity = collective_mode_continuity( ...
    scanState, numericalAccepted, modeNullity, modeMultiplicity, ...
    modeSemisimple);
if any(numericalAccepted) && ~continuity.accepted
    error('nqscan:CollectiveModeContinuityFailure', ...
        ['Collective-pole mode identity is not continuous across the ' ...
         'external-energy scan.  Per-mode curves must not connect these ' ...
         'points.']);
end

relativeTotalCorrections = totalDeltaProbabilities ./ treeProbabilities;
oneLoopClosureResidual = sum(totalDeltaProbabilities, 2);

wrapperContractTolerance = 5e-9;
if max([maximumKernelSourceClosure, ...
        maximumProbabilitySourceClosure, maximumModePoleClosure, ...
        maximumModePoleProbabilityClosure]) > ...
        wrapperContractTolerance
    error('nqscan:WrapperAccountingClosureFailure', ...
        ['The exported source or per-mode pole ledger does not close ' ...
         'within %.3g.'], wrapperContractTolerance);
end
if ordinaryPoleMaximum > 1e-14 || ...
        ordinaryPoleKernelMaximum > 1e-14 || ~mixedPoleExactlyZero
    error('nqscan:UnexpectedNonzeroOrdinaryOrMixedPole', ...
        ['The frozen contract requires ordinaryPole and mixedPole to be ' ...
         'zero; the extracted ledger violates that contract.']);
end

data = struct();
data.externalEnergy = energyValues;
data.P = P;
data.N = profile.N;
data.positions = profile.positions;
data.strengths = profile.strengths;
data.termNames = termNames;
data.channelNames = channelNames;
data.sourceNames = sourceNames;
data.completed = completed;
data.accepted = accepted;
data.numericalAccepted = numericalAccepted;
data.perturbativeInterpretationAccepted = perturbativeAccepted;
data.status = status;
data.errorIdentifier = errorIdentifier;
data.errorMessage = errorMessage;
data.evaluationMode = evaluationMode;
data.treeProbabilities = treeProbabilities;
data.treeAmplitudesLeft = treeAmplitudesLeft;
data.treeAmplitudesRight = treeAmplitudesRight;
data.termReducedKernels = termReducedKernels;
data.termDeltaAmplitudes = termDeltaAmplitudes;
data.totalDeltaAmplitudesLeft = totalDeltaAmplitudesLeft;
data.totalDeltaAmplitudesRight = totalDeltaAmplitudesRight;
data.totalAmplitudesPerMu2Left = totalAmplitudesPerMu2Left;
data.totalAmplitudesPerMu2Right = totalAmplitudesPerMu2Right;
data.termDeltaProbabilities = termDeltaProbabilities;
data.totalDeltaProbabilities = totalDeltaProbabilities;
data.correctedProbabilities = correctedProbabilities;
data.relativeTotalCorrections = relativeTotalCorrections;
data.oneLoopClosureResidual = oneLoopClosureResidual;
data.sourceReducedKernels = sourceReducedKernels;
data.sourceDeltaProbabilities = sourceDeltaProbabilities;
data.numberOfCollectiveModes = numberOfModes;
data.modeReducedKernels = modeReducedKernels;
data.modeDeltaProbabilities = modeDeltaProbabilities;
data.modeAlpha = modeAlpha;
data.modeQPerpCritical = modeQPerpCritical;
data.modeStable = modeStable;
data.modeRootResidual = modeRootResidual;
data.modeLabel = modeLabel;
data.modeBranchIndices = modeBranchIndices;
data.modeNullity = modeNullity;
data.modeMultiplicity = modeMultiplicity;
data.modeSemisimple = modeSemisimple;
data.collectiveModeContinuity = continuity;
data.elasticLower = elasticWindow.lower;
data.elasticUpper = elasticUpper;
data.maximumSourceClosure = maximumSourceClosure;
data.maximumTauEquationResidual = maximumTauEquationResidual;
data.minimumTauScaledRcond = minimumTauScaledRcond;
data.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
data.minimumCollectiveProjectedRcond = ...
    minimumCollectiveProjectedRcond;
data.minimumCollectiveProjectedScaledRcond = ...
    minimumCollectiveProjectedScaledRcond;
data.collectiveConditionAccepted = collectiveConditionAccepted;
data.leftUnitarityNormalisedError = ...
    leftUnitarityNormalisedError;
data.maximumSourceConvergenceError = ...
    maximumSourceConvergenceError;
data.maximumTermConvergenceError = maximumTermConvergenceError;
data.maximumCombinedConvergenceError = ...
    maximumCombinedConvergenceError;
data.perturbativeEta = perturbativeEta;
data.fullSMatrixTested = fullSMatrixTested;
data.fullSMatrixAccepted = fullSMatrixAccepted;
data.uvAuditTested = uvAuditTested;
data.uvOneLoopAccepted = uvOneLoopAccepted;
data.symmetricUVFormulaApplicable = ...
    symmetricUVFormulaApplicable;
data.uLeftResidual = uLeftResidual;
data.uRightResidual = uRightResidual;
data.v12Residual = v12Residual;
data.uLeftResidualPerMu2 = uLeftResidualPerMu2;
data.uRightResidualPerMu2 = uRightResidualPerMu2;
data.v12ResidualPerMu2 = v12ResidualPerMu2;
data.symmetricUResidual = symmetricUResidual;
data.symmetricVResidual = symmetricVResidual;
data.symmetricUResidualPerMu2 = symmetricUResidualPerMu2;
data.symmetricVResidualPerMu2 = symmetricVResidualPerMu2;
data.uvFrobeniusResidual = uvFrobeniusResidual;
data.uvFrobeniusResidualPerMu2 = uvFrobeniusResidualPerMu2;
data.uvScale = uvScale;
data.uvScalePerMu2 = uvScalePerMu2;
data.uvGateRatio = uvGateRatio;
data.uvHermiticityResidualPerMu2 = ...
    uvHermiticityResidualPerMu2;
data.uvDirectFormulaResidualPerMu2 = ...
    uvDirectFormulaResidualPerMu2;
data.uvSymmetricFormulaResidualPerMu2 = ...
    uvSymmetricFormulaResidualPerMu2;
data.uvEngineMatrixAgreementResidualPerMu2 = ...
    uvEngineMatrixAgreementResidualPerMu2;
data.uvEngineAcceptanceAgreement = uvEngineAcceptanceAgreement;
data.uLeftProbabilityAgreement = uLeftProbabilityAgreement;
data.uRightProbabilityAgreement = uRightProbabilityAgreement;
data.maximumDeltaAmplitude = maximumDeltaAmplitude;
data.maximumConditionalAmplitudeRatio = maximumConditionalAmplitudeRatio;
data.omittedAmplitudeSquaredScale = omittedAmplitudeSquaredScale;
data.truncatedProbabilitiesInNominalRange = ...
    truncatedProbabilitiesInNominalRange;
data.contracts = struct( ...
    'maximumKernelSourceClosure', maximumKernelSourceClosure, ...
    'maximumProbabilitySourceClosure', ...
        maximumProbabilitySourceClosure, ...
    'maximumModePoleClosure', maximumModePoleClosure, ...
    'maximumModePoleProbabilityClosure', ...
        maximumModePoleProbabilityClosure, ...
    'ordinaryPoleMaximumAbsoluteDeltaProbability', ...
        ordinaryPoleMaximum, ...
    'ordinaryPoleMaximumAbsoluteReducedKernel', ...
        ordinaryPoleKernelMaximum, ...
    'mixedPoleExactlyZero', mixedPoleExactlyZero, ...
    'wrapperContractTolerance', wrapperContractTolerance, ...
    'singleDeltaBarrierPoleIncludedInCollectivePole', true, ...
    'amplitudeSquaredIncluded', false, ...
    'strictOrder', 'O(mu^2)');
end

function validate_uv_audit_schema(audit)
required = {'treeLeft', 'treeRight', 'deltaLeft', 'deltaRight', ...
    'deltaLeftPerMu2', 'deltaRightPerMu2', 'uLeft', 'uRight', ...
    'v12', 'uLeftPerMu2', 'uRightPerMu2', 'v12PerMu2', ...
    'symmetricFormulaApplicable', 'symmetricU', 'symmetricV', ...
    'symmetricUPerMu2', 'symmetricVPerMu2', ...
    'frobeniusResidual', 'frobeniusResidualPerMu2', 'scale', ...
    'scalePerMu2', 'gateRatio', 'accepted', ...
    'hermiticityResidualPerMu2', 'directFormulaResidualPerMu2', ...
    'symmetricFormulaResidualPerMu2', ...
    'engineMatrixAgreementResidualPerMu2', ...
    'engineAcceptanceAgreement', 'uLeftProbabilityAgreement', ...
    'uRightProbabilityAgreement'};
if ~all(isfield(audit, required)) || ...
        numel(audit.treeLeft) ~= 2 || numel(audit.treeRight) ~= 2 || ...
        numel(audit.deltaLeft) ~= 2 || numel(audit.deltaRight) ~= 2
    error('nqscan:IncompleteUVAudit', ...
        'A tested U/V audit is missing required amplitude or residual data.');
end
end

function continuity = collective_mode_continuity( ...
        scanState, numericalAccepted, modeNullity, modeMultiplicity, ...
        modeSemisimple)
indices = find(numericalAccepted);
continuity = struct('modeIdentityAccepted', true, ...
    'modeMultiplicityAccepted', true, 'maximumAlphaError', 0, ...
    'maximumQCriticalFormulaError', 0, ...
    'qCriticalMonotonic', true, 'accepted', false, ...
    'numberOfEnergyPoints', numel(indices));
if isempty(indices)
    return;
end

energyPoints = cell(numel(indices), 1);
for localIndex = 1:numel(indices)
    wrapper = struct();
    wrapper.pair = struct();
    wrapper.pair.published = struct();
    wrapper.pair.published.left = ...
        scanState.records{indices(localIndex)}.point;
    energyPoints{localIndex} = wrapper;
end
engineContinuity = ndelta.stage12.energy_root_continuity( ...
    energyPoints, scanState.requestKey.baseConfiguration);
continuity.modeIdentityAccepted = ...
    engineContinuity.modeIdentityAccepted;
continuity.maximumAlphaError = engineContinuity.maximumAlphaError;
continuity.maximumQCriticalFormulaError = ...
    engineContinuity.maximumQCriticalFormulaError;
continuity.qCriticalMonotonic = ...
    engineContinuity.qCriticalMonotonic;

referenceIndex = indices(1);
referenceCount = ...
    scanState.records{referenceIndex}.point.spectrum.numberOfModes;
for localIndex = 2:numel(indices)
    pointIndex = indices(localIndex);
    count = scanState.records{pointIndex}.point.spectrum.numberOfModes;
    if count ~= referenceCount || ...
            ~isequaln(modeNullity(pointIndex, 1:count), ...
            modeNullity(referenceIndex, 1:referenceCount)) || ...
            ~isequaln(modeMultiplicity(pointIndex, 1:count), ...
            modeMultiplicity(referenceIndex, 1:referenceCount)) || ...
            ~isequaln(modeSemisimple(pointIndex, 1:count), ...
            modeSemisimple(referenceIndex, 1:referenceCount))
        continuity.modeMultiplicityAccepted = false;
    end
end
continuity.accepted = engineContinuity.accepted && ...
    continuity.modeMultiplicityAccepted;
end

function validate_point_schema(point, termNames)
required = {'P', 'tree', 'spectrum', 'elasticWindow', 'reduced', ...
    'amplitudes', 'combined', 'maximumDeltaAmplitude', ...
    'maximumConditionalAmplitudeRatio', 'omittedAmplitudeSquaredScale', ...
    'truncatedProbabilitiesInNominalRange'};
if ~isstruct(point) || ~isscalar(point) || ...
        ~all(isfield(point, required)) || ...
        ~all(isfield(point.reduced, termNames)) || ...
        ~all(isfield(point.amplitudes, termNames)) || ...
        ~all(isfield(point.combined, {'termKernelMatrix', ...
        'termDeltaAmplitudeMatrix', 'termDeltaProbabilityMatrix', ...
        'totalAmplitudesPerMu2', 'totalDeltaAmplitudes', ...
        'totalDeltaProbabilities', 'truncatedProbabilities'}))
    error('nqscan:IncompleteAcceptedPoint', ...
        'An accepted point is missing the complete G1--G4 payload.');
end
if ~isequal(size(point.combined.termKernelMatrix), [4, 2]) || ...
        ~isequal(size(point.combined.termDeltaProbabilityMatrix), [4, 2])
    error('nqscan:InvalidTermMatrixShape', ...
        'Accepted term matrices must be 4-by-2 in G1--G4 by T/R order.');
end
end

function index = unique_source_index(names, target, term)
matches = find(strcmp(names, target));
if numel(matches) ~= 1
    error('nqscan:MissingOrDuplicateSource', ...
        '%s must contain source %s exactly once.', term, target);
end
index = matches;
end

function value = optional_scalar(record, name, defaultValue)
if isstruct(record) && isscalar(record) && isfield(record, name) && ...
        (isnumeric(record.(name)) || islogical(record.(name))) && ...
        isscalar(record.(name))
    value = record.(name);
else
    value = defaultValue;
end
end
