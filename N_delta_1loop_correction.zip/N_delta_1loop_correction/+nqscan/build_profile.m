function profile = build_profile(settings)
%BUILD_PROFILE Resolve one explicit arbitrary-N delta configuration.

narginchk(1, 1);
settings = nqscan.validate_settings(settings);
geometry = settings.geometry;
switch geometry.mode
    case 'fixed_support_trapezoidal'
        N = geometry.N;
        support = geometry.support;
        totalStrength = geometry.totalStrength;
        if N == 1
            positions = mean(support);
            strengths = totalStrength;
            scheme = 'single_centre_total_strength';
        else
            positions = linspace(support(1), support(2), N);
            weights = ones(1, N);
            weights([1, end]) = 0.5;
            weights = weights ./ sum(weights);
            strengths = totalStrength .* weights;
            scheme = 'fixed_support_trapezoidal';
        end
    case 'explicit'
        positions = geometry.positions;
        strengths = geometry.strengths;
        N = numel(positions);
        support = [min(positions), max(positions)];
        totalStrength = sum(strengths);
        scheme = 'explicit_positions_and_strengths';
    otherwise
        error('nqscan:UnknownGeometryMode', ...
            'Unsupported geometry mode %s.', geometry.mode);
end

profile = struct();
profile.mode = geometry.mode;
profile.scheme = scheme;
profile.N = N;
profile.positions = positions(:).';
profile.strengths = strengths(:).';
profile.activeMask = strengths ~= 0;
profile.numberOfActiveCentres = nnz(profile.activeMask);
profile.support = support;
profile.totalStrength = totalStrength;
profile.generatedAutomatically = ...
    strcmp(geometry.mode, 'fixed_support_trapezoidal');
end
