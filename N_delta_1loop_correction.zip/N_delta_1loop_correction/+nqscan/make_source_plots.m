function files = make_source_plots(result, outputDirectory)
%MAKE_SOURCE_PLOTS Plot source-resolved probability corrections for each G_j.
%
% The complex reduced kernels remain available in the MAT/CSV ledgers.  The
% public source figures deliberately show only the strict O(mu^2)
% interference contributions to Delta T_j and Delta R_j.  Pole and branch
% locations in the complex q^0 plane are drawn by MAKE_SINGULARITY_PLOTS.

narginchk(2, 2);
data = result.data;
settings = result.settings;
if ~isfield(data, 'analyticSourceGroups')
    groups = nqscan.group_analytic_sources(data);
else
    groups = data.analyticSourceGroups;
end

energy = data.externalEnergy(:);
acceptedMask = logical(data.accepted(:));
diagnosticMask = logical(data.numericalAccepted(:)) & ~acceptedMask & ...
    data.perturbativeInterpretationAccepted(:) == 0;
files = struct();

for termIndex = 1:4
    term = data.termNames{termIndex};
    fig = figure('Visible', settings.output.figureVisible, 'Color', 'w', ...
        'Position', [40, 80, 1280, 520]);
    for channelIndex = 1:2
        sourceProbabilities = reshape(groups.deltaProbabilities(:, ...
            termIndex, channelIndex, :), numel(energy), 4);
        totalProbability = reshape(data.termDeltaProbabilities(:, ...
            termIndex, channelIndex), [], 1);
        [probabilityLabels, probabilityTotalLabel] = ...
            probability_source_labels( ...
            term, channelIndex, groups.names);

        axesHandle = subplot(1, 2, channelIndex);
        draw_source_lines(axesHandle, energy, sourceProbabilities, ...
            totalProbability, probabilityLabels, acceptedMask, ...
            diagnosticMask, probabilityTotalLabel);
        if channelIndex == 1
            ylabel(axesHandle, ['\Delta T_{left,' term '}']);
            titleText = 'transmission source contributions';
        else
            ylabel(axesHandle, ['\Delta R_{left,' term '}']);
            titleText = 'reflection source contributions';
        end
        xlabel(axesHandle, 'External energy E = p^0');
        title(axesHandle, [term ': strict O(\mu^2) ' titleText], ...
            'FontWeight', 'normal');
    end
    files.(term) = save_figure(fig, outputDirectory, ...
        [term '_analytic_source_contributions_vs_energy'], ...
        settings.output);

    % Also expose the raw five-source audit so cut banks and endpoint
    % keyhole remain separately visible.  These two curves are subpieces
    % of K_cut and must not both be added again to the Rose four-source sum.
    fig = figure('Visible', settings.output.figureVisible, 'Color', 'w', ...
        'Position', [40, 80, 1280, 520]);
    for channelIndex = 1:2
        sourceProbabilities = reshape(data.sourceDeltaProbabilities(:, ...
            termIndex, channelIndex, :), numel(energy), 5);
        totalProbability = reshape(data.termDeltaProbabilities(:, ...
            termIndex, channelIndex), [], 1);
        [probabilityLabels, probabilityTotalLabel] = ...
            probability_source_labels( ...
            term, channelIndex, data.sourceNames);

        axesHandle = subplot(1, 2, channelIndex);
        draw_source_lines(axesHandle, energy, sourceProbabilities, ...
            totalProbability, probabilityLabels, acceptedMask, ...
            diagnosticMask, probabilityTotalLabel);
        if channelIndex == 1
            ylabel(axesHandle, ['\Delta T_{left,' term '}']);
            titleText = 'transmission audit';
        else
            ylabel(axesHandle, ['\Delta R_{left,' term '}']);
            titleText = 'reflection audit';
        end
        xlabel(axesHandle, 'External energy E = p^0');
        title(axesHandle, [term ': strict O(\mu^2) raw five-source ' ...
            titleText], ...
            'FontWeight', 'normal');
    end
    files.rawFive.(term) = save_figure(fig, outputDirectory, ...
        [term '_raw_five_source_audit_vs_energy'], settings.output);
end
end

function draw_source_lines(axesHandle, energy, sourceMatrix, total, labels, ...
        acceptedMask, diagnosticMask, totalLabel)
colours = [ ...
    0.0000, 0.4470, 0.7410; ...
    0.4660, 0.6740, 0.1880; ...
    0.8500, 0.3250, 0.0980; ...
    0.4940, 0.1840, 0.5560; ...
    0.9290, 0.6940, 0.1250];
lineStyles = {'-', ':', '-.', '--', '-'};
numberOfSources = size(sourceMatrix, 2);
if numberOfSources < 1 || numberOfSources > size(colours, 1) || ...
        numel(labels) ~= numberOfSources
    error('nqscan:InvalidPlottedSourceCount', ...
        'Source matrices must contain between one and five labelled columns.');
end
hold(axesHandle, 'on');
draw_zero_line(axesHandle, energy);
lineHandles = gobjects(numberOfSources + 1, 1);
legendLabels = cell(numberOfSources + 1, 1);
for sourceIndex = 1:numberOfSources
    values = sourceMatrix(:, sourceIndex);
    values(~acceptedMask) = NaN;
    lineHandles(sourceIndex) = plot(axesHandle, energy, values, ...
        lineStyles{sourceIndex}, 'Color', colours(sourceIndex, :), ...
        'LineWidth', 1.5, 'Marker', 'o', 'MarkerSize', 3);
    legendLabels{sourceIndex} = labels{sourceIndex};
end
formalTotal = total;
formalTotal(~acceptedMask) = NaN;
lineHandles(numberOfSources + 1) = plot(axesHandle, energy, formalTotal, 'k-', ...
    'LineWidth', 2.1);
legendLabels{numberOfSources + 1} = totalLabel;

if any(diagnosticMask)
    diagnosticX = repmat(energy(diagnosticMask), numberOfSources, 1);
    diagnosticY = reshape(sourceMatrix(diagnosticMask, :), [], 1);
    plot(axesHandle, diagnosticX, diagnosticY, ...
        'LineStyle', 'none', 'Marker', 'o', ...
        'MarkerEdgeColor', [0.85, 0.10, 0.10], ...
        'MarkerFaceColor', 'none', 'MarkerSize', 6, ...
        'LineWidth', 1.2, 'HandleVisibility', 'off');
    plot(axesHandle, energy(diagnosticMask), total(diagnosticMask), ...
        'LineStyle', 'none', 'Marker', 'x', ...
        'Color', [0.85, 0.10, 0.10], 'MarkerSize', 7, ...
        'LineWidth', 1.4, 'HandleVisibility', 'off');
end
grid(axesHandle, 'on');
box(axesHandle, 'on');
xlim(axesHandle, x_limits(energy));
legend(axesHandle, lineHandles, legendLabels, 'Location', 'best');
hold(axesHandle, 'off');
end

function [labels, totalLabel] = probability_source_labels( ...
        ~, ~, sourceNames)
labels = cell(numel(sourceNames), 1);
for index = 1:numel(sourceNames)
    name = sourceNames{index};
    switch name
        case 'euclidean'
            labels{index} = 'Euclidean';
        case {'ordinaryPole', 'ordinaryMixedPole'}
            labels{index} = 'mix pole';
        case {'collectivePole', 'collectiveBarrierPole'}
            labels{index} = 'barrier pole';
        case 'branchCutTotal'
            labels{index} = 'branch cut';
        case 'cutBanks'
            labels{index} = 'cut banks';
        case 'endpointKeyhole'
            labels{index} = 'endpoint';
        otherwise
            error('nqscan:UnknownPlottedSource', ...
                'Cannot label analytic source %s.', name);
    end
end
totalLabel = 'total';
end

function draw_zero_line(axesHandle, energy)
limits = x_limits(energy);
plot(axesHandle, limits, [0, 0], '-', 'Color', [0.75, 0.75, 0.75], ...
    'LineWidth', 0.7, 'HandleVisibility', 'off');
end

function limits = x_limits(energy)
energy = energy(isfinite(energy));
if isempty(energy)
    limits = [0, 1];
elseif numel(energy) == 1 || max(energy) == min(energy)
    halfWidth = max(0.05 .* max(abs(energy(1)), 1), 1e-3);
    limits = [energy(1) - halfWidth, energy(1) + halfWidth];
else
    padding = 0.02 .* (max(energy) - min(energy));
    limits = [min(energy) - padding, max(energy) + padding];
end
end

function paths = save_figure(figureHandle, directory, stem, output)
paths = struct('png', '', 'fig', '');
if output.writePng
    paths.png = fullfile(directory, [stem '.png']);
    resolutionFlag = sprintf('-r%d', output.imageResolution);
    print(figureHandle, paths.png, '-dpng', resolutionFlag);
end
if output.writeFig
    paths.fig = fullfile(directory, [stem '.fig']);
    savefig(figureHandle, paths.fig);
end
close(figureHandle);
end
