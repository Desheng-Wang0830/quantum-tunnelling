function cfg = build_configuration(settings, profile)
%BUILD_CONFIGURATION Apply public settings to the frozen v1.9.6 config.

narginchk(2, 2);
settings = nqscan.validate_settings(settings);
if ~isstruct(profile) || ~isscalar(profile) || ...
        ~all(isfield(profile, {'positions', 'strengths', 'N'}))
    error('nqscan:InvalidProfile', ...
        'profile must be returned by nqscan.build_profile.');
end

cfg = run_stage0(false);
cfg.model.mphi = settings.model.mphi;
cfg.model.mPhi = settings.model.mPhi;
cfg.model.mu = settings.model.mu;
cfg.barriers.positions = profile.positions;
cfg.barriers.strengths = profile.strengths;
cfg.referenceEnergy = settings.scan.energyValues(1);

% finalize_configuration validates the unused Stage-12 placeholder grid
% even though this driver never launches a Stage-12 scan.  Rebuild that
% internal grid whenever the masses change so it remains inside the free
% window and cannot reject an otherwise valid custom model.
lower = cfg.model.mphi;
span = cfg.model.mPhi;
cfg.stage12.energyValues = lower + span .* [0.2, 0.5, 0.8];

% This wrapper owns all output.  The engine leaf evaluator writes nothing.
cfg.output.saveMatFile = false;
cfg.output.writeTextReport = false;
cfg.output.writeStage4Figure = false;
cfg.output.writeStage9Figure = false;
cfg.output.writeStage10Figure = false;
cfg.output.writeStage12Figure = false;
cfg.execution.parallel.mode = 'serial';

cfg = ndelta.config.finalize_configuration(cfg);
end
