function options = resolve_options(cfg, orderFactor)
%RESOLVE_OPTIONS Scale the six frozen production quadrature orders.

narginchk(2, 2);
validateattributes(orderFactor, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'orderFactor');
options = ndelta.integration.resolve_options(cfg, struct());
orderNames = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
for index = 1:numel(orderNames)
    name = orderNames{index};
    options.(name) = max(4, round(orderFactor .* options.(name)));
end
options = ndelta.integration.resolve_options(cfg, options);
end
