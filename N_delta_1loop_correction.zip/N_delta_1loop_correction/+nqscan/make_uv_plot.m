function paths = make_uv_plot(result, outputDirectory)
%MAKE_UV_PLOT Plot the complete first-order channel-space residual.

narginchk(2, 2);
data = nqscan.ensure_uv_schema(result.data, result.settings.model.mu);
settings = result.settings;
paths = struct('png', '', 'fig', '');
energy = data.externalEnergy(:);
tested = logical(data.uvAuditTested(:));
if ~any(tested)
    return;
end
accepted = tested & data.uvOneLoopAccepted(:) == 1;
rejected = tested & ~accepted;

fig = figure('Visible', settings.output.figureVisible, 'Color', 'w', ...
    'Position', [60, 60, 1240, 900]);

axesHandle = subplot(2, 2, 1);
hold(axesHandle, 'on');
plot_component(axesHandle, energy, data.uLeftResidual, accepted, ...
    rejected, [0.0000, 0.4470, 0.7410], '-', 'U_L');
plot_component(axesHandle, energy, data.uRightResidual, accepted, ...
    rejected, [0.8500, 0.3250, 0.0980], '--', 'U_R');
draw_zero_line(axesHandle, energy);
grid(axesHandle, 'on');
box(axesHandle, 'on');
xlabel(axesHandle, 'External energy E = p^0');
ylabel(axesHandle, 'Diagonal residual at O(\mu^2)');
title(axesHandle, 'U_L and U_R', 'FontWeight', 'normal');
legend(axesHandle, 'Location', 'best');
hold(axesHandle, 'off');

axesHandle = subplot(2, 2, 2);
hold(axesHandle, 'on');
plot_component(axesHandle, energy, real(data.v12Residual), accepted, ...
    rejected, [0.4940, 0.1840, 0.5560], '-', 'Re V_{12}');
plot_component(axesHandle, energy, imag(data.v12Residual), accepted, ...
    rejected, [0.4660, 0.6740, 0.1880], '--', 'Im V_{12}');
draw_zero_line(axesHandle, energy);
grid(axesHandle, 'on');
box(axesHandle, 'on');
xlabel(axesHandle, 'External energy E = p^0');
ylabel(axesHandle, 'Off-diagonal residual at O(\mu^2)');
title(axesHandle, 'Complex V_{12}', 'FontWeight', 'normal');
legend(axesHandle, 'Location', 'best');
hold(axesHandle, 'off');

axesHandle = subplot(2, 2, 3);
hold(axesHandle, 'on');
absoluteMatrix = [abs(data.uLeftResidual), abs(data.uRightResidual), ...
    abs(data.v12Residual)];
displayFloor = residual_display_floor(absoluteMatrix(tested, :));
styles = {'-', '--', '-.'};
colours = [0.0000, 0.4470, 0.7410; ...
    0.8500, 0.3250, 0.0980; 0.4940, 0.1840, 0.5560];
labels = {'|U_L|', '|U_R|', '|V_{12}|'};
for index = 1:3
    values = max(absoluteMatrix(:, index), displayFloor);
    values(~tested) = NaN;
    semilogy(axesHandle, energy, values, styles{index}, ...
        'Color', colours(index, :), 'LineWidth', 1.5, ...
        'Marker', 'o', 'MarkerSize', 3, 'DisplayName', labels{index});
end
grid(axesHandle, 'on');
box(axesHandle, 'on');
xlabel(axesHandle, 'External energy E = p^0');
ylabel(axesHandle, 'Absolute residual');
title(axesHandle, sprintf( ...
    'Residual magnitudes (display floor %.1e)', displayFloor), ...
    'FontWeight', 'normal');
legend(axesHandle, 'Location', 'best');
hold(axesHandle, 'off');

axesHandle = subplot(2, 2, 4);
hold(axesHandle, 'on');
ratio = data.uvGateRatio(:);
ratioFloor = max(1e-16, residual_display_floor(ratio(tested)));
displayRatio = max(abs(ratio), ratioFloor);
displayRatio(~tested) = NaN;
semilogy(axesHandle, energy, displayRatio, '-o', ...
    'Color', [0.3010, 0.7450, 0.9330], 'LineWidth', 1.6, ...
    'MarkerSize', 3, 'DisplayName', ...
    '||M||_F / (absolute + relative gate)');
limits = x_limits(energy);
plot(axesHandle, limits, [1, 1], 'k--', 'LineWidth', 1.2, ...
    'DisplayName', 'acceptance boundary');
if any(rejected)
    semilogy(axesHandle, energy(rejected), displayRatio(rejected), 'rx', ...
        'MarkerSize', 8, 'LineWidth', 1.5, ...
        'DisplayName', 'rejected U/V gate');
end
grid(axesHandle, 'on');
box(axesHandle, 'on');
xlabel(axesHandle, 'External energy E = p^0');
ylabel(axesHandle, 'Dimensionless gate ratio');
title(axesHandle, 'Full 2-by-2 first-order gate', ...
    'FontWeight', 'normal');
legend(axesHandle, 'Location', 'best');
hold(axesHandle, 'off');

if all(data.symmetricUVFormulaApplicable(tested))
    overallTitle = sprintf([ ...
        'Centred mirror-symmetric audit: U_L=U_R=U, ' ...
        'V_{12}=V is real, N=%d'], data.N);
else
    overallTitle = sprintf([ ...
        'General arbitrary-N audit: U_L, U_R and complex V_{12}, N=%d'], ...
        data.N);
end
add_overall_title(fig, overallTitle);
paths = save_figure(fig, outputDirectory, ...
    'UV_unitarity_residuals_vs_energy', settings.output);
end

function plot_component(axesHandle, energy, values, accepted, rejected, ...
        colour, lineStyle, label)
values = reshape(values, [], 1);
formal = values;
formal(~accepted) = NaN;
plot(axesHandle, energy, formal, lineStyle, 'Color', colour, ...
    'LineWidth', 1.5, 'Marker', 'o', 'MarkerSize', 3, ...
    'DisplayName', [label ' accepted']);
if any(rejected)
    plot(axesHandle, energy(rejected), values(rejected), 'x', ...
        'Color', colour, 'MarkerSize', 8, 'LineWidth', 1.5, ...
        'DisplayName', [label ' rejected']);
end
end

function floorValue = residual_display_floor(values)
values = abs(values(isfinite(values)));
if isempty(values) || max(values) == 0
    floorValue = eps;
else
    floorValue = max(realmin, max(values) .* 1e-14);
end
end

function draw_zero_line(axesHandle, energy)
limits = x_limits(energy);
plot(axesHandle, limits, [0, 0], 'k:', 'LineWidth', 0.8, ...
    'HandleVisibility', 'off');
xlim(axesHandle, limits);
end

function limits = x_limits(energy)
energy = energy(isfinite(energy));
if isempty(energy)
    limits = [0, 1];
elseif numel(energy) == 1 || max(energy) == min(energy)
    halfWidth = max(0.05 .* max(abs(energy(1)), 1), 1e-3);
    limits = [energy(1) - halfWidth, energy(1) + halfWidth];
else
    padding = 0.02 .* (max(energy) - min(energy));
    limits = [min(energy) - padding, max(energy) + padding];
end
end

function add_overall_title(figureHandle, textValue)
if exist('sgtitle', 'file') == 2
    sgtitle(figureHandle, textValue, 'FontWeight', 'normal');
else
    annotation(figureHandle, 'textbox', [0, 0.955, 1, 0.04], ...
        'String', textValue, 'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', 'EdgeColor', 'none', ...
        'FontWeight', 'normal');
end
end

function paths = save_figure(figureHandle, directory, stem, output)
paths = struct('png', '', 'fig', '');
if output.writePng
    paths.png = fullfile(directory, [stem '.png']);
    resolutionFlag = sprintf('-r%d', output.imageResolution);
    print(figureHandle, paths.png, '-dpng', resolutionFlag);
end
if output.writeFig
    paths.fig = fullfile(directory, [stem '.fig']);
    savefig(figureHandle, paths.fig);
end
close(figureHandle);
end
