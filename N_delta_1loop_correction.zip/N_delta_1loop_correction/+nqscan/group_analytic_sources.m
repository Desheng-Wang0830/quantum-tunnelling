function grouped = group_analytic_sources(data)
%GROUP_ANALYTIC_SOURCES Reassemble the four Rose contour contributions.
%
% The engine stores five mutually exclusive audit sources because the
% branch sector is split into cut banks and its endpoint keyhole.  The
% paper-level four-piece decomposition is
%
%   K_E, K_star, K_B, K_cut,
%
% where K_cut contains both banks and endpoint exactly once.

narginchk(1, 1);
required = {'sourceNames', 'sourceReducedKernels', ...
    'sourceDeltaProbabilities', 'termReducedKernels', ...
    'termDeltaProbabilities'};
if ~isstruct(data) || ~isscalar(data) || ~all(isfield(data, required))
    error('nqscan:InvalidSourcePayload', ...
        'A complete extracted source payload is required.');
end

euclideanIndex = unique_index(data.sourceNames, 'euclidean');
ordinaryIndex = unique_index(data.sourceNames, 'ordinaryPole');
collectiveIndex = unique_index(data.sourceNames, 'collectivePole');
cutBankIndex = unique_index(data.sourceNames, 'cutBanks');
endpointIndex = unique_index(data.sourceNames, 'endpointKeyhole');

sourceShape = size(data.sourceReducedKernels);
if numel(sourceShape) < 4 || sourceShape(4) ~= numel(data.sourceNames) || ...
        ~isequal(size(data.sourceDeltaProbabilities), sourceShape)
    error('nqscan:InvalidSourceArrayShape', ...
        ['sourceReducedKernels and sourceDeltaProbabilities must have ' ...
         'identical E-by-term-by-channel-by-source shapes.']);
end

reduced = complex(zeros(sourceShape(1), sourceShape(2), ...
    sourceShape(3), 4));
probability = zeros(sourceShape(1), sourceShape(2), sourceShape(3), 4);

reduced(:, :, :, 1) = data.sourceReducedKernels(:, :, :, euclideanIndex);
reduced(:, :, :, 2) = data.sourceReducedKernels(:, :, :, ordinaryIndex);
reduced(:, :, :, 3) = data.sourceReducedKernels(:, :, :, collectiveIndex);
reduced(:, :, :, 4) = data.sourceReducedKernels(:, :, :, cutBankIndex) + ...
    data.sourceReducedKernels(:, :, :, endpointIndex);

probability(:, :, :, 1) = ...
    data.sourceDeltaProbabilities(:, :, :, euclideanIndex);
probability(:, :, :, 2) = ...
    data.sourceDeltaProbabilities(:, :, :, ordinaryIndex);
probability(:, :, :, 3) = ...
    data.sourceDeltaProbabilities(:, :, :, collectiveIndex);
probability(:, :, :, 4) = ...
    data.sourceDeltaProbabilities(:, :, :, cutBankIndex) + ...
    data.sourceDeltaProbabilities(:, :, :, endpointIndex);

kernelResidual = sum(reduced, 4) - data.termReducedKernels;
probabilityResidual = sum(probability, 4) - data.termDeltaProbabilities;
kernelScale = 1 + abs(data.termReducedKernels);
probabilityScale = 1 + abs(data.termDeltaProbabilities);
maximumKernelClosure = finite_max(abs(kernelResidual) ./ kernelScale);
maximumProbabilityClosure = finite_max( ...
    abs(probabilityResidual) ./ probabilityScale);

tolerance = 5e-9;
if maximumKernelClosure > tolerance || ...
        maximumProbabilityClosure > tolerance
    error('nqscan:AnalyticSourceClosureFailure', ...
        ['Rose four-source grouping does not close: kernel %.3e, ' ...
         'probability %.3e.'], maximumKernelClosure, ...
        maximumProbabilityClosure);
end

grouped = struct();
grouped.names = {'euclidean', 'ordinaryMixedPole', ...
    'collectiveBarrierPole', 'branchCutTotal'};
grouped.symbols = {'K_E', 'K_star', 'K_B', 'K_cut'};
grouped.labels = {'Euclidean', ...
    'mix pole', ...
    'barrier pole', ...
    'branch cut'};
grouped.reducedKernels = reduced;
grouped.deltaProbabilities = probability;
grouped.termReducedKernels = data.termReducedKernels;
grouped.termDeltaProbabilities = data.termDeltaProbabilities;
grouped.branchBankSourceIndex = cutBankIndex;
grouped.endpointSourceIndex = endpointIndex;
grouped.endpointIncludedExactlyOnce = true;
grouped.ordinaryPoleContractuallyZero = ...
    finite_max(abs(reduced(:, :, :, 2))) <= 1e-14 && ...
    finite_max(abs(probability(:, :, :, 2))) <= 1e-14;
grouped.maximumKernelClosure = maximumKernelClosure;
grouped.maximumProbabilityClosure = maximumProbabilityClosure;
grouped.closureTolerance = tolerance;
grouped.strictProbabilityOrder = 'O(mu^2)';
end

function index = unique_index(names, target)
matches = find(strcmp(names, target));
if numel(matches) ~= 1
    error('nqscan:MissingOrDuplicateSource', ...
        'Source %s must occur exactly once.', target);
end
index = matches;
end

function value = finite_max(values)
values = values(isfinite(values));
if isempty(values)
    value = 0;
else
    value = max(values(:));
end
end
