function files = write_outputs(result, outputDirectory)
%WRITE_OUTPUTS Write CSV tables, figures and a compact validation report.

narginchk(2, 2);
settings = result.settings;
files = struct();
files.outputDirectory = outputDirectory;
files.checkpoint = fullfile(outputDirectory, 'energy_scan_checkpoint.mat');
files.mat = '';
files.tables = struct();
files.figures = struct();
files.report = '';

if settings.output.writeCsv
    files.tables = nqscan.write_tables(result, outputDirectory);
end
if settings.output.writePng || settings.output.writeFig
    files.figures = nqscan.make_plots(result, outputDirectory);
end
if settings.output.writeReport
    files.report = fullfile(outputDirectory, 'SCAN_REPORT.txt');
    nqscan.write_report(files.report, result, files);
end
end
