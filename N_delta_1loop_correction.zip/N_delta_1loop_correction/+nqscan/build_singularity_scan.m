function singularity = build_singularity_scan(settings, data, baseCfg)
%BUILD_SINGULARITY_SCAN Reconstruct exact q^0-plane cuts and pole paths.
%
% This is pure post-processing.  It calls the verified physical-sheet
% geometry helpers but never repeats a G1--G4 integration.

narginchk(3, 3);
if ~isstruct(data) || ~isscalar(data) || ...
        ~all(isfield(data, {'externalEnergy', 'modeAlpha', ...
        'modeQPerpCritical', 'modeStable', 'modeSemisimple', ...
        'numberOfCollectiveModes'}))
    error('nqscan:IncompleteSingularitySourceData', ...
        'Extracted mode and external-energy arrays are required.');
end
if ~isstruct(baseCfg) || ~isscalar(baseCfg) || ...
        ~all(isfield(baseCfg, {'model', 'sheet', 'tolerances'}))
    error('nqscan:IncompleteSingularityConfiguration', ...
        'The scan base configuration is required.');
end

options = resolve_plot_options(settings, baseCfg, data);
energy = data.externalEnergy(:);
numberOfPoints = numel(energy);
numberOfModes = size(data.modeAlpha, 2);
qPerp = options.referenceQPerp;
epsilon = baseCfg.sheet.epsilon;
model = baseCfg.model;
cutParameter = linspace(0, options.cutParameterMax, options.cutSamples);

branchPointNames = {'omegaLeft', 'omegaRight', ...
    'kappaILeft', 'kappaIRight'};
cutNames = branchPointNames;
branchPoints = complex(NaN(numberOfPoints, 4), ...
    NaN(numberOfPoints, 4));
cutCurves = complex(NaN(numberOfPoints, 4, options.cutSamples), ...
    NaN(numberOfPoints, 4, options.cutSamples));
cutRadicandResidual = NaN(numberOfPoints, 4);
kappaLeftCutSwept = false(numberOfPoints, 1);
kappaLeftCutSweepParameterMax = NaN(numberOfPoints, 1);
kappaLeftCutSweptMask = false(numberOfPoints, options.cutSamples);
kappaLeftCutSweepCrossing = complex(NaN(numberOfPoints, 1), ...
    NaN(numberOfPoints, 1));
hasOpenKappaLeftCutSweep = false(numberOfPoints, 1);

collectiveK = complex(NaN(numberOfPoints, numberOfModes), ...
    NaN(numberOfPoints, numberOfModes));
collectiveLeft = collectiveK;
collectiveRight = collectiveK;
collectiveLeftAccepted = false(numberOfPoints, numberOfModes);
collectiveRightAccepted = false(numberOfPoints, numberOfModes);
collectiveLeftResidual = NaN(numberOfPoints, numberOfModes);
collectiveRightResidual = NaN(numberOfPoints, numberOfModes);

mixedCandidates = complex(NaN(numberOfPoints, 2), ...
    NaN(numberOfPoints, 2));
mixedCandidateResidual = NaN(numberOfPoints, 2);
mixedCandidateAccepted = false(numberOfPoints, 2);

qPerpTrajectoryParameter = linspace(0, 1, ...
    options.qPerpTrajectorySamples);
qPerpTrajectoryMaximum = NaN(numberOfPoints, 1);
qPerpCutSectorBoundary = NaN(numberOfPoints, 1);
qPerpCutSectorBranchPoint = complex(NaN(numberOfPoints, 1), ...
    NaN(numberOfPoints, 1));
hasOpenQPerpCutSector = false(numberOfPoints, 1);
qPerpTrajectoryValues = NaN(numberOfPoints, ...
    options.qPerpTrajectorySamples);
qPerpBranchPoints = complex(NaN(numberOfPoints, 4, ...
    options.qPerpTrajectorySamples), NaN(numberOfPoints, 4, ...
    options.qPerpTrajectorySamples));
qPerpCollectiveLeft = complex(NaN(numberOfPoints, numberOfModes, ...
    options.qPerpTrajectorySamples), NaN(numberOfPoints, numberOfModes, ...
    options.qPerpTrajectorySamples));
qPerpCollectiveRight = qPerpCollectiveLeft;
qPerpCollectiveLeftAccepted = false(numberOfPoints, numberOfModes, ...
    options.qPerpTrajectorySamples);
qPerpCollectiveLeftResidual = NaN(numberOfPoints, numberOfModes, ...
    options.qPerpTrajectorySamples);
qPerpCollectiveRightResidual = qPerpCollectiveLeftResidual;
qPerpCollectiveLeftBoundary = complex( ...
    NaN(numberOfPoints, numberOfModes), ...
    NaN(numberOfPoints, numberOfModes));
qPerpCollectiveRightBoundary = qPerpCollectiveLeftBoundary;
qPerpCollectiveLeftBoundaryResidual = ...
    NaN(numberOfPoints, numberOfModes);
qPerpCollectiveRightBoundaryResidual = ...
    NaN(numberOfPoints, numberOfModes);

for pointIndex = 1:numberOfPoints
    E = energy(pointIndex);
    points = ndelta.sheet.branch_points(qPerp, E, model, epsilon);
    cuts = ndelta.sheet.outward_cut_points( ...
        cutParameter, qPerp, E, model, epsilon);
    branchPoints(pointIndex, :) = [points.omega.left, ...
        points.omega.right, points.kappaI.left, points.kappaI.right];
    cutCurves(pointIndex, 1, :) = reshape(cuts.omega.left, 1, 1, []);
    cutCurves(pointIndex, 2, :) = reshape(cuts.omega.right, 1, 1, []);
    cutCurves(pointIndex, 3, :) = reshape(cuts.kappaI.left, 1, 1, []);
    cutCurves(pointIndex, 4, :) = reshape(cuts.kappaI.right, 1, 1, []);
    cutRadicandResidual(pointIndex, :) = [ ...
        max(abs(cuts.omegaLeftResidual(:))), ...
        max(abs(cuts.omegaRightResidual(:))), ...
        max(abs(cuts.kappaILeftResidual(:))), ...
        max(abs(cuts.kappaIRightResidual(:)))];
    finiteCorrection = (epsilon ./ (2 .* E)).^2;
    P = sqrt((E - model.mphi) .* (E + model.mphi));
    sweepParameterSquared = P.^2 - qPerp.^2 - finiteCorrection;
    if sweepParameterSquared > 0
        hasOpenKappaLeftCutSweep(pointIndex) = true;
        kappaLeftCutSweepParameterMax(pointIndex) = ...
            sqrt(sweepParameterSquared);
        crossing = ndelta.sheet.outward_cut_points( ...
            kappaLeftCutSweepParameterMax(pointIndex), ...
            qPerp, E, model, epsilon);
        kappaLeftCutSweepCrossing(pointIndex) = crossing.kappaI.left;
    end
    sweptMask = cutParameter.^2 < sweepParameterSquared & ...
        real(cuts.kappaI.left) > 0 & imag(cuts.kappaI.left) > 0;
    kappaLeftCutSweptMask(pointIndex, :) = sweptMask;
    kappaLeftCutSwept(pointIndex) = any(sweptMask);

    pointCfg = baseCfg;
    pointCfg.referenceEnergy = E;
    pointCfg = ndelta.config.finalize_configuration(pointCfg);
    mixed = ndelta.singularity.mixed_candidates(qPerp, pointCfg);
    for candidateIndex = 1:2
        mixedCandidates(pointIndex, candidateIndex) = ...
            mixed.candidates(candidateIndex).q0;
        mixedCandidateResidual(pointIndex, candidateIndex) = ...
            mixed.candidates(candidateIndex).unsquaredResidual;
        mixedCandidateAccepted(pointIndex, candidateIndex) = ...
            mixed.candidates(candidateIndex).accepted;
    end

    localModeCount = min(data.numberOfCollectiveModes(pointIndex), ...
        numberOfModes);
    for modeIndex = 1:localModeCount
        alpha = data.modeAlpha(pointIndex, modeIndex);
        if ~isfinite(alpha)
            continue;
        end
        offset = sqrt(qPerp.^2 + model.mphi.^2 - alpha.^2 ...
            - 1i .* epsilon);
        qLeft = E - offset;
        qRight = E + offset;
        K = 1i .* alpha;
        leftRoots = ndelta.sheet.physical_roots( ...
            qLeft, qPerp, E, model, epsilon);
        rightRoots = ndelta.sheet.physical_roots( ...
            qRight, qPerp, E, model, epsilon);
        leftResidual = abs(leftRoots.kappaI - K) ./ (1 + abs(K));
        rightResidual = abs(rightRoots.kappaI - K) ./ (1 + abs(K));
        isStable = data.modeStable(pointIndex, modeIndex);
        isSemisimple = data.modeSemisimple(pointIndex, modeIndex);
        inSupport = qPerp < ...
            data.modeQPerpCritical(pointIndex, modeIndex);
        inFirstQuadrant = real(qLeft) > 0 && imag(qLeft) > 0;

        collectiveK(pointIndex, modeIndex) = K;
        collectiveLeft(pointIndex, modeIndex) = qLeft;
        collectiveRight(pointIndex, modeIndex) = qRight;
        collectiveLeftResidual(pointIndex, modeIndex) = leftResidual;
        collectiveRightResidual(pointIndex, modeIndex) = rightResidual;
        collectiveLeftAccepted(pointIndex, modeIndex) = isStable && ...
            isSemisimple && inSupport && inFirstQuadrant && ...
            leftResidual <= baseCfg.tolerances.collectiveResidual;
        % The right solution is a physical-sheet candidate but is never
        % swept by the positive modified-Wick deformation.
        collectiveRightAccepted(pointIndex, modeIndex) = false;

        qCritical = data.modeQPerpCritical(pointIndex, modeIndex);
        if isfinite(qCritical) && qCritical > 0
            boundaryOffset = sqrt(qCritical.^2 + model.mphi.^2 ...
                - alpha.^2 - 1i .* epsilon);
            boundaryLeft = E - boundaryOffset;
            boundaryRight = E + boundaryOffset;
            boundaryLeftRoots = ndelta.sheet.physical_roots( ...
                boundaryLeft, qCritical, E, model, epsilon);
            boundaryRightRoots = ndelta.sheet.physical_roots( ...
                boundaryRight, qCritical, E, model, epsilon);
            qPerpCollectiveLeftBoundary(pointIndex, modeIndex) = ...
                boundaryLeft;
            qPerpCollectiveRightBoundary(pointIndex, modeIndex) = ...
                boundaryRight;
            qPerpCollectiveLeftBoundaryResidual(pointIndex, modeIndex) = ...
                abs(boundaryLeftRoots.kappaI - K) ./ (1 + abs(K));
            qPerpCollectiveRightBoundaryResidual(pointIndex, modeIndex) = ...
                abs(boundaryRightRoots.kappaI - K) ./ (1 + abs(K));
        end
    end

    supportBoundaries = data.modeQPerpCritical( ...
        pointIndex, 1:localModeCount);
    supportBoundaries = supportBoundaries( ...
        isfinite(supportBoundaries) & supportBoundaries > 0);
    qPerpBoundarySquared = P.^2 - finiteCorrection;
    boundaryCandidates = [qPerp, supportBoundaries(:).'];
    if qPerpBoundarySquared > 0
        qPerpSweepBoundary = sqrt(qPerpBoundarySquared);
        qPerpCutSectorBoundary(pointIndex) = qPerpSweepBoundary;
        hasOpenQPerpCutSector(pointIndex) = true;
        boundaryPoints = ndelta.sheet.branch_points( ...
            qPerpSweepBoundary, E, model, epsilon);
        qPerpCutSectorBranchPoint(pointIndex) = ...
            boundaryPoints.kappaI.left;
        boundaryCandidates(end + 1) = qPerpSweepBoundary; %#ok<AGROW>
    end
    qPerpMaximum = max(boundaryCandidates);
    if ~(isfinite(qPerpMaximum) && qPerpMaximum > 0)
        qPerpMaximum = max(P, 1e-6);
    end
    qPerpPath = qPerpTrajectoryParameter .* qPerpMaximum;
    qPerpTrajectoryMaximum(pointIndex) = qPerpMaximum;
    qPerpTrajectoryValues(pointIndex, :) = qPerpPath;
    for qIndex = 1:numel(qPerpPath)
        qValue = qPerpPath(qIndex);
        pathPoints = ndelta.sheet.branch_points( ...
            qValue, E, model, epsilon);
        qPerpBranchPoints(pointIndex, :, qIndex) = [ ...
            pathPoints.omega.left, pathPoints.omega.right, ...
            pathPoints.kappaI.left, pathPoints.kappaI.right];
        for modeIndex = 1:localModeCount
            alpha = data.modeAlpha(pointIndex, modeIndex);
            if ~isfinite(alpha)
                continue;
            end
            offset = sqrt(qValue.^2 + model.mphi.^2 - alpha.^2 ...
                - 1i .* epsilon);
            qLeft = E - offset;
            qRight = E + offset;
            K = 1i .* alpha;
            roots = ndelta.sheet.physical_roots( ...
                qLeft, qValue, E, model, epsilon);
            rightRoots = ndelta.sheet.physical_roots( ...
                qRight, qValue, E, model, epsilon);
            residual = abs(roots.kappaI - K) ./ (1 + abs(K));
            rightResidual = abs(rightRoots.kappaI - K) ./ ...
                (1 + abs(K));
            inSupport = qValue < ...
                data.modeQPerpCritical(pointIndex, modeIndex);
            inFirstQuadrant = real(qLeft) > 0 && imag(qLeft) > 0;
            qPerpCollectiveLeft(pointIndex, modeIndex, qIndex) = qLeft;
            qPerpCollectiveRight(pointIndex, modeIndex, qIndex) = qRight;
            qPerpCollectiveLeftResidual( ...
                pointIndex, modeIndex, qIndex) = residual;
            qPerpCollectiveRightResidual( ...
                pointIndex, modeIndex, qIndex) = rightResidual;
            qPerpCollectiveLeftAccepted( ...
                pointIndex, modeIndex, qIndex) = ...
                data.modeStable(pointIndex, modeIndex) && ...
                data.modeSemisimple(pointIndex, modeIndex) && ...
                inSupport && inFirstQuadrant && ...
                residual <= baseCfg.tolerances.collectiveResidual;
        end
    end
end

cutEndpointResidual = zeros(numberOfPoints, 4);
for cutIndex = 1:4
    cutEndpoint = reshape(cutCurves(:, cutIndex, 1), [], 1);
    cutEndpointResidual(:, cutIndex) = ...
        abs(cutEndpoint - branchPoints(:, cutIndex));
end

singularity = struct();
singularity.plane = 'internal_complex_q0';
singularity.externalScanVariable = 'E_equals_p0';
singularity.qPerpFixed = qPerp;
singularity.epsilon = epsilon;
singularity.branchPointNames = branchPointNames;
singularity.branchPoints = branchPoints;
singularity.cutNames = cutNames;
singularity.cutParameter = cutParameter;
singularity.cutCurves = cutCurves;
singularity.cutRadicandResidual = cutRadicandResidual;
singularity.kappaLeftCutSwept = kappaLeftCutSwept;
singularity.kappaLeftCutSweepParameterMax = ...
    kappaLeftCutSweepParameterMax;
singularity.kappaLeftCutSweptMask = kappaLeftCutSweptMask;
singularity.kappaLeftCutSweepCrossing = kappaLeftCutSweepCrossing;
singularity.hasOpenKappaLeftCutSweep = hasOpenKappaLeftCutSweep;
singularity.collectiveK = collectiveK;
singularity.collectiveLeft = collectiveLeft;
singularity.collectiveRight = collectiveRight;
singularity.collectiveLeftAccepted = collectiveLeftAccepted;
singularity.collectiveRightAccepted = collectiveRightAccepted;
singularity.collectiveLeftResidual = collectiveLeftResidual;
singularity.collectiveRightResidual = collectiveRightResidual;
singularity.mixedCandidates = mixedCandidates;
singularity.mixedCandidateResidual = mixedCandidateResidual;
singularity.mixedCandidateAccepted = mixedCandidateAccepted;
singularity.mixedCandidateTermScope = 'G1_squared_candidate_audit_only';
singularity.snapshotEnergyIndices = options.snapshotEnergyIndices;
singularity.qPerpTrajectoryEnergyIndices = options.snapshotEnergyIndices;
singularity.qPerpTrajectoryParameter = qPerpTrajectoryParameter;
singularity.qPerpTrajectoryMaximum = qPerpTrajectoryMaximum;
singularity.qPerpCutSectorBoundary = qPerpCutSectorBoundary;
singularity.qPerpCutSectorBranchPoint = qPerpCutSectorBranchPoint;
singularity.hasOpenQPerpCutSector = hasOpenQPerpCutSector;
singularity.qPerpTrajectoryValues = qPerpTrajectoryValues;
singularity.qPerpBranchPoints = qPerpBranchPoints;
singularity.qPerpCollectiveLeft = qPerpCollectiveLeft;
singularity.qPerpCollectiveRight = qPerpCollectiveRight;
singularity.qPerpCollectiveLeftAccepted = qPerpCollectiveLeftAccepted;
singularity.qPerpCollectiveLeftResidual = qPerpCollectiveLeftResidual;
singularity.qPerpCollectiveRightResidual = qPerpCollectiveRightResidual;
singularity.qPerpCollectiveLeftBoundary = ...
    qPerpCollectiveLeftBoundary;
singularity.qPerpCollectiveRightBoundary = ...
    qPerpCollectiveRightBoundary;
singularity.qPerpCollectiveLeftBoundaryResidual = ...
    qPerpCollectiveLeftBoundaryResidual;
singularity.qPerpCollectiveRightBoundaryResidual = ...
    qPerpCollectiveRightBoundaryResidual;
singularity.maximumCutEndpointResidual = ...
    finite_max(cutEndpointResidual);
singularity.maximumCutRadicandResidual = ...
    finite_max(cutRadicandResidual);
singularity.maximumAcceptedCollectiveResidual = finite_max( ...
    collectiveLeftResidual(collectiveLeftAccepted));
singularity.collectiveKIsGeometryFixed = true;
singularity.mappedQ0PoleMovesWithExternalEnergy = true;
singularity.mappedQ0PoleLocusVariesWithQPerp = true;
singularity.rightCollectiveCandidateIsNotSwept = true;
singularity.ordinaryMixedPoleContributionExactlyZero = ...
    ~any(mixedCandidateAccepted(:));
singularity.G2G3OrdinaryPoleContributionExactlyZero = true;
singularity.G4OrdinaryPoleDenominatorAbsent = true;
singularity.q3PolesIncluded = false;
singularity.q3ExclusionReason = ...
    ['q3 poles require an additional chosen internal q0 contour node; ' ...
     'they are not uniquely defined by an E scan after q0 integration'];
singularity.formulas = struct( ...
    'omegaBranchPoints', ...
        'q0=+/-sqrt(qPerp^2+mPhi^2-i*epsilon)', ...
    'kappaIBranchPoints', ...
        'q0=E+/-sqrt(qPerp^2+mphi^2-i*epsilon)', ...
    'collectiveMappedPole', ...
        'q0=E+/-sqrt(qPerp^2+mphi^2-alpha^2-i*epsilon)');
end

function options = resolve_plot_options(settings, cfg, data)
options = struct();
numberOfPoints = numel(data.externalEnergy);
if isfield(settings, 'singularity') && ...
        isstruct(settings.singularity) && isscalar(settings.singularity)
    value = settings.singularity;
else
    value = struct();
end
options.referenceQPerp = field_or(value, 'referenceQPerp', ...
    cfg.sheet.referenceQPerp);
options.cutParameterMax = field_or(value, 'cutParameterMax', ...
    cfg.sheet.cutParameterMax);
options.cutSamples = field_or(value, 'cutSamples', cfg.sheet.cutSamples);
options.qPerpTrajectorySamples = field_or( ...
    value, 'qPerpTrajectorySamples', 301);
indices = field_or(value, 'snapshotEnergyIndices', zeros(1, 0));
if isempty(indices)
    candidates = default_snapshot_candidates(data, numberOfPoints);
    candidatePositions = unique([1, ...
        round((numel(candidates) + 1) ./ 2), numel(candidates)], ...
        'stable');
    indices = candidates(candidatePositions);
end
options.snapshotEnergyIndices = indices(:).';
end

function candidates = default_snapshot_candidates(data, numberOfPoints)
candidates = zeros(1, 0);
maskNames = {'accepted', 'numericalAccepted', 'completed'};
for maskIndex = 1:numel(maskNames)
    name = maskNames{maskIndex};
    if isfield(data, name) && numel(data.(name)) == numberOfPoints
        candidates = find(logical(data.(name)(:))).';
        if ~isempty(candidates)
            return;
        end
    end
end
candidates = 1:numberOfPoints;
end

function value = field_or(structure, name, fallback)
if isfield(structure, name)
    value = structure.(name);
else
    value = fallback;
end
end

function value = finite_max(values)
values = values(isfinite(values));
if isempty(values)
    value = 0;
else
    value = max(values(:));
end
end
