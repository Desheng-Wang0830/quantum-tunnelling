function cfg = run_stage0(showSummary)
%RUN_STAGE0 Single user-editable entry point for the N-delta project.
%
%   CFG = RUN_STAGE0 validates the physical model and the complete list of
%   delta centres.  Edit only the USER-EDITABLE SETTINGS block below.
%
%   The present cumulative release implements Stages 0--12:
%       Stage 0  configuration and conventions,
%       Stage 1  on-shell kinematics and centre geometry,
%       Stage 2  Gamma_N, tau_N, B_N and exact tree amplitudes,
%       Stage 3  N=1 and Rose N=2 regression benchmarks,
%       Stage 4  outward-cut physical-sheet roots and continuation,
%       Stage 5  directed G1 longitudinal q3 kernel I_1(d),
%       Stage 6  pointwise centre-pair contraction and distance cache,
%       Stage 7  collective spectrum and fixed-qPerp contour ledger,
%       Stage 8  qPerp integration of every analytic source,
%       Stage 9  LSZ normalisation and strict O(mu^2) probabilities,
%       Stage 10 convergence and independent contour diagnostics,
%       Stage 11 complete arbitrary-N Rose G1--G4 correction,
%       Stage 12 finite-epsilon contour audit, energy scan and formal
%                fixed-support N>=3 physical scan.

if nargin < 1
    showSummary = true;
end

projectRoot = fileparts(mfilename('fullpath'));
addpath(projectRoot);

%% ================= USER-EDITABLE SETTINGS ==========================
% 1. Scalar-field model.  mphi is the incident-field mass, mPhi is the
% heavy-field mass and mu is the one-loop coupling.  Stages 4--8 use both
% masses but remain independent of mu.  Stage 9 inserts mu^2 exactly once.
cfg.model.mphi = 0.2;
cfg.model.mPhi = 1.4;
cfg.model.mu = 0.1;

% 2. External on-shell energy p^0.  The default stays in the elastic
% window mphi < p^0 < mphi+mPhi used by the previous single-delta code.
cfg.referenceEnergy = 0.30;

% 3. N-delta geometry and signed strengths.
%
%       V(z) = sum_a g_a delta(z-z_a)
%
% g_a>0 is repulsive, g_a<0 is attractive and g_a=0 removes that centre.
% The default is Rose's symmetric double-delta geometry with total signed
% strength g=-0.3 and separation b=1.  To change N, edit these two arrays;
% they must have the same length.  Centre labels need not be sorted.
cfg.barriers.positions = [-0.5, 0.5];
cfg.barriers.strengths = [-0.15, -0.15];

% 4. Numerical contract tolerances shared by tree, sheet and Stage 5--6
% diagnostics.
cfg.tolerances.distanceMerge = 1e-12;
cfg.tolerances.amplitude = 5e-12;
cfg.tolerances.matrix = 5e-12;
cfg.tolerances.unitarity = 5e-11;
cfg.tolerances.coalescence = 1e-8;
cfg.tolerances.nearSingularRcond = sqrt(eps);

% 5. Stage 4 physical-sheet controls.  epsilon is the explicit Feynman
% regulator, has units of mass^2 and must remain strictly positive.
% referenceQPerp is only
% used for the Stage 4 diagnostic report/figure; the sheet functions
% accept any scalar qPerp>=0 in the frozen elastic energy window.
cfg.sheet.epsilon = 1e-9;
cfg.sheet.referenceQPerp = 0.10;
cfg.sheet.cutParameterMax = 2.5;
cfg.sheet.cutSamples = 401;
cfg.sheet.realAxisSamples = 601;

cfg.tolerances.rootResidual = 5e-12;
cfg.tolerances.cutResidual = 5e-12;

% 6. Stage 5 G1 longitudinal-kernel reference point.  These settings only
% control the diagnostic table and independent validation quadrature.
% Production leaf functions accept any finite scalar q0, qPerp>=0 and any
% real array of directed distances d=z_b-z_a.
cfg.g1.referenceQ0 = 0.30;
cfg.g1.referenceQPerp = 0.10;
cfg.g1.validationDistance = 0.73;
cfg.g1.validationQuadratureOrder = 256;

cfg.tolerances.g1Algebra = 5e-11;
cfg.tolerances.g1Quadrature = 2e-9;
cfg.tolerances.g1Limit = 5e-9;
% q3-pole separation normalised by max(|Omega|,|kappaI|,P,realmin), used
% only as a diagnostic label.  It never changes a distance sign or
% replaces a near merger by an exact merger.
cfg.tolerances.g1Coalescence = 1e-8;

% Stage 6 compares the full explicit ordered-pair double loop with the
% directed-distance cached implementation at a fixed integration node.
cfg.tolerances.g1Contraction = 5e-11;

% 7. Stage 7 collective-pole and endpoint controls.  Physical collective
% poles are found once in K=i*alpha and then mapped to q0 at each qPerp.
cfg.collective.scanSamples = 801;
cfg.tolerances.collectiveRoot = 5e-11;
cfg.tolerances.collectiveResidual = 2e-8;
cfg.tolerances.collectiveDuplicate = 2e-12;
cfg.tolerances.zeroEnergy = 2e-9;
cfg.tolerances.contourClosure = 2e-6;

% 8. Stage 7--8 deterministic quadrature.  All orders may be increased
% for convergence studies; Gauss nodes never sit on endpoints or poles.
cfg.integration.q4Order = 20;
cfg.integration.qPerpOrder = 18;
cfg.integration.collectiveOrder = 24;
cfg.integration.cutRadialOrder = 20;
cfg.integration.cutAngleOrder = 20;
cfg.integration.endpointOrder = 20;
cfg.integration.q4Scale = 1.0;
cfg.integration.qPerpTailScale = 1.0;
cfg.integration.q4MapPower = 2.0;
cfg.integration.endpointTauSwitchRelative = 5e-2;
cfg.integration.cutEvenSubtraction = true;
cfg.tolerances.integrationClosure = 5e-10;
cfg.tolerances.integrationConvergence = 8e-2;

% 9. Stage 10 convergence/contour validation.  The direct real-axis
% identity is evaluated at the explicitly separate finite regulator below;
% the physical epsilon remains cfg.sheet.epsilon and is connected by the
% MWR-only plateau.  Do not describe this as a direct epsilon=1e-9 audit.
cfg.stage10.orderMultipliers = [0.75, 1.0, 1.4];
cfg.stage10.mappingScaleFactors = [0.75, 1.0, 1.5];
cfg.stage10.mappingPowers = [1.5, 2.0, 2.5];
cfg.stage10.endpointSwitchFactors = [0.25, 1.0, 4.0];
cfg.stage10.collectiveScanSamples = [401, 801, 1601];
cfg.stage10.collectiveRootTolerances = [2e-10, 5e-11, 1.25e-11];
cfg.stage10.thresholdRelativeOffsets = [-1e-4, 0, 1e-4];
cfg.stage10.directDiagnosticEpsilon = 1e-5;
cfg.stage10.directOrder = 128;
cfg.stage10.directComparisonOrder = 96;
cfg.stage10.directTailScale = 1.0;
cfg.stage10.directWindowFactors = [-64, -16, -4, -1, 0, 1, 4, 16, 64];
cfg.stage10.directMWROrder = 128;
cfg.stage10.directMWRComparisonOrder = 96;
cfg.stage10.epsilonPlateau = [1e-7, 1e-8, 1e-9];
cfg.stage10.plateauOrder = 64;

cfg.tolerances.stage10OrderConvergence = 2e-2;
cfg.tolerances.stage10MappingSensitivity = 2e-2;
cfg.tolerances.stage10RootStability = 2e-7;
cfg.tolerances.stage10EndpointSwitch = 2e-3;
cfg.tolerances.stage10DirectSelf = 5e-4;
cfg.tolerances.stage10MWRSelf = 5e-4;
cfg.tolerances.stage10ContourIdentity = 2e-4;
cfg.tolerances.stage10EpsilonTotal = 5e-4;
cfg.tolerances.stage10EpsilonSource = 2e-3;
cfg.tolerances.stage10N1Kernel = 5e-6;
cfg.tolerances.stage10N1Probability = 2e-8;

% 10. Stage 11 G2/G3/G4 reference node and independent comparison-order
% comparison.  The production integration orders remain those in
% cfg.integration; comparisonOrderFactor only builds the convergence gate.
cfg.stage11.referenceQ0 = 0.30;
cfg.stage11.referenceQPerp = 0.10;
cfg.stage11.comparisonOrderFactor = 0.75;

cfg.tolerances.stage11Pointwise = 1e-8;
cfg.tolerances.stage11SourceClosure = 5e-10;
cfg.tolerances.stage11Convergence = 1e-2;
cfg.tolerances.stage11Unitarity = 2e-3;

% 11. Stage 12 publishable-scan contract.  The energy scan retains the
% current geometry.  The N scan holds the support and total signed
% strength fixed and uses trapezoidal delta weights, so N=2 exactly
% recovers the default two-centre configuration while N=3,4 begin a
% controlled finite-N approach to a uniform compact potential.
cfg.stage12.energyValues = [0.24, 0.30, 0.50, 0.80, 1.10, 1.40];
cfg.stage12.nValues = [2, 3, 4];
cfg.stage12.support = [-0.5, 0.5];
cfg.stage12.totalStrength = -0.30;
cfg.stage12.discretisation = 'fixed_support_trapezoidal';
% Stage 12 compares every published scan point with an independent higher
% order calculation and publishes the higher-order centre value.
cfg.stage12.referenceOrderFactor = 1.40;
% This is an interpretation gate, kept separate from numerical closure.
% eta=||delta S||_2 includes mu^2 and must remain perturbatively small.
cfg.stage12.perturbativeEtaLimit = 0.10;

% The independent G2--G4 raw/MWR audit reuses the frozen Stage 10 finite
% diagnostic epsilon, direct-axis orders and production epsilon plateau.
% These Stage 12 tolerances are separate because the three longer Rose
% routes have different cancellation scales from G1.
cfg.tolerances.stage12Anchor = 5e-10;
cfg.tolerances.stage12SourceClosure = 5e-10;
cfg.tolerances.stage12Convergence = 2e-2;
cfg.tolerances.stage12Unitarity = 5e-3;
cfg.tolerances.stage12SMatrix = 5e-3;
cfg.tolerances.stage12UnitarityAbsolute = 5e-10;
cfg.tolerances.stage12SMatrixAbsolute = 5e-10;
cfg.tolerances.stage12RootContinuity = 2e-7;
cfg.tolerances.stage12DirectSelf = 5e-4;
cfg.tolerances.stage12MWRSelf = 5e-4;
cfg.tolerances.stage12ContourIdentity = 2e-4;
cfg.tolerances.stage12EpsilonTotal = 5e-4;
cfg.tolerances.stage12EpsilonSource = 2e-3;

% 12. Output and execution controls.
cfg.output.directoryName = 'output';
cfg.output.saveMatFile = true;
cfg.output.writeTextReport = true;
cfg.output.writeStage4Figure = true;
cfg.output.writeStage9Figure = true;
cfg.output.writeStage10Figure = true;
cfg.output.writeStage12Figure = true;
cfg.execution.failOnBenchmarkFailure = true;
% Setting this false permits inspection of an unstable Stage 7 spectrum;
% Stage 8 still rejects alpha>=mphi because its transverse integral is not
% a supported production observable.
cfg.execution.rejectUnstableCollective = true;
% Stage 12 coarse jobs can use one process-based Parallel Computing Toolbox
% pool.  auto uses the pool when available and emits an explicit warning on
% serial fallback; required rejects any unavailable/failed parallel setup;
% serial never inspects or starts a pool.  Four process workers is a safe
% default for typical 16-GB desktops.  Set workerCount=0 to use the profile
% default, or raise it deliberately on a machine with more memory.
cfg.execution.parallel.mode = 'auto';
cfg.execution.parallel.profile = 'local';
cfg.execution.parallel.workerCount = 4;
cfg.execution.parallel.autoStartPool = true;
cfg.execution.parallel.attachProjectFiles = true;
cfg.execution.parallel.showProgress = true;
%% ================= END USER-EDITABLE SETTINGS ======================

release = ndelta.config.release_contract();
cfg.configurationVersion = release.configurationVersion;
cfg.projectRoot = projectRoot;
cfg = ndelta.config.finalize_configuration(cfg);

if showSummary
    ndelta.reporting.print_configuration(cfg);
end
end
