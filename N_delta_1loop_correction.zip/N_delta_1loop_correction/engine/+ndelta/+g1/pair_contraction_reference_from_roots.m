function [value, diagnostics] = pair_contraction_reference_from_roots( ...
        omega, kappaI, P, channelInput, geometry, strengths, ...
        nearSingularRcond, coalescenceTolerance)
%PAIR_CONTRACTION_REFERENCE_FROM_ROOTS Explicit Stage 6 double loop.
%
%   This auditable reference evaluates I(D_ab) independently for every
%   ordered centre pair and then forms
%
%     F_1,chi = sum_ab E_chi(a,b) tau_N(kappaI)(b,a) I_1,chi(D_ab).
%
%   OMEGA and KAPPAI are already selected/continued roots.  This function
%   never calls SQRT and is therefore safe on the Stage 7 contour.

narginchk(8, 8);
channel = ndelta.g1.validate_pair_contraction_inputs( ...
    omega, kappaI, P, channelInput, geometry, strengths, ...
    nearSingularRcond, coalescenceTolerance);

background = ndelta.background.background_kernel_N( ...
    kappaI, P, geometry, strengths, nearSingularRcond);
if channel == 'T'
    phaseMatrix = background.phases.transmission;
else
    phaseMatrix = background.phases.reflection;
end

N = geometry.N;
activeMask = background.activeMask(:);
activePairMask = bsxfun(@and, activeMask, activeMask.');
kernelMatrix = complex(zeros(N, N));
termMatrix = complex(zeros(N, N));
weightMatrix = complex(zeros(N, N));
evaluationMethods = repmat({'inactive_pair_skipped'}, N, N);
kernelDiagnostics = cell(N, N);
value = complex(0);

for a = 1:N
    for b = 1:N
        if ~activePairMask(a, b)
            continue;
        end
        distance = geometry.directedDistances(a, b);
        [kernelValue, kernelDetails] = ...
            ndelta.g1.longitudinal_kernel_from_roots( ...
            distance, omega, kappaI, P, channel, ...
            coalescenceTolerance);
        weight = phaseMatrix(a, b) .* background.tau(b, a);
        term = weight .* kernelValue;
        kernelMatrix(a, b) = kernelValue;
        weightMatrix(a, b) = weight;
        termMatrix(a, b) = term;
        evaluationMethods{a, b} = kernelDetails.evaluationMethods{1};
        kernelDiagnostics{a, b} = kernelDetails;
        value = value + term;
    end
end

diagnostics = make_diagnostics(value, channel, omega, kappaI, P, ...
    geometry, background, phaseMatrix, weightMatrix, kernelMatrix, ...
    termMatrix, evaluationMethods);
diagnostics.kernelDiagnosticsByPair = kernelDiagnostics;
diagnostics.method = 'explicit_ordered_pair_double_loop';
diagnostics.usedDirectedDistanceCache = false;
diagnostics.numberOfKernelEvaluations = nnz(activePairMask);
diagnostics.numberOfOrderedPairs = N.^2;
diagnostics.numberOfActiveOrderedPairs = nnz(activePairMask);
diagnostics.numberOfSkippedInactivePairs = N.^2 - nnz(activePairMask);
diagnostics.inactiveKernelEntriesAreZeroPlaceholders = true;
diagnostics.cacheReductionFactor = 1;
diagnostics.cacheKeys = complex(zeros(0, 1));
diagnostics.cacheValues = complex(zeros(0, 1));
diagnostics.cacheIndexMap = zeros(0, 0);
diagnostics.cachedOnlyLongitudinalKernel = false;
diagnostics.tauWasDistanceCached = false;
end

function diagnostics = make_diagnostics(value, channel, omega, kappaI, ...
        P, geometry, background, phaseMatrix, weightMatrix, ...
        kernelMatrix, termMatrix, evaluationMethods)
diagnostics = struct();
diagnostics.value = value;
diagnostics.channel = channel;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.geometry = geometry;
diagnostics.background = background;
diagnostics.tau = background.tau;
diagnostics.phaseMatrix = phaseMatrix;
diagnostics.weightMatrix = weightMatrix;
diagnostics.kernelMatrix = kernelMatrix;
diagnostics.termMatrix = termMatrix;
diagnostics.evaluationMethods = evaluationMethods;
diagnostics.termSumResidual = value - sum(termMatrix(:));
diagnostics.directedDistanceConvention = 'D(a,b)=z_b-z_a';
diagnostics.indexContract = 'E(a,b)*tau(b,a)*I(D(a,b))';
diagnostics.tauArgument = kappaI;
diagnostics.tauArgumentName = 'kappaI';
diagnostics.tauArgumentIsKappaI = true;
diagnostics.reusedTreeTauAtP = false;
diagnostics.includesLongitudinalQ3Integration = true;
diagnostics.contractsCentrePairs = true;
diagnostics.includesTauN = true;
diagnostics.includesCentrePhase = true;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.includesOneOverTwoP = false;
diagnostics.performsQ0Integration = false;
diagnostics.performsQPerpIntegration = false;
diagnostics.massDimension = -4;
end
