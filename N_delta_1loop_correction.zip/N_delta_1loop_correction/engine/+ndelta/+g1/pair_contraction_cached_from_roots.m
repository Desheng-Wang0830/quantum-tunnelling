function [value, diagnostics] = pair_contraction_cached_from_roots( ...
        omega, kappaI, P, channelInput, geometry, strengths, ...
        nearSingularRcond, coalescenceTolerance)
%PAIR_CONTRACTION_CACHED_FROM_ROOTS Stage 6 directed-distance cache.
%
%   I(D) is evaluated once per distinct directed-distance cache key.  The
%   full E(a,b) and tau(b,a) matrices are retained and contracted pair by
%   pair; tau_N is never approximated as a function of distance.

narginchk(8, 8);
channel = ndelta.g1.validate_pair_contraction_inputs( ...
    omega, kappaI, P, channelInput, geometry, strengths, ...
    nearSingularRcond, coalescenceTolerance);

background = ndelta.background.background_kernel_N( ...
    kappaI, P, geometry, strengths, nearSingularRcond);
if channel == 'T'
    phaseMatrix = background.phases.transmission;
else
    phaseMatrix = background.phases.reflection;
end

N = geometry.N;
activeMask = background.activeMask(:);
activePairMask = bsxfun(@and, activeMask, activeMask.');
cacheIndexMap = zeros(N, N);
kernelMatrix = complex(zeros(N, N));
reconstructedDistances = geometry.directedDistances;
evaluationMethods = repmat({'inactive_pair_skipped'}, N, N);

if ~any(activeMask)
    activeGeometry = empty_cache_geometry( ...
        geometry.distanceMergeRelativeTolerance);
    cacheKeys = zeros(0, 1);
    cacheValues = complex(zeros(0, 1));
    cacheDetails = empty_cache_details( ...
        channel, omega, kappaI, P, coalescenceTolerance);
else
    activeGeometry = ndelta.geometry.build_geometry( ...
        geometry.positions(activeMask), ...
        geometry.distanceMergeRelativeTolerance);
    cacheKeys = activeGeometry.uniqueDirectedDistances(:);
    cacheIndexMap(activeMask, activeMask) = ...
        activeGeometry.directedDistanceIndex;
    [cacheValues, cacheDetails] = ...
        ndelta.g1.longitudinal_kernel_from_roots( ...
        cacheKeys, omega, kappaI, P, channel, coalescenceTolerance);
    kernelMatrix(activeMask, activeMask) = reshape( ...
        cacheValues(activeGeometry.directedDistanceIndex), ...
        size(activeGeometry.directedDistanceIndex));
    reconstructedDistances(activeMask, activeMask) = reshape( ...
        cacheKeys(activeGeometry.directedDistanceIndex), ...
        size(activeGeometry.directedDistanceIndex));
    evaluationMethods(activeMask, activeMask) = reshape( ...
        cacheDetails.evaluationMethods( ...
        activeGeometry.directedDistanceIndex), ...
        size(activeGeometry.directedDistanceIndex));
end
distanceReconstructionError = abs( ...
    reconstructedDistances - geometry.directedDistances);
[value, termMatrix, weightMatrix] = ...
    ndelta.g1.contract_pair_matrices( ...
    phaseMatrix, background.tau, kernelMatrix);

diagnostics = struct();
diagnostics.value = value;
diagnostics.channel = channel;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.geometry = geometry;
diagnostics.background = background;
diagnostics.tau = background.tau;
diagnostics.phaseMatrix = phaseMatrix;
diagnostics.weightMatrix = weightMatrix;
diagnostics.kernelMatrix = kernelMatrix;
diagnostics.termMatrix = termMatrix;
diagnostics.evaluationMethods = evaluationMethods;
diagnostics.termSumResidual = value - sum(termMatrix(:));
diagnostics.directedDistanceConvention = 'D(a,b)=z_b-z_a';
diagnostics.indexContract = 'E(a,b)*tau(b,a)*I(D(a,b))';
diagnostics.tauArgument = kappaI;
diagnostics.tauArgumentName = 'kappaI';
diagnostics.tauArgumentIsKappaI = true;
diagnostics.reusedTreeTauAtP = false;
diagnostics.method = 'directed_distance_kernel_cache';
diagnostics.usedDirectedDistanceCache = true;
diagnostics.numberOfKernelEvaluations = numel(cacheKeys);
diagnostics.numberOfOrderedPairs = N.^2;
diagnostics.numberOfActiveOrderedPairs = nnz(activePairMask);
diagnostics.numberOfSkippedInactivePairs = N.^2 - nnz(activePairMask);
diagnostics.inactiveKernelEntriesAreZeroPlaceholders = true;
if isempty(cacheKeys)
    diagnostics.cacheReductionFactor = 0;
else
    diagnostics.cacheReductionFactor = ...
        nnz(activePairMask) ./ numel(cacheKeys);
end
diagnostics.cacheKeys = cacheKeys;
diagnostics.cacheValues = cacheValues;
diagnostics.cacheIndexMap = cacheIndexMap;
diagnostics.cacheGeometry = activeGeometry;
diagnostics.cacheBuiltFromActiveGeometryOnly = true;
diagnostics.inactiveCentresCannotAffectCacheKeys = true;
diagnostics.reconstructedDirectedDistances = reconstructedDistances;
diagnostics.maximumDistanceReconstructionError = ...
    max(distanceReconstructionError(:));
diagnostics.cacheApproximationActive = ...
    diagnostics.maximumDistanceReconstructionError > 0;
diagnostics.cacheKernelDiagnostics = cacheDetails;
diagnostics.cachedOnlyLongitudinalKernel = true;
diagnostics.tauWasDistanceCached = false;
diagnostics.includesLongitudinalQ3Integration = true;
diagnostics.contractsCentrePairs = true;
diagnostics.includesTauN = true;
diagnostics.includesCentrePhase = true;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.includesOneOverTwoP = false;
diagnostics.performsQ0Integration = false;
diagnostics.performsQPerpIntegration = false;
diagnostics.massDimension = -4;
end

function details = empty_cache_details( ...
        channel, omega, kappaI, P, coalescenceTolerance)
details = struct();
details.value = complex(zeros(0, 1));
details.channel = channel;
details.omega = omega;
details.kappaI = kappaI;
details.P = P;
details.directedDistances = zeros(0, 1);
details.distanceBranches = cell(0, 1);
details.evaluationMethods = cell(0, 1);
details.groupedResidueDiagnostics = cell(0, 1);
details.coalescenceTolerance = coalescenceTolerance;
details.skippedBecauseNoActiveOrderedPairs = true;
end

function geometry = empty_cache_geometry(relativeTolerance)
geometry = struct();
geometry.N = 0;
geometry.positions = zeros(0, 1);
geometry.directedDistances = zeros(0, 0);
geometry.absoluteDistances = zeros(0, 0);
geometry.uniqueDirectedDistances = zeros(0, 1);
geometry.directedDistanceIndex = zeros(0, 0);
geometry.numberOfUniqueDirectedDistances = 0;
geometry.distanceMergeRelativeTolerance = relativeTolerance;
geometry.distanceMergeAbsoluteTolerance = NaN;
geometry.distanceMergeScale = NaN;
geometry.distanceMergeRepresentative = ...
    'none_no_active_pairs';
geometry.distanceMergePermutationInvariant = true;
geometry.distanceMergeScaleInvariant = true;
geometry.distanceMergeSignSymmetric = true;
geometry.directedDistanceConvention = 'D(a,b)=z_b-z_a';
end
