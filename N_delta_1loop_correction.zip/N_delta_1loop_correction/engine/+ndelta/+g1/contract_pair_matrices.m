function [value, termMatrix, weightMatrix] = ...
        contract_pair_matrices(phaseMatrix, tau, kernelMatrix)
%CONTRACT_PAIR_MATRICES Contract E_ab, tau_ba and I(D_ab).
%
%   No conjugation is used:
%
%       F = sum_ab E(a,b) tau(b,a) I(a,b).
%
%   This small leaf is tested with a deliberately nonsymmetric synthetic
%   tau matrix so the ba ordering cannot be hidden by the physical complex
%   symmetry of Gamma_N^{-1}.

narginchk(3, 3);
matrices = {phaseMatrix, tau, kernelMatrix};
for index = 1:numel(matrices)
    valueToCheck = matrices{index};
    if ~isnumeric(valueToCheck) || ndims(valueToCheck) ~= 2 || ...
            size(valueToCheck, 1) ~= size(valueToCheck, 2) || ...
            isempty(valueToCheck) || ...
            any(~isfinite(real(valueToCheck(:)))) || ...
            any(~isfinite(imag(valueToCheck(:))))
        error('ndelta:g1:InvalidPairMatrix', ...
            'phaseMatrix, tau and kernelMatrix must be finite square matrices.');
    end
end
if ~isequal(size(phaseMatrix), size(tau), size(kernelMatrix))
    error('ndelta:g1:PairMatrixSizeMismatch', ...
        'phaseMatrix, tau and kernelMatrix must have identical sizes.');
end

weightMatrix = phaseMatrix .* tau.';
termMatrix = weightMatrix .* kernelMatrix;
value = sum(termMatrix(:));
end
