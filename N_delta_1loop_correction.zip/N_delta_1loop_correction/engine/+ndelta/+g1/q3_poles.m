function poles = q3_poles(channelInput, omega, kappaI, P)
%Q3_POLES Return the labelled Stage 5 poles for both distance closures.

%   D>0 closes counterclockwise in the upper half-plane at the physical
%   Feynman seed.  D<0 closes clockwise in the lower half-plane.  The
%   labels are analytically continued with OMEGA and KAPPAI afterward.

narginchk(4, 4);
channel = ndelta.g1.normalise_channel(channelInput);
ndelta.g1.validate_longitudinal_inputs(0, omega, kappaI, P);

poles = struct();
poles.channel = channel;
poles.directedDistanceConvention = 'd=z_b-z_a';
poles.positiveDistanceClosure = ...
    'upper_half_plane_counterclockwise_at_physical_seed';
poles.negativeDistanceClosure = ...
    'lower_half_plane_clockwise_at_physical_seed';
poles.positiveDistanceIntegralMultiplier = 1i;
poles.negativeDistanceIntegralMultiplier = -1i;
poles.doNotReclassifyAfterAnalyticContinuation = true;

if channel == 'T'
    poles.positiveDistanceLocations = [omega, P + kappaI];
    poles.positiveDistanceOrders = [1, 2];
    poles.positiveDistanceLabels = {'Omega', 'P+kappaI'};
    poles.negativeDistanceLocations = [-omega, P - kappaI];
    poles.negativeDistanceOrders = [1, 2];
    poles.negativeDistanceLabels = {'-Omega', 'P-kappaI'};
else
    poles.positiveDistanceLocations = ...
        [omega, P + kappaI, -P + kappaI];
    poles.positiveDistanceOrders = [1, 1, 1];
    poles.positiveDistanceLabels = ...
        {'Omega', 'P+kappaI', '-P+kappaI'};
    poles.negativeDistanceLocations = ...
        [-omega, P - kappaI, -P - kappaI];
    poles.negativeDistanceOrders = [1, 1, 1];
    poles.negativeDistanceLabels = ...
        {'-Omega', 'P-kappaI', '-P-kappaI'};
end
end
