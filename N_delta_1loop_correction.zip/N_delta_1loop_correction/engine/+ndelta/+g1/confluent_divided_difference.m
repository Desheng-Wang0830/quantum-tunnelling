function [value, diagnostics] = confluent_divided_difference( ...
        nodes, d, unselectedLocations, unselectedOrders)
%CONFLUENT_DIVIDED_DIFFERENCE Stable second divided difference of h(z).
%
%   h(z) = i*exp(i*d*z) / prod_j (z-r_j)^m_j.
%
%   The three NODES may coincide.  A full confluent cluster is evaluated
%   from the Taylor coefficients of h; otherwise the nodes are reordered
%   so the outer denominator is the farthest pair and close first
%   differences use the same analytic Taylor construction.  This avoids
%   catastrophic cancellation in removable same-side pole mergers.

narginchk(4, 4);
if ~isnumeric(nodes) || numel(nodes) ~= 3 || ...
        any(~isfinite(real(nodes(:)))) || ...
        any(~isfinite(imag(nodes(:))))
    error('ndelta:g1:InvalidDividedDifferenceNodes', ...
        'nodes must contain exactly three finite complex values.');
end
if ~isnumeric(unselectedLocations) || ...
        ~isvector(unselectedLocations) || isempty(unselectedLocations) || ...
        any(~isfinite(real(unselectedLocations(:)))) || ...
        any(~isfinite(imag(unselectedLocations(:))))
    error('ndelta:g1:InvalidUnselectedPoles', ...
        'unselectedLocations must be a nonempty finite numeric vector.');
end
if ~isnumeric(unselectedOrders) || ...
        ~isequal(size(unselectedOrders), size(unselectedLocations)) || ...
        any(~isfinite(unselectedOrders(:))) || ...
        any(unselectedOrders(:) < 1) || ...
        any(unselectedOrders(:) ~= fix(unselectedOrders(:)))
    error('ndelta:g1:InvalidUnselectedOrders', ...
        'unselectedOrders must match the poles and contain positive integers.');
end
if ~isnumeric(d) || ~isscalar(d) || ~isreal(d) || ~isfinite(d)
    error('ndelta:g1:DividedDifferenceDistanceMustBeScalar', ...
        'd must be a finite real scalar.');
end

nodes = nodes(:).';
unselectedLocations = unselectedLocations(:).';
unselectedOrders = unselectedOrders(:).';
seriesOrder = 18;
seriesRatioThreshold = 1e-2;
% A geometric pole-radius test alone is insufficient because
% exp(i*d*z) may vary rapidly across an otherwise tiny pole cluster.
% Use the fixed Taylor order only when the total local logarithmic
% variation of h is small; otherwise direct recursive differences are
% better conditioned precisely because the sampled h values are no
% longer nearly equal.
seriesVariationThreshold = 0.25;

pairDistances = [abs(nodes(1) - nodes(2)), ...
    abs(nodes(1) - nodes(3)), abs(nodes(2) - nodes(3))];
clusterCentre = mean(nodes);
clusterRadius = max(abs(nodes - clusterCentre));
analyticRadius = min(abs(clusterCentre - unselectedLocations));
if analyticRadius == 0
    error('ndelta:g1:DividedDifferenceHitsUnselectedPole', ...
        'A selected pole collides with an unselected pole.');
end
clusterLocalVariation = local_variation_bound(clusterRadius, ...
    clusterCentre, d, unselectedLocations, unselectedOrders);

if clusterRadius <= seriesRatioThreshold .* analyticRadius && ...
        clusterLocalVariation <= seriesVariationThreshold
    coefficients = taylor_coefficients(clusterCentre, d, ...
        unselectedLocations, unselectedOrders, seriesOrder);
    offsets = nodes - clusterCentre;
    value = second_difference_from_series(coefficients, offsets);
    method = 'three_node_confluent_taylor';
    usedTaylor = true;
else
    [~, farthestCode] = max(pairDistances);
    switch farthestCode
        case 1
            ordered = nodes([1, 3, 2]);
        case 2
            ordered = nodes([1, 2, 3]);
        otherwise
            ordered = nodes([2, 1, 3]);
    end
    firstLeft = first_difference(ordered(1), ordered(2), d, ...
        unselectedLocations, unselectedOrders, seriesOrder, ...
        seriesRatioThreshold, seriesVariationThreshold);
    firstRight = first_difference(ordered(2), ordered(3), d, ...
        unselectedLocations, unselectedOrders, seriesOrder, ...
        seriesRatioThreshold, seriesVariationThreshold);
    value = (firstRight.value - firstLeft.value) ./ ...
        (ordered(3) - ordered(1));
    method = 'farthest_pair_recursive';
    usedTaylor = firstLeft.usedTaylor || firstRight.usedTaylor;
end

diagnostics = struct();
diagnostics.method = method;
diagnostics.usedConfluentTaylor = usedTaylor;
diagnostics.nodes = nodes;
diagnostics.unselectedLocations = unselectedLocations;
diagnostics.unselectedOrders = unselectedOrders;
diagnostics.clusterRadius = clusterRadius;
diagnostics.analyticRadius = analyticRadius;
diagnostics.clusterToAnalyticRadiusRatio = ...
    clusterRadius ./ analyticRadius;
diagnostics.clusterPhaseSpan = abs(d) .* clusterRadius;
diagnostics.clusterLocalVariationBound = clusterLocalVariation;
diagnostics.seriesOrder = seriesOrder;
diagnostics.seriesRatioThreshold = seriesRatioThreshold;
diagnostics.seriesVariationThreshold = seriesVariationThreshold;
end

function result = first_difference(x, y, d, poles, orders, ...
        seriesOrder, ratioThreshold, variationThreshold)
centre = (x + y) ./ 2;
halfSeparation = (y - x) ./ 2;
analyticRadius = min(abs(centre - poles));
if analyticRadius == 0
    error('ndelta:g1:DividedDifferenceHitsUnselectedPole', ...
        'A selected pole collides with an unselected pole.');
end
localVariation = local_variation_bound(abs(halfSeparation), ...
    centre, d, poles, orders);
if abs(halfSeparation) <= ratioThreshold .* analyticRadius && ...
        localVariation <= variationThreshold
    coefficients = taylor_coefficients( ...
        centre, d, poles, orders, seriesOrder);
    if halfSeparation == 0
        value = coefficients(2);
    else
        value = 0;
        for power = 1:2:seriesOrder
            value = value + coefficients(power + 1) ...
                .* halfSeparation.^(power - 1);
        end
    end
    usedTaylor = true;
else
    value = (evaluate_h(y, d, poles, orders) ...
        - evaluate_h(x, d, poles, orders)) ./ (y - x);
    usedTaylor = false;
end
result = struct('value', value, 'usedTaylor', usedTaylor, ...
    'localVariationBound', localVariation);
end

function value = local_variation_bound(radius, centre, d, poles, orders)
if radius == 0
    value = 0;
    return
end
distances = abs(centre - poles);
if any(distances == 0)
    value = Inf;
    return
end
value = radius .* (abs(d) + sum(orders ./ distances));
end

function value = second_difference_from_series(coefficients, offsets)
maximumDegree = numel(coefficients) - 1;
maximumH = maximumDegree - 2;
h = complex(zeros(maximumH + 1, 1));
h(1) = 1;
e1 = sum(offsets);
e2 = offsets(1) .* offsets(2) + offsets(1) .* offsets(3) ...
    + offsets(2) .* offsets(3);
e3 = prod(offsets);
for degree = 1:maximumH
    previous1 = h(degree);
    previous2 = 0;
    previous3 = 0;
    if degree >= 2
        previous2 = h(degree - 1);
    end
    if degree >= 3
        previous3 = h(degree - 2);
    end
    h(degree + 1) = e1 .* previous1 ...
        - e2 .* previous2 + e3 .* previous3;
end
value = 0;
for power = 2:maximumDegree
    value = value + coefficients(power + 1) .* h(power - 1);
end
end

function coefficients = taylor_coefficients( ...
        centre, d, poles, orders, maximumDegree)
coefficients = complex(zeros(maximumDegree + 1, 1));
exponentialPrefactor = 1i .* exp(1i .* d .* centre);
for degree = 0:maximumDegree
    coefficients(degree + 1) = exponentialPrefactor ...
        .* (1i .* d).^degree ./ factorial(degree);
end

for poleIndex = 1:numel(poles)
    base = centre - poles(poleIndex);
    order = orders(poleIndex);
    factor = complex(zeros(maximumDegree + 1, 1));
    for degree = 0:maximumDegree
        binomial = nchoosek(order + degree - 1, degree);
        factor(degree + 1) = (-1).^degree .* binomial ...
            ./ base.^(order + degree);
    end
    product = conv(coefficients, factor);
    coefficients = product(1:(maximumDegree + 1));
end
end

function value = evaluate_h(z, d, poles, orders)
denominator = 1;
for index = 1:numel(poles)
    denominator = denominator .* ...
        (z - poles(index)).^orders(index);
end
value = 1i .* exp(1i .* d .* z) ./ denominator;
end
