function [value, diagnostics] = longitudinal_kernel_from_roots( ...
        d, omega, kappaI, P, channelInput, coalescenceTolerance)
%LONGITUDINAL_KERNEL_FROM_ROOTS Analytic G1 q3 integral at fixed roots.
%
%   I = LONGITUDINAL_KERNEL_FROM_ROOTS(D,OMEGA,KAPPAI,P,CHANNEL,TOL)
%   evaluates
%
%     integral dq3/(2*pi) [-i exp(i*q3*D)]
%       /[(OMEGA^2-q3^2)
%         (KAPPAI^2-(P-q3)^2)
%         (KAPPAI^2-(sigma*P-q3)^2)].
%
%   D is the directed centre separation z_b-z_a and may be an array.
%   OMEGA and KAPPAI must already be values on one continuously chosen
%   sheet.  This leaf function never calls SQRT and is therefore the
%   correct entry point for the Stage 7 contour continuation.
%
%   The result includes i^3=-i and dq3/(2*pi), but excludes tau_N,
%   external centre phases, (-mu^2), LSZ and 1/(2P).

narginchk(5, 6);
if nargin < 6
    coalescenceTolerance = sqrt(eps);
end
channel = ndelta.g1.normalise_channel(channelInput);
ndelta.g1.validate_longitudinal_inputs(d, omega, kappaI, P);
validateattributes(coalescenceTolerance, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'coalescenceTolerance');

separation = ndelta.g1.assert_nondegenerate( ...
    channel, omega, kappaI, P);
poles = ndelta.g1.q3_poles(channel, omega, kappaI, P);

positive = d > 0;
negative = d < 0;
zero = d == 0;
value = complex(zeros(size(d)));
notAvailable = complex(NaN(size(d)), NaN(size(d)));
heavyContribution = notAvailable;
firstShiftedContribution = notAvailable;
secondShiftedContribution = notAvailable;

rootScale = max([abs(omega), abs(kappaI), P, realmin]);
positiveSameSideSeparation = minimum_pair_separation( ...
    poles.positiveDistanceLocations, rootScale);
negativeSameSideSeparation = minimum_pair_separation( ...
    poles.negativeDistanceLocations, rootScale);
positiveComponentMask = positive & ...
    (positiveSameSideSeparation > coalescenceTolerance);
negativeComponentMask = negative & ...
    (negativeSameSideSeparation > coalescenceTolerance);

APlus = omega.^2 - (P + kappaI).^2;
AMinus = omega.^2 - (P - kappaI).^2;

if channel == 'T'
    [value, heavyContribution, firstShiftedContribution] = ...
        transmission_kernel(d, positiveComponentMask, ...
        negativeComponentMask, zero, ...
        omega, kappaI, P, APlus, AMinus, value, ...
        heavyContribution, firstShiftedContribution);
    componentSum = heavyContribution + firstShiftedContribution;
    componentNames = {'heavy_pole', 'shifted_double_pole'};
else
    [value, heavyContribution, firstShiftedContribution, ...
        secondShiftedContribution] = reflection_kernel( ...
        d, positiveComponentMask, negativeComponentMask, zero, ...
        omega, kappaI, P, ...
        APlus, AMinus, value, heavyContribution, ...
        firstShiftedContribution, secondShiftedContribution);
    componentSum = heavyContribution + firstShiftedContribution + ...
        secondShiftedContribution;
    componentNames = {'heavy_pole', 'incoming_shifted_pole', ...
        'outgoing_shifted_pole'};
end
if positiveSameSideSeparation <= coalescenceTolerance && any(zero(:))
    heavyContribution(zero) = complex(NaN, NaN);
    firstShiftedContribution(zero) = complex(NaN, NaN);
    secondShiftedContribution(zero) = complex(NaN, NaN);
    componentSum(zero) = complex(NaN, NaN);
end

% The displayed separated-residue formulas above are retained as an
% auditable decomposition.  The production value for every nonzero
% distance is evaluated as one grouped divided difference.  This is
% algebraically identical at separated poles and remains finite when
% same-closure poles merge into a higher-order pole.
methods = repmat({'exact_zero_compact'}, size(d));
groupedDiagnostics = cell(size(d));
nonzeroIndices = find(~zero);
for flatIndex = 1:numel(nonzeroIndices)
    index = nonzeroIndices(flatIndex);
    distance = d(index);
    if channel == 'T'
        if distance > 0
            nodes = [omega, P + kappaI, P + kappaI];
            unselected = [-omega, P - kappaI];
            unselectedOrders = [1, 2];
            multiplier = 1i;
        else
            nodes = [-omega, P - kappaI, P - kappaI];
            unselected = [omega, P + kappaI];
            unselectedOrders = [1, 2];
            multiplier = -1i;
        end
    else
        if distance > 0
            nodes = [omega, P + kappaI, -P + kappaI];
            unselected = [-omega, P - kappaI, -P - kappaI];
            unselectedOrders = [1, 1, 1];
            multiplier = 1i;
        else
            nodes = [-omega, P - kappaI, -P - kappaI];
            unselected = [omega, P + kappaI, -P + kappaI];
            unselectedOrders = [1, 1, 1];
            multiplier = -1i;
        end
    end
    [dividedDifference, grouped] = ...
        ndelta.g1.confluent_divided_difference( ...
        nodes, distance, unselected, unselectedOrders);
    value(index) = multiplier .* dividedDifference;
    methods{index} = grouped.method;
    groupedDiagnostics{index} = grouped;
end

branches = repmat({'zero'}, size(d));
branches(positive) = repmat({'positive'}, nnz(positive), 1);
branches(negative) = repmat({'negative'}, nnz(negative), 1);
componentResidual = abs(componentSum - value) ./ (1 + abs(value));
finiteComponentResidual = componentResidual(isfinite(componentResidual));
if isempty(finiteComponentResidual)
    maximumComponentResidual = NaN;
else
    maximumComponentResidual = max(finiteComponentResidual);
end

diagnostics = struct();
diagnostics.value = value;
diagnostics.channel = channel;
diagnostics.sigma = 1;
if channel == 'R'
    diagnostics.sigma = -1;
end
diagnostics.directedDistances = d;
diagnostics.distanceBranches = branches;
diagnostics.directedDistanceConvention = 'd=z_b-z_a';
diagnostics.usedAbsoluteDistance = false;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.APlus = APlus;
diagnostics.AMinus = AMinus;
diagnostics.heavyPoleContribution = heavyContribution;
diagnostics.firstShiftedPoleContribution = ...
    firstShiftedContribution;
diagnostics.secondShiftedPoleContribution = ...
    secondShiftedContribution;
diagnostics.componentNames = componentNames;
diagnostics.maximumComponentAssemblyResidual = ...
    maximumComponentResidual;
diagnostics.positiveSameSideNormalisedSeparation = ...
    positiveSameSideSeparation;
diagnostics.negativeSameSideNormalisedSeparation = ...
    negativeSameSideSeparation;
diagnostics.evaluationMethods = methods;
diagnostics.groupedResidueDiagnostics = groupedDiagnostics;
diagnostics.poles = poles;
diagnostics.poleSeparation = separation;
diagnostics.coalescenceTolerance = coalescenceTolerance;
diagnostics.nearSameSideMerger = ...
    separation.minimumSameSideNormalisedSeparation ...
    <= coalescenceTolerance;
diagnostics.nearCrossSidePinch = ...
    separation.minimumCrossSideNormalisedSeparation ...
    <= coalescenceTolerance;
diagnostics.nearDegenerate = diagnostics.nearSameSideMerger || ...
    diagnostics.nearCrossSidePinch;
diagnostics.hardDegenerate = ...
    separation.hasMachineScaleCrossSidePinch;
diagnostics.sameSideMergersUseGroupedResidues = true;
diagnostics.formulaSheet = ...
    'analytic_continuation_of_initial_feynman_pole_labels';
diagnostics.reflectionEvennessIsIdentity = channel == 'R';
diagnostics.includesInternalPropagatorNumeratorMinusI = true;
diagnostics.includesQ3MeasureOneOverTwoPi = true;
diagnostics.includesTauN = false;
diagnostics.includesCentrePhase = false;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.includesOneOverTwoP = false;
diagnostics.massDimension = -5;
end

function minimum = minimum_pair_separation(locations, normalisationScale)
minimum = Inf;
for first = 1:(numel(locations) - 1)
    for second = (first + 1):numel(locations)
        separation = abs(locations(first) - locations(second)) ./ ...
            normalisationScale;
        minimum = min(minimum, separation);
    end
end
end

function [value, heavy, shifted] = transmission_kernel( ...
        d, positive, negative, zero, omega, kappaI, P, ...
        APlus, AMinus, value, heavy, shifted)
shiftAtPositiveHeavy = kappaI.^2 - (P - omega).^2;
shiftAtNegativeHeavy = kappaI.^2 - (P + omega).^2;

if any(positive(:))
    distance = d(positive);
    heavy(positive) = -exp(1i .* omega .* distance) ./ ...
        (2 .* omega .* shiftAtPositiveHeavy.^2);
    shifted(positive) = exp(1i .* (P + kappaI) .* distance) .* ( ...
        1i .* distance ./ (4 .* kappaI.^2 .* APlus) ...
        + (P + kappaI) ./ (2 .* kappaI.^2 .* APlus.^2) ...
        - 1 ./ (4 .* kappaI.^3 .* APlus));
    value(positive) = heavy(positive) + shifted(positive);
end

if any(negative(:))
    distance = d(negative);
    heavy(negative) = -exp(-1i .* omega .* distance) ./ ...
        (2 .* omega .* shiftAtNegativeHeavy.^2);
    shifted(negative) = exp(1i .* (P - kappaI) .* distance) .* ( ...
        -1i .* distance ./ (4 .* kappaI.^2 .* AMinus) ...
        - (P - kappaI) ./ (2 .* kappaI.^2 .* AMinus.^2) ...
        - 1 ./ (4 .* kappaI.^3 .* AMinus));
    value(negative) = heavy(negative) + shifted(negative);
end

if any(zero(:))
    numerator = omega.^3 + 4 .* kappaI .* omega.^2 ...
        + (5 .* kappaI.^2 - P.^2) .* omega ...
        + 2 .* kappaI.^3;
    zeroValue = -numerator ./ ( ...
        4 .* omega .* kappaI.^3 ...
        .* (omega + kappaI - P).^2 ...
        .* (omega + kappaI + P).^2);
    value(zero) = zeroValue;

    % Keep an independent UHP residue decomposition for diagnostics while
    % using the compact expression above as the exact d=0 production path.
    heavy(zero) = -1 ./ ...
        (2 .* omega .* shiftAtPositiveHeavy.^2);
    shifted(zero) = (P + kappaI) ./ ...
        (2 .* kappaI.^2 .* APlus.^2) ...
        - 1 ./ (4 .* kappaI.^3 .* APlus);
end
end

function [value, heavy, incomingShifted, outgoingShifted] = ...
        reflection_kernel(d, positive, negative, zero, omega, ...
        kappaI, P, APlus, AMinus, value, heavy, ...
        incomingShifted, outgoingShifted)
commonHeavy = (kappaI.^2 - (P - omega).^2) .* ...
    (kappaI.^2 - (P + omega).^2);

if any(positive(:))
    distance = d(positive);
    heavy(positive) = -exp(1i .* omega .* distance) ./ ...
        (2 .* omega .* commonHeavy);
    incomingShifted(positive) = ...
        exp(1i .* (P + kappaI) .* distance) ./ ...
        (8 .* kappaI .* P .* (P + kappaI) .* APlus);
    outgoingShifted(positive) = ...
        exp(-1i .* (P - kappaI) .* distance) ./ ...
        (8 .* kappaI .* P .* (P - kappaI) .* AMinus);
    value(positive) = heavy(positive) ...
        + incomingShifted(positive) + outgoingShifted(positive);
end

if any(negative(:))
    distance = d(negative);
    heavy(negative) = -exp(-1i .* omega .* distance) ./ ...
        (2 .* omega .* commonHeavy);
    incomingShifted(negative) = ...
        exp(1i .* (P - kappaI) .* distance) ./ ...
        (8 .* kappaI .* P .* (P - kappaI) .* AMinus);
    outgoingShifted(negative) = ...
        exp(-1i .* (P + kappaI) .* distance) ./ ...
        (8 .* kappaI .* P .* (P + kappaI) .* APlus);
    value(negative) = heavy(negative) ...
        + incomingShifted(negative) + outgoingShifted(negative);
end

if any(zero(:))
    zeroValue = (omega + 2 .* kappaI) ./ ( ...
        4 .* omega .* kappaI .* (P.^2 - kappaI.^2) ...
        .* (omega + kappaI - P) ...
        .* (omega + kappaI + P));
    value(zero) = zeroValue;

    heavy(zero) = -1 ./ (2 .* omega .* commonHeavy);
    incomingShifted(zero) = 1 ./ ...
        (8 .* kappaI .* P .* (P + kappaI) .* APlus);
    outgoingShifted(zero) = 1 ./ ...
        (8 .* kappaI .* P .* (P - kappaI) .* AMinus);
end
end
