function value = longitudinal_integrand( ...
        channelInput, q3, d, omega, kappaI, P)
%LONGITUDINAL_INTEGRAND Raw G1 centre-pair q3 integrand.

%   VALUE contains the three internal propagator numerators i^3=-i and
%   exp(i*q3*d), but excludes dq3/(2*pi), tau_N, barrier strengths, mu^2,
%   external propagators and LSZ factors.

narginchk(6, 6);
channel = ndelta.g1.normalise_channel(channelInput);
ndelta.g1.validate_longitudinal_inputs(d, omega, kappaI, P);
if ~isscalar(d)
    error('ndelta:g1:IntegrandDistanceMustBeScalar', ...
        'Raw q3 integrand evaluation requires a scalar d.');
end
if ~isnumeric(q3) || isempty(q3) || ...
        any(~isfinite(real(q3(:)))) || ...
        any(~isfinite(imag(q3(:))))
    error('ndelta:g1:InvalidQ3', ...
        'q3 must be a nonempty finite numeric array.');
end

denHeavy = omega.^2 - q3.^2;
denIncoming = kappaI.^2 - (P - q3).^2;
if channel == 'T'
    denOutgoing = denIncoming;
else
    denOutgoing = kappaI.^2 - (P + q3).^2;
end
value = -1i .* exp(1i .* q3 .* d) ./ ...
    (denHeavy .* denIncoming .* denOutgoing);
end
