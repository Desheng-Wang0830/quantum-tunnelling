function [value, diagnostics] = pair_contraction_cached( ...
        q0, qPerp, channel, cfg, geometry)
%PAIR_CONTRACTION_CACHED Direct physical-sheet Stage 6 cached result.

narginchk(4, 5);
cfg = ndelta.config.finalize_configuration(cfg);
validate_node(q0, qPerp);
if nargin < 5
    geometry = ndelta.g1.resolve_pair_geometry(cfg);
else
    geometry = ndelta.g1.resolve_pair_geometry(cfg, geometry);
end
roots = ndelta.sheet.physical_roots(q0, qPerp, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
[value, diagnostics] = ...
    ndelta.g1.pair_contraction_cached_from_roots( ...
    roots.omega, roots.kappaI, cfg.derived.P, channel, geometry, ...
    cfg.barriers.strengths, cfg.tolerances.nearSingularRcond, ...
    cfg.tolerances.g1Coalescence);
diagnostics.q0 = q0;
diagnostics.qPerp = qPerp;
diagnostics.E = cfg.referenceEnergy;
diagnostics.epsilon = cfg.sheet.epsilon;
diagnostics.roots = roots;
diagnostics.rootSource = 'ndelta.sheet.physical_roots';
diagnostics.directPhysicalSheetWrapper = true;
end

function validate_node(q0, qPerp)
if ~isnumeric(q0) || ~isscalar(q0) || ...
        ~isfinite(real(q0)) || ~isfinite(imag(q0))
    error('ndelta:g1:PairQ0MustBeScalar', ...
        'q0 must be a finite numeric scalar.');
end
if ~isnumeric(qPerp) || ~isscalar(qPerp) || ~isreal(qPerp) || ...
        ~isfinite(qPerp) || qPerp < 0
    error('ndelta:g1:InvalidPairQPerp', ...
        'qPerp must be a finite nonnegative real scalar.');
end
end
