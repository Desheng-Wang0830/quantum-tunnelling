function value = numerical_real_axis_reference( ...
        d, omega, kappaI, P, channel, quadratureOrder)
%NUMERICAL_REAL_AXIS_REFERENCE Independent validation-only q3 integral.
%
%   A tangent map q3=tan(pi*x/2) and a deterministic Gauss-Legendre rule
%   evaluate the original real-axis definition.  Production kernels use
%   analytic residues; this routine is deliberately retained only as an
%   independent Stage 5 contract check at well-separated test poles.

narginchk(6, 6);
ndelta.g1.validate_longitudinal_inputs(d, omega, kappaI, P);
if ~isscalar(d)
    error('ndelta:g1:ReferenceDistanceMustBeScalar', ...
        'The numerical reference integral requires scalar d.');
end
[nodes, weights] = ndelta.numerics.gauss_legendre_rule( ...
    quadratureOrder);
angle = (pi ./ 2) .* nodes;
q3 = tan(angle);
jacobian = (pi ./ 2) ./ cos(angle).^2;
integrand = ndelta.g1.q3_integrand( ...
    q3, d, omega, kappaI, P, channel);
value = sum(weights .* jacobian .* integrand) ./ (2 .* pi);
end
