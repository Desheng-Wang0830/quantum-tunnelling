function [value, diagnostics] = longitudinal_kernel( ...
        d, q0, qPerp, channel, cfg)
%LONGITUDINAL_KERNEL Public direct-physical-sheet Stage 5 interface.
%
%   I = ndelta.g1.longitudinal_kernel(D,Q0,QPERP,CHANNEL,CFG) first
%   evaluates the Stage 4 physical roots at one scalar (Q0,QPERP) point,
%   then calls LONGITUDINAL_KERNEL_FROM_ROOTS.  Use the root-level leaf
%   directly after a future contour continuation; this wrapper always
%   means the direct outward-cut physical value.

narginchk(5, 5);
cfg = ndelta.config.finalize_configuration(cfg);
if ~isnumeric(q0) || ~isscalar(q0) || ...
        ~isfinite(real(q0)) || ~isfinite(imag(q0))
    error('ndelta:g1:Q0MustBeScalar', ...
        'q0 must be a finite numeric scalar.');
end
if ~isnumeric(qPerp) || ~isscalar(qPerp) || ~isreal(qPerp) || ...
        ~isfinite(qPerp) || qPerp < 0
    error('ndelta:g1:InvalidQPerp', ...
        'qPerp must be a finite nonnegative real scalar.');
end

roots = ndelta.sheet.physical_roots(q0, qPerp, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
[value, leaf] = ndelta.g1.longitudinal_kernel_from_roots( ...
    d, roots.omega, roots.kappaI, cfg.derived.P, channel, ...
    cfg.tolerances.g1Coalescence);

diagnostics = leaf;
diagnostics.q0 = q0;
diagnostics.qPerp = qPerp;
diagnostics.E = cfg.referenceEnergy;
diagnostics.epsilon = cfg.sheet.epsilon;
diagnostics.roots = roots;
diagnostics.rootSource = 'ndelta.sheet.physical_roots';
diagnostics.directPhysicalSheetWrapper = true;
end
