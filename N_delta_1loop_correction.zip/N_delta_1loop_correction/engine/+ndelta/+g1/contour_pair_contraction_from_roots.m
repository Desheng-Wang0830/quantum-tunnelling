function [value, diagnostics] = contour_pair_contraction_from_roots( ...
        omega, kappaI, P, channelInput, geometry, strengths, cfg)
%CONTOUR_PAIR_CONTRACTION_FROM_ROOTS Endpoint-stable Stage 7 leaf.
%
%   This is the contour counterpart of the accepted Stage 6 cache.  It
%   keeps the frozen root labels and directed-distance cache, but replaces
%   the ordinary Gamma solve by an endpoint-stable solve when |kappaI| is
%   small.  It returns the raw Stage 6 integrand; the vertex-reduced code
%   kernel is its negative.

narginchk(7, 7);
channel = ndelta.g1.normalise_channel(channelInput);
if ~isnumeric(omega) || ~isscalar(omega) || ...
        ~isfinite(real(omega)) || ~isfinite(imag(omega)) || ...
        ~isnumeric(kappaI) || ~isscalar(kappaI) || ...
        ~isfinite(real(kappaI)) || ~isfinite(imag(kappaI))
    error('ndelta:g1:InvalidContourRoots', ...
        'omega and kappaI must be finite complex scalars.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');
g = strengths(:);
if ~isstruct(geometry) || ~isscalar(geometry) || ...
        ~isfield(geometry, 'N') || numel(g) ~= geometry.N
    error('ndelta:g1:InvalidContourGeometry', ...
        'geometry and strengths must describe the same centre system.');
end

activeMask = g ~= 0;
N = geometry.N;
kernelMatrix = complex(zeros(N));
tau = complex(zeros(N));
cacheKeys = zeros(0, 1);
cacheValues = complex(zeros(0, 1));
tauDiagnostics = struct('method', 'empty_active_system', ...
    'usedEndpointScaledSolve', false, 'scaledRcond', Inf, ...
    'conditionAmplification', 0, 'nearSingular', false, ...
    'normalisedEquationResidual', 0);

if any(activeMask)
    if kappaI == 0
        error('ndelta:g1:ContourEndpointRequiresLimit', ...
            ['An active system cannot be evaluated at kappaI=0.  Use ' ...
             'the analytic endpoint residue/arc supplied by Stage 7.']);
    end
    activeGeometry = ndelta.geometry.build_geometry( ...
        geometry.positions(activeMask), ...
        geometry.distanceMergeRelativeTolerance);
    cacheKeys = activeGeometry.uniqueDirectedDistances(:);
    cacheValues = ndelta.g1.longitudinal_kernel_from_roots( ...
        cacheKeys, omega, kappaI, P, channel, ...
        cfg.tolerances.g1Coalescence);
    kernelMatrix(activeMask, activeMask) = reshape( ...
        cacheValues(activeGeometry.directedDistanceIndex), ...
        size(activeGeometry.directedDistanceIndex));
    [tau, tauDiagnostics] = ...
        ndelta.background.solve_tau_endpoint_stable( ...
        kappaI, geometry, g, cfg.derived.endpointTauSwitch, ...
        cfg.tolerances.nearSingularRcond);
end

phases = ndelta.geometry.build_channel_phases(geometry.positions, P);
if channel == 'T'
    phaseMatrix = phases.transmission;
else
    phaseMatrix = phases.reflection;
end
[value, termMatrix, weightMatrix] = ...
    ndelta.g1.contract_pair_matrices(phaseMatrix, tau, kernelMatrix);
value = complex(real(value), imag(value));

diagnostics = struct();
diagnostics.value = value;
diagnostics.vertexReducedValue = -value;
diagnostics.channel = channel;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.activeMask = activeMask;
diagnostics.tau = tau;
diagnostics.tauDiagnostics = tauDiagnostics;
diagnostics.phaseMatrix = phaseMatrix;
diagnostics.kernelMatrix = kernelMatrix;
diagnostics.weightMatrix = weightMatrix;
diagnostics.termMatrix = termMatrix;
diagnostics.cacheKeys = cacheKeys;
diagnostics.cacheValues = cacheValues;
diagnostics.rawStage6Convention = true;
diagnostics.vertexReducedEqualsNegativeRaw = true;
diagnostics.includesQ0Measure = false;
diagnostics.includesQPerpMeasure = false;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
end
