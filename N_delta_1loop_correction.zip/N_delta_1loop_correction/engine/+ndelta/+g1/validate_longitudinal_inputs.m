function validate_longitudinal_inputs(d, omega, kappaI, P)
%VALIDATE_LONGITUDINAL_INPUTS Validate the low-level Stage 5 kernel data.

%   D may be a finite real array.  OMEGA and KAPPAI are scalar values on
%   one continuously chosen sheet.  They are not reselected here.

narginchk(4, 4);
if ~isnumeric(d) || isempty(d) || ~isreal(d) || ...
        any(~isfinite(d(:)))
    error('ndelta:g1:InvalidDirectedDistance', ...
        'd must be a nonempty finite real numeric array.');
end
if ~isnumeric(omega) || ~isscalar(omega) || ...
        ~isfinite(real(omega)) || ~isfinite(imag(omega))
    error('ndelta:g1:InvalidOmega', ...
        'omega must be a finite numeric scalar.');
end
if ~isnumeric(kappaI) || ~isscalar(kappaI) || ...
        ~isfinite(real(kappaI)) || ~isfinite(imag(kappaI))
    error('ndelta:g1:InvalidKappaI', ...
        'kappaI must be a finite numeric scalar.');
end
if ~isnumeric(P) || ~isscalar(P) || ~isreal(P) || ...
        ~isfinite(P) || P <= 0
    error('ndelta:g1:InvalidP', ...
        'P must be a finite positive real scalar.');
end
end
