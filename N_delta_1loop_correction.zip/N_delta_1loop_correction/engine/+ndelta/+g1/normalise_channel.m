function channel = normalise_channel(channelInput)
%NORMALISE_CHANNEL Convert a G1 channel label to the frozen T/R code.

%   Accepted labels are T, TRANSMISSION, R and REFLECTION, independent of
%   letter case.  The returned value is the character vector 'T' or 'R'.

narginchk(1, 1);
if isstring(channelInput)
    if ~isscalar(channelInput)
        error('ndelta:g1:InvalidChannel', ...
            'channel must be a scalar string or character vector.');
    end
    channelInput = char(channelInput);
end
if ~ischar(channelInput) || isempty(channelInput) || ...
        size(channelInput, 1) ~= 1
    error('ndelta:g1:InvalidChannel', ...
        'channel must be T, transmission, R or reflection.');
end

label = upper(strtrim(channelInput));
switch label
    case {'T', 'TRANSMISSION'}
        channel = 'T';
    case {'R', 'REFLECTION'}
        channel = 'R';
    otherwise
        error('ndelta:g1:InvalidChannel', ...
            'channel must be T, transmission, R or reflection.');
end
end
