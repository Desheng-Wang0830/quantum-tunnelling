function diagnostics = pole_separation(channelInput, omega, kappaI, P)
%POLE_SEPARATION Separate same-side mergers from cross-side pinches.

%   Labels refer to the poles selected on the initial Feynman sheet.  The
%   same algebraic labels are then analytically continued; they must not be
%   reclassified from the instantaneous sign of an imaginary part.

narginchk(4, 4);
channel = ndelta.g1.normalise_channel(channelInput);
ndelta.g1.validate_longitudinal_inputs(0, omega, kappaI, P);

poleTable = ndelta.g1.q3_poles(channel, omega, kappaI, P);
upper = poleTable.positiveDistanceLocations;
lower = poleTable.negativeDistanceLocations;
upperLabels = poleTable.positiveDistanceLabels;
lowerLabels = poleTable.negativeDistanceLabels;
normalisationScale = max([abs(omega), abs(kappaI), P, realmin]);

[upperMinimum, upperAbsolute, upperPair] = ...
    within_set_minimum(upper, normalisationScale);
[lowerMinimum, lowerAbsolute, lowerPair] = ...
    within_set_minimum(lower, normalisationScale);
[crossMinimum, crossAbsolute, crossPair] = ...
    cross_set_minimum(upper, lower, normalisationScale);

if upperMinimum <= lowerMinimum
    sameMinimum = upperMinimum;
    sameAbsolute = upperAbsolute;
    sameSide = 'positive_distance_closure';
    sameLabels = upperLabels(upperPair);
else
    sameMinimum = lowerMinimum;
    sameAbsolute = lowerAbsolute;
    sameSide = 'negative_distance_closure';
    sameLabels = lowerLabels(lowerPair);
end

% The separations below are already dimensionless.  Compare them with a
% dimensionless floating-point threshold so a change of mass units cannot
% turn a benign point into a false pinch.
machineThreshold = 4096 .* eps(1);
diagnostics = struct();
diagnostics.channel = channel;
diagnostics.normalisationScale = normalisationScale;
diagnostics.positiveDistanceLocations = upper;
diagnostics.negativeDistanceLocations = lower;
diagnostics.positiveDistanceLabels = upperLabels;
diagnostics.negativeDistanceLabels = lowerLabels;
diagnostics.minimumSameSideNormalisedSeparation = sameMinimum;
diagnostics.minimumSameSideAbsoluteSeparation = sameAbsolute;
diagnostics.closestSameSide = sameSide;
diagnostics.closestSameSidePairLabels = sameLabels;
diagnostics.minimumCrossSideNormalisedSeparation = crossMinimum;
diagnostics.minimumCrossSideAbsoluteSeparation = crossAbsolute;
diagnostics.closestCrossSidePairIndices = crossPair;
diagnostics.closestCrossSidePairLabels = ...
    {upperLabels{crossPair(1)}, lowerLabels{crossPair(2)}};
diagnostics.machineThreshold = machineThreshold;
diagnostics.hasMachineScaleSameSideMerger = ...
    sameMinimum <= machineThreshold;
diagnostics.hasMachineScaleCrossSidePinch = ...
    crossMinimum <= machineThreshold;
diagnostics.isAnalyticContinuationOfPhysicalLabels = true;
diagnostics.reclassifiedByInstantaneousImaginaryPart = false;
end

function [minimum, absoluteMinimum, pair] = ...
        within_set_minimum(values, normalisationScale)
minimum = Inf;
absoluteMinimum = Inf;
pair = [1, 1];
for first = 1:(numel(values) - 1)
    for second = (first + 1):numel(values)
        absolute = abs(values(first) - values(second));
        normalised = absolute ./ normalisationScale;
        if normalised < minimum
            minimum = normalised;
            absoluteMinimum = absolute;
            pair = [first, second];
        end
    end
end
end

function [minimum, absoluteMinimum, pair] = ...
        cross_set_minimum(upper, lower, normalisationScale)
minimum = Inf;
absoluteMinimum = Inf;
pair = [1, 1];
for upperIndex = 1:numel(upper)
    for lowerIndex = 1:numel(lower)
        absolute = abs(upper(upperIndex) - lower(lowerIndex));
        normalised = absolute ./ normalisationScale;
        if normalised < minimum
            minimum = normalised;
            absoluteMinimum = absolute;
            pair = [upperIndex, lowerIndex];
        end
    end
end
end
