function result = collective_pole_residue( ...
        mode, qPerp, channelInput, cfg, geometry)
%COLLECTIVE_POLE_RESIDUE Matrix residue of the Stage 7 G1 integrand.
%
%   The ordinary tau solver is deliberately bypassed.  The returned
%   VERTEXREDUCEDRESIDUE belongs to F_code=-F_Stage6.

narginchk(5, 5);
channel = ndelta.g1.normalise_channel(channelInput);
mapped = ndelta.singularity.map_collective_q0(mode, qPerp, cfg);
result = base_result(mode, qPerp, channel, mapped, cfg);
if ~mapped.left.accepted
    return;
end
if isfield(mode, 'semisimple') && ~mode.semisimple
    result.rejectionReason = 'nonsemisimple_collective_mode';
    return;
end

q0 = mapped.left.q0;
omega = mapped.left.omega;
K = mode.K;
active = mode.activeIndices(:);
zActive = geometry.positions(active);
V = mode.nullVectorsActive;
if isempty(V) || size(V, 2) ~= mode.nullity
    error('ndelta:g1:InvalidCollectiveNullspace', ...
        'The collective mode has no valid active nullspace.');
end

gammaDerivativeK = ndelta.singularity.gamma_derivative_N(K, zActive);
dKdq0 = (q0 - cfg.referenceEnergy) ./ K;
derivativeQ0 = gammaDerivativeK .* dKdq0;
projectedDerivativeQ0 = ...
    V.' * derivativeQ0 * V;
result.projectedDerivativeQ0 = projectedDerivativeQ0;
if any(~isfinite(derivativeQ0(:))) || ...
        any(~isfinite(projectedDerivativeQ0(:)))
    result.rejectionReason = 'nonfinite_collective_projected_derivative';
    return;
end
projectedScale = max(1, norm(derivativeQ0, 2));
result.projectedDerivativeQ0Scale = projectedScale;
if ~isfinite(projectedScale)
    result.rejectionReason = 'nonfinite_collective_projected_derivative';
    return;
end
projectedRcond = rcond(projectedDerivativeQ0);
projectedSingularValues = svd(projectedDerivativeQ0);
projectedMinimum = min(projectedSingularValues);
projectedScaledRcond = projectedMinimum ./ projectedScale;
result.projectedDerivativeRcond = projectedRcond;
result.projectedDerivativeScaledRcond = projectedScaledRcond;
result.minimumProjectedDerivativeQ0 = projectedMinimum;
if ~isfinite(projectedRcond) || ...
        ~isfinite(projectedScaledRcond) || ...
        projectedRcond <= 100 .* eps || ...
        projectedMinimum <= 100 .* eps .* projectedScale
    result.rejectionReason = 'nonsemisimple_or_multiple_q0_pole';
    return;
end
if projectedRcond < cfg.tolerances.nearSingularRcond || ...
        projectedScaledRcond < cfg.tolerances.nearSingularRcond
    result.rejectionReason = ...
        'near_singular_collective_projected_derivative';
    return;
end
residueTauActive = V * (projectedDerivativeQ0 \ V.');
residueTau = complex(zeros(geometry.N));
residueTau(active, active) = residueTauActive;

activeGeometry = ndelta.geometry.build_geometry( ...
    zActive, geometry.distanceMergeRelativeTolerance);
keys = activeGeometry.uniqueDirectedDistances(:);
kernelValues = ndelta.g1.longitudinal_kernel_from_roots( ...
    keys, omega, K, cfg.derived.P, channel, ...
    cfg.tolerances.g1Coalescence);
kernelMatrix = complex(zeros(geometry.N));
kernelMatrix(active, active) = reshape( ...
    kernelValues(activeGeometry.directedDistanceIndex), ...
    size(activeGeometry.directedDistanceIndex));
phases = ndelta.geometry.build_channel_phases( ...
    geometry.positions, cfg.derived.P);
if channel == 'T'
    phaseMatrix = phases.transmission;
else
    phaseMatrix = phases.reflection;
end
[rawResidue, termMatrix] = ndelta.g1.contract_pair_matrices( ...
    phaseMatrix, residueTau, kernelMatrix);
vertexReducedResidue = -rawResidue;

gammaAtPole = ndelta.background.build_gamma_N( ...
    K, zActive, cfg.barriers.strengths(active));
nullResidual = norm(gammaAtPole * V, 'fro') ./ ...
    (1 + norm(gammaAtPole, 'fro'));
result.accepted = nullResidual <= cfg.tolerances.collectiveResidual;
result.rejectionReason = '';
if ~result.accepted
    result.rejectionReason = 'collective_null_residual_failed';
end
result.q0 = q0;
result.omega = omega;
result.kappaI = K;
result.dKdq0 = dKdq0;
result.gammaDerivativeK = gammaDerivativeK;
result.projectedDerivativeConditionThreshold = ...
    cfg.tolerances.nearSingularRcond;
result.residueTau = residueTau;
result.kernelMatrix = kernelMatrix;
result.phaseMatrix = phaseMatrix;
result.termMatrix = termMatrix;
result.rawStage6Residue = rawResidue;
result.vertexReducedResidue = vertexReducedResidue;
result.contourContribution = 1i .* vertexReducedResidue;
result.nullResidual = nullResidual;
result.includesQ0Measure = true;
result.q0MeasureResidueMultiplier = 1i;
end

function result = base_result(mode, qPerp, channel, mapped, cfg)
result = struct();
result.accepted = false;
result.rejectionReason = 'outside_open_QI_support_or_unstable_mode';
result.modeIndex = mode.index;
result.modeLabel = mode.label;
result.alpha = mode.alpha;
result.K = mode.K;
result.qPerp = qPerp;
result.channel = channel;
result.mapping = mapped;
result.q0 = complex(NaN);
result.omega = complex(NaN);
result.kappaI = mode.K;
result.rawStage6Residue = complex(0);
result.vertexReducedResidue = complex(0);
result.contourContribution = complex(0);
result.nullResidual = Inf;
result.projectedDerivativeRcond = 0;
result.projectedDerivativeScaledRcond = 0;
result.projectedDerivativeConditionThreshold = ...
    cfg.tolerances.nearSingularRcond;
result.includesQ0Measure = true;
result.q0MeasureResidueMultiplier = 1i;
result.includesQPerpMeasure = false;
result.includesMuSquared = false;
result.includesLSZ = false;
end
