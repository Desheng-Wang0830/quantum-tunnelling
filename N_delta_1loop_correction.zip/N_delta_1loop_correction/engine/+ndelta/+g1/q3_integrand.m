function value = q3_integrand(q3, d, omega, kappaI, P, channel)
%Q3_INTEGRAND Public argument-order alias for the raw Stage 5 integrand.

narginchk(6, 6);
value = ndelta.g1.longitudinal_integrand( ...
    channel, q3, d, omega, kappaI, P);
end
