function diagnostics = assert_nondegenerate(channel, omega, kappaI, P)
%ASSERT_NONDEGENERATE Reject only cross-closure pinch collisions.

%   Threshold, pinch and coalescing-pole limits require a separate local
%   treatment.  Stage 5 deliberately does not regularise them by silently
%   perturbing a root or by inserting a larger artificial epsilon.

narginchk(4, 4);
diagnostics = ndelta.g1.pole_separation(channel, omega, kappaI, P);
if diagnostics.hasMachineScaleCrossSidePinch
    if diagnostics.channel == 'T'
        identifier = 'ndelta:g1:PinchedTransmissionPoint';
    else
        identifier = 'ndelta:g1:PinchedReflectionPoint';
    end
    error(identifier, ...
        ['A positive-closure pole and a negative-closure pole collide ' ...
         '(%s and %s). This is a threshold/pinch candidate, not a ' ...
         'removable same-side merger; keep it for Stage 7.'], ...
        diagnostics.closestCrossSidePairLabels{1}, ...
        diagnostics.closestCrossSidePairLabels{2});
end
end
