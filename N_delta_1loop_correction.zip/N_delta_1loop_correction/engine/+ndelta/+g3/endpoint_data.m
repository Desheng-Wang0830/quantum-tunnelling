function result = endpoint_data(qPerp, channelInput, cfg, context)
%ENDPOINT_DATA Full branch-keyhole residue for arbitrary-N G3.

narginchk(4, 4);
result = ndelta.g2.endpoint_data(qPerp, channelInput, cfg, context);
result.term = 'G3';
result.routing = 'original_Rose_G3';
end
