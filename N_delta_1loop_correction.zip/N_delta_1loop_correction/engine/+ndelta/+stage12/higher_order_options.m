function options = higher_order_options(cfg, supplied)
%HIGHER_ORDER_OPTIONS Independent higher-order Stage 12 reference profile.

narginchk(1, 2);
if nargin < 2
    supplied = struct();
end
baseline = ndelta.integration.resolve_options(cfg, supplied);
factor = cfg.stage12.referenceOrderFactor;
names = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
options = baseline;
for index = 1:numel(names)
    name = names{index};
    options.(name) = max(baseline.(name) + 1, ...
        round(factor .* baseline.(name)));
end
end
