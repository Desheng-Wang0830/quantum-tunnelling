function options = resolve_scan_options(cfg, supplied)
%RESOLVE_SCAN_OPTIONS Production, portable and quick Stage 12 plans.

narginchk(1, 2);
if nargin < 2
    supplied = struct();
end
if ~isstruct(supplied) || ~isscalar(supplied)
    error('ndelta:stage12:InvalidScanOptions', ...
        'Stage 12 options must be a scalar structure.');
end
known = {'profile', 'energyValues', 'nValues', ...
    'integrationOptions', 'runContourAudit', 'runEpsilonPlateau'};
unknown = setdiff(fieldnames(supplied), known);
if ~isempty(unknown)
    error('ndelta:stage12:UnknownScanOption', ...
        'Unknown Stage 12 option(s): %s.', strjoin(unknown, ', '));
end
profile = get_value(supplied, 'profile', 'production');
if isstring(profile) && isscalar(profile), profile = char(profile); end
if ~ischar(profile) || ...
        ~ismember(profile, {'production', 'portable', 'quick'})
    error('ndelta:stage12:InvalidScanProfile', ...
        'profile must be production, portable or quick.');
end
% Canonicalise the frozen plan before any profile-specific concatenation.
% FINALIZE_CONFIGURATION accepts both MATLAB vector orientations.
energyValues = cfg.stage12.energyValues(:).';
nValues = cfg.stage12.nValues(:).';
runContourAudit = strcmp(profile, 'production');
runEpsilonPlateau = strcmp(profile, 'production');
formalReleaseRequested = strcmp(profile, 'production');
if strcmp(profile, 'portable')
    energyValues = unique([cfg.referenceEnergy, energyValues(end)]);
    nCandidates = nValues(nValues >= 3);
    nValues = nCandidates(1);
elseif strcmp(profile, 'quick')
    energyValues = cfg.referenceEnergy;
    nCandidates = nValues(nValues >= 3);
    nValues = nCandidates(1);
end
energyValues = get_value(supplied, 'energyValues', energyValues);
nValues = get_value(supplied, 'nValues', nValues);
integrationOptions = get_value(supplied, 'integrationOptions', struct());
runContourAudit = get_value( ...
    supplied, 'runContourAudit', runContourAudit);
runEpsilonPlateau = get_value( ...
    supplied, 'runEpsilonPlateau', runEpsilonPlateau);
validate_subset(energyValues, cfg.stage12.energyValues, 'energyValues');
validate_subset(nValues, cfg.stage12.nValues, 'nValues');
if ~islogical(runContourAudit) || ~isscalar(runContourAudit) || ...
        ~islogical(runEpsilonPlateau) || ~isscalar(runEpsilonPlateau)
    error('ndelta:stage12:InvalidAuditSwitch', ...
        'Stage 12 audit switches must be logical scalars.');
end
options = struct();
options.profile = profile;
options.energyValues = energyValues(:).';
options.nValues = nValues(:).';
options.integrationOptions = ...
    ndelta.integration.resolve_options(cfg, integrationOptions);
options.runContourAudit = runContourAudit;
options.runEpsilonPlateau = runEpsilonPlateau;
options.formalReleaseRequested = formalReleaseRequested;
end

function validate_subset(values, allowed, name)
if ~isnumeric(values) || isempty(values) || ~isvector(values) || ...
        ~isreal(values) || any(~isfinite(values(:))) || ...
        numel(unique(values(:))) ~= numel(values) || ...
        any(diff(values(:)) <= 0)
    error('ndelta:stage12:InvalidScanSubset', ...
        ['%s must be a nonempty finite strictly increasing numeric ' ...
         'vector.'], name);
end
for index = 1:numel(values)
    % ALLOWED is a validated vector but may be supplied as either a row
    % or a column.  Build a column explicitly so configuration orientation
    % cannot turn this scalar comparison into a concatenation error.
    scale = max([1; abs(values(index)); abs(allowed(:))]);
    if min(abs(allowed - values(index))) > 64 .* eps(scale)
        error('ndelta:stage12:ScanSubsetOutsidePlan', ...
            '%s must be selected from the frozen Stage 12 plan.', name);
    end
end
end

function value = get_value(structure, name, defaultValue)
if isfield(structure, name)
    value = structure.(name);
else
    value = defaultValue;
end
end
