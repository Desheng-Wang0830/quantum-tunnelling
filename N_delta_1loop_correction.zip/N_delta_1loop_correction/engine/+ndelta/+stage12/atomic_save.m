function atomic_save(path, variables)
%ATOMIC_SAVE Save named MATLAB variables through a same-directory rename.
%
%   NDELTA.STAGE12.ATOMIC_SAVE(PATH, VARIABLES) writes each field of the
%   scalar structure VARIABLES as a variable in PATH.  The payload is first
%   written to a temporary MAT file in the destination directory and is
%   moved over PATH only after SAVE has completed successfully.

narginchk(2, 2);
if isstring(path) && isscalar(path), path = char(path); end
if ~ischar(path) || isempty(path)
    error('ndelta:stage12:InvalidAtomicSavePath', ...
        'The atomic-save path must be a nonempty character vector.');
end
if ~isstruct(variables) || ~isscalar(variables) || ...
        isempty(fieldnames(variables))
    error('ndelta:stage12:InvalidAtomicSavePayload', ...
        'Atomic-save variables must be a nonempty scalar structure.');
end

directory = fileparts(path);
if isempty(directory)
    directory = pwd;
end
if ~exist(directory, 'dir')
    [created, message] = mkdir(directory);
    if ~created
        error('ndelta:stage12:AtomicSaveDirectoryFailure', ...
            'Could not create checkpoint directory %s: %s', ...
            directory, message);
    end
end

temporaryPath = [tempname(directory), '.mat'];
cleanup = onCleanup(@() delete_if_present(temporaryPath)); %#ok<NASGU>
save(temporaryPath, '-struct', 'variables', '-v7.3');
[moved, message, messageIdentifier] = movefile( ...
    temporaryPath, path, 'f');
if ~moved
    error('ndelta:stage12:AtomicSaveRenameFailure', ...
        'Could not atomically install %s [%s]: %s', ...
        path, messageIdentifier, message);
end
end

function delete_if_present(path)
if exist(path, 'file')
    try
        delete(path);
    catch
        % Preserve the original save or rename error.
    end
end
end
