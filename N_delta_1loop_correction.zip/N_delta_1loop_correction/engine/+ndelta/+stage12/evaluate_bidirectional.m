function result = evaluate_bidirectional(cfg, options, preparedState)
%EVALUATE_BIDIRECTIONAL Build left/right data and the complete 2x2 S gate.

narginchk(1, 3);
if nargin < 2
    options = struct();
end
cfg = ndelta.config.finalize_configuration(cfg);
if nargin < 3
    preparedState = ndelta.stage12.prepare_bidirectional_state(cfg);
else
    validate_prepared_state(preparedState, cfg);
end
left = ndelta.stage12.evaluate_direction( ...
    cfg, options, preparedState.left);
symmetry = preparedState.symmetry;
if symmetry.accepted
    right = left;
    mirrorReusedByExactParity = true;
else
    mirrorCfg = preparedState.mirrorConfiguration;
    right = ndelta.stage12.evaluate_direction( ...
        mirrorCfg, options, preparedState.right);
    mirrorReusedByExactParity = false;
end

result = struct('left', left, 'rightFromMirroredPotential', right, ...
    'centredMirrorSymmetry', symmetry, ...
    'mirrorReusedByExactParity', mirrorReusedByExactParity, ...
    'accepted', false, 'status', 'direction_rejected');
result.S0 = complex(NaN(2));
result.deltaSPerMu2 = complex(NaN(2));
result.deltaS = complex(NaN(2));
result.treeUnitarityResidualMatrix = complex(NaN(2));
result.oneLoopUnitarityResidualMatrixPerMu2 = complex(NaN(2));
result.treeUnitarityResidual = Inf;
result.oneLoopUnitarityResidualPerMu2 = Inf;
result.oneLoopUnitarityScalePerMu2 = 0;
result.oneLoopUnitarityNormalisedError = Inf;
result.leftDiagonalClosurePerMu2 = Inf;
result.rightDiagonalClosurePerMu2 = Inf;
result.offDiagonalClosurePerMu2 = complex(Inf);
result.treeTransmissionReciprocityResidual = Inf;
result.oneLoopTransmissionReciprocityResidualPerMu2 = Inf;
result.treeReciprocityAccepted = false;
result.oneLoopReciprocityAccepted = false;
result.treeUnitarityAccepted = false;
result.oneLoopUnitarityAccepted = false;
result.perturbativeEta = Inf;
result.truncatedProbabilitiesInNominalRange = false;
result.perturbativeInterpretationAccepted = false;
result.perturbativeInterpretationStatus = 'direction_rejected';
result.fullTwoByTwoSMatrixTested = false;
result.rightIncidenceObtainedFromMirroredPotential = true;
if ~left.accepted || ~right.accepted
    return;
end

tL = left.tree.t0;
rL = left.tree.r0;
tR = right.tree.t0;
rR = right.tree.r0;
dtL = left.combined.totalAmplitudesPerMu2(1);
drL = left.combined.totalAmplitudesPerMu2(2);
dtR = right.combined.totalAmplitudesPerMu2(1);
drR = right.combined.totalAmplitudesPerMu2(2);
S0 = [rL, tR; tL, rR];
deltaSPerMu2 = [drL, dtR; dtL, drR];
treeResidualMatrix = S0' * S0 - eye(2);
loopResidualMatrix = S0' * deltaSPerMu2 + ...
    deltaSPerMu2' * S0;
treeResidual = norm(treeResidualMatrix, 'fro');
loopResidual = norm(loopResidualMatrix, 'fro');
loopScale = norm(S0' * deltaSPerMu2, 'fro') + ...
    norm(deltaSPerMu2' * S0, 'fro');
loopAccepted = loopResidual <= ...
    cfg.tolerances.stage12SMatrixAbsolute + ...
    cfg.tolerances.stage12SMatrix .* loopScale;
treeAccepted = treeResidual <= 2 .* cfg.tolerances.unitarity;
treeReciprocity = abs(tL - tR);
loopReciprocity = abs(dtL - dtR);
treeReciprocityAccepted = treeReciprocity <= ...
    cfg.tolerances.stage12Anchor .* (1 + max(abs([tL, tR])));
loopReciprocityAccepted = loopReciprocity <= ...
    cfg.tolerances.stage12Anchor .* (1 + max(abs([dtL, dtR])));

result.S0 = S0;
result.deltaSPerMu2 = deltaSPerMu2;
result.deltaS = cfg.model.mu.^2 .* deltaSPerMu2;
result.treeUnitarityResidualMatrix = treeResidualMatrix;
result.oneLoopUnitarityResidualMatrixPerMu2 = loopResidualMatrix;
result.treeUnitarityResidual = treeResidual;
result.oneLoopUnitarityResidualPerMu2 = loopResidual;
result.oneLoopUnitarityScalePerMu2 = loopScale;
result.oneLoopUnitarityNormalisedError = loopResidual ./ ...
    max(1e-12, loopScale);
result.leftDiagonalClosurePerMu2 = real(loopResidualMatrix(1, 1));
result.rightDiagonalClosurePerMu2 = real(loopResidualMatrix(2, 2));
result.offDiagonalClosurePerMu2 = loopResidualMatrix(1, 2);
result.treeTransmissionReciprocityResidual = treeReciprocity;
result.oneLoopTransmissionReciprocityResidualPerMu2 = loopReciprocity;
result.treeReciprocityAccepted = treeReciprocityAccepted;
result.oneLoopReciprocityAccepted = loopReciprocityAccepted;
result.treeUnitarityAccepted = treeAccepted;
result.oneLoopUnitarityAccepted = loopAccepted;
result.perturbativeEta = norm(result.deltaS, 2);
result.truncatedProbabilitiesInNominalRange = ...
    left.truncatedProbabilitiesInNominalRange && ...
    right.truncatedProbabilitiesInNominalRange;
result.perturbativeInterpretationAccepted = ...
    result.perturbativeEta <= cfg.stage12.perturbativeEtaLimit && ...
    result.truncatedProbabilitiesInNominalRange;
if result.perturbativeInterpretationAccepted
    result.perturbativeInterpretationStatus = ...
        'nominal_strict_O_mu2_interpretation';
elseif ~result.truncatedProbabilitiesInNominalRange
    result.perturbativeInterpretationStatus = ...
        'truncated_probability_outside_nominal_range';
else
    result.perturbativeInterpretationStatus = ...
        'large_loop_amplitude_requires_caution';
end
result.fullTwoByTwoSMatrixTested = true;
result.rightIncidenceObtainedFromMirroredPotential = true;
result.accepted = treeAccepted && loopAccepted && ...
    treeReciprocityAccepted && loopReciprocityAccepted;
if result.accepted
    result.status = 'accepted_complete_closed_elastic_S_matrix';
else
    result.status = 'complete_S_matrix_gate_rejected';
end
end

function validate_prepared_state(state, cfg)
required = {'left', 'right', 'mirrorConfiguration', 'symmetry', ...
    'mirrorReusedByExactParity', 'configurationFingerprint', ...
    'preparationFingerprint', 'modelMu', 'orderIndependent'};
validState = isstruct(state) && isscalar(state) && ...
    all(isfield(state, required));
if validState
    validState = islogical(state.orderIndependent) && ...
        isscalar(state.orderIndependent) && state.orderIndependent && ...
        islogical(state.mirrorReusedByExactParity) && ...
        isscalar(state.mirrorReusedByExactParity);
end
if ~validState
    error('ndelta:stage12:InvalidPreparedBidirectionalState', ...
        'A complete order-independent bidirectional state is required.');
end
expectedSymmetry = ndelta.stage12.is_centered_mirror_symmetric( ...
    cfg.barriers.positions, cfg.barriers.strengths);
expectedMirrorCfg = cfg;
if ~expectedSymmetry.accepted
    expectedMirrorCfg.barriers.positions = -cfg.barriers.positions;
    expectedMirrorCfg = ndelta.config.finalize_configuration( ...
        expectedMirrorCfg);
end
outerFingerprintAccepted = isequaln(state.preparationFingerprint, ...
    ndelta.stage12.preparation_fingerprint(cfg));
mirrorFingerprintAccepted = isstruct(state.mirrorConfiguration) && ...
    isscalar(state.mirrorConfiguration) && isequaln( ...
    ndelta.stage12.preparation_fingerprint(state.mirrorConfiguration), ...
    ndelta.stage12.preparation_fingerprint(expectedMirrorCfg));
parityAccepted = isequaln(state.symmetry, expectedSymmetry) && ...
    state.mirrorReusedByExactParity == expectedSymmetry.accepted;
if ~outerFingerprintAccepted || ~mirrorFingerprintAccepted || ...
        ~parityAccepted
    error('ndelta:stage12:PreparedBidirectionalConfigurationMismatch', ...
        'The prepared bidirectional state has stale mirror or parity data.');
end
ndelta.config.assert_physics_fingerprint( ...
    state.configurationFingerprint, cfg, ...
    'ndelta:stage12:PreparedBidirectionalConfigurationMismatch');
if ~isequaln(state.modelMu, cfg.model.mu) || ...
        state.mirrorReusedByExactParity ~= state.symmetry.accepted
    error('ndelta:stage12:PreparedBidirectionalConfigurationMismatch', ...
        'The prepared bidirectional state has stale coupling or parity data.');
end
end
