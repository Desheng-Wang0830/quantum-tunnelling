function fingerprint = observable_fingerprint(cfg, options, spectrum)
%OBSERVABLE_FINGERPRINT Identity of one strict-O(mu^2) scan observable.

narginchk(3, 3);
cfg = ndelta.config.finalize_configuration(cfg);
effectiveOptions = ndelta.integration.resolve_options(cfg, options);
fingerprint = struct();
fingerprint.version = 1;
fingerprint.physics = ndelta.config.physics_fingerprint(cfg);
fingerprint.mu = cfg.model.mu;
fingerprint.integration = ...
    ndelta.config.integration_fingerprint(cfg, effectiveOptions);
fingerprint.spectrum = ndelta.singularity.spectrum_signature(spectrum);
fingerprint.strictOrder = 'O(mu^2)';
fingerprint.lszConvention = 'mu^2*K/(2P)_exactly_once';
fingerprint.amplitudeSquaredIncluded = false;
end
