function state = prepare_direction_state(cfg)
%PREPARE_DIRECTION_STATE Order-independent geometry/tree/spectrum context.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
stage1 = run_stage1(cfg);
stage2 = run_stage2(cfg, stage1);
geometry = stage1.geometry;
tree = stage2.tree;
spectrum = ndelta.singularity.find_collective_modes(cfg, geometry);
elasticWindow = ndelta.stage12.closed_elastic_window(cfg, spectrum);
context = struct();
if elasticWindow.accepted && spectrum.accepted && ...
        ~tree.background.solveDiagnostics.nearSingular
    context = ndelta.stage11.build_context(cfg, geometry);
end
state = struct();
state.preparationFingerprint = ...
    ndelta.stage12.preparation_fingerprint(cfg);
state.configurationFingerprint = ndelta.config.physics_fingerprint(cfg);
state.spectrumSolverFingerprint = ...
    ndelta.config.spectrum_solver_fingerprint(cfg);
state.modelMu = cfg.model.mu;
state.stage1 = stage1;
state.tree = tree;
state.geometry = geometry;
state.spectrum = spectrum;
state.elasticWindow = elasticWindow;
state.context = context;
state.orderIndependent = true;
state.status = 'stage12_order_independent_direction_state';
end
