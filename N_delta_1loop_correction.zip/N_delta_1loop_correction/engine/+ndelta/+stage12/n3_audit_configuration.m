function auditCfg = n3_audit_configuration(cfg, epsilon)
%N3_AUDIT_CONFIGURATION Fixed N=3 trapezoidal profile for route audits.

narginchk(1, 2);
cfg = ndelta.config.finalize_configuration(cfg);
profile = ndelta.stage12.trapezoidal_profile( ...
    3, cfg.stage12.support, cfg.stage12.totalStrength);
auditCfg = cfg;
auditCfg.barriers.positions = profile.positions;
auditCfg.barriers.strengths = profile.strengths;
if nargin >= 2
    auditCfg.sheet.epsilon = epsilon;
end
auditCfg = ndelta.config.finalize_configuration(auditCfg);
end
