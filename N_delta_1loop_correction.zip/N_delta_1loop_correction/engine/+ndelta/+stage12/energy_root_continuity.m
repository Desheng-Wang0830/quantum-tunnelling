function result = energy_root_continuity(energyPoints, cfg)
%ENERGY_ROOT_CONTINUITY Mode identity/alpha fixed while qcrit follows E.

narginchk(2, 2);
numberOfPoints = numel(energyPoints);
result = struct('modeIdentityAccepted', true, ...
    'maximumAlphaError', 0, 'maximumQCriticalFormulaError', 0, ...
    'qCriticalMonotonic', true, 'accepted', true, ...
    'numberOfEnergyPoints', numberOfPoints);
if numberOfPoints == 0
    result.accepted = false;
    return;
end
reference = energyPoints{1}.pair.published.left.spectrum;
referenceAlphas = reshape([reference.modes.alpha], 1, []);
referenceBranches = {reference.modes.branchIndices};
referenceLabels = {reference.modes.label};
qCriticalRows = NaN(numberOfPoints, numel(referenceAlphas));
energies = zeros(numberOfPoints, 1);
for pointIndex = 1:numberOfPoints
    point = energyPoints{pointIndex}.pair.published.left;
    spectrum = point.spectrum;
    energies(pointIndex) = point.energy;
    if spectrum.numberOfModes ~= numel(referenceAlphas) || ...
            ~isequal({spectrum.modes.branchIndices}, referenceBranches) || ...
            ~isequal({spectrum.modes.label}, referenceLabels)
        result.modeIdentityAccepted = false;
        continue;
    end
    alphas = reshape([spectrum.modes.alpha], 1, []);
    if ~isempty(alphas)
        alphaErrors = abs(alphas - referenceAlphas) ./ ...
            (1 + abs(referenceAlphas));
        result.maximumAlphaError = max(result.maximumAlphaError, ...
            max(alphaErrors(:)));
    end
    for modeIndex = 1:numel(spectrum.modes)
        mode = spectrum.modes(modeIndex);
        expectedSquared = point.P.^2 + mode.alpha.^2 ...
            - (cfg.sheet.epsilon ./ (2 .* point.energy)).^2;
        expected = sqrt(max(expectedSquared, 0));
        result.maximumQCriticalFormulaError = max( ...
            result.maximumQCriticalFormulaError, ...
            abs(mode.qPerpCritical - expected) ./ (1 + abs(expected)));
        qCriticalRows(pointIndex, modeIndex) = mode.qPerpCritical;
    end
end
[~, order] = sort(energies);
qCriticalRows = qCriticalRows(order, :);
if size(qCriticalRows, 1) > 1 && ~isempty(qCriticalRows)
    monotonicSteps = diff(qCriticalRows, 1, 1) >= ...
        -cfg.tolerances.stage12RootContinuity;
    result.qCriticalMonotonic = all(monotonicSteps(:));
end
result.accepted = result.modeIdentityAccepted && ...
    result.maximumAlphaError <= cfg.tolerances.stage12RootContinuity && ...
    result.maximumQCriticalFormulaError <= ...
    cfg.tolerances.stage12RootContinuity && ...
    result.qCriticalMonotonic;
end
