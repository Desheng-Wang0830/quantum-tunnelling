function key = checkpoint_key(cfg, scanOptions, phaseName, phasePlan)
%CHECKPOINT_KEY Exact Stage 12 phase identity and numerical provenance.

narginchk(4, 4);
cfg = ndelta.config.finalize_configuration(cfg);
if ~isstruct(scanOptions) || ~isscalar(scanOptions) || ...
        ~all(isfield(scanOptions, {'profile', 'energyValues', 'nValues', ...
        'integrationOptions', 'runContourAudit', 'runEpsilonPlateau', ...
        'formalReleaseRequested'}))
    error('ndelta:stage12:InvalidCheckpointScanPlan', ...
        'A resolved scalar Stage 12 scan plan is required.');
end
if isstring(phaseName) && isscalar(phaseName), phaseName = char(phaseName); end
if ~ischar(phaseName) || isempty(regexp(phaseName, ...
        '^[A-Za-z][A-Za-z0-9_]*$', 'once'))
    error('ndelta:stage12:InvalidCheckpointPhase', ...
        'Checkpoint phase names must be portable MATLAB identifiers.');
end
if ~isstruct(phasePlan) || ~isscalar(phasePlan)
    error('ndelta:stage12:InvalidCheckpointPhasePlan', ...
        'The phase plan must be a scalar structure.');
end

% Deliberately retain the complete finalised configuration.  A checkpoint
% is accepted only under ISEQUALN; there is no fuzzy comparison, tolerance
% matching, release migration, or partial-provenance reuse.
key = struct();
key.schema = 'N_delta_stage12_phase_checkpoint_key_v1';
key.phase = phaseName;
key.release = ndelta.config.release_contract();
key.configuration = cfg;
key.scanPlan = scanOptions;
key.phasePlan = phasePlan;
key.physics = ndelta.config.physics_fingerprint(cfg);
key.spectrumNumerics = ...
    ndelta.config.spectrum_solver_fingerprint(cfg);
key.integrationNumerics = ndelta.config.integration_fingerprint( ...
    cfg, scanOptions.integrationOptions);
key.higherOrderIntegrationOptions = ...
    ndelta.stage12.higher_order_options( ...
    cfg, scanOptions.integrationOptions);
key.strictOrder = 'O(mu^2)';
end
