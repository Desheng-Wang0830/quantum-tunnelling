function result = topology_qperp_points(cfg, spectrum)
%TOPOLOGY_QPERP_POINTS Sample every interval between cut/mode supports.

narginchk(2, 2);
finiteCorrection = (cfg.sheet.epsilon ./ ...
    (2 .* cfg.referenceEnergy)).^2;
qCut = sqrt(max(cfg.derived.P.^2 - finiteCorrection, 0));
qCritical = zeros(1, 0);
modeIndices = zeros(1, 0);
for index = 1:numel(spectrum.modes)
    mode = spectrum.modes(index);
    if mode.stable && mode.hasOpenTransverseSupport && ...
            mode.qPerpCritical > 0
        qCritical(end + 1) = mode.qPerpCritical; %#ok<AGROW>
        modeIndices(end + 1) = index; %#ok<AGROW>
    end
end
rawBoundaries = qCritical;
rawSources = arrayfun(@(x) sprintf('mode_%d', x), ...
    modeIndices, 'UniformOutput', false);
if qCut > 0
    rawBoundaries = [qCut, rawBoundaries];
    rawSources = [{'cut'}, rawSources];
end
[boundaries, groups] = merge_boundaries(rawBoundaries, cfg);
points = zeros(1, numel(boundaries) + 1);
lower = [0, boundaries];
upper = [boundaries, Inf];
for interval = 1:numel(points)
    if isfinite(upper(interval))
        points(interval) = 0.5 .* ...
            (lower(interval) + upper(interval));
    elseif lower(interval) > 0
        % The final open interval only needs one interior topology sample.
        % Stay 20 percent beyond its last event, matching the independently
        % validated Stage 10 sampler.  A mass-scale jump can place the raw
        % finite-epsilon audit deep in an avoidable near-coalescence regime
        % even though the MWR production integral is already stable there.
        points(interval) = 1.2 .* lower(interval);
    else
        points(interval) = 0.5 .* cfg.derived.massScale;
    end
end
records = repmat(struct('index', 0, 'qPerp', 0, ...
    'lower', 0, 'upper', Inf, 'cutActive', false, ...
    'collectiveModeIndices', zeros(1, 0), ...
    'numberOfCollectiveModes', 0, 'label', ''), numel(points), 1);
for index = 1:numel(points)
    activeModes = modeIndices(points(index) < qCritical);
    % MATLAB returns a 0-by-0 empty array for a false logical selection,
    % whereas fixed_qperp_term accumulates accepted indices as 1-by-0.
    % Canonicalise the topology set to a row so physically identical empty
    % mode sets cannot fail an exact isequal comparison.
    activeModes = activeModes(:).';
    records(index).index = index;
    records(index).qPerp = points(index);
    records(index).lower = lower(index);
    records(index).upper = upper(index);
    records(index).cutActive = points(index) < qCut;
    records(index).collectiveModeIndices = activeModes;
    records(index).numberOfCollectiveModes = numel(activeModes);
    records(index).label = sprintf('cut%d_modes%s', ...
        records(index).cutActive, index_text(activeModes));
end
result = struct('qCut', qCut, 'qCritical', qCritical, ...
    'qCriticalModeIndices', modeIndices, 'rawBoundaries', rawBoundaries, ...
    'rawBoundarySources', {rawSources}, 'boundaries', boundaries, ...
    'boundaryGroups', {groups}, 'points', points, 'records', records, ...
    'coversEveryOpenTopologyInterval', true, ...
    'tracksModeIndexSetsNotOnlyAnyMode', true);
end

function [boundaries, groups] = merge_boundaries(values, cfg)
[values, order] = sort(values(:).');
groups = cell(1, 0);
boundaries = zeros(1, 0);
if isempty(values)
    return;
end
tolerance = max(cfg.tolerances.collectiveRoot, ...
    128 .* eps) .* max([1, values]);
start = 1;
while start <= numel(values)
    stop = start;
    while stop < numel(values) && ...
            abs(values(stop + 1) - values(start)) <= tolerance
        stop = stop + 1;
    end
    members = start:stop;
    boundaries(end + 1) = mean(values(members)); %#ok<AGROW>
    groups{end + 1} = order(members); %#ok<AGROW>
    start = stop + 1;
end
end

function value = index_text(indices)
if isempty(indices)
    value = 'none';
else
    value = sprintf('_%d', indices);
end
end
