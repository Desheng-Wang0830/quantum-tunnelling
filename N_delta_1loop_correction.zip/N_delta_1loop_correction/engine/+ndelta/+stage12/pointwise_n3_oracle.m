function result = pointwise_n3_oracle(cfg)
%POINTWISE_N3_ORACLE Optimised versus explicit N=3 centre sums at one node.

narginchk(1, 1);
cfg = ndelta.stage12.n3_audit_configuration(cfg);
geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
context = ndelta.stage11.build_context(cfg, geometry);
[q0, qPerp, nodeSelection] = safe_oracle_node(cfg);
roots = ndelta.sheet.physical_roots( ...
    q0, qPerp, cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
terms = {'G2', 'G3', 'G4'};
channels = 'TR';
errors = zeros(numel(terms), numel(channels));
values = complex(zeros(numel(terms), numel(channels)));
references = complex(zeros(numel(terms), numel(channels)));
for termIndex = 1:numel(terms)
    route = ndelta.stage12.term_route(terms{termIndex});
    referenceEvaluator = reference_evaluator(terms{termIndex});
    for channelIndex = 1:numel(channels)
        value = route.pointEvaluator(roots.omega, roots.kappaI, ...
            channels(channelIndex), cfg, geometry, context);
        reference = referenceEvaluator(roots.omega, roots.kappaI, ...
            channels(channelIndex), cfg, geometry, context);
        values(termIndex, channelIndex) = value;
        references(termIndex, channelIndex) = reference;
        errors(termIndex, channelIndex) = abs(value - reference) ./ ...
            (1 + abs(reference));
    end
end

% A deliberately asymmetric N=3 geometry ensures the two ordered routes
% are not accidentally identified.  This remains a pointwise oracle, not
% an extra published physical scan.
asymmetricCfg = cfg;
asymmetricCfg.barriers.positions = [-0.7, -0.05, 0.8];
asymmetricCfg.barriers.strengths = [-0.06, -0.11, -0.13];
asymmetricCfg = ndelta.config.finalize_configuration(asymmetricCfg);
asymmetricGeometry = ndelta.geometry.build_geometry( ...
    asymmetricCfg.barriers.positions, ...
    asymmetricCfg.tolerances.distanceMerge);
asymmetricContext = ndelta.stage11.build_context( ...
    asymmetricCfg, asymmetricGeometry);
asymmetricRoots = ndelta.sheet.physical_roots(q0, qPerp, ...
    asymmetricCfg.referenceEnergy, asymmetricCfg.model, ...
    asymmetricCfg.sheet.epsilon);
g2 = ndelta.g2.pointwise_contraction_from_roots( ...
    asymmetricRoots.omega, asymmetricRoots.kappaI, 'T', ...
    asymmetricCfg, asymmetricGeometry, asymmetricContext);
g3 = ndelta.g3.pointwise_contraction_from_roots( ...
    asymmetricRoots.omega, asymmetricRoots.kappaI, 'T', ...
    asymmetricCfg, asymmetricGeometry, asymmetricContext);

result = struct();
result.configuration = cfg;
result.q0 = q0;
result.qPerp = qPerp;
result.nodeSelection = nodeSelection;
result.values = values;
result.references = references;
result.errors = errors;
result.maximumError = max(errors(:));
result.asymmetricG2Transmission = g2;
result.asymmetricG3Transmission = g3;
result.asymmetricRouteDifference = abs(g2 - g3);
result.asymmetricRoutesDistinct = result.asymmetricRouteDifference > ...
    1e-10 .* (1 + max(abs([g2, g3])));
result.accepted = result.maximumError <= ...
    cfg.tolerances.stage11Pointwise && result.asymmetricRoutesDistinct;
result.status = 'stage12_N3_explicit_pointwise_oracle';
end

function [q0, qPerp, selection] = safe_oracle_node(cfg)
configuredQ0 = cfg.stage11.referenceQ0;
configuredQPerp = cfg.stage11.referenceQPerp;
configuredRoots = ndelta.sheet.physical_roots(configuredQ0, ...
    configuredQPerp, cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
configuredScore = separation_score(configuredRoots, cfg);
minimumScore = 1e-3;
if configuredScore > minimumScore
    q0 = configuredQ0;
    qPerp = configuredQPerp;
    status = 'configured_stage11_node_is_safe';
    usedFallback = false;
    score = configuredScore;
else
    % Keep the oracle away from a moving kappaI=0 branch point.  This is
    % a pointwise algebra audit only, so it need not share Stage 11's
    % user-facing diagnostic node.
    q0 = -0.5 .* cfg.model.mphi;
    qPerp = 0.37 .* cfg.derived.P;
    fallbackRoots = ndelta.sheet.physical_roots(q0, qPerp, ...
        cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
    score = separation_score(fallbackRoots, cfg);
    status = 'dynamic_branch_safe_fallback_node';
    usedFallback = true;
    if score <= minimumScore
        error('ndelta:stage12:NoSafePointwiseOracleNode', ...
            'Could not construct a root-separated Stage 12 oracle node.');
    end
end
selection = struct('status', status, 'usedFallback', usedFallback, ...
    'configuredQ0', configuredQ0, ...
    'configuredQPerp', configuredQPerp, ...
    'configuredSeparationScore', configuredScore, ...
    'selectedSeparationScore', score, ...
    'minimumSeparationScore', minimumScore);
end

function score = separation_score(roots, cfg)
omega = roots.omega;
kappaI = roots.kappaI;
regulariser = sqrt(cfg.sheet.epsilon);
omegaScale = max([abs(omega), cfg.model.mPhi, ...
    roots.qPerp, regulariser]);
kappaScale = max([abs(kappaI), cfg.derived.P, cfg.model.mphi, ...
    roots.qPerp, regulariser]);
ratios = [abs(omega) ./ omegaScale, abs(kappaI) ./ kappaScale];
poles = [omega, -omega, kappaI, -kappaI, ...
    cfg.derived.P, -cfg.derived.P];
for first = 1:(numel(poles) - 1)
    for second = (first + 1):numel(poles)
        scale = max([abs(poles(first)), abs(poles(second)), regulariser]);
        ratios(end + 1) = abs(poles(first) - poles(second)) ./ scale; %#ok<AGROW>
    end
end
score = min(ratios);
end

function evaluator = reference_evaluator(term)
switch term
    case 'G2'
        evaluator = @ndelta.g2.pointwise_reference_from_roots;
    case 'G3'
        evaluator = @ndelta.g3.pointwise_reference_from_roots;
    case 'G4'
        evaluator = @ndelta.g4.pointwise_reference_from_roots;
    otherwise
        error('ndelta:stage12:InvalidTermLabel', 'Unsupported term.');
end
end
