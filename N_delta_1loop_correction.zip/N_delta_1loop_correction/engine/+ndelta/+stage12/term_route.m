function route = term_route(termInput)
%TERM_ROUTE Freeze one G2/G3/G4 point, endpoint and collective route.

narginchk(1, 1);
if isstring(termInput) && isscalar(termInput)
    termInput = char(termInput);
end
if ~ischar(termInput)
    error('ndelta:stage12:InvalidTermLabel', ...
        'term must be G2, G3 or G4.');
end
term = upper(strtrim(termInput));
switch term
    case 'G2'
        route.pointEvaluator = ...
            @ndelta.g2.pointwise_contraction_from_roots;
        route.endpointEvaluator = @ndelta.g2.endpoint_data;
        route.collectiveEvaluator = @ndelta.g2.collective_pole_residue;
    case 'G3'
        route.pointEvaluator = ...
            @ndelta.g3.pointwise_contraction_from_roots;
        route.endpointEvaluator = @ndelta.g3.endpoint_data;
        route.collectiveEvaluator = @ndelta.g3.collective_pole_residue;
    case 'G4'
        route.pointEvaluator = ...
            @ndelta.g4.pointwise_contraction_from_roots;
        route.endpointEvaluator = @ndelta.g4.endpoint_data;
        route.collectiveEvaluator = @ndelta.g4.collective_pole_residue;
    otherwise
        error('ndelta:stage12:InvalidTermLabel', ...
            'term must be G2, G3 or G4.');
end
route.term = term;
end
