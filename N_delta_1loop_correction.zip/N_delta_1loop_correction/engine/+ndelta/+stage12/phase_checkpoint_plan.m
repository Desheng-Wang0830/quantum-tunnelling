function plan = phase_checkpoint_plan(cfg, scanOptions, phaseName, data)
%PHASE_CHECKPOINT_PLAN Build explicit phase-specific checkpoint provenance.

narginchk(3, 4);
if nargin < 4
    data = struct();
end
cfg = ndelta.config.finalize_configuration(cfg);
if isstring(phaseName) && isscalar(phaseName), phaseName = char(phaseName); end
plan = struct();
plan.schemaVersion = 1;
plan.phase = phaseName;
plan.profile = scanOptions.profile;
plan.terms = {'G2', 'G3', 'G4'};
plan.channels = 'TR';
switch phaseName
    case 'contourAudit'
        plan.auditConfiguration = ...
            ndelta.stage12.n3_audit_configuration( ...
            cfg, cfg.stage10.directDiagnosticEpsilon);
        plan.directOrder = cfg.stage10.directOrder;
        plan.directComparisonOrder = ...
            cfg.stage10.directComparisonOrder;
        plan.directMWROrder = cfg.stage10.directMWROrder;
        plan.directMWRComparisonOrder = ...
            cfg.stage10.directMWRComparisonOrder;
        plan.directTailScale = cfg.stage10.directTailScale;
        plan.directWindowFactors = cfg.stage10.directWindowFactors;
    case 'epsilonPlateau'
        plan.auditConfiguration = ...
            ndelta.stage12.n3_audit_configuration(cfg);
        plan.epsilons = cfg.stage10.epsilonPlateau(:);
        plan.q4Order = cfg.stage10.plateauOrder;
    case 'jobPairs'
        if ~isstruct(data) || ~isscalar(data) || ...
                ~all(isfield(data, {'configurations', ...
                'energyJobIndices', 'nJobIndices', ...
                'asymmetricJobIndex'}))
            error('ndelta:stage12:InvalidCheckpointJobPlan', ...
                'The job-pair checkpoint requires the complete scan job plan.');
        end
        plan.configurations = data.configurations;
        plan.energyJobIndices = data.energyJobIndices;
        plan.nJobIndices = data.nJobIndices;
        plan.asymmetricJobIndex = data.asymmetricJobIndex;
        plan.integrationOptions = scanOptions.integrationOptions;
        plan.higherOrderIntegrationOptions = ...
            ndelta.stage12.higher_order_options( ...
            cfg, scanOptions.integrationOptions);
        plan.publishedOrder = 'higher_order';
    otherwise
        error('ndelta:stage12:UnknownCheckpointPhase', ...
            'Unknown Stage 12 checkpoint phase %s.', phaseName);
end
end
