function result = term_epsilon_plateau(cfg, executionPlan, pool)
%TERM_EPSILON_PLATEAU G2--G4 N>=3 MWR Cauchy bridge to production epsilon.

narginchk(1, 3);
cfg = ndelta.config.finalize_configuration(cfg);
if nargin < 2
    executionPlan = ndelta.execution.serial_plan(cfg);
end
if nargin < 3, pool = []; end
productionCfg = ndelta.stage12.n3_audit_configuration(cfg);
productionGeometry = ndelta.geometry.build_geometry( ...
    productionCfg.barriers.positions, ...
    productionCfg.tolerances.distanceMerge);
productionSpectrum = ndelta.singularity.find_collective_modes( ...
    productionCfg, productionGeometry);
if ~productionSpectrum.accepted
    error('ndelta:stage12:EpsilonPlateauSpectrumRejected', ...
        'The production N>=3 plateau spectrum was rejected.');
end
topology = ndelta.stage12.topology_qperp_points( ...
    productionCfg, productionSpectrum);
epsilons = cfg.stage10.epsilonPlateau(:);
terms = {'G2', 'G3', 'G4'};
channels = 'TR';
numberOfRecords = numel(topology.records) .* ...
    numel(terms) .* numel(channels);
values = complex(zeros(numel(epsilons), numberOfRecords));
sources = complex(zeros(numel(epsilons), numberOfRecords, 5));
evaluator = @(epsilonIndex) ndelta.stage12.epsilon_plateau_row( ...
    epsilons(epsilonIndex), cfg, topology);
[rows, execution] = ndelta.execution.map_indexed( ...
    numel(epsilons), evaluator, executionPlan, pool, 'epsilon rows');
for epsilonIndex = 1:numel(epsilons)
    values(epsilonIndex, :) = rows{epsilonIndex}.values;
    sources(epsilonIndex, :, :) = reshape( ...
        rows{epsilonIndex}.sources, [1, numberOfRecords, 5]);
end
metadata = rows{1}.metadata;
allTopologyMatches = all(cellfun(@(row) row.accepted, rows));

floorValue = 1e-8 ./ max(cfg.derived.massScale, realmin);
maximumTotalError = cauchy_error(values, floorValue);
maximumSourceError = cauchy_error( ...
    reshape(sources, numel(epsilons), []), floorValue);
result = struct();
result.N = productionCfg.derived.N;
result.epsilons = epsilons;
result.productionEpsilon = cfg.sheet.epsilon;
result.topology = topology;
result.metadata = metadata;
result.values = values;
result.sources = sources;
result.execution = execution;
result.sourceNames = {'euclidean', 'ordinaryPole', ...
    'collectivePole', 'cutBanks', 'endpointKeyhole'};
result.maximumTotalCauchyError = maximumTotalError;
result.maximumSourceCauchyError = maximumSourceError;
result.minimumTauScaledRcond = min(cellfun( ...
    @(row) row.minimumTauScaledRcond, rows));
result.maximumTauConditionAmplification = max(cellfun( ...
    @(row) row.maximumTauConditionAmplification, rows));
result.minimumCollectiveProjectedRcond = min(cellfun( ...
    @(row) row.minimumCollectiveProjectedRcond, rows));
result.minimumCollectiveProjectedScaledRcond = min(cellfun( ...
    @(row) row.minimumCollectiveProjectedScaledRcond, rows));
result.collectiveConditionAccepted = all(cellfun( ...
    @(row) row.collectiveConditionAccepted, rows));
result.totalAccepted = maximumTotalError <= ...
    cfg.tolerances.stage12EpsilonTotal;
result.sourceAccepted = maximumSourceError <= ...
    cfg.tolerances.stage12EpsilonSource;
result.topologyAccepted = allTopologyMatches;
result.accepted = result.totalAccepted && result.sourceAccepted && ...
    result.topologyAccepted && result.collectiveConditionAccepted;
result.noExtrapolationUsed = true;
result.directProductionEpsilonIdentityClaimed = false;
result.status = 'stage12_N3_G2_G4_MWR_production_epsilon_plateau';
end

function maximumError = cauchy_error(values, floorValue)
maximumError = 0;
for first = 1:(size(values, 1) - 1)
    for second = (first + 1):size(values, 1)
        errors = abs(values(first, :) - values(second, :)) ./ ...
            (floorValue + max(abs(values(first, :)), ...
            abs(values(second, :))));
        maximumError = max(maximumError, max(errors(:)));
    end
end
end
