function result = fixed_qperp_term( ...
        termInput, qPerp, channelInput, cfg, geometry, spectrum, ...
        context, options)
%FIXED_QPERP_TERM MWR total and five sources for one G2/G3/G4 term.

narginchk(7, 8);
if nargin < 8
    options = struct();
end
cfg = ndelta.config.finalize_configuration(cfg);
validateattributes(qPerp, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, mfilename, 'qPerp');
channel = ndelta.g1.normalise_channel(channelInput);
geometry = ndelta.g1.resolve_pair_geometry(cfg, geometry);
context = ndelta.stage11.validate_context(context, cfg, geometry);
validate_spectrum(spectrum, cfg);
route = ndelta.stage12.term_route(termInput);
options = ndelta.contour.resolve_options(cfg, options);

euclidean = ndelta.stage11.euclidean_fixed(route.term, ...
    route.pointEvaluator, qPerp, channel, cfg, geometry, context, options);
collectiveRecords = cell(numel(spectrum.modes), 1);
collectiveValue = complex(0);
acceptedModeIndices = zeros(1, 0);
minimumProjectedRcond = Inf;
minimumProjectedScaledRcond = Inf;
for modeIndex = 1:numel(spectrum.modes)
    mode = spectrum.modes(modeIndex);
    residue = route.collectiveEvaluator( ...
        mode, qPerp, channel, cfg, geometry, context);
    collectiveRecords{modeIndex} = residue;
    if residue.accepted
        collectiveValue = collectiveValue + residue.contourContribution;
        acceptedModeIndices(end + 1) = modeIndex; %#ok<AGROW>
        minimumProjectedRcond = min(minimumProjectedRcond, ...
            residue.matrixResidue.projectedDerivativeRcond);
        minimumProjectedScaledRcond = min( ...
            minimumProjectedScaledRcond, ...
            residue.matrixResidue.projectedDerivativeScaledRcond);
    elseif mode.stable && mode.hasOpenTransverseSupport && ...
            qPerp < mode.qPerpCritical
        error('ndelta:stage12:InteriorCollectiveResidueRejected', ...
            ['A collective mode expected inside its open support was ' ...
             'rejected by the matrix-residue gate.']);
    end
end
cut = ndelta.stage11.cut_fixed(route.term, route.pointEvaluator, ...
    route.endpointEvaluator, qPerp, channel, cfg, geometry, context, options);
ordinary = complex(0);
sourceVector = [euclidean.value, ordinary, collectiveValue, ...
    cut.bankContribution, cut.endpointContribution];
total = sum(sourceVector);
finiteCorrection = (cfg.sheet.epsilon ./ ...
    (2 .* cfg.referenceEnergy)).^2;
qCut = sqrt(max(cfg.derived.P.^2 - finiteCorrection, 0));

result = struct();
result.term = route.term;
result.channel = channel;
result.qPerp = qPerp;
result.value = complex(real(total), imag(total));
result.euclidean = euclidean;
result.ordinaryPole = ordinary;
result.collectivePoleValue = collectiveValue;
result.collective = collectiveRecords;
result.acceptedCollectiveModeIndices = acceptedModeIndices;
result.minimumCollectiveProjectedRcond = minimumProjectedRcond;
result.minimumCollectiveProjectedScaledRcond = ...
    minimumProjectedScaledRcond;
result.collectiveConditionAccepted = ...
    minimumProjectedRcond >= cfg.tolerances.nearSingularRcond && ...
    minimumProjectedScaledRcond >= cfg.tolerances.nearSingularRcond;
result.cut = cut;
result.sourceNames = {'euclidean', 'ordinaryPole', ...
    'collectivePole', 'cutBanks', 'endpointKeyhole'};
result.sourceVector = sourceVector;
result.sourceClosureResidual = abs(total - sum(sourceVector)) ./ ...
    (1 + abs(total));
result.hasCut = qPerp < qCut;
result.qCut = qCut;
result.includesQ0Measure = true;
result.includesQPerpMeasure = false;
result.includesMuSquared = false;
result.includesLSZ = false;
result.maximumTauEquationResidual = max( ...
    euclidean.maximumTauEquationResidual, ...
    cut.maximumTauEquationResidual);
result.minimumTauScaledRcond = min( ...
    euclidean.minimumTauScaledRcond, ...
    cut.minimumTauScaledRcond);
result.maximumTauConditionAmplification = max( ...
    euclidean.maximumTauConditionAmplification, ...
    cut.maximumTauConditionAmplification);
result.status = 'stage12_fixed_qperp_term_MWR_five_sources';
end

function validate_spectrum(spectrum, cfg)
required = {'configurationFingerprint', 'solverFingerprint', ...
    'accepted', 'modes'};
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~all(isfield(spectrum, required)) || ~spectrum.accepted
    error('ndelta:stage12:InvalidCollectiveSpectrum', ...
        'An accepted spectrum from the same point configuration is required.');
end
ndelta.config.assert_physics_fingerprint( ...
    spectrum.configurationFingerprint, cfg, ...
    'ndelta:stage12:SpectrumConfigurationMismatch');
if ~isequaln(spectrum.solverFingerprint, ...
        ndelta.config.spectrum_solver_fingerprint(cfg))
    error('ndelta:stage12:SpectrumSolverMismatch', ...
        'The fixed-qPerp term received a stale spectrum.');
end
end
