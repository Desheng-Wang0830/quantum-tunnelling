function profile = asymmetric_n3_profile(support, totalStrength)
%ASYMMETRIC_N3_PROFILE Deterministic full-integral mirror-audit anchor.

% This profile is deliberately outside the trapezoidal N family.  It
% exists only to force a fresh mirrored-potential right-incidence run and
% to prevent a parity shortcut from hiding an off-diagonal S-matrix bug.

narginchk(2, 2);
if ~isnumeric(support) || ~isreal(support) || ...
        ~isequal(size(support), [1, 2]) || ...
        any(~isfinite(support)) || support(2) <= support(1)
    error('ndelta:stage12:InvalidAsymmetricSupport', ...
        'support must be a finite increasing 1-by-2 vector.');
end
validateattributes(totalStrength, {'numeric'}, ...
    {'real', 'finite', 'nonzero', 'scalar'}, ...
    mfilename, 'totalStrength');

span = support(2) - support(1);
positionFractions = [0, 0.43, 1];
strengthFractions = [0.20, 11 ./ 30, 13 ./ 30];
positions = support(1) + span .* positionFractions;
strengths = totalStrength .* strengthFractions;
symmetry = ndelta.stage12.is_centered_mirror_symmetric( ...
    positions, strengths);

profile = struct();
profile.N = 3;
profile.positions = positions;
profile.strengths = strengths;
profile.support = support;
profile.totalStrength = sum(strengths);
profile.positionFractions = positionFractions;
profile.strengthFractions = strengthFractions;
profile.discretisation = 'deliberately_asymmetric_N3_mirror_audit';
profile.exactSupportEndpoints = isequal(positions([1, end]), support);
profile.centred = false;
profile.mirrorSymmetric = symmetry.accepted;
profile.requiresFreshMirroredRightIncidence = true;
end
