function [payload, report] = checkpoint_phase( ...
        cfg, scanOptions, phaseName, phasePlan, producer)
%CHECKPOINT_PHASE Reuse or atomically save one complete Stage 12 phase.

narginchk(5, 5);
cfg = ndelta.config.finalize_configuration(cfg);
if ~isa(producer, 'function_handle')
    error('ndelta:stage12:InvalidCheckpointProducer', ...
        'The checkpoint producer must be a zero-input function handle.');
end
key = ndelta.stage12.checkpoint_key( ...
    cfg, scanOptions, phaseName, phasePlan);
enabled = strcmp(scanOptions.profile, 'production');
report = struct('enabled', enabled, 'hit', false, 'saved', false, ...
    'path', '', 'status', 'checkpoint_disabled_nonproduction', ...
    'phase', phaseName, 'key', key);

% Portable and quick tests must be hermetic and must never read or write a
% production cache, even if a compatible file happens to exist.
if ~enabled
    payload = producer();
    return;
end

directory = fullfile(cfg.projectRoot, char(cfg.output.directoryName), ...
    'stage12_checkpoints');
path = fullfile(directory, ['stage12_', phaseName, '.mat']);
report.path = path;
if exist(path, 'file')
    try
        loaded = load(path, 'checkpoint');
        valid = isfield(loaded, 'checkpoint') && ...
            isstruct(loaded.checkpoint) && ...
            isscalar(loaded.checkpoint) && ...
            all(isfield(loaded.checkpoint, ...
            {'schema', 'key', 'payload'})) && ...
            strcmp(loaded.checkpoint.schema, ...
            'N_delta_stage12_phase_checkpoint_v1') && ...
            isequaln(loaded.checkpoint.key, key);
        if valid
            payload = loaded.checkpoint.payload;
            report.hit = true;
            report.status = 'checkpoint_hit_exact_key';
            fprintf('Stage 12 checkpoint HIT: %s (%s)\n', ...
                phaseName, path);
            return;
        end
        fprintf(['Stage 12 checkpoint KEY MISMATCH: %s; ' ...
            'the phase will be recomputed.\n'], phaseName);
    catch exception
        warning('ndelta:stage12:CheckpointReadFailure', ...
            ['Could not validate Stage 12 checkpoint %s [%s]: %s. ' ...
             'The phase will be recomputed.'], ...
            path, exception.identifier, exception.message);
    end
end

payload = producer();
checkpoint = struct();
checkpoint.schema = 'N_delta_stage12_phase_checkpoint_v1';
checkpoint.key = key;
checkpoint.payload = payload;
checkpoint.savedAt = datestr(now, 30);
variables = struct('checkpoint', checkpoint);
ndelta.stage12.atomic_save(path, variables);
report.saved = true;
report.status = 'checkpoint_saved_after_complete_phase';
fprintf('Stage 12 checkpoint SAVED: %s (%s)\n', phaseName, path);
end
