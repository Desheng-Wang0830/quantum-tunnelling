function result = term_contour_audit(cfg, executionPlan, pool)
%TERM_CONTOUR_AUDIT G2--G4 finite-epsilon raw/MWR identity at formal N>=3.

narginchk(1, 3);
cfg = ndelta.config.finalize_configuration(cfg);
if nargin < 2
    executionPlan = ndelta.execution.serial_plan(cfg);
end
if nargin < 3, pool = []; end
auditCfg = ndelta.stage12.n3_audit_configuration( ...
    cfg, cfg.stage10.directDiagnosticEpsilon);
geometry = ndelta.geometry.build_geometry( ...
    auditCfg.barriers.positions, auditCfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(auditCfg, geometry);
if ~spectrum.accepted
    error('ndelta:stage12:ContourAuditSpectrumRejected', ...
        'The finite-epsilon N>=3 contour audit spectrum was rejected.');
end
context = ndelta.stage11.build_context(auditCfg, geometry);
topology = ndelta.stage12.topology_qperp_points(auditCfg, spectrum);
terms = {'G2', 'G3', 'G4'};
channels = 'TR';
recordCount = numel(terms) .* numel(channels) .* numel(topology.records);
floorValue = 1e-8 ./ max(auditCfg.derived.massScale, realmin);

highDirect = struct('order', cfg.stage10.directOrder, ...
    'tailScale', cfg.stage10.directTailScale, ...
    'windowFactors', cfg.stage10.directWindowFactors);
lowDirect = highDirect;
lowDirect.order = cfg.stage10.directComparisonOrder;
highMWR = struct('q4Order', cfg.stage10.directMWROrder, ...
    'q4Scale', auditCfg.integration.q4Scale, ...
    'q4MapPower', auditCfg.integration.q4MapPower, ...
    'cutRadialOrder', cfg.stage10.directMWROrder);
lowMWR = highMWR;
lowMWR.q4Order = cfg.stage10.directMWRComparisonOrder;
lowMWR.cutRadialOrder = cfg.stage10.directMWRComparisonOrder;

tasks = cell(recordCount, 1);
recordIndex = 0;
for topologyIndex = 1:numel(topology.records)
    topologyRecord = topology.records(topologyIndex);
    for termIndex = 1:numel(terms)
        for channelIndex = 1:numel(channels)
            recordIndex = recordIndex + 1;
            tasks{recordIndex} = struct('term', terms{termIndex}, ...
                'channel', channels(channelIndex), ...
                'topologyIndex', topologyIndex, ...
                'topologyRecord', topologyRecord);
        end
    end
end
evaluator = @(index) ndelta.stage12.contour_audit_record( ...
    tasks{index}, auditCfg, geometry, spectrum, context, ...
    highDirect, lowDirect, highMWR, lowMWR, floorValue);
[recordCells, execution] = ndelta.execution.map_indexed( ...
    recordCount, evaluator, executionPlan, pool, 'contour records');
records = vertcat(recordCells{:});
maximumDirectSelfError = max([records.directSelfError]);
maximumMWRSelfError = max([records.mwrSelfError]);
maximumIdentityError = max([records.identityError]);
allTopologyMatches = all([records.topologyMatches]);

result = struct();
result.auditConfiguration = auditCfg;
result.N = auditCfg.derived.N;
result.diagnosticEpsilon = auditCfg.sheet.epsilon;
result.productionEpsilon = cfg.sheet.epsilon;
result.topology = topology;
result.records = records;
result.execution = execution;
result.maximumDirectSelfError = maximumDirectSelfError;
result.maximumMWRSelfError = maximumMWRSelfError;
result.maximumIdentityError = maximumIdentityError;
result.minimumTauScaledRcond = min([records.minimumTauScaledRcond]);
result.maximumTauConditionAmplification = max( ...
    [records.maximumTauConditionAmplification]);
result.minimumCollectiveProjectedRcond = min( ...
    [records.minimumCollectiveProjectedRcond]);
result.minimumCollectiveProjectedScaledRcond = min( ...
    [records.minimumCollectiveProjectedScaledRcond]);
result.collectiveConditionAccepted = ...
    all([records.collectiveConditionAccepted]);
result.directSelfAccepted = maximumDirectSelfError <= ...
    cfg.tolerances.stage12DirectSelf;
result.mwrSelfAccepted = maximumMWRSelfError <= ...
    cfg.tolerances.stage12MWRSelf;
result.identityAccepted = maximumIdentityError <= ...
    cfg.tolerances.stage12ContourIdentity;
result.topologyAccepted = allTopologyMatches;
result.accepted = result.directSelfAccepted && ...
    result.mwrSelfAccepted && result.identityAccepted && ...
    result.topologyAccepted && result.collectiveConditionAccepted;
result.rawPathUsesNoMWRSources = true;
result.directIdentityAtProductionEpsilonStatus = 'not_claimed';
result.status = 'stage12_N3_G2_G4_finite_epsilon_raw_equals_MWR';
end
