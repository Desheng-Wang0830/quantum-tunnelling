function point = evaluate_direction(cfg, options, preparedState)
%EVALUATE_DIRECTION One validated left-incidence full G1--G4 scan point.

narginchk(1, 3);
if nargin < 2
    options = struct();
end
cfg = ndelta.config.finalize_configuration(cfg);
effectiveOptions = ndelta.integration.resolve_options(cfg, options);
if nargin < 3
    preparedState = ndelta.stage12.prepare_direction_state(cfg);
else
    validate_prepared_state(preparedState, cfg);
end
stage1 = preparedState.stage1;
geometry = preparedState.geometry;
tree = preparedState.tree;
spectrum = preparedState.spectrum;
elasticWindow = preparedState.elasticWindow;

point = base_point(cfg, effectiveOptions, stage1, tree, spectrum, ...
    elasticWindow);
if ~elasticWindow.accepted
    point.rejectionIdentifier = ...
        'ndelta:stage12:InelasticChannelNotImplemented';
    point.status = elasticWindow.classification;
    return;
end
if ~spectrum.accepted
    point.rejectionIdentifier = ...
        'ndelta:stage12:CollectiveSpectrumRejected';
    point.status = 'collective_spectrum_rejected';
    return;
end
if tree.background.solveDiagnostics.nearSingular
    point.rejectionIdentifier = ...
        'ndelta:stage12:NearSingularExternalGamma';
    point.status = 'near_singular_external_Gamma_N';
    return;
end

context = preparedState.context;
g1 = ndelta.integration.integrate_g1( ...
    cfg, geometry, spectrum, effectiveOptions);
g2 = ndelta.integration.integrate_g2( ...
    cfg, geometry, spectrum, context, effectiveOptions);
g3 = ndelta.integration.integrate_g3( ...
    cfg, geometry, spectrum, context, effectiveOptions);
g4 = ndelta.integration.integrate_g4( ...
    cfg, geometry, spectrum, context, effectiveOptions);
g1.term = 'G1';
reduced = struct('G1', g1, 'G2', g2, 'G3', g3, 'G4', g4);
validate_reduced_provenance(cfg, effectiveOptions, spectrum, reduced);

a1 = ndelta.amplitude.assemble_g1(cfg, tree, g1);
a2 = ndelta.amplitude.assemble_stage11_term(cfg, tree, g2);
a3 = ndelta.amplitude.assemble_stage11_term(cfg, tree, g3);
a4 = ndelta.amplitude.assemble_stage11_term(cfg, tree, g4);
amplitudes = struct('G1', a1, 'G2', a2, 'G3', a3, 'G4', a4);
combined = ndelta.amplitude.assemble_g1_g4( ...
    cfg, tree, a1, a2, a3, a4);

termNames = {'G1', 'G2', 'G3', 'G4'};
sourceTensor = complex(zeros(4, 2, 5));
maximumSourceClosure = 0;
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
minimumProjectedRcond = Inf;
minimumProjectedScaledRcond = Inf;
numberOfPointEvaluations = 0;
for termIndex = 1:4
    item = reduced.(termNames{termIndex});
    sourceTensor(termIndex, :, :) = reshape( ...
        item.sourceMatrix, [1, 2, 5]);
    maximumSourceClosure = max(maximumSourceClosure, ...
        item.maximumClosureResidual);
    if isfield(item, 'maximumTauEquationResidual')
        maximumTauResidual = max(maximumTauResidual, ...
            item.maximumTauEquationResidual);
    end
    if isfield(item, 'minimumTauScaledRcond')
        minimumTauScaledRcond = min(minimumTauScaledRcond, ...
            item.minimumTauScaledRcond);
    end
    if isfield(item, 'maximumTauConditionAmplification')
        maximumTauConditionAmplification = max( ...
            maximumTauConditionAmplification, ...
            item.maximumTauConditionAmplification);
    end
    if isfield(item, 'minimumCollectiveProjectedRcond')
        minimumProjectedRcond = min(minimumProjectedRcond, ...
            item.minimumCollectiveProjectedRcond);
    end
    if isfield(item, 'minimumCollectiveProjectedScaledRcond')
        minimumProjectedScaledRcond = min( ...
            minimumProjectedScaledRcond, ...
            item.minimumCollectiveProjectedScaledRcond);
    end
    if isfield(item, 'numberOfPointEvaluations')
        numberOfPointEvaluations = numberOfPointEvaluations + ...
            item.numberOfPointEvaluations;
    end
end

finiteVector = [combined.termKernelMatrix(:); ...
    combined.termAmplitudesPerMu2(:); ...
    combined.totalDeltaAmplitudes(:); ...
    combined.totalDeltaProbabilities(:); sourceTensor(:)];
allFinite = all(isfinite(real(finiteVector))) && ...
    all(isfinite(imag(finiteVector)));
deltaProbabilityPerMu2 = 2 .* real(conj([tree.t0, tree.r0]) ...
    .* combined.totalAmplitudesPerMu2);
closurePerMu2 = sum(deltaProbabilityPerMu2);
closureScalePerMu2 = sum(abs(deltaProbabilityPerMu2));
closureAccepted = abs(closurePerMu2) <= ...
    cfg.tolerances.stage12UnitarityAbsolute + ...
    cfg.tolerances.stage12Unitarity .* closureScalePerMu2;
nearDegeneracy = unresolved_near_degeneracy(spectrum, cfg);

point.context = context;
point.reduced = reduced;
point.amplitudes = amplitudes;
point.combined = combined;
point.sourceTensor = sourceTensor;
point.termKernelMatrix = combined.termKernelMatrix;
point.maximumSourceClosure = maximumSourceClosure;
point.maximumTauEquationResidual = maximumTauResidual;
point.minimumTauScaledRcond = minimumTauScaledRcond;
point.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
point.tauConditionAccepted = minimumTauScaledRcond >= ...
    cfg.tolerances.nearSingularRcond;
point.minimumCollectiveProjectedRcond = minimumProjectedRcond;
point.minimumCollectiveProjectedScaledRcond = ...
    minimumProjectedScaledRcond;
point.collectiveConditionAccepted = ...
    minimumProjectedRcond >= cfg.tolerances.nearSingularRcond && ...
    minimumProjectedScaledRcond >= cfg.tolerances.nearSingularRcond;
point.numberOfPointEvaluations = numberOfPointEvaluations;
point.deltaProbabilityPerMu2 = deltaProbabilityPerMu2;
point.leftUnitarityClosurePerMu2 = closurePerMu2;
point.leftUnitarityScalePerMu2 = closureScalePerMu2;
point.leftUnitarityNormalisedError = abs(closurePerMu2) ./ ...
    max(1e-12, closureScalePerMu2);
point.leftUnitarityAccepted = closureAccepted;
point.allFinite = allFinite;
point.unresolvedNearDegeneracy = nearDegeneracy;
point.observableFingerprint = ...
    ndelta.stage12.observable_fingerprint(cfg, effectiveOptions, spectrum);
point.maximumDeltaAmplitude = max(abs( ...
    combined.totalDeltaAmplitudes));
point.maximumConditionalAmplitudeRatio = max(abs( ...
    combined.totalDeltaAmplitudes) ./ ...
    max(1e-12, abs([tree.t0, tree.r0])));
point.omittedAmplitudeSquaredScale = ...
    sum(abs(combined.totalDeltaAmplitudes).^2);
point.truncatedProbabilitiesInNominalRange = all( ...
    combined.truncatedProbabilities >= -1e-8 & ...
    combined.truncatedProbabilities <= 1 + 1e-8);
point.accepted = allFinite && closureAccepted && ...
    maximumSourceClosure <= cfg.tolerances.stage12SourceClosure && ...
    maximumTauResidual <= cfg.tolerances.matrix && ...
    point.tauConditionAccepted && ...
    point.collectiveConditionAccepted && ...
    abs(tree.probabilityClosureResidual) <= cfg.tolerances.unitarity && ...
    ~nearDegeneracy;
if point.accepted
    point.status = 'accepted_closed_elastic_direction';
else
    point.rejectionIdentifier = ...
        'ndelta:stage12:DirectionValidationRejected';
    point.status = 'direction_validation_rejected';
end
end

function validate_prepared_state(state, cfg)
required = {'preparationFingerprint', 'configurationFingerprint', ...
    'spectrumSolverFingerprint', 'modelMu', 'stage1', 'tree', ...
    'geometry', 'spectrum', 'elasticWindow', 'context', ...
    'orderIndependent'};
validState = isstruct(state) && isscalar(state) && ...
    all(isfield(state, required));
if validState
    validState = islogical(state.orderIndependent) && ...
        isscalar(state.orderIndependent) && state.orderIndependent;
end
if ~validState
    error('ndelta:stage12:InvalidPreparedDirectionState', ...
        'A complete order-independent direction state is required.');
end
if ~isequaln(state.preparationFingerprint, ...
        ndelta.stage12.preparation_fingerprint(cfg))
    error('ndelta:stage12:PreparedDirectionConfigurationMismatch', ...
        ['The prepared direction state has stale tree, solver, coupling ' ...
         'or preflight-tolerance data.']);
end
ndelta.config.assert_physics_fingerprint( ...
    state.configurationFingerprint, cfg, ...
    'ndelta:stage12:PreparedDirectionConfigurationMismatch');
if ~isequaln(state.spectrumSolverFingerprint, ...
        ndelta.config.spectrum_solver_fingerprint(cfg)) || ...
        ~isequaln(state.modelMu, cfg.model.mu)
    error('ndelta:stage12:PreparedDirectionConfigurationMismatch', ...
        'The prepared direction state has stale solver or coupling data.');
end
end

function point = base_point(cfg, options, stage1, tree, spectrum, window)
point = struct();
point.configuration = cfg;
point.configurationFingerprint = ndelta.config.physics_fingerprint(cfg);
point.effectiveOptions = options;
point.energy = cfg.referenceEnergy;
point.P = cfg.derived.P;
point.N = cfg.derived.N;
point.numberOfActiveCentres = cfg.derived.numberOfActiveCentres;
point.positions = cfg.barriers.positions;
point.strengths = cfg.barriers.strengths;
point.stage1 = stage1;
point.tree = tree;
point.spectrum = spectrum;
point.elasticWindow = window;
point.context = struct();
point.reduced = struct();
point.amplitudes = struct();
point.combined = struct();
point.sourceTensor = complex(zeros(4, 2, 5));
point.termKernelMatrix = complex(zeros(4, 2));
point.maximumSourceClosure = Inf;
point.maximumTauEquationResidual = Inf;
point.minimumTauScaledRcond = 0;
point.maximumTauConditionAmplification = Inf;
point.tauConditionAccepted = false;
point.minimumCollectiveProjectedRcond = 0;
point.minimumCollectiveProjectedScaledRcond = 0;
point.collectiveConditionAccepted = false;
point.numberOfPointEvaluations = 0;
point.deltaProbabilityPerMu2 = [NaN, NaN];
point.leftUnitarityClosurePerMu2 = NaN;
point.leftUnitarityScalePerMu2 = NaN;
point.leftUnitarityNormalisedError = Inf;
point.leftUnitarityAccepted = false;
point.allFinite = false;
point.unresolvedNearDegeneracy = false;
point.observableFingerprint = struct();
point.maximumDeltaAmplitude = NaN;
point.maximumConditionalAmplitudeRatio = NaN;
point.omittedAmplitudeSquaredScale = NaN;
point.truncatedProbabilitiesInNominalRange = false;
point.accepted = false;
point.rejectionIdentifier = '';
point.status = 'not_evaluated';
end

function validate_reduced_provenance(cfg, options, spectrum, reduced)
expectedSolver = ndelta.config.spectrum_solver_fingerprint(cfg);
expectedSpectrum = ndelta.singularity.spectrum_signature(spectrum);
expectedNumerics = ndelta.config.integration_fingerprint(cfg, options);
expectedCutFamily = expectedNumerics.cutBankQuadratureFamily;
for termCell = {'G1', 'G2', 'G3', 'G4'}
    term = termCell{1};
    item = reduced.(term);
    if ~isfield(item, 'term') || ~strcmp(item.term, term) || ...
            ~isfield(item, 'spectrumSolverFingerprint') || ...
            ~isequaln(item.spectrumSolverFingerprint, expectedSolver) || ...
            ~isfield(item, 'spectrumSignature') || ...
            ~isequaln(item.spectrumSignature, expectedSpectrum) || ...
            ~isfield(item, 'numericsFingerprint') || ...
            ~isequaln(item.numericsFingerprint, expectedNumerics) || ...
            ~isfield(item, 'cutQuadratureFamily') || ...
            ~strcmp(item.cutQuadratureFamily, expectedCutFamily)
        error('ndelta:stage12:ReducedProvenanceMismatch', ...
            ['All four reduced terms must retain the same term label, ' ...
             'spectrum identity and production numerical fingerprint.']);
    end
end
end

function rejected = unresolved_near_degeneracy(spectrum, cfg)
rejected = false;
for index = 1:numel(spectrum.modes)
    mode = spectrum.modes(index);
    if mode.nullity <= 1 || numel(mode.candidateAlphas) <= 1
        continue;
    end
    spread = max(mode.candidateAlphas) - min(mode.candidateAlphas);
    scale = max(mode.alpha, realmin);
    rejected = rejected || spread > max(1024 .* eps .* scale, ...
        0.25 .* cfg.tolerances.collectiveDuplicate .* scale);
end
end
