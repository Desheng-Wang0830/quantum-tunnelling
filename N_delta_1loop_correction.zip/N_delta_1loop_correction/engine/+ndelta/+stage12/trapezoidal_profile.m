function profile = trapezoidal_profile(N, support, totalStrength)
%TRAPEZOIDAL_PROFILE Fixed-support delta quadrature with fixed total weight.

narginchk(3, 3);
validateattributes(N, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 2, 'scalar'}, mfilename, 'N');
if ~isnumeric(support) || ~isreal(support) || ...
        ~isequal(size(support), [1, 2]) || ...
        any(~isfinite(support)) || support(2) <= support(1)
    error('ndelta:stage12:InvalidProfileSupport', ...
        'support must be a finite increasing 1-by-2 vector.');
end
validateattributes(totalStrength, {'numeric'}, ...
    {'real', 'finite', 'nonzero', 'scalar'}, ...
    mfilename, 'totalStrength');

positions = linspace(support(1), support(2), N);
weights = ones(1, N);
weights([1, end]) = 0.5;
strengths = totalStrength .* weights ./ sum(weights);
profile = struct();
profile.N = N;
profile.positions = positions;
profile.strengths = strengths;
profile.support = support;
profile.totalStrength = sum(strengths);
profile.spacing = (support(2) - support(1)) ./ (N - 1);
profile.quadratureWeights = weights ./ sum(weights);
profile.discretisation = 'fixed_support_trapezoidal';
profile.exactSupportEndpoints = isequal(positions([1, end]), support);
profile.centred = abs(sum(support)) <= ...
    64 .* eps(max([1, abs(support)]));
profile.mirrorSymmetric = max(abs(positions + fliplr(positions))) <= ...
    64 .* eps(max([1, abs(positions)])) && ...
    max(abs(strengths - fliplr(strengths))) <= ...
    64 .* eps(max([1, abs(strengths)]));
end
