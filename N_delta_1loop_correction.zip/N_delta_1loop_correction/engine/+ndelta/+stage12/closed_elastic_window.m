function result = closed_elastic_window(cfg, spectrum)
%CLOSED_ELASTIC_WINDOW Include Phi plus collective-bound-mode thresholds.

narginchk(2, 2);
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~all(isfield(spectrum, {'modes', 'configurationFingerprint', ...
        'solverFingerprint'})) || ~isstruct(spectrum.modes)
    error('ndelta:stage12:InvalidSpectrumForThreshold', ...
        'spectrum must contain the collective mode list.');
end
ndelta.config.assert_physics_fingerprint( ...
    spectrum.configurationFingerprint, cfg, ...
    'ndelta:stage12:ThresholdSpectrumConfigurationMismatch');
if ~isequaln(spectrum.solverFingerprint, ...
        ndelta.config.spectrum_solver_fingerprint(cfg))
    error('ndelta:stage12:ThresholdSpectrumSolverMismatch', ...
        'The elastic-threshold calculation received a stale spectrum.');
end
freeThreshold = cfg.model.mphi + cfg.model.mPhi;
numberOfModes = numel(spectrum.modes);
alphas = zeros(1, numberOfModes);
boundMasses = zeros(1, numberOfModes);
thresholds = zeros(1, numberOfModes);
for index = 1:numberOfModes
    alpha = spectrum.modes(index).alpha;
    alphas(index) = alpha;
    if spectrum.modes(index).stable
        boundMasses(index) = sqrt(max( ...
            cfg.model.mphi.^2 - alpha.^2, 0));
        thresholds(index) = cfg.model.mPhi + boundMasses(index);
    else
        boundMasses(index) = NaN;
        thresholds(index) = NaN;
    end
end
ceiling = freeThreshold;
limitingModeIndex = 0;
stableIndices = find([spectrum.modes.stable]);
if ~isempty(stableIndices)
    [collectiveCeiling, localIndex] = min(thresholds(stableIndices));
    limitingModeIndex = stableIndices(localIndex);
    if collectiveCeiling < ceiling
        ceiling = collectiveCeiling;
    else
        limitingModeIndex = 0;
    end
end
scale = max([1, abs(cfg.referenceEnergy), abs(ceiling)]);
eventTolerance = 128 .* eps(scale);
if cfg.referenceEnergy < ceiling - eventTolerance
    classification = 'closed_elastic';
    accepted = true;
elseif abs(cfg.referenceEnergy - ceiling) <= eventTolerance
    classification = 'inelastic_threshold_endpoint_not_implemented';
    accepted = false;
else
    classification = 'inelastic_channel_not_implemented';
    accepted = false;
end
result = struct('lower', cfg.model.mphi, 'upper', ceiling, ...
    'freeThreshold', freeThreshold, 'collectiveAlphas', alphas, ...
    'collectiveStableMask', reshape([spectrum.modes.stable], 1, []), ...
    'boundModeMasses', boundMasses, ...
    'boundModeThresholds', thresholds, ...
    'limitingModeIndex', limitingModeIndex, ...
    'classification', classification, 'accepted', accepted, ...
    'eventTolerance', eventTolerance, ...
    'includesPhiPlusBoundModeThresholds', true, ...
    'qPerpCriticalIsNotProductionThreshold', true);
end
