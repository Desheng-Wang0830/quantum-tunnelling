function fingerprint = preparation_fingerprint(cfg)
%PREPARATION_FINGERPRINT Identity of all order-independent Stage 12 data.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
fingerprint = struct();
fingerprint.version = 1;
fingerprint.physics = ndelta.config.physics_fingerprint(cfg);
fingerprint.spectrumSolver = ...
    ndelta.config.spectrum_solver_fingerprint(cfg);
fingerprint.modelMu = cfg.model.mu;
fingerprint.nearSingularRcond = cfg.tolerances.nearSingularRcond;
fingerprint.matrixTolerance = cfg.tolerances.matrix;
fingerprint.unitarityTolerance = cfg.tolerances.unitarity;
end
