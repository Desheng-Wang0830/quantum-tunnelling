function result = real_axis_fixed_term( ...
        termInput, qPerp, channelInput, cfg, geometry, spectrum, ...
        context, options)
%REAL_AXIS_FIXED_TERM Independent finite-epsilon raw q0 integral, G2--G4.
%
% This routine reads no MWR residue, cut-bank or endpoint value.  The
% collective spectrum is used only to place open quadrature landmarks.

narginchk(7, 8);
if nargin < 8
    options = struct();
end
cfg = ndelta.config.finalize_configuration(cfg);
validateattributes(qPerp, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, mfilename, 'qPerp');
channel = ndelta.g1.normalise_channel(channelInput);
geometry = ndelta.g1.resolve_pair_geometry(cfg, geometry);
context = ndelta.stage11.validate_context(context, cfg, geometry);
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~all(isfield(spectrum, {'accepted', 'modes', ...
        'configurationFingerprint', 'solverFingerprint'})) || ...
        ~spectrum.accepted
    error('ndelta:stage12:InvalidRawAxisSpectrum', ...
        'An accepted same-configuration spectrum is required.');
end
ndelta.config.assert_physics_fingerprint( ...
    spectrum.configurationFingerprint, cfg, ...
    'ndelta:stage12:RawAxisSpectrumConfigurationMismatch');
if ~isequaln(spectrum.solverFingerprint, ...
        ndelta.config.spectrum_solver_fingerprint(cfg))
    error('ndelta:stage12:RawAxisSpectrumSolverMismatch', ...
        'The raw-axis diagnostic received a stale spectrum.');
end
route = ndelta.stage12.term_route(termInput);
[order, tailScale, windowFactors] = parse_options(options, cfg);
landmarks = build_landmarks(qPerp, cfg, spectrum, windowFactors);
finiteEdges = unique(sort([landmarks.edges]));
finiteEdges = finiteEdges(isfinite(finiteEdges));
if numel(finiteEdges) < 2
    error('ndelta:stage12:InsufficientRealAxisEdges', ...
        'Finite-epsilon landmarks did not define the real-axis segments.');
end
segmentEdges = [-Inf, finiteEdges, Inf];
segmentValues = complex(zeros(1, numel(segmentEdges) - 1));
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
numberOfPointEvaluations = 0;

if isempty(context.activeIndices)
    result = make_result(complex(0), segmentEdges, segmentValues, 0, 0);
    result.allInactiveExactZero = true;
    result.status = 'interaction_only_exact_zero_at_all_inactive';
    return;
end

[nodes, weights] = ndelta.numerics.unit_gauss_rule(order);
for segment = 1:numel(segmentValues)
    [q0Nodes, jacobian] = map_segment(nodes, ...
        segmentEdges(segment), segmentEdges(segment + 1), tailScale);
    contribution = complex(0);
    for nodeIndex = 1:numel(q0Nodes)
        roots = ndelta.sheet.physical_roots(q0Nodes(nodeIndex), qPerp, ...
            cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
        [raw, details] = route.pointEvaluator( ...
            roots.omega, roots.kappaI, channel, cfg, geometry, context);
        contribution = contribution + weights(nodeIndex) ...
            .* jacobian(nodeIndex) .* (-raw);
        maximumTauResidual = max(maximumTauResidual, ...
            details.tauDiagnostics.normalisedEquationResidual);
        minimumTauScaledRcond = min(minimumTauScaledRcond, ...
            details.tauDiagnostics.scaledRcond);
        maximumTauConditionAmplification = max( ...
            maximumTauConditionAmplification, ...
            details.tauDiagnostics.conditionAmplification);
        numberOfPointEvaluations = numberOfPointEvaluations + 1;
    end
    segmentValues(segment) = contribution ./ (2 .* pi);
end
value = sum(segmentValues);
result = make_result(value, segmentEdges, segmentValues, ...
    maximumTauResidual, numberOfPointEvaluations);
result.allInactiveExactZero = false;
result.status = 'stage12_independent_raw_real_axis_term_integral';

    function output = make_result(valueInput, edges, values, tauResidual, count)
        output = struct();
        output.term = route.term;
        output.channel = channel;
        output.qPerp = qPerp;
        output.value = complex(real(valueInput), imag(valueInput));
        output.order = order;
        output.tailScale = tailScale;
        output.windowFactors = windowFactors;
        output.landmarks = landmarks;
        output.segmentEdges = edges;
        output.segmentValues = values;
        output.segmentClosureResidual = abs(valueInput - sum(values)) ...
            ./ (1 + abs(valueInput));
        output.maximumTauEquationResidual = tauResidual;
        output.minimumTauScaledRcond = minimumTauScaledRcond;
        output.maximumTauConditionAmplification = ...
            maximumTauConditionAmplification;
        output.numberOfPointEvaluations = count;
        output.includesQ0Measure = true;
        output.includesQPerpMeasure = false;
        output.includesMuSquared = false;
        output.includesLSZ = false;
        output.kernelConvention = 'F_code=-F_raw';
        output.usesModifiedWickRotation = false;
        output.usesMWRSourceValues = false;
        output.collectiveModesUsedOnlyAsGridLandmarks = true;
        output.allInactiveExactZero = false;
        output.status = 'not_evaluated';
    end
end

function landmarks = build_landmarks(qPerp, cfg, spectrum, factors)
points = ndelta.sheet.branch_points( ...
    qPerp, cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
q0Values = [points.omega.left, points.omega.right, ...
    points.kappaI.left, points.kappaI.right];
sources = {'omega_left', 'omega_right', ...
    'kappaI_left', 'kappaI_right'};
Ephi = hypot(qPerp, cfg.model.mphi);
for modeIndex = 1:numel(spectrum.modes)
    alpha = spectrum.modes(modeIndex).alpha;
    offset = sqrt(Ephi.^2 - alpha.^2 - 1i .* cfg.sheet.epsilon);
    q0Values = [q0Values, cfg.referenceEnergy - offset, ...
        cfg.referenceEnergy + offset]; %#ok<AGROW>
    sources = [sources, {sprintf('collective_%d_left', modeIndex), ...
        sprintf('collective_%d_right', modeIndex)}]; %#ok<AGROW>
end
% KappaI=+/-P attachments can be removable in a given route, but keeping
% them as grid-only landmarks prevents a narrow finite-epsilon feature
% from being mistaken for raw/MWR disagreement.
attachment = sqrt(Ephi.^2 + cfg.derived.P.^2 ...
    - 1i .* cfg.sheet.epsilon);
q0Values = [q0Values, cfg.referenceEnergy - attachment, ...
    cfg.referenceEnergy + attachment];
sources = [sources, {'kappaI_P_left', 'kappaI_P_right'}];

landmarks = repmat(struct('source', '', 'q0', complex(0), ...
    'realPart', 0, 'imaginaryWidth', 0, 'edges', zeros(1, 0), ...
    'usedAsGridOnly', true), numel(q0Values), 1);
for index = 1:numel(q0Values)
    centre = real(q0Values(index));
    width = max(abs(imag(q0Values(index))), ...
        16 .* eps(max(1, abs(centre))));
    landmarks(index).source = sources{index};
    landmarks(index).q0 = q0Values(index);
    landmarks(index).realPart = centre;
    landmarks(index).imaginaryWidth = width;
    landmarks(index).edges = centre + width .* factors;
end
end

function [order, tailScale, factors] = parse_options(options, cfg)
if ~isstruct(options) || ~isscalar(options)
    error('ndelta:stage12:InvalidRealAxisOptions', ...
        'options must be a scalar structure.');
end
known = {'order', 'tailScale', 'windowFactors'};
unknown = setdiff(fieldnames(options), known);
if ~isempty(unknown)
    error('ndelta:stage12:UnknownRealAxisOption', ...
        'Unknown option(s): %s.', strjoin(unknown, ', '));
end
order = get_option(options, 'order', cfg.stage10.directOrder);
tailScale = get_option(options, 'tailScale', ...
    cfg.stage10.directTailScale);
rawFactors = get_option(options, 'windowFactors', ...
    cfg.stage10.directWindowFactors);
validateattributes(order, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'});
validateattributes(tailScale, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'});
if ~isnumeric(rawFactors) || ~isreal(rawFactors) || ...
        ~isvector(rawFactors) || isempty(rawFactors) || ...
        any(~isfinite(rawFactors(:))) || ~any(rawFactors(:) ~= 0)
    error('ndelta:stage12:InvalidRealAxisWindowFactors', ...
        'windowFactors must contain finite nonzero magnitudes.');
end
magnitudes = unique(sort(abs(rawFactors(rawFactors ~= 0))));
factors = [-fliplr(magnitudes(:).'), 0, magnitudes(:).'];
end

function value = get_option(options, name, defaultValue)
if isfield(options, name)
    value = options.(name);
else
    value = defaultValue;
end
end

function [q0, jacobian] = map_segment(t, lower, upper, scale)
if isinf(lower) && isfinite(upper)
    q0 = upper - scale .* t ./ (1 - t);
    jacobian = scale ./ (1 - t).^2;
elseif isfinite(lower) && isinf(upper)
    q0 = lower + scale .* t ./ (1 - t);
    jacobian = scale ./ (1 - t).^2;
elseif isfinite(lower) && isfinite(upper) && upper > lower
    q0 = lower + (upper - lower) .* t;
    jacobian = (upper - lower) .* ones(size(t));
else
    error('ndelta:stage12:InvalidRealAxisSegment', ...
        'Real-axis segment edges must be strictly ordered.');
end
end
