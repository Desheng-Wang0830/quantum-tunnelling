function kin = on_shell_kinematics(E, mphi)
%ON_SHELL_KINEMATICS Construct left-incident on-shell kinematics.

narginchk(2, 2);
validateattributes(E, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'E');
validateattributes(mphi, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'mphi');
if E <= mphi
    error('ndelta:model:ClosedIncidentChannel', ...
        'The incident channel requires E>mphi.');
end

kin = struct();
kin.E = E;
kin.mphi = mphi;
kin.P = sqrt((E - mphi) .* (E + mphi));
kin.incomingLongitudinalMomentum = kin.P;
kin.transmittedLongitudinalMomentum = kin.P;
kin.reflectedLongitudinalMomentum = -kin.P;
end
