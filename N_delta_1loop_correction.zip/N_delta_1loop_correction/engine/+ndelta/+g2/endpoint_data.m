function result = endpoint_data(qPerp, channelInput, cfg, context)
%ENDPOINT_DATA Full branch-keyhole residue for arbitrary-N G2.

narginchk(4, 4);
channel = ndelta.g1.normalise_channel(channelInput);
P = cfg.derived.P;
radialBranch = sqrt(qPerp.^2 + cfg.model.mphi.^2 ...
    - 1i .* cfg.sheet.epsilon);
q0Branch = cfg.referenceEnergy - radialBranch;
roots = ndelta.sheet.physical_roots(q0Branch, qPerp, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
if channel == 'T'
    backgroundContraction = context.backgroundP.BNTransmission;
else
    backgroundContraction = context.backgroundP.BNReflection;
end
A = roots.omega.^2 - P.^2;
residue = backgroundContraction ./ (16 .* P .* radialBranch .* A);
result = struct();
result.term = 'G2';
result.channel = channel;
result.qPerp = qPerp;
result.radialBranch = radialBranch;
result.q0Branch = q0Branch;
result.omegaBranch = roots.omega;
result.ABranch = A;
result.backgroundContraction = backgroundContraction;
result.vertexReducedResidue = residue;
result.keyholeContribution = 1i .* residue;
result.keyholeQ0WindingFraction = 1;
result.ordinaryHalfIndentationUsed = false;
result.evenSubtractionEnabled = true;
result.endpointIsZero = abs(residue) == 0;
end
