function [value, diagnostics] = pointwise_contraction_from_roots( ...
        omega, kappaI, channelInput, cfg, geometry, context)
%POINTWISE_CONTRACTION_FROM_ROOTS Endpoint-stable ordinary G2 point.

narginchk(5, 6);
if nargin < 6
    context = [];
end
context = ndelta.stage11.validate_context(context, cfg, geometry);
if isempty(context.activeIndices)
    tauI = complex(zeros(geometry.N));
    tauDiagnostics = empty_tau_diagnostics();
else
    [tauI, tauDiagnostics] = ndelta.background.solve_tau_endpoint_stable( ...
        kappaI, geometry, cfg.barriers.strengths, ...
        cfg.derived.endpointTauSwitch, ...
        cfg.tolerances.nearSingularRcond);
end
[value, diagnostics] = ...
    ndelta.g2.contract_with_internal_matrix_from_roots( ...
    omega, kappaI, channelInput, tauI, cfg, geometry, context);
diagnostics.tauDiagnostics = tauDiagnostics;
diagnostics.internalMatrixRole = 'tau_N(kappaI)';
end

function value = empty_tau_diagnostics()
value = struct('method', 'empty_active_system', ...
    'usedEndpointScaledSolve', false, 'scaledRcond', Inf, ...
    'conditionAmplification', 0, 'nearSingular', false, ...
    'normalisedEquationResidual', 0);
end
