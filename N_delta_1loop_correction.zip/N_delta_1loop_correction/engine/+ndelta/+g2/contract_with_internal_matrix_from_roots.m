function [value, diagnostics] = contract_with_internal_matrix_from_roots( ...
        omega, kappaI, channelInput, internalMatrix, cfg, geometry, context)
%CONTRACT_WITH_INTERNAL_MATRIX_FROM_ROOTS Optimised O(N^3) G2 contraction.

narginchk(7, 7);
channel = ndelta.g1.normalise_channel(channelInput);
context = ndelta.stage11.validate_context(context, cfg, geometry);
validate_internal_matrix(internalMatrix, geometry.N);
if channel == 'T'
    externalMatrix = context.transmissionETauP;
else
    externalMatrix = context.reflectionETauP;
end

active = context.activeIndices(:).';
value = complex(0);
termCount = 0;
cacheKeys = zeros(0, 2);
cacheValues = complex(zeros(0, 1));
distanceCount = geometry.numberOfUniqueDirectedDistances;
denseCache = double(distanceCount).^2 <= 1e6;
if denseCache
    cacheLookup = zeros(double(distanceCount).^2, 1);
    cacheMap = [];
else
    cacheLookup = [];
    cacheMap = containers.Map( ...
        'KeyType', 'uint64', 'ValueType', 'double');
end
for a = active
    for b = active
        for c = active
            x = geometry.directedDistances(a, b);
            y = geometry.directedDistances(b, c);
            xIndex = geometry.directedDistanceIndex(a, b);
            yIndex = geometry.directedDistanceIndex(b, c);
            cacheKey = pair_cache_key(xIndex, yIndex, distanceCount);
            if denseCache
                cacheIndex = cacheLookup(double(cacheKey));
            elseif isKey(cacheMap, cacheKey)
                cacheIndex = cacheMap(cacheKey);
            else
                cacheIndex = 0;
            end
            if cacheIndex == 0
                kernel = ndelta.longitudinal.g2_kernel_from_roots( ...
                    x, y, omega, kappaI, context.P, ...
                    cfg.tolerances.g1Coalescence);
                cacheKeys(end + 1, :) = [x, y]; %#ok<AGROW>
                cacheValues(end + 1, 1) = kernel; %#ok<AGROW>
                cacheIndex = numel(cacheValues);
                if denseCache
                    cacheLookup(double(cacheKey)) = cacheIndex;
                else
                    cacheMap(cacheKey) = cacheIndex;
                end
            else
                kernel = cacheValues(cacheIndex);
            end
            value = value + externalMatrix(a, c) ...
                .* internalMatrix(b, a) .* kernel;
            termCount = termCount + 1;
        end
    end
end
value = complex(real(value), imag(value));
diagnostics = base_diagnostics('G2', value, channel, omega, kappaI, ...
    internalMatrix, context, cacheKeys, cacheValues, termCount);
diagnostics.indexContract = ...
    '(E_chi*tauP)(a,c)*tauI(b,a)*I2(D_ab,D_bc)';
diagnostics.contractionComplexity = 'O(N_active^3)';
diagnostics.cacheLookupComplexity = 'O(1)_integer_distance_indices';
end

function key = pair_cache_key(first, second, distanceCount)
key = uint64(first - 1) .* uint64(distanceCount) + uint64(second);
end

function validate_internal_matrix(value, N)
if ~isnumeric(value) || ~isequal(size(value), [N, N]) || ...
        any(~isfinite(real(value(:)))) || any(~isfinite(imag(value(:))))
    error('ndelta:g2:InvalidInternalMatrix', ...
        'internalMatrix must be one finite geometry.N square matrix.');
end
end

function diagnostics = base_diagnostics(term, value, channel, omega, ...
        kappaI, internalMatrix, context, keys, values, count)
diagnostics = struct();
diagnostics.term = term;
diagnostics.value = value;
diagnostics.rawConvention = true;
diagnostics.vertexReducedValue = -value;
diagnostics.channel = channel;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = context.P;
diagnostics.tauI = internalMatrix;
diagnostics.tauP = context.tauP;
diagnostics.cacheKeys = keys;
diagnostics.cacheValues = values;
diagnostics.numberOfKernelEvaluations = size(keys, 1);
diagnostics.numberOfActiveTerms = count;
diagnostics.cacheUsesOrderedDistancePairs = true;
diagnostics.usesNonconjugateMatrixProducts = true;
diagnostics.includesTauI = true;
diagnostics.includesTauP = true;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.includesOneOverTwoP = false;
diagnostics.massDimension = -4;
end
