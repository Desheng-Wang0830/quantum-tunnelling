function resolved = resolve_options(cfg, options)
%RESOLVE_OPTIONS Canonicalise and validate all Stage 8 integration options.

narginchk(1, 2);
if nargin < 2
    options = struct();
end
if ~isstruct(options) || ~isscalar(options)
    error('ndelta:integration:InvalidOptions', ...
        'options must be a scalar structure.');
end

canonicalNames = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder', ...
    'q4Scale', 'q4MapPower', 'qPerpTailScale'};
unknownNames = setdiff(fieldnames(options), canonicalNames);
if ~isempty(unknownNames)
    error('ndelta:integration:UnknownOption', ...
        'Unknown integration option(s): %s.', ...
        strjoin(unknownNames, ', '));
end
if ~isstruct(cfg) || ~isscalar(cfg) || ...
        ~isfield(cfg, 'integration') || ...
        ~isstruct(cfg.integration) || ~isscalar(cfg.integration)
    error('ndelta:integration:InvalidOptionsConfiguration', ...
        'cfg.integration must be a scalar structure.');
end

resolved = struct();
orderNames = canonicalNames(1:6);
for index = 1:numel(orderNames)
    name = orderNames{index};
    value = resolve_one(name);
    validateattributes(value, {'numeric'}, ...
        {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
        mfilename, ['options.' name]);
    resolved.(name) = value;
end
positiveNames = canonicalNames(7:9);
for index = 1:numel(positiveNames)
    name = positiveNames{index};
    value = resolve_one(name);
    validateattributes(value, {'numeric'}, ...
        {'real', 'finite', 'positive', 'scalar'}, ...
        mfilename, ['options.' name]);
    resolved.(name) = value;
end

    function value = resolve_one(name)
        if isfield(options, name)
            value = options.(name);
        elseif isfield(cfg.integration, name)
            value = cfg.integration.(name);
        else
            error('ndelta:integration:InvalidOptionsConfiguration', ...
                'Missing cfg.integration.%s default.', name);
        end
    end
end
