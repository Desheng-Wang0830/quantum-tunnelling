function result = integrate_collective(channelInput, cfg, geometry, spectrum, options)
%INTEGRATE_COLLECTIVE Stage 8 transverse integral of all QI modes.

narginchk(4, 5);
if nargin < 5
    options = struct();
end
channel = ndelta.g1.normalise_channel(channelInput);
options = ndelta.integration.resolve_options(cfg, options);
order = options.collectiveOrder;
[t, weights] = ndelta.numerics.unit_gauss_rule(order);
modeValues = complex(zeros(numel(spectrum.modes), 1));
acceptedNodeCounts = zeros(numel(spectrum.modes), 1);
maximumNullResidual = 0;
minimumProjectedRcond = Inf;
minimumProjectedScaledRcond = Inf;
for modeIndex = 1:numel(spectrum.modes)
    mode = spectrum.modes(modeIndex);
    if ~mode.stable
        error('ndelta:integration:UnstableCollectiveMode', ...
            ['Stage 8 cannot integrate a collective mode with ' ...
             'alpha >= mphi.']);
    end
    qCritical = mode.qPerpCritical;
    if (isfield(mode, 'hasOpenTransverseSupport') && ...
            ~mode.hasOpenTransverseSupport) || qCritical <= 0
        continue;
    end
    qNodes = qCritical .* t;
    qWeights = qCritical .* weights;
    contribution = complex(0);
    for node = 1:numel(qNodes)
        residue = ndelta.g1.collective_pole_residue( ...
            mode, qNodes(node), channel, cfg, geometry);
        if ~residue.accepted
            error('ndelta:integration:CollectiveResidueRejected', ...
                ['An interior collective-pole residue failed the ' ...
                 'physical-sheet or nullspace gate.']);
        end
        contribution = contribution + qWeights(node) .* qNodes(node) ...
            .* residue.contourContribution ./ (2 .* pi);
        acceptedNodeCounts(modeIndex) = ...
            acceptedNodeCounts(modeIndex) + 1;
        maximumNullResidual = max(maximumNullResidual, residue.nullResidual);
        minimumProjectedRcond = min(minimumProjectedRcond, ...
            residue.projectedDerivativeRcond);
        minimumProjectedScaledRcond = min( ...
            minimumProjectedScaledRcond, ...
            residue.projectedDerivativeScaledRcond);
    end
    modeValues(modeIndex) = contribution;
end

result = struct();
result.value = complex(real(sum(modeValues)), imag(sum(modeValues)));
result.channel = channel;
result.modeContributions = modeValues;
result.modeAlphas = reshape([spectrum.modes.alpha], [], 1);
result.modeQPerpCritical = reshape( ...
    [spectrum.modes.qPerpCritical], [], 1);
result.acceptedNodeCounts = acceptedNodeCounts;
result.order = order;
result.maximumNullResidual = maximumNullResidual;
result.minimumProjectedDerivativeRcond = minimumProjectedRcond;
result.minimumProjectedDerivativeScaledRcond = ...
    minimumProjectedScaledRcond;
result.oldSingleDeltaBarrierIsIncludedHere = true;
result.separateSingleDeltaBarrierTermAdded = false;
result.includesQ0Measure = true;
result.includesQPerpMeasure = true;
result.status = 'stage8_collective_pole_transverse_integral';
end
