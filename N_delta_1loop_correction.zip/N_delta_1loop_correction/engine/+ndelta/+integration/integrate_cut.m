function result = integrate_cut(channelInput, cfg, geometry, spectrum, options)
%INTEGRATE_CUT Stage 8 quarter-disk bank integral plus endpoint keyhole.

narginchk(4, 5);
if nargin < 5
    options = struct();
end
channel = ndelta.g1.normalise_channel(channelInput);
options = ndelta.integration.resolve_options(cfg, options);
radialOrder = options.cutRadialOrder;
angleOrder = options.cutAngleOrder;
endpointOrder = options.endpointOrder;
result = base_result(channel, radialOrder, angleOrder, endpointOrder);
if cfg.derived.numberOfActiveCentres == 0
    result.status = 'interaction_only_zero_at_all_inactive';
    return;
end
if spectrum.zeroEnergy.isZeroEnergyResonance
    error('ndelta:integration:ZeroEnergyEndpointUnsupported', ...
        ['The generic cut endpoint expansion is invalid at a ' ...
         'zero-energy collective threshold.']);
end

P = cfg.derived.P;
E = cfg.referenceEnergy;
epsilon = cfg.sheet.epsilon;
radialMaximumSquared = P.^2 - (epsilon ./ (2 .* E)).^2;
if radialMaximumSquared <= 0
    result.status = 'finite_epsilon_cut_domain_has_zero_measure';
    return;
end
radialMaximum = sqrt(max(radialMaximumSquared, 0));
rule = ndelta.integration.cut_polar_rule( ...
    radialMaximum, radialOrder, angleOrder);
rho = rule.rho;
radialWeights = rule.radialWeights;
rhoJacobian = rule.rhoJacobian;
theta = rule.theta;
angleWeights = rule.angleWeights;
thetaJacobian = rule.thetaJacobian;

bankBeforeMeasures = complex(0);
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
for radialIndex = 1:numel(rho)
    for angleIndex = 1:numel(theta)
        radialValue = rho(radialIndex);
        angleValue = theta(angleIndex);
        qPerp = radialValue .* sin(angleValue);
        kappa = radialValue .* cos(angleValue);
        EphiSquared = qPerp.^2 + cfg.model.mphi.^2;
        radialEnergy = sqrt(EphiSquared + kappa.^2 - 1i .* epsilon);
        q0 = E - radialEnergy;
        roots = ndelta.sheet.physical_roots( ...
            q0, qPerp, E, cfg.model, epsilon);
        [rawLower, lowerDetails] = ...
            ndelta.g1.contour_pair_contraction_from_roots( ...
            roots.omega, +kappa, P, channel, geometry, ...
            cfg.barriers.strengths, cfg);
        [rawUpper, upperDetails] = ...
            ndelta.g1.contour_pair_contraction_from_roots( ...
            roots.omega, -kappa, P, channel, geometry, ...
            cfg.barriers.strengths, cfg);
        lower = -rawLower;
        upper = -rawUpper;
        if channel == 'T' && cfg.integration.cutEvenSubtraction
            evenA = roots.omega.^2 + kappa.^2 - P.^2;
            universalEven = -1 ./ (2 .* evenA .* kappa.^2);
            lower = lower - universalEven;
            upper = upper - universalEven;
        end
        mappedJump = kappa ./ radialEnergy .* (lower - upper);
        domainJacobian = radialValue.^2 .* sin(angleValue);
        weight = radialWeights(radialIndex) .* rhoJacobian(radialIndex) ...
            .* angleWeights(angleIndex) .* thetaJacobian;
        bankBeforeMeasures = bankBeforeMeasures + ...
            weight .* domainJacobian .* mappedJump;
        maximumTauResidual = max([maximumTauResidual, ...
            lowerDetails.tauDiagnostics.normalisedEquationResidual, ...
            upperDetails.tauDiagnostics.normalisedEquationResidual]);
        minimumTauScaledRcond = min([minimumTauScaledRcond, ...
            lowerDetails.tauDiagnostics.scaledRcond, ...
            upperDetails.tauDiagnostics.scaledRcond]);
        maximumTauConditionAmplification = max([ ...
            maximumTauConditionAmplification, ...
            lowerDetails.tauDiagnostics.conditionAmplification, ...
            upperDetails.tauDiagnostics.conditionAmplification]);
    end
end
bankContribution = bankBeforeMeasures ./ (2 .* pi).^2;

endpointContribution = complex(0);
if channel == 'T'
    [t, weights] = ndelta.numerics.unit_gauss_rule(endpointOrder);
    qNodes = radialMaximum .* t;
    qWeights = radialMaximum .* weights;
    for index = 1:numel(qNodes)
        qPerp = qNodes(index);
        radialBranch = sqrt(qPerp.^2 + cfg.model.mphi.^2 ...
            - 1i .* epsilon);
        q0Branch = E - radialBranch;
        roots = ndelta.sheet.physical_roots( ...
            q0Branch, qPerp, E, cfg.model, epsilon);
        endpointResidue = 1 ./ ...
            (4 .* radialBranch .* (roots.omega.^2 - P.^2));
        fixedEndpoint = 1i .* endpointResidue;
        endpointContribution = endpointContribution + ...
            qWeights(index) .* qPerp .* fixedEndpoint ./ (2 .* pi);
    end
end

result.value = bankContribution + endpointContribution;
result.bankContribution = bankContribution;
result.endpointContribution = endpointContribution;
result.bankBeforeMeasures = bankBeforeMeasures;
result.radialMaximum = radialMaximum;
result.maximumTauEquationResidual = maximumTauResidual;
result.minimumTauScaledRcond = minimumTauScaledRcond;
result.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
result.numberOfBankPairEvaluations = ...
    2 .* radialOrder .* angleOrder;
result.quadratureFamily = rule.family;
result.mapping = rule.mapping;
result.cutClosureResidual = abs(result.value - bankContribution ...
    - endpointContribution) ./ (1 + abs(result.value));
result.status = 'stage8_cut_banks_plus_full_keyhole';
end

function result = base_result(channel, radialOrder, angleOrder, endpointOrder)
result = struct('value', complex(0), 'bankContribution', complex(0), ...
    'endpointContribution', complex(0), ...
    'bankBeforeMeasures', complex(0), 'channel', channel, ...
    'radialOrder', radialOrder, 'angleOrder', angleOrder, ...
    'endpointOrder', endpointOrder, 'radialMaximum', 0, ...
    'maximumTauEquationResidual', 0, ...
    'minimumTauScaledRcond', Inf, ...
    'maximumTauConditionAmplification', 0, ...
    'numberOfBankPairEvaluations', 0, 'cutClosureResidual', 0, ...
    'quadratureFamily', 'shared_polar_quarter_disk_v1', ...
    'mapping', ['qPerp=rho*sin(theta),kappa=rho*cos(theta),' ...
    'rho_boundary_clustered'], ...
    'keyholeQ0WindingFraction', 1, ...
    'ordinaryHalfIndentationUsedHere', false, ...
    'reflectionCutAttachedCornerHandledByMeasure', true, ...
    'includesQ0Measure', true, 'includesQPerpMeasure', true, ...
    'status', 'not_evaluated');
end
