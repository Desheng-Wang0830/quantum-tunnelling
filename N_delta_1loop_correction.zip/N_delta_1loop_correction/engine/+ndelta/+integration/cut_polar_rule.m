function rule = cut_polar_rule(radialMaximum, radialOrder, angleOrder)
%CUT_POLAR_RULE Shared open-node quarter-disk mesh for every Rose term.

narginchk(3, 3);
validateattributes(radialMaximum, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, ...
    mfilename, 'radialMaximum');
validateattributes(radialOrder, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'radialOrder');
validateattributes(angleOrder, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'angleOrder');

[u, radialWeights] = ndelta.numerics.unit_gauss_rule(radialOrder);
rho = radialMaximum .* (1 - (1 - u).^2);
rhoJacobian = 2 .* radialMaximum .* (1 - u);
[v, angleWeights] = ndelta.numerics.unit_gauss_rule(angleOrder);
theta = 0.5 .* pi .* v;

rule = struct();
rule.rho = rho;
rule.radialWeights = radialWeights;
rule.rhoJacobian = rhoJacobian;
rule.theta = theta;
rule.angleWeights = angleWeights;
rule.thetaJacobian = 0.5 .* pi;
rule.radialMaximum = radialMaximum;
rule.radialOrder = radialOrder;
rule.angleOrder = angleOrder;
rule.family = 'shared_polar_quarter_disk_v1';
rule.mapping = ...
    'qPerp=rho*sin(theta),kappa=rho*cos(theta),rho_boundary_clustered';
rule.openNodesOnly = true;
end
