function result = integrate_euclidean(channelInput, cfg, geometry, spectrum, options)
%INTEGRATE_EUCLIDEAN Stage 8 transverse integral of the Wick-axis source.

narginchk(4, 5);
if nargin < 5
    options = struct();
end
channel = ndelta.g1.normalise_channel(channelInput);
options = ndelta.integration.resolve_options(cfg, options);
outerOrder = options.qPerpOrder;
innerOptions = struct( ...
    'q4Order', options.q4Order, ...
    'q4Scale', options.q4Scale, ...
    'q4MapPower', options.q4MapPower);

breaks = cfg.derived.P;
for index = 1:numel(spectrum.modes)
    if spectrum.modes(index).stable && ...
            spectrum.modes(index).qPerpCritical > 0
        breaks(end + 1) = spectrum.modes(index).qPerpCritical; %#ok<AGROW>
    end
end
breaks = unique(sort(breaks));
lowerEdges = [0, breaks];
upperEdges = [breaks, Inf];
segmentValues = complex(zeros(size(lowerEdges)));
numberOfFixedEvaluations = 0;
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
[t, weights] = ndelta.numerics.unit_gauss_rule(outerOrder);
for segment = 1:numel(lowerEdges)
    lower = lowerEdges(segment);
    upper = upperEdges(segment);
    if isfinite(upper)
        qNodes = lower + (upper - lower) .* t;
        qJacobian = (upper - lower) .* ones(size(t));
    else
        tailScale = options.qPerpTailScale;
        qNodes = lower + tailScale .* t ./ (1 - t);
        qJacobian = tailScale ./ (1 - t).^2;
    end
    contribution = complex(0);
    for index = 1:numel(qNodes)
        fixed = ndelta.contour.euclidean_fixed( ...
            qNodes(index), channel, cfg, geometry, innerOptions);
        contribution = contribution + weights(index) .* qJacobian(index) ...
            .* qNodes(index) .* fixed.value ./ (2 .* pi);
        maximumTauResidual = max(maximumTauResidual, ...
            fixed.maximumTauEquationResidual);
        minimumTauScaledRcond = min(minimumTauScaledRcond, ...
            fixed.minimumTauScaledRcond);
        maximumTauConditionAmplification = max( ...
            maximumTauConditionAmplification, ...
            fixed.maximumTauConditionAmplification);
        numberOfFixedEvaluations = numberOfFixedEvaluations + 1;
    end
    segmentValues(segment) = contribution;
end

result = struct();
result.value = complex(real(sum(segmentValues)), imag(sum(segmentValues)));
result.channel = channel;
result.segmentLowerEdges = lowerEdges;
result.segmentUpperEdges = upperEdges;
result.segmentContributions = segmentValues;
result.qPerpBreakpoints = breaks;
result.qPerpOrder = outerOrder;
result.q4Order = innerOptions.q4Order;
result.numberOfFixedQPerpEvaluations = numberOfFixedEvaluations;
result.numberOfPairEvaluations = ...
    2 .* innerOptions.q4Order .* numberOfFixedEvaluations;
result.maximumTauEquationResidual = maximumTauResidual;
result.minimumTauScaledRcond = minimumTauScaledRcond;
result.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
result.includesQ0Measure = true;
result.includesQPerpMeasure = true;
result.includesCollectiveResidues = false;
result.includesCut = false;
result.status = 'stage8_euclidean_transverse_integral';
end
