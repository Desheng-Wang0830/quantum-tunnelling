function [value, diagnostics] = g2_kernel_from_roots( ...
        firstDistance, bridgeDistance, omega, kappaI, P, ...
        coalescenceTolerance)
%G2_KERNEL_FROM_ROOTS Two-distance Rose G2 longitudinal kernel.

narginchk(5, 6);
if nargin < 6
    coalescenceTolerance = 1e-8;
end
validate_inputs(firstDistance, bridgeDistance, omega, kappaI, P);
terms = ndelta.longitudinal.bridge_terms(bridgeDistance, kappaI, P);
termValues = complex(zeros(1, numel(terms)));
termDiagnostics = cell(1, numel(terms));
for termIndex = 1:numel(terms)
    term = terms(termIndex);
    [integralValue, details] = q_integral( ...
        firstDistance + term.qPhaseShift, omega, kappaI, P, ...
        term, coalescenceTolerance);
    % The remaining D_Phi(q)D_phi(p-q) numerators give i^2=-1.
    termValues(termIndex) = -term.coefficient .* integralValue;
    termDiagnostics{termIndex} = details;
end
value = sum(termValues);
diagnostics = make_diagnostics('G2', value, firstDistance, ...
    bridgeDistance, omega, kappaI, P, terms, termValues, ...
    termDiagnostics, coalescenceTolerance);
diagnostics.outerLightShift = P;
diagnostics.firstPhaseDistance = firstDistance;
diagnostics.secondPhaseDistance = firstDistance + bridgeDistance;
end

function [value, details] = q_integral(distance, omega, kappaI, P, ...
        bridge, tolerance)
heavyLocations = [omega, -omega];
heavySides = [1, -1];
outerLocations = [P + kappaI, P - kappaI];
outerSides = [1, -1];
locations = [heavyLocations, outerLocations, bridge.poleLocations];
sides = [heavySides, outerSides, bridge.poleSides];
factorisationSign = (-1) .* (-1) ...
    .* bridge.denominatorFactorisationSign;
[value, details] = ndelta.longitudinal.rational_contour_integral( ...
    distance, locations, sides, factorisationSign, tolerance);
details.bridgeLabel = bridge.label;
end

function validate_inputs(x, y, omega, kappaI, P)
validateattributes(x, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'firstDistance');
validateattributes(y, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'bridgeDistance');
if ~isnumeric(omega) || ~isscalar(omega) || ...
        ~isfinite(real(omega)) || ~isfinite(imag(omega)) || ...
        ~isnumeric(kappaI) || ~isscalar(kappaI) || kappaI == 0 || ...
        ~isfinite(real(kappaI)) || ~isfinite(imag(kappaI))
    error('ndelta:g2:InvalidLongitudinalRoots', ...
        'omega and kappaI must be finite scalars with kappaI nonzero.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');
end

function diagnostics = make_diagnostics(termName, value, x, y, ...
        omega, kappaI, P, terms, termValues, details, tolerance)
diagnostics = struct();
diagnostics.term = termName;
diagnostics.value = value;
diagnostics.firstDistance = x;
diagnostics.bridgeDistance = y;
diagnostics.orderedDistancePair = [x, y];
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.bridgeTerms = terms;
diagnostics.termValues = termValues;
diagnostics.termDiagnostics = details;
diagnostics.termAssemblyResidual = value - sum(termValues);
diagnostics.coalescenceTolerance = tolerance;
diagnostics.includesS3Integration = true;
diagnostics.includesQ3Integration = true;
diagnostics.includesBothLongitudinalMeasures = true;
diagnostics.includesTauI = false;
diagnostics.includesTauP = false;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.massDimension = -6;
end
