function [value, diagnostics] = g3_kernel_from_roots( ...
        bridgeDistance, finalDistance, omega, kappaI, P, ...
        channelInput, coalescenceTolerance)
%G3_KERNEL_FROM_ROOTS Original-routing two-distance Rose G3 kernel.

narginchk(6, 7);
if nargin < 7
    coalescenceTolerance = 1e-8;
end
channel = ndelta.g1.normalise_channel(channelInput);
validateattributes(bridgeDistance, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'bridgeDistance');
validateattributes(finalDistance, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'finalDistance');
if ~isnumeric(omega) || ~isscalar(omega) || ...
        ~isfinite(real(omega)) || ~isfinite(imag(omega)) || ...
        ~isnumeric(kappaI) || ~isscalar(kappaI) || kappaI == 0 || ...
        ~isfinite(real(kappaI)) || ~isfinite(imag(kappaI))
    error('ndelta:g3:InvalidLongitudinalRoots', ...
        'omega and kappaI must be finite scalars with kappaI nonzero.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');

sigma = 1;
if channel == 'R'
    sigma = -1;
end
terms = ndelta.longitudinal.bridge_terms( ...
    bridgeDistance, kappaI, P);
termValues = complex(zeros(1, numel(terms)));
termDiagnostics = cell(1, numel(terms));
for termIndex = 1:numel(terms)
    term = terms(termIndex);
    distance = finalDistance + term.qPhaseShift;
    heavyLocations = [omega, -omega];
    heavySides = [1, -1];
    outerLocations = [sigma .* P + kappaI, ...
        sigma .* P - kappaI];
    outerSides = [1, -1];
    locations = [heavyLocations, outerLocations, term.poleLocations];
    sides = [heavySides, outerSides, term.poleSides];
    factorisationSign = (-1) .* (-1) ...
        .* term.denominatorFactorisationSign;
    [integralValue, details] = ...
        ndelta.longitudinal.rational_contour_integral( ...
        distance, locations, sides, factorisationSign, ...
        coalescenceTolerance);
    termValues(termIndex) = -term.coefficient .* integralValue;
    details.bridgeLabel = term.label;
    termDiagnostics{termIndex} = details;
end
value = sum(termValues);
diagnostics = struct();
diagnostics.term = 'G3';
diagnostics.routing = 'original_Rose_G3';
diagnostics.channel = channel;
diagnostics.sigma = sigma;
diagnostics.value = value;
diagnostics.bridgeDistance = bridgeDistance;
diagnostics.finalDistance = finalDistance;
diagnostics.orderedDistancePair = [bridgeDistance, finalDistance];
diagnostics.firstPhaseDistance = finalDistance;
diagnostics.secondPhaseDistance = bridgeDistance + finalDistance;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.bridgeTerms = terms;
diagnostics.termValues = termValues;
diagnostics.termDiagnostics = termDiagnostics;
diagnostics.termAssemblyResidual = value - sum(termValues);
diagnostics.coalescenceTolerance = coalescenceTolerance;
diagnostics.includesS3Integration = true;
diagnostics.includesQ3Integration = true;
diagnostics.includesBothLongitudinalMeasures = true;
diagnostics.includesTauI = false;
diagnostics.includesTauP = false;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.massDimension = -6;
end
