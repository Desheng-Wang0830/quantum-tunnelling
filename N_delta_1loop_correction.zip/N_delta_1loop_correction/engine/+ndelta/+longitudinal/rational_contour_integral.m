function [value, diagnostics] = rational_contour_integral( ...
        phaseDistance, poleLocations, poleSides, ...
        factorisationSign, coalescenceTolerance)
%RATIONAL_CONTOUR_INTEGRAL Grouped residues of exp(i*q*d)/prod(q-p).
%
%   POLESIDES=+1/-1 are frozen analytic pole labels, not classifications
%   made again from imag(POLELOCATIONS) at each continued contour node.
%   The function evaluates
%
%     integral dq/(2*pi) factorisationSign*exp(i*q*d)/prod_j(q-p_j)
%
%   by closing above for d>=0 and below for d<0.  Close selected poles are
%   clustered and evaluated as confluent divided differences of the
%   analytic remainder, so removable same-side mergers remain finite.

narginchk(4, 5);
if nargin < 5
    coalescenceTolerance = 1e-8;
end
validateattributes(phaseDistance, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'phaseDistance');
if ~isnumeric(poleLocations) || isempty(poleLocations) || ...
        ~isvector(poleLocations) || ...
        any(~isfinite(real(poleLocations(:)))) || ...
        any(~isfinite(imag(poleLocations(:))))
    error('ndelta:longitudinal:InvalidPoleLocations', ...
        'poleLocations must be a nonempty finite complex vector.');
end
if ~isnumeric(poleSides) || ...
        ~isequal(size(poleSides), size(poleLocations)) || ...
        any(~ismember(poleSides(:), [-1, 1]))
    error('ndelta:longitudinal:InvalidPoleSides', ...
        'poleSides must match poleLocations and contain only +/-1.');
end
validateattributes(factorisationSign, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'factorisationSign');
if abs(abs(factorisationSign) - 1) > 10 .* eps
    error('ndelta:longitudinal:InvalidFactorisationSign', ...
        'factorisationSign must be +1 or -1.');
end
validateattributes(coalescenceTolerance, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'coalescenceTolerance');

closureSide = 1;
orientation = 1;
if phaseDistance < 0
    closureSide = -1;
    orientation = -1;
end
locations = poleLocations(:).';
sides = poleSides(:).';
selected = locations(sides == closureSide);
unselected = locations(sides ~= closureSide);
if isempty(selected)
    value = complex(0);
    diagnostics = make_diagnostics(selected, unselected, {}, ...
        phaseDistance, closureSide, orientation, factorisationSign, ...
        complex(0), coalescenceTolerance);
    return;
end

scale = max([1, abs(locations)]);
pinchDistance = minimum_cross_distance(selected, unselected);
if pinchDistance <= 100 .* eps .* scale
    error('ndelta:longitudinal:SelectedUnselectedPinch', ...
        ['A selected pole collides with an unselected pole.  This is ' ...
         'not a removable same-side merger.']);
end

clusters = build_clusters(selected, unselected, phaseDistance, ...
    coalescenceTolerance);
residueSum = complex(0);
clusterRecords = cell(numel(clusters), 1);
for clusterIndex = 1:numel(clusters)
    memberIndices = clusters{clusterIndex};
    outsideMask = true(size(selected));
    outsideMask(memberIndices) = false;
    otherPoles = [unselected, selected(outsideMask)];
    [clusterValue, record] = cluster_divided_difference( ...
        selected(memberIndices), otherPoles, phaseDistance);
    residueSum = residueSum + clusterValue;
    clusterRecords{clusterIndex} = record;
end

value = orientation .* 1i .* factorisationSign .* residueSum;
diagnostics = make_diagnostics(selected, unselected, clusterRecords, ...
    phaseDistance, closureSide, orientation, factorisationSign, ...
    residueSum, coalescenceTolerance);
diagnostics.minimumSelectedUnselectedSeparation = pinchDistance;
diagnostics.value = value;
end

function clusters = build_clusters(selected, unselected, distance, tolerance)
n = numel(selected);
clusters = cell(1, n);
for index = 1:n
    clusters{index} = index;
end
scale = max([1, abs(selected), abs(unselected)]);
exactThreshold = max(100 .* eps, tolerance .* 1e-4) .* scale;

% Merge exact numerical duplicates first, including multiplicities three
% and higher, before applying the analytic-radius test.
changed = true;
while changed
    changed = false;
    for first = 1:(numel(clusters) - 1)
        for second = (first + 1):numel(clusters)
            firstValues = selected(clusters{first});
            secondValues = selected(clusters{second});
            if min(abs(firstValues(:) - secondValues(:).')) ...
                    <= exactThreshold
                clusters{first} = [clusters{first}, clusters{second}];
                clusters(second) = [];
                changed = true;
                break;
            end
        end
        if changed
            break;
        end
    end
end

% Merge a close analytic cluster only when its Taylor disk is well inside
% every remaining pole and the exponential/remainder variation is small.
while true
    bestPair = [];
    bestRatio = Inf;
    for first = 1:(numel(clusters) - 1)
        for second = (first + 1):numel(clusters)
            candidate = [clusters{first}, clusters{second}];
            outsideMask = true(size(selected));
            outsideMask(candidate) = false;
            others = [unselected, selected(outsideMask)];
            values = selected(candidate);
            centre = mean(values);
            radius = max(abs(values - centre));
            if isempty(others)
                analyticRadius = Inf;
                variation = radius .* abs(distance);
            else
                separations = abs(centre - others);
                analyticRadius = min(separations);
                if analyticRadius == 0
                    continue;
                end
                variation = radius .* (abs(distance) + ...
                    sum(1 ./ separations));
            end
            ratio = radius ./ analyticRadius;
            if ratio <= 1e-2 && variation <= 0.25 && ratio < bestRatio
                bestPair = [first, second]; %#ok<AGROW>
                bestRatio = ratio;
            end
        end
    end
    if isempty(bestPair)
        break;
    end
    clusters{bestPair(1)} = [clusters{bestPair(1)}, ...
        clusters{bestPair(2)}];
    clusters(bestPair(2)) = [];
end
end

function [value, record] = cluster_divided_difference(nodes, otherPoles, d)
nodes = nodes(:).';
otherPoles = otherPoles(:).';
multiplicity = numel(nodes);
centre = mean(nodes);
offsets = nodes - centre;
radius = max(abs(offsets));
maximumDegree = max(30, multiplicity + 12);

if multiplicity == 1
    denominator = prod(centre - otherPoles);
    value = exp(1i .* d .* centre) ./ denominator;
    method = 'direct_single_residue';
    lastTermRatio = 0;
else
    coefficients = taylor_coefficients( ...
        centre, d, otherPoles, maximumDegree);
    maximumH = maximumDegree - multiplicity + 1;
    homogeneous = complete_homogeneous(offsets, maximumH);
    terms = complex(zeros(maximumH + 1, 1));
    for degree = (multiplicity - 1):maximumDegree
        hIndex = degree - multiplicity + 1;
        terms(hIndex + 1) = coefficients(degree + 1) ...
            .* homogeneous(hIndex + 1);
    end
    value = sum(terms);
    scale = max(1, sum(abs(terms)));
    lastTermRatio = abs(terms(end)) ./ scale;
    method = 'confluent_cluster_taylor';
end

record = struct();
record.nodes = nodes;
record.otherPoles = otherPoles;
record.multiplicity = multiplicity;
record.centre = centre;
record.radius = radius;
record.method = method;
record.maximumTaylorDegree = maximumDegree;
record.lastTermRatio = lastTermRatio;
record.value = value;
end

function coefficients = taylor_coefficients(centre, d, poles, degreeMax)
coefficients = complex(zeros(degreeMax + 1, 1));
prefactor = exp(1i .* d .* centre);
for degree = 0:degreeMax
    coefficients(degree + 1) = prefactor .* (1i .* d).^degree ...
        ./ factorial(degree);
end
for poleIndex = 1:numel(poles)
    base = centre - poles(poleIndex);
    if base == 0
        error('ndelta:longitudinal:ClusterHitsOtherPole', ...
            'A confluent selected cluster hits an unselected pole.');
    end
    factor = complex(zeros(degreeMax + 1, 1));
    for degree = 0:degreeMax
        factor(degree + 1) = (-1).^degree ./ base.^(degree + 1);
    end
    product = conv(coefficients, factor);
    coefficients = product(1:(degreeMax + 1));
end
end

function values = complete_homogeneous(offsets, maximumDegree)
values = complex(zeros(maximumDegree + 1, 1));
values(1) = 1;
for offsetIndex = 1:numel(offsets)
    previous = values;
    for degree = 1:maximumDegree
        accumulator = complex(0);
        for power = 0:degree
            accumulator = accumulator + previous(degree - power + 1) ...
                .* offsets(offsetIndex).^power;
        end
        values(degree + 1) = accumulator;
    end
end
end

function minimum = minimum_cross_distance(first, second)
if isempty(first) || isempty(second)
    minimum = Inf;
    return;
end
distances = abs(first(:) - second(:).');
minimum = min(distances(:));
end

function diagnostics = make_diagnostics(selected, unselected, clusters, ...
        distance, closureSide, orientation, factorisationSign, ...
        residueSum, tolerance)
diagnostics = struct();
diagnostics.phaseDistance = distance;
diagnostics.closureSide = closureSide;
diagnostics.closure = 'upper';
if closureSide < 0
    diagnostics.closure = 'lower';
end
diagnostics.orientation = orientation;
diagnostics.factorisationSign = factorisationSign;
diagnostics.selectedPoles = selected;
diagnostics.unselectedPoles = unselected;
diagnostics.numberOfSelectedPolesWithMultiplicity = numel(selected);
diagnostics.numberOfUnselectedPolesWithMultiplicity = numel(unselected);
diagnostics.clusters = clusters;
diagnostics.numberOfClusters = numel(clusters);
diagnostics.residueSumBeforeContourFactor = residueSum;
diagnostics.coalescenceTolerance = tolerance;
diagnostics.frozenPoleLabelsUsed = true;
diagnostics.reclassifiedByCurrentImaginaryPart = false;
diagnostics.includesQ3MeasureOneOverTwoPi = true;
end
