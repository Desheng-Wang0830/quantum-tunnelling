function terms = bridge_terms(distance, kappaI, P)
%BRIDGE_TERMS Residue-resolved mixed P/K longitudinal convolution.
%
%   J(D,Q) = integral ds/(2*pi) exp(i*s*D)
%       i/(P^2-s^2) * i/(K^2-(s-Q)^2)
%
%   is returned as two Q-dependent terms.  The pole-side labels are
%   frozen by analytic continuation from the Feynman contour.  In
%   particular, the two poles of P^2-(Q+ETA*K)^2 lie on the same frozen
%   side; assigning one pole to each half-plane is incorrect.

narginchk(3, 3);
validateattributes(distance, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'distance');
if ~isnumeric(kappaI) || ~isscalar(kappaI) || kappaI == 0 || ...
        ~isfinite(real(kappaI)) || ~isfinite(imag(kappaI))
    error('ndelta:longitudinal:InvalidBridgeRoot', ...
        'kappaI must be one finite nonzero complex scalar.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');

eta = 1;
if distance < 0
    eta = -1;
end
absoluteDistance = abs(distance);

externalPole = struct();
externalPole.label = 'external_P_pole';
externalPole.coefficient = 1i .* exp(1i .* P .* absoluteDistance) ...
    ./ (2 .* P);
externalPole.qPhaseShift = 0;
externalPole.poleLocations = [eta .* P + kappaI, ...
    eta .* P - kappaI];
externalPole.poleSides = [1, -1];
externalPole.denominatorFactorisationSign = -1;
externalPole.denominator = 'kappaI^2-(eta*P-q3)^2';

internalPole = struct();
internalPole.label = 'shifted_internal_K_pole';
internalPole.coefficient = 1i .* exp(1i .* kappaI .* absoluteDistance) ...
    ./ (2 .* kappaI);
internalPole.qPhaseShift = distance;
internalPole.poleLocations = [-eta .* kappaI + P, ...
    -eta .* kappaI - P];
% Both locations inherit the same side from the selected s3 pole.
internalPole.poleSides = [-eta, -eta];
internalPole.denominatorFactorisationSign = -1;
internalPole.denominator = 'P^2-(q3+eta*kappaI)^2';

terms = [externalPole, internalPole];
end
