function [value, diagnostics] = g4_kernel_from_roots( ...
        internalDistance, leftBridgeDistance, rightBridgeDistance, ...
        omega, kappaI, P, coalescenceTolerance)
%G4_KERNEL_FROM_ROOTS Three-distance, two-bridge Rose G4 kernel.

narginchk(6, 7);
if nargin < 7
    coalescenceTolerance = 1e-8;
end
distances = [internalDistance, leftBridgeDistance, rightBridgeDistance];
if ~isnumeric(distances) || any(~isfinite(distances)) || ...
        ~isreal(distances)
    error('ndelta:g4:InvalidLongitudinalDistances', ...
        'All G4 directed distances must be finite real scalars.');
end
if ~isnumeric(omega) || ~isscalar(omega) || ...
        ~isfinite(real(omega)) || ~isfinite(imag(omega)) || ...
        ~isnumeric(kappaI) || ~isscalar(kappaI) || kappaI == 0 || ...
        ~isfinite(real(kappaI)) || ~isfinite(imag(kappaI))
    error('ndelta:g4:InvalidLongitudinalRoots', ...
        'omega and kappaI must be finite scalars with kappaI nonzero.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');

leftTerms = ndelta.longitudinal.bridge_terms( ...
    leftBridgeDistance, kappaI, P);
rightTerms = ndelta.longitudinal.bridge_terms( ...
    rightBridgeDistance, kappaI, P);
termValues = complex(zeros(numel(leftTerms), numel(rightTerms)));
termDiagnostics = cell(numel(leftTerms), numel(rightTerms));
for leftIndex = 1:numel(leftTerms)
    for rightIndex = 1:numel(rightTerms)
        left = leftTerms(leftIndex);
        right = rightTerms(rightIndex);
        distance = internalDistance + left.qPhaseShift ...
            + right.qPhaseShift;
        locations = [omega, -omega, ...
            left.poleLocations, right.poleLocations];
        sides = [1, -1, left.poleSides, right.poleSides];
        factorisationSign = (-1) ...
            .* left.denominatorFactorisationSign ...
            .* right.denominatorFactorisationSign;
        [integralValue, details] = ...
            ndelta.longitudinal.rational_contour_integral( ...
            distance, locations, sides, factorisationSign, ...
            coalescenceTolerance);
        % The remaining heavy propagator contributes its numerator i.
        termValues(leftIndex, rightIndex) = 1i ...
            .* left.coefficient .* right.coefficient .* integralValue;
        details.leftBridgeLabel = left.label;
        details.rightBridgeLabel = right.label;
        termDiagnostics{leftIndex, rightIndex} = details;
    end
end
value = sum(termValues(:));
diagnostics = struct();
diagnostics.term = 'G4';
diagnostics.value = value;
diagnostics.internalDistance = internalDistance;
diagnostics.leftBridgeDistance = leftBridgeDistance;
diagnostics.rightBridgeDistance = rightBridgeDistance;
diagnostics.orderedDistanceTriple = distances;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = P;
diagnostics.leftBridgeTerms = leftTerms;
diagnostics.rightBridgeTerms = rightTerms;
diagnostics.termValues = termValues;
diagnostics.termDiagnostics = termDiagnostics;
diagnostics.termAssemblyResidual = value - sum(termValues(:));
diagnostics.coalescenceTolerance = coalescenceTolerance;
diagnostics.sameSideMergersUseConfluentResidues = true;
diagnostics.mixedMinusOrdinaryPolePresent = false;
diagnostics.includesS3Integration = true;
diagnostics.includesW3Integration = true;
diagnostics.includesQ3Integration = true;
diagnostics.includesThreeLongitudinalMeasures = true;
diagnostics.includesTauI = false;
diagnostics.includesTauP = false;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.massDimension = -7;
end
