function result = assemble_g1_g4(cfg, tree, g1, g2, g3, g4)
%ASSEMBLE_G1_G4 Sum all Rose terms at amplitude level before interference.

narginchk(6, 6);
terms = {g1, g2, g3, g4};
termNames = {'G1', 'G2', 'G3', 'G4'};
termKernels = complex(zeros(4, 2));
termAmplitudesPerMu2 = complex(zeros(4, 2));
termDeltaAmplitudes = complex(zeros(4, 2));
termDeltaProbabilities = zeros(4, 2);
for termIndex = 1:4
    item = terms{termIndex};
    required = {'reducedKernelsPerMu2', 'amplitudesPerMu2', ...
        'deltaAmplitudes', 'deltaProbabilities'};
    if ~isstruct(item) || ~isscalar(item) || ~all(isfield(item, required))
        error('ndelta:amplitude:InvalidRoseTerm', ...
            'Every Rose term must be an assembled amplitude result.');
    end
    termKernels(termIndex, :) = item.reducedKernelsPerMu2;
    termAmplitudesPerMu2(termIndex, :) = item.amplitudesPerMu2;
    termDeltaAmplitudes(termIndex, :) = item.deltaAmplitudes;
    termDeltaProbabilities(termIndex, :) = item.deltaProbabilities;
end
treeAmplitudes = [tree.t0, tree.r0];
treeProbabilities = [tree.T0, tree.R0];
totalAmplitudesPerMu2 = sum(termAmplitudesPerMu2, 1);
totalDeltaAmplitudes = sum(termDeltaAmplitudes, 1);
totalDeltaProbabilitiesDirect = 2 .* real( ...
    conj(treeAmplitudes) .* totalDeltaAmplitudes);
totalDeltaProbabilitiesByTerms = sum(termDeltaProbabilities, 1);
interferenceResidual = max(abs(totalDeltaProbabilitiesDirect ...
    - totalDeltaProbabilitiesByTerms));
truncatedProbabilities = treeProbabilities + totalDeltaProbabilitiesDirect;

result = struct();
result.termNames = termNames;
result.channelNames = {'transmission', 'reflection'};
result.termKernelMatrix = termKernels;
result.termAmplitudesPerMu2 = termAmplitudesPerMu2;
result.termDeltaAmplitudeMatrix = termDeltaAmplitudes;
result.termDeltaProbabilityMatrix = termDeltaProbabilities;
result.totalReducedKernelsPerMu2 = sum(termKernels, 1);
result.totalAmplitudesPerMu2 = totalAmplitudesPerMu2;
result.totalDeltaAmplitudes = totalDeltaAmplitudes;
result.totalDeltaProbabilities = totalDeltaProbabilitiesDirect;
result.totalDeltaProbabilitiesByTermSum = ...
    totalDeltaProbabilitiesByTerms;
result.maximumInterferenceAssemblyResidual = interferenceResidual;
result.treeAmplitudes = treeAmplitudes;
result.treeProbabilities = treeProbabilities;
result.truncatedProbabilities = truncatedProbabilities;
result.unitarity = struct( ...
    'treeClosureResidual', sum(treeProbabilities) - 1, ...
    'oneLoopInterferenceClosure', sum(totalDeltaProbabilitiesDirect), ...
    'oneLoopInterferenceClosurePerMu2', ...
    sum(totalDeltaProbabilitiesDirect) ./ max(cfg.model.mu.^2, realmin), ...
    'truncatedProbabilityClosure', sum(truncatedProbabilities) - 1, ...
    'leftIncidenceProbabilityClosureTested', true, ...
    'fullTwoByTwoSMatrixTested', false);
result.amplitudeLevelSumUsed = true;
result.termwiseInterferenceSumUsedAsCrossCheck = true;
result.amplitudeSquaredIncluded = false;
result.mu4TermsIncluded = false;
result.status = 'complete_Rose_G1_G4_strict_O_mu2_amplitude_sum';
end
