function result = assemble_stage11_term(cfg, tree, reduced)
%ASSEMBLE_STAGE11_TERM LSZ and strict O(mu^2) map for G2, G3 or G4.

narginchk(3, 3);
P = cfg.derived.P;
muSquared = cfg.model.mu.^2;
K = [reduced.transmission.value, reduced.reflection.value];
amplitudesPerMu2 = K ./ (2 .* P);
deltaAmplitudes = muSquared .* amplitudesPerMu2;
treeAmplitudes = [tree.t0, tree.r0];
treeProbabilities = [tree.T0, tree.R0];
deltaProbabilitiesPerMu2 = 2 .* real( ...
    conj(treeAmplitudes) .* amplitudesPerMu2);
deltaProbabilities = muSquared .* deltaProbabilitiesPerMu2;
componentAmplitudesPerMu2 = reduced.componentMatrix ./ (2 .* P);
sourceAmplitudesPerMu2 = reduced.sourceMatrix ./ (2 .* P);
componentDeltaProbabilitiesPerMu2 = 2 .* real(bsxfun( ...
    @times, componentAmplitudesPerMu2, conj(treeAmplitudes.')));
sourceDeltaProbabilitiesPerMu2 = 2 .* real(bsxfun( ...
    @times, sourceAmplitudesPerMu2, conj(treeAmplitudes.')));

result = struct();
result.term = reduced.term;
result.P = P;
result.mu = cfg.model.mu;
result.muSquared = muSquared;
result.lszCoefficient = 1 ./ (2 .* P);
result.treeAmplitudes = treeAmplitudes;
result.treeProbabilities = treeProbabilities;
result.reducedKernelsPerMu2 = K;
result.amplitudesPerMu2 = amplitudesPerMu2;
result.deltaAmplitudes = deltaAmplitudes;
result.deltaProbabilitiesPerMu2 = deltaProbabilitiesPerMu2;
result.deltaProbabilities = deltaProbabilities;
result.truncatedProbabilities = treeProbabilities + deltaProbabilities;
result.componentNames = reduced.componentNames;
result.sourceNames = reduced.sourceNames;
result.componentAmplitudesPerMu2 = componentAmplitudesPerMu2;
result.sourceAmplitudesPerMu2 = sourceAmplitudesPerMu2;
result.componentDeltaProbabilitiesPerMu2 = ...
    componentDeltaProbabilitiesPerMu2;
result.sourceDeltaProbabilitiesPerMu2 = ...
    sourceDeltaProbabilitiesPerMu2;
result.transmission = channel_record(1);
result.reflection = channel_record(2);
result.amplitudeSquaredIncluded = false;
result.mu4TermsIncluded = false;
result.oneOverTwoPAppliedExactlyOnce = true;
result.muSquaredAppliedExactlyOnce = true;
result.status = 'stage11_single_term_strict_O_mu2_interference';

    function item = channel_record(index)
        item = struct('treeAmplitude', treeAmplitudes(index), ...
            'treeProbability', treeProbabilities(index), ...
            'reducedKernelPerMu2', K(index), ...
            'amplitudePerMu2', amplitudesPerMu2(index), ...
            'deltaAmplitude', deltaAmplitudes(index), ...
            'deltaProbabilityPerMu2', ...
            deltaProbabilitiesPerMu2(index), ...
            'deltaProbability', deltaProbabilities(index), ...
            'truncatedProbability', ...
            treeProbabilities(index) + deltaProbabilities(index));
    end
end
