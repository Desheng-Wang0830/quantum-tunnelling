function result = assemble_g1(cfg, tree, reduced)
%ASSEMBLE_G1 Stage 9 LSZ map and strict O(mu^2) interference.

narginchk(3, 3);
P = cfg.derived.P;
muSquared = cfg.model.mu.^2;
coefficient = 1 ./ (2 .* P);
K = [reduced.transmission.value, reduced.reflection.value];
amplitudesPerMu2 = coefficient .* K;
deltaAmplitudes = muSquared .* amplitudesPerMu2;
treeAmplitudes = [tree.t0, tree.r0];
treeProbabilities = [tree.T0, tree.R0];
deltaProbabilitiesPerMu2 = 2 .* real( ...
    conj(treeAmplitudes) .* amplitudesPerMu2);
deltaProbabilities = muSquared .* deltaProbabilitiesPerMu2;
truncatedProbabilities = treeProbabilities + deltaProbabilities;

componentAmplitudesPerMu2 = coefficient .* reduced.componentMatrix;
sourceAmplitudesPerMu2 = coefficient .* reduced.sourceMatrix;
componentDeltaProbabilitiesPerMu2 = 2 .* real(bsxfun( ...
    @times, componentAmplitudesPerMu2, conj(treeAmplitudes.')));
sourceDeltaProbabilitiesPerMu2 = 2 .* real(bsxfun( ...
    @times, sourceAmplitudesPerMu2, conj(treeAmplitudes.')));

result = struct();
result.P = P;
result.mu = cfg.model.mu;
result.muSquared = muSquared;
result.lszCoefficient = coefficient;
result.lszCoefficients = [coefficient, coefficient];
result.channelNames = {'transmission', 'reflection'};
result.treeAmplitudes = treeAmplitudes;
result.treeProbabilities = treeProbabilities;
result.reducedKernelsPerMu2 = K;
result.amplitudesPerMu2 = amplitudesPerMu2;
result.deltaAmplitudes = deltaAmplitudes;
result.deltaProbabilitiesPerMu2 = deltaProbabilitiesPerMu2;
result.deltaProbabilities = deltaProbabilities;
result.truncatedProbabilities = truncatedProbabilities;
result.componentNames = reduced.componentNames;
result.sourceNames = reduced.sourceNames;
result.componentAmplitudesPerMu2 = componentAmplitudesPerMu2;
result.sourceAmplitudesPerMu2 = sourceAmplitudesPerMu2;
result.componentDeltaProbabilitiesPerMu2 = ...
    componentDeltaProbabilitiesPerMu2;
result.sourceDeltaProbabilitiesPerMu2 = ...
    sourceDeltaProbabilitiesPerMu2;
result.transmission = channel_record(1);
result.reflection = channel_record(2);
result.partialUnitarityDiagnostic = struct( ...
    'treeClosureResidual', sum(treeProbabilities) - 1, ...
    'g1InterferenceSumPerMu2', sum(deltaProbabilitiesPerMu2), ...
    'g1InterferenceSum', sum(deltaProbabilities), ...
    'truncatedProbabilitySum', sum(truncatedProbabilities), ...
    'g1AloneRequiredToClose', false, ...
    'fullRoseG1ToG4RequiredForOneLoopClosure', true);
result.perturbativeOrder = 'strict_O(mu^2)';
result.amplitudeSquaredIncluded = false;
result.mu4TermsIncluded = false;
result.vertexSignAlreadyInsideReducedKernel = true;
result.additionalVertexMinusApplied = false;
result.additionalImaginaryUnitApplied = false;
result.oneOverTwoPAppliedExactlyOnce = true;
result.muSquaredAppliedExactlyOnce = true;
result.status = 'stage9_g1_lsz_and_probability_interference';

    function out = channel_record(index)
        out = struct('treeAmplitude', treeAmplitudes(index), ...
            'treeProbability', treeProbabilities(index), ...
            'reducedKernelPerMu2', K(index), ...
            'amplitudePerMu2', amplitudesPerMu2(index), ...
            'deltaAmplitude', deltaAmplitudes(index), ...
            'deltaProbabilityPerMu2', deltaProbabilitiesPerMu2(index), ...
            'deltaProbability', deltaProbabilities(index), ...
            'truncatedProbability', truncatedProbabilities(index));
    end
end
