function [outputs, elapsedSeconds] = map_indexed_parallel( ...
        numberOfTasks, evaluator, plan, pool, label)
%MAP_INDEXED_PARALLEL PCT-only rolling future scheduler.
%   Kept separate so the serial backend never loads PCT class references.

narginchk(5, 5);
if isempty(pool)
    error('ndelta:parallel:MissingPreparedPool', ...
        'The parallel plan is active but no prepared pool was supplied.');
end
outputs = cell(numberOfTasks, 1);
timer = tic;
maximumInFlight = min(numberOfTasks, max(1, plan.workerCount));
activeFutures(1:maximumInFlight) = parallel.FevalFuture;
activeJobIndices = zeros(1, maximumInFlight);
submitted = 0;
try
    for slot = 1:maximumInFlight
        nextIndex = submitted + 1;
        activeJobIndices(slot) = nextIndex;
        activeFutures(slot) = parfeval( ...
            pool, evaluator, 1, nextIndex);
        submitted = nextIndex;
    end
    for completed = 1:numberOfTasks
        [completedSlot, value] = fetchNext(activeFutures);
        canonicalIndex = activeJobIndices(completedSlot);
        outputs{canonicalIndex} = value;
        print_progress(plan, label, completed, numberOfTasks, toc(timer));
        if submitted < numberOfTasks
            nextIndex = submitted + 1;
            activeJobIndices(completedSlot) = nextIndex;
            activeFutures(completedSlot) = parfeval( ...
                pool, evaluator, 1, nextIndex);
            submitted = nextIndex;
        else
            activeFutures(completedSlot) = [];
            activeJobIndices(completedSlot) = [];
        end
    end
catch exception
    cancel_futures_safely(activeFutures, activeJobIndices);
    rethrow(exception);
end
elapsedSeconds = toc(timer);
end

function cancel_futures_safely(futures, jobIndices)
for slot = find(jobIndices > 0)
    try
        cancel(futures(slot));
    catch
        % Preserve the original worker, submission or user-interrupt error.
    end
end
end

function print_progress(plan, label, completed, total, elapsedSeconds)
if ~plan.showProgress
    return;
end
average = elapsedSeconds ./ max(completed, 1);
etaSeconds = average .* max(total - completed, 0);
fprintf('Stage 12 %s: %d/%d complete (%.1f min elapsed, %.1f min ETA).\n', ...
    label, completed, total, elapsedSeconds ./ 60, etaSeconds ./ 60);
end
