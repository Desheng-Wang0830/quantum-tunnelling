function [outputs, report] = map_indexed( ...
        numberOfTasks, evaluator, plan, pool, label)
%MAP_INDEXED Execute coarse independent jobs and restore canonical order.

narginchk(4, 5);
if nargin < 5, label = 'jobs'; end
if isstring(label) && isscalar(label), label = char(label); end
if ~isnumeric(numberOfTasks) || ~isscalar(numberOfTasks) || ...
        ~isreal(numberOfTasks) || ~isfinite(numberOfTasks) || ...
        numberOfTasks ~= fix(numberOfTasks) || numberOfTasks < 0
    error('ndelta:parallel:InvalidTaskCount', ...
        'numberOfTasks must be a nonnegative integer scalar.');
end
if ~isa(evaluator, 'function_handle')
    error('ndelta:parallel:InvalidEvaluator', ...
        'evaluator must be a function handle accepting one task index.');
end
requiredPlan = {'useParallel', 'showProgress', 'workerCount', ...
    'deterministicIndexedMerge'};
if ~isstruct(plan) || ~isscalar(plan) || ...
        ~all(isfield(plan, requiredPlan))
    error('ndelta:parallel:InvalidExecutionPlan', ...
        'A prepared parallel execution plan is required.');
end
if ~isnumeric(plan.workerCount) || ~isscalar(plan.workerCount) || ...
        ~isreal(plan.workerCount) || ~isfinite(plan.workerCount) || ...
        plan.workerCount ~= fix(plan.workerCount) || plan.workerCount < 1
    error('ndelta:parallel:InvalidExecutionPlan', ...
        'A prepared plan must contain a positive integer workerCount.');
end

outputs = cell(numberOfTasks, 1);
timer = tic;
if numberOfTasks == 0
    report = make_report(plan, label, numberOfTasks, 0);
    return;
end

if ~plan.useParallel
    for index = 1:numberOfTasks
        outputs{index} = evaluator(index);
        print_progress(plan, label, index, numberOfTasks, toc(timer));
    end
else
    [outputs, elapsedSeconds] = ...
        ndelta.execution.map_indexed_parallel( ...
        numberOfTasks, evaluator, plan, pool, label);
    report = make_report(plan, label, numberOfTasks, elapsedSeconds);
    return;
end
report = make_report(plan, label, numberOfTasks, toc(timer));
end

function report = make_report(plan, label, numberOfTasks, elapsedSeconds)
report = struct();
report.label = label;
report.usedParallel = logical(plan.useParallel);
report.taskCount = numberOfTasks;
report.workerCount = max(1, plan.workerCount);
report.elapsedSeconds = elapsedSeconds;
report.canonicalOrderingPreserved = logical( ...
    plan.deterministicIndexedMerge);
if plan.useParallel
    report.status = 'parallel_jobs_completed_and_indexed_canonically';
else
    report.status = 'serial_jobs_completed_in_canonical_order';
end
end

function print_progress(plan, label, completed, total, elapsedSeconds)
if ~plan.showProgress
    return;
end
average = elapsedSeconds ./ max(completed, 1);
etaSeconds = average .* max(total - completed, 0);
fprintf('Stage 12 %s: %d/%d complete (%.1f min elapsed, %.1f min ETA).\n', ...
    label, completed, total, elapsedSeconds ./ 60, etaSeconds ./ 60);
end
