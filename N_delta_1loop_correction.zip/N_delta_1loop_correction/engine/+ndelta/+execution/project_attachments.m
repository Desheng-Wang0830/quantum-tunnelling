function paths = project_attachments(projectRoot)
%PROJECT_ATTACHMENTS Code-only worker payload; exclude output and documents.

narginchk(1, 1);
if isstring(projectRoot) && isscalar(projectRoot)
    projectRoot = char(projectRoot);
end
if ~ischar(projectRoot) || exist(projectRoot, 'dir') ~= 7
    error('ndelta:parallel:InvalidProjectRoot', ...
        'A readable project-root folder is required for worker attachment.');
end
rootFiles = dir(fullfile(projectRoot, '*.m'));
paths = cell(numel(rootFiles) + 1, 1);
paths{1} = fullfile(projectRoot, '+ndelta');
for index = 1:numel(rootFiles)
    paths{index + 1} = fullfile(projectRoot, rootFiles(index).name);
end
end
