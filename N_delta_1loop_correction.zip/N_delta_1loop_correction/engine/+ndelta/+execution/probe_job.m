function result = probe_job(index)
%PROBE_JOB Small deterministic worker/order smoke task.

narginchk(1, 1);
validateattributes(index, {'numeric'}, ...
    {'real', 'finite', 'integer', 'positive', 'scalar'});
onWorker = false;
try
    onWorker = ~isempty(getCurrentTask());
catch
    onWorker = false;
end
result = struct('index', index, ...
    'value', complex(index.^2 + 0.5 .* index, -index ./ 7), ...
    'onWorker', onWorker);
end
