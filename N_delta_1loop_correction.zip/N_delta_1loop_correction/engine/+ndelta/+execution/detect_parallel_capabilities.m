function capabilities = detect_parallel_capabilities()
%DETECT_PARALLEL_CAPABILITIES Inspect PCT without creating a pool.

narginchk(0, 0);
% Query the installed-product catalogue by the stable product name.  Do not
% query the historical toolbox-folder alias: recent MATLAB releases warn
% for that alias and future releases will remove it.  The product-name
% catalogue is available throughout the declared R2016b+ support window.
installedProducts = ver;
installedNames = {installedProducts.Name};
toolboxInstalled = any(strcmp( ...
    installedNames, 'Parallel Computing Toolbox'));

% These are ordinary top-level entry points in every supported PCT release.
% Method-dispatched operations such as fetchOutputs/addAttachedFiles are
% deliberately exercised later against a real pool, where their support can
% be established without false negatives from which/exist.
requiredFunctions = {'gcp', 'parpool', 'parfeval'};
functionFound = false(size(requiredFunctions));
for index = 1:numel(requiredFunctions)
    functionFound(index) = exist(requiredFunctions{index}, 'file') ~= 0 || ...
        exist(requiredFunctions{index}, 'builtin') ~= 0;
end
functionsAvailable = all(functionFound);
missingFunctions = requiredFunctions(~functionFound);

licenseAvailable = false;
try
    licenseAvailable = license('test', 'Distrib_Computing_Toolbox');
catch
    licenseAvailable = false;
end

capabilities = struct();
capabilities.toolboxInstalled = toolboxInstalled;
capabilities.licenseAvailable = logical(licenseAvailable);
capabilities.functionsAvailable = functionsAvailable;
capabilities.missingFunctions = missingFunctions(:);
capabilities.available = toolboxInstalled && licenseAvailable && ...
    functionsAvailable;
if ~toolboxInstalled
    capabilities.status = 'parallel_toolbox_not_installed';
    capabilities.reason = [ ...
        'Parallel Computing Toolbox is not present in the installed-' ...
        'product catalogue. Use mode=''auto'' or ''serial'', or install ' ...
        'the toolbox before requesting mode=''required''.'];
elseif ~licenseAvailable
    capabilities.status = 'parallel_license_unavailable';
    capabilities.reason = ...
        'A Parallel Computing Toolbox licence is not available.';
elseif ~functionsAvailable
    capabilities.status = 'parallel_api_unavailable';
    capabilities.reason = sprintf( ...
        'Required Parallel Computing Toolbox API(s) are unavailable: %s.', ...
        join_names(missingFunctions));
else
    capabilities.status = 'parallel_runtime_available';
    capabilities.reason = '';
end
end

function value = join_names(names)
if isempty(names)
    value = '';
    return;
end
value = names{1};
for index = 2:numel(names)
    value = [value ', ' names{index}]; %#ok<AGROW>
end
end
