function plan = serial_plan(cfg)
%SERIAL_PLAN Prepared no-pool execution metadata for internal callers/tests.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
settings = cfg.execution.parallel;
settings.mode = 'serial';
capabilities = struct('available', false, ...
    'status', 'serial_requested', 'reason', '');
plan = ndelta.execution.resolve_parallel_policy(settings, capabilities);
end
