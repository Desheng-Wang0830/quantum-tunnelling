function plan = resolve_parallel_policy(settings, capabilities)
%RESOLVE_PARALLEL_POLICY Pure serial/auto/required policy resolution.

narginchk(2, 2);
requiredSettings = {'mode', 'profile', 'workerCount', 'autoStartPool', ...
    'attachProjectFiles', 'showProgress'};
requiredCapabilities = {'available', 'status', 'reason'};
if ~isstruct(settings) || ~isscalar(settings) || ...
        ~all(isfield(settings, requiredSettings))
    error('ndelta:parallel:InvalidSettings', ...
        'A validated Stage 12 parallel-settings structure is required.');
end
if ~isstruct(capabilities) || ~isscalar(capabilities) || ...
        ~all(isfield(capabilities, requiredCapabilities))
    error('ndelta:parallel:InvalidCapabilities', ...
        'A scalar parallel-capabilities structure is required.');
end

mode = settings.mode;
if isstring(mode) && isscalar(mode), mode = char(mode); end
plan = struct();
plan.requestedMode = mode;
plan.effectiveMode = 'serial';
plan.useParallel = false;
plan.fallbackUsed = false;
plan.fallbackReason = '';
plan.capabilityStatus = capabilities.status;
plan.capabilityReason = capabilities.reason;
plan.profile = settings.profile;
plan.requestedWorkerCount = settings.workerCount;
plan.autoStartPool = settings.autoStartPool;
plan.attachProjectFiles = settings.attachProjectFiles;
plan.showProgress = settings.showProgress;
plan.poolStartedByStage12 = false;
plan.poolReused = false;
plan.workerCount = 1;
plan.poolWorkerCount = 0;
plan.poolClass = '';
plan.poolClosedAfterPreparationFailure = false;
plan.workerDependencyCheckPassed = false;
plan.projectFilesAttached = false;
plan.deterministicIndexedMerge = true;
plan.innerQuadratureRemainsSerial = true;
plan.status = 'serial_requested';

if strcmp(mode, 'serial')
    return;
end
if capabilities.available
    plan.effectiveMode = 'parallel';
    plan.useParallel = true;
    plan.status = 'parallel_runtime_available_pool_not_prepared';
    return;
end
if strcmp(mode, 'required')
    error('ndelta:parallel:Unavailable', ...
        'Required Stage 12 parallel execution is unavailable: %s', ...
        capabilities.reason);
end

plan.fallbackUsed = true;
plan.fallbackReason = capabilities.reason;
plan.status = 'auto_fallback_to_serial';
end
