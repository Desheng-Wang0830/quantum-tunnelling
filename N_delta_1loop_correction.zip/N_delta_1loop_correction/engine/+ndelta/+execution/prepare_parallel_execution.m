function [plan, pool] = prepare_parallel_execution(cfg)
%PREPARE_PARALLEL_EXECUTION Resolve and initialise one Stage 12 pool.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
settings = cfg.execution.parallel;
pool = [];
if strcmp(settings.mode, 'serial')
    capabilities = struct('available', false, ...
        'status', 'serial_requested', 'reason', '');
    plan = ndelta.execution.resolve_parallel_policy( ...
        settings, capabilities);
    return;
end

capabilities = ndelta.execution.detect_parallel_capabilities();
plan = ndelta.execution.resolve_parallel_policy(settings, capabilities);
if ~plan.useParallel
    warning('ndelta:parallel:SerialFallback', ...
        'Stage 12 parallel auto mode is using serial execution: %s', ...
        plan.fallbackReason);
    return;
end

try
    pool = gcp('nocreate');
    if isempty(pool)
        if ~settings.autoStartPool
            error('ndelta:parallel:PoolNotRunning', ...
                ['No parallel pool is running and automatic pool startup ' ...
                 'is disabled.']);
        end
        if settings.workerCount > 0
            pool = parpool(settings.profile, settings.workerCount);
        else
            pool = parpool(settings.profile);
        end
        plan.poolStartedByStage12 = true;
    else
        plan.poolReused = true;
    end

    plan.poolClass = class(pool);
    if ~isempty(strfind(lower(plan.poolClass), 'threadpool')) %#ok<STREMP>
        error('ndelta:parallel:ThreadPoolUnsupported', ...
            ['This release supports process/cluster workers only; an ' ...
             'existing thread pool is not used or deleted.']);
    end
    plan.poolWorkerCount = pool.NumWorkers;
    if settings.workerCount > 0
        plan.workerCount = min(pool.NumWorkers, settings.workerCount);
    else
        plan.workerCount = pool.NumWorkers;
    end
    if settings.attachProjectFiles
        attachments = ndelta.execution.project_attachments(cfg.projectRoot);
        addAttachedFiles(pool, attachments);
        % Before R2026a, re-attaching an existing path does not refresh it.
        % updateAttachedFiles is a Pool method in supported PCT releases.
        updateAttachedFiles(pool);
        plan.projectFilesAttached = true;
    end
    release = ndelta.config.release_contract();
    probeFuture = parfevalOnAll(pool, ...
        @ndelta.execution.worker_dependency_probe, 0, ...
        release.releaseVersion);
    % A missing dependency or release mismatch throws on fetchOutputs.
    % Using zero outputs avoids cross-release array-concatenation semantics.
    fetchOutputs(probeFuture);
    plan.workerDependencyCheckPassed = true;
    plan.status = 'parallel_process_pool_ready';
catch exception
    if plan.poolStartedByStage12 && ~isempty(pool)
        try
            delete(pool);
            plan.poolClosedAfterPreparationFailure = true;
        catch
            % Preserve the original preparation failure or interruption.
        end
    end
    if is_user_interruption(exception)
        rethrow(exception);
    end
    if strcmp(settings.mode, 'required')
        error('ndelta:parallel:PoolPreparationFailed', ...
            'Required Stage 12 parallel preparation failed [%s]: %s', ...
            exception.identifier, exception.message);
    end
    pool = [];
    plan.effectiveMode = 'serial';
    plan.useParallel = false;
    plan.workerCount = 1;
    plan.poolWorkerCount = 0;
    plan.fallbackUsed = true;
    plan.fallbackReason = sprintf('%s: %s', ...
        exception.identifier, exception.message);
    plan.status = 'auto_pool_preparation_fallback_to_serial';
    warning('ndelta:parallel:SerialFallback', ...
        'Stage 12 pool preparation failed; using serial execution [%s]: %s', ...
        exception.identifier, exception.message);
end
end

function interrupted = is_user_interruption(exception)
identifier = exception.identifier;
interrupted = strcmp(identifier, 'MATLAB:OperationTerminatedByUser') || ...
    ~isempty(strfind(identifier, 'OperationTerminated')); %#ok<STREMP>
end
