function settings = default_parallel_settings()
%DEFAULT_PARALLEL_SETTINGS Frozen optional Stage 12 process-pool policy.

settings = struct();
settings.mode = 'auto';
settings.profile = 'local';
settings.workerCount = 4;
settings.autoStartPool = true;
settings.attachProjectFiles = true;
settings.showProgress = true;
end
