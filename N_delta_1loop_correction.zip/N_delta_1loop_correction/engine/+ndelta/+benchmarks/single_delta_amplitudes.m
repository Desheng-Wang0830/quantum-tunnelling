function oracle = single_delta_amplitudes(P, g, z0)
%SINGLE_DELTA_AMPLITUDES Independent analytic N=1 reference.

narginchk(3, 3);
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');
validateattributes(g, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'g');
validateattributes(z0, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'z0');

denominator = 2 .* P + 1i .* g;
oracle = struct();
oracle.t0 = (2 .* P) ./ denominator;
oracle.r0 = (-1i .* g .* exp(2i .* P .* z0)) ./ denominator;
oracle.T0 = abs(oracle.t0).^2;
oracle.R0 = abs(oracle.r0).^2;
end
