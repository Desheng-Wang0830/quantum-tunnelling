function oracle = rose_double_amplitudes(P, totalStrength, separation)
%ROSE_DOUBLE_AMPLITUDES Rose Eqs. (25)--(26), g=aeV0.
%
%   The two centres are at +/-b/2 and each has strength g/2.

narginchk(3, 3);
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');
validateattributes(totalStrength, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'totalStrength');
validateattributes(separation, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, ...
    mfilename, 'separation');

g = totalStrength;
b = separation;
denominator = g.^2 .* exp(2i .* P .* b) + ...
    (4 .* P + 1i .* g).^2;

oracle = struct();
oracle.t0 = (16 .* P.^2) ./ denominator;
oracle.r0 = (-2i .* g .* ...
    (g .* sin(P .* b) + 4 .* P .* cos(P .* b))) ./ denominator;
oracle.T0 = abs(oracle.t0).^2;
oracle.R0 = abs(oracle.r0).^2;
oracle.probabilityClosureResidual = oracle.T0 + oracle.R0 - 1;
end
