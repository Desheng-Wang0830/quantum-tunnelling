function tau = explicit_tau2(K, totalStrength, separation)
%EXPLICIT_TAU2 Closed 2x2 inverse for Rose's symmetric double delta.

narginchk(3, 3);
if ~isnumeric(K) || ~isscalar(K) || K == 0 || ...
        ~isfinite(real(K)) || ~isfinite(imag(K))
    error('ndelta:benchmark:InvalidExplicitTauK', ...
        'K must be one finite nonzero scalar.');
end
validateattributes(totalStrength, {'numeric'}, ...
    {'real', 'finite', 'scalar'}, mfilename, 'totalStrength');
if totalStrength == 0
    error('ndelta:benchmark:ZeroExplicitTauStrength', ...
        'totalStrength must be nonzero in the explicit tau_2 formula.');
end
validateattributes(separation, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, ...
    mfilename, 'separation');

A = 2i ./ totalStrength - 1 ./ (2 .* K);
c = exp(1i .* K .* separation) ./ (2 .* K);
tau = [A, c; c, A] ./ (A.^2 - c.^2);
end
