function result = epsilon_plateau(cfg, spectrum)
%EPSILON_PLATEAU Bridge finite-epsilon contour validation to production.
%
% Only the MWR representation is used here.  The last three regulators are
% tested by a Cauchy criterion; no polynomial extrapolation is performed.

narginchk(2, 2);
cfg = ndelta.config.finalize_configuration(cfg);
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~all(isfield(spectrum, {'accepted', 'modes', ...
        'configurationFingerprint', 'solverFingerprint'}))
    error('ndelta:diagnostics:InvalidEpsilonPlateauSpectrum', ...
        'spectrum must be the accepted production Stage 7 spectrum.');
end
ndelta.config.assert_physics_fingerprint( ...
    spectrum.configurationFingerprint, cfg, ...
    'ndelta:diagnostics:EpsilonPlateauSpectrumMismatch');
if ~isequaln(spectrum.solverFingerprint, ...
        ndelta.config.spectrum_solver_fingerprint(cfg))
    error('ndelta:diagnostics:EpsilonPlateauSolverMismatch', ...
        'The production spectrum used different collective solver settings.');
end
if ~spectrum.accepted
    error('ndelta:diagnostics:EpsilonPlateauSpectrumRejected', ...
        'The production spectrum must be accepted before the epsilon scan.');
end
[qPerpPoints, regionLabels] = ...
    ndelta.diagnostics.qperp_regions(cfg, spectrum);
epsilons = cfg.stage10.epsilonPlateau(:);
if numel(epsilons) ~= 3
    error('ndelta:diagnostics:EpsilonPlateauPointCount', ...
        'The production Cauchy plateau requires exactly three epsilons.');
end
if epsilons(end) ~= cfg.sheet.epsilon
    error('ndelta:diagnostics:EpsilonPlateauMissesProduction', ...
        ['The last Stage 10 plateau epsilon must equal the production ' ...
         'cfg.sheet.epsilon exactly.']);
end
channels = 'TR';
numberOfRecords = numel(qPerpPoints) .* numel(channels);
values = complex(zeros(numel(epsilons), numberOfRecords));
sources = complex(zeros(numel(epsilons), numberOfRecords, 5));
recordQPerp = zeros(numberOfRecords, 1);
recordChannel = repmat(' ', numberOfRecords, 1);
recordRegion = cell(numberOfRecords, 1);

for epsilonIndex = 1:numel(epsilons)
    localCfg = cfg;
    localCfg.sheet.epsilon = epsilons(epsilonIndex);
    localCfg = ndelta.config.finalize_configuration(localCfg);
    geometry = ndelta.geometry.build_geometry( ...
        localCfg.barriers.positions, localCfg.tolerances.distanceMerge);
    localSpectrum = ndelta.singularity.find_collective_modes( ...
        localCfg, geometry);
    if ~localSpectrum.accepted
        error('ndelta:diagnostics:EpsilonPlateauSpectrumRejected', ...
            'An epsilon-plateau spectrum was rejected.');
    end
    options = struct('q4Order', cfg.stage10.plateauOrder, ...
        'q4Scale', localCfg.integration.q4Scale, ...
        'q4MapPower', localCfg.integration.q4MapPower, ...
        'cutRadialOrder', cfg.stage10.plateauOrder);
    recordIndex = 0;
    for pointIndex = 1:numel(qPerpPoints)
        for channelIndex = 1:numel(channels)
            recordIndex = recordIndex + 1;
            channel = channels(channelIndex);
            fixed = ndelta.contour.fixed_qperp_g1( ...
                qPerpPoints(pointIndex), channel, localCfg, ...
                geometry, localSpectrum, options);
            values(epsilonIndex, recordIndex) = fixed.value;
            sources(epsilonIndex, recordIndex, :) = [ ...
                fixed.components.euclidean, ...
                fixed.components.ordinaryPole, ...
                fixed.components.collectivePole, ...
                fixed.components.cutBanks, ...
                fixed.components.endpointKeyhole];
            if epsilonIndex == 1
                recordQPerp(recordIndex) = qPerpPoints(pointIndex);
                recordChannel(recordIndex) = channel;
                recordRegion{recordIndex} = regionLabels{pointIndex};
            end
        end
    end
end

floorValue = 1e-9 ./ max(cfg.derived.massScale.^3, realmin);
maximumTotalError = cauchy_error(values, floorValue);
sourceMatrix = reshape(sources, numel(epsilons), []);
maximumSourceError = cauchy_error(sourceMatrix, floorValue);

result = struct();
result.epsilons = epsilons;
result.qPerpPoints = qPerpPoints;
result.regionLabels = regionLabels;
result.recordQPerp = recordQPerp;
result.recordChannel = recordChannel;
result.recordRegion = recordRegion;
result.values = values;
result.sources = sources;
result.sourceNames = {'euclidean', 'ordinaryPole', ...
    'collectivePole', 'cutBanks', 'endpointKeyhole'};
result.maximumTotalCauchyError = maximumTotalError;
result.maximumSourceCauchyError = maximumSourceError;
result.totalAccepted = maximumTotalError <= ...
    cfg.tolerances.stage10EpsilonTotal;
result.sourceAccepted = maximumSourceError <= ...
    cfg.tolerances.stage10EpsilonSource;
result.accepted = result.totalAccepted && result.sourceAccepted;
result.mwrProductionEpsilonPlateauPassed = result.accepted;
result.noExtrapolationUsed = true;
result.directProductionEpsilonIdentityClaimed = false;
result.status = 'mwr_last_three_epsilon_cauchy_plateau';
end

function maximum = cauchy_error(values, floorValue)
maximum = 0;
numberOfEpsilons = size(values, 1);
for first = 1:(numberOfEpsilons - 1)
    for second = (first + 1):numberOfEpsilons
        left = values(first, :);
        right = values(second, :);
        denominator = max(floorValue, max(abs(left), abs(right)));
        substantial = max(abs(left), abs(right)) > floorValue;
        errors = abs(left - right) ./ denominator;
        errors(~substantial) = 0;
        maximum = max(maximum, max(errors(:)));
    end
end
end
