function [points, labels] = qperp_regions(cfg, spectrum)
%QPERP_REGIONS Interior fixed-qPerp samples away from topology boundaries.

narginchk(2, 2);
P = cfg.derived.P;
finiteEpsilonCorrection = ...
    (cfg.sheet.epsilon ./ (2 .* cfg.referenceEnergy)).^2;
cutCritical = sqrt(max(P.^2 - finiteEpsilonCorrection, 0));
if cfg.derived.numberOfActiveCentres == 0
    points = [0.5 .* P, 0.8 .* P, 1.2 .* P];
    labels = {'euclidean_only', 'euclidean_only_secondary', ...
        'euclidean_only'};
    return;
end
qCritical = 0;
hasCollectiveSupport = false;
if ~isempty(spectrum.modes)
    supported = [spectrum.modes.qPerpCritical];
    supported = supported(supported > 0 & [spectrum.modes.stable]);
    if ~isempty(supported)
        hasCollectiveSupport = true;
        qCritical = max(supported);
    end
end
if hasCollectiveSupport && cutCritical > 0
    lowerBoundary = min(cutCritical, qCritical);
    upperBoundary = max(cutCritical, qCritical);
    first = 0.5 .* lowerBoundary;
    firstLabel = 'cut_and_collective';
    separationScale = max([cutCritical, qCritical, ...
        cfg.derived.massScale, realmin]);
    if qCritical > cutCritical && ...
            qCritical - cutCritical > 1e-8 .* separationScale
        second = 0.5 .* (cutCritical + qCritical);
        secondLabel = 'collective_only';
    elseif cutCritical > qCritical && ...
            cutCritical - qCritical > 1e-8 .* separationScale
        second = 0.5 .* (cutCritical + qCritical);
        secondLabel = 'cut_only';
    else
        second = 0.75 .* lowerBoundary;
        secondLabel = 'cut_and_collective_secondary';
    end
    third = 1.2 .* upperBoundary;
elseif hasCollectiveSupport
    first = 0.5 .* qCritical;
    second = 0.8 .* qCritical;
    third = 1.2 .* qCritical;
    firstLabel = 'collective_only';
    secondLabel = 'collective_only_secondary';
elseif cutCritical > 0
    first = 0.5 .* cutCritical;
    second = 0.8 .* cutCritical;
    third = 1.2 .* cutCritical;
    firstLabel = 'cut_only';
    secondLabel = 'cut_only_secondary';
else
    scale = max(P, cfg.model.mphi);
    first = 0.25 .* scale;
    second = 0.75 .* scale;
    third = 1.25 .* scale;
    firstLabel = 'euclidean_only';
    secondLabel = 'euclidean_only_secondary';
end
points = [first, second, third];
labels = {firstLabel, secondLabel, 'euclidean_only'};
end
