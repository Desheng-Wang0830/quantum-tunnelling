function result = n1_regression(cfg)
%N1_REGRESSION Promote the accepted single-delta G1 full-chain benchmark.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
localCfg = run_stage0(false);
localCfg.referenceEnergy = 0.8;
localCfg.model.mphi = 0.2;
localCfg.model.mPhi = 1.4;
localCfg.model.mu = 0.1;
localCfg.barriers.positions = 0;
localCfg.barriers.strengths = -0.3;
localCfg.sheet.epsilon = 1e-9;
localCfg.integration.q4Scale = 1.0;
localCfg.integration.qPerpTailScale = 1.0;
localCfg.integration.q4MapPower = 2.0;
localCfg.integration.endpointTauSwitchRelative = 5e-2;
localCfg.integration.cutEvenSubtraction = true;
localCfg.stage10.mappingPowers = [1.5, 2.0, 2.5];
localCfg.collective.scanSamples = 801;
localCfg.tolerances.distanceMerge = 1e-12;
localCfg.tolerances.nearSingularRcond = sqrt(eps);
localCfg.tolerances.g1Coalescence = 1e-8;
localCfg.tolerances.collectiveRoot = 5e-11;
localCfg.tolerances.collectiveResidual = 2e-8;
localCfg.tolerances.collectiveDuplicate = 2e-12;
localCfg.tolerances.zeroEnergy = 2e-9;
localCfg.execution.rejectUnstableCollective = true;
localCfg = ndelta.config.finalize_configuration(localCfg);
geometry = ndelta.geometry.build_geometry( ...
    localCfg.barriers.positions, localCfg.tolerances.distanceMerge);
spectrum = ndelta.singularity.find_collective_modes(localCfg, geometry);
options = struct('q4Order', 32, 'qPerpOrder', 32, ...
    'collectiveOrder', 32, 'cutRadialOrder', 32, ...
    'cutAngleOrder', 32, 'endpointOrder', 32, ...
    'q4Scale', localCfg.integration.q4Scale, ...
    'q4MapPower', localCfg.integration.q4MapPower, ...
    'qPerpTailScale', localCfg.integration.qPerpTailScale);
reduced = ndelta.integration.integrate_g1( ...
    localCfg, geometry, spectrum, options);
tree = ndelta.tree.tree_amplitudes_N(localCfg.derived.P, geometry, ...
    localCfg.barriers.strengths, ...
    localCfg.tolerances.nearSingularRcond);
amplitude = ndelta.amplitude.assemble_g1(localCfg, tree, reduced);

expectedKernels = [ ...
    -1.4936260e-10 + 4.49250481860e-3i, ...
     8.5302119e-12 + 1.71157151372e-3i];
expectedDeltaProbabilities = [ ...
    1.08253109607105e-5, 4.12426869481478e-6];
kernelAbsoluteError = max(abs(reduced.values - expectedKernels));
probabilityAbsoluteError = max(abs( ...
    amplitude.deltaProbabilities - expectedDeltaProbabilities));

result = struct();
result.configuration = localCfg;
result.expectedKernels = expectedKernels;
result.actualKernels = reduced.values;
result.expectedDeltaProbabilities = expectedDeltaProbabilities;
result.actualDeltaProbabilities = amplitude.deltaProbabilities;
result.kernelAbsoluteError = kernelAbsoluteError;
result.probabilityAbsoluteError = probabilityAbsoluteError;
result.kernelAccepted = kernelAbsoluteError <= ...
    cfg.tolerances.stage10N1Kernel;
result.probabilityAccepted = probabilityAbsoluteError <= ...
    cfg.tolerances.stage10N1Probability;
result.accepted = spectrum.accepted && result.kernelAccepted && ...
    result.probabilityAccepted;
result.numberOfCollectiveModes = spectrum.numberOfModes;
result.expectedN1Alpha = 0.15;
if spectrum.numberOfModes == 1
    result.actualN1Alpha = spectrum.modes(1).alpha;
else
    result.actualN1Alpha = NaN;
end
result.alphaAbsoluteError = abs( ...
    result.actualN1Alpha - result.expectedN1Alpha);
result.alphaAccepted = spectrum.numberOfModes == 1 && ...
    result.alphaAbsoluteError <= 2e-10;
result.spectrumAccepted = spectrum.accepted;
result.accepted = result.accepted && result.alphaAccepted;
result.usesFrozenReferenceConfiguration = true;
result.status = 'stage10_N1_full_chain_regression_at_E_0p8';
end
