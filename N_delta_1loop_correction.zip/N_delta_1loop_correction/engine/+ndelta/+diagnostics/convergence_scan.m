function result = convergence_scan(cfg, geometry, spectrum, baseline)
%CONVERGENCE_SCAN Stage 10 one-variable source-resolved numerical scans.

narginchk(4, 4);
cfg = ndelta.config.finalize_configuration(cfg);
if ~isstruct(baseline) || ~isscalar(baseline) || ...
        ~isfield(baseline, 'effectiveOptions')
    error('ndelta:diagnostics:MissingBaselineOptions', ...
        ['The Stage 8 baseline must expose the effective integration ' ...
         'options that produced it.']);
end
baseOptions = ndelta.integration.resolve_options( ...
    cfg, baseline.effectiveOptions);
if min(cfg.stage10.mappingPowers) >= baseOptions.q4MapPower || ...
        max(cfg.stage10.mappingPowers) <= baseOptions.q4MapPower
    error('ndelta:diagnostics:MappingScanDoesNotStraddleBaseline', ...
        ['stage10.mappingPowers must include values below and above ' ...
         'the Stage 8 effective q4MapPower.']);
end
baseSource = baseline.sourceMatrix;
baseValues = baseline.values;
orderNames = {'q4Order', 'qPerpOrder', 'collectiveOrder', ...
    'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'};
multipliers = cfg.stage10.orderMultipliers(:).';
orderRecords = repmat(scan_record(), 0, 1);

for parameterIndex = 1:numel(orderNames)
    name = orderNames{parameterIndex};
    resolvedOrders = max(4, round( ...
        baseOptions.(name) .* multipliers));
    if numel(unique(resolvedOrders)) < 2 || ...
            max(resolvedOrders) <= baseOptions.(name)
        error('ndelta:diagnostics:OrderScanCollapsedAfterRounding', ...
            ['The Stage 10 multipliers do not produce a higher ' ...
             'effective %s order than the Stage 8 baseline.'], name);
    end
    for level = 1:numel(multipliers)
        options = baseOptions;
        options.(name) = resolvedOrders(level);
        source = evaluate_affected_source(name, cfg, geometry, ...
            spectrum, baseSource, options);
        orderRecords(end + 1, 1) = make_record( ... %#ok<AGROW>
            name, options.(name), multipliers(level), source, options);
    end
end

jointOptions = baseOptions;
highMultiplier = max(multipliers);
for index = 1:numel(orderNames)
    name = orderNames{index};
    jointOptions.(name) = max(4, round( ...
        baseOptions.(name) .* highMultiplier));
end
joint = ndelta.integration.integrate_g1( ...
    cfg, geometry, spectrum, jointOptions);
jointComparison = comparison(joint.sourceMatrix, baseSource, cfg);

orderComparisons = repmat(comparison_record(), numel(orderNames), 1);
for parameterIndex = 1:numel(orderNames)
    name = orderNames{parameterIndex};
    indices = find(strcmp({orderRecords.parameter}, name));
    [~, highLocal] = max([orderRecords(indices).multiplier]);
    highRecord = orderRecords(indices(highLocal));
    item = comparison(highRecord.sourceMatrix, baseSource, cfg);
    item.parameter = name;
    item.referenceValue = baseOptions.(name);
    item.comparisonValue = highRecord.value;
    orderComparisons(parameterIndex) = item;
end
maximumOrderError = max([ ...
    [orderComparisons.maximumError], jointComparison.maximumError]);

mappingRecords = repmat(scan_record(), 0, 1);
mappingNames = {'q4Scale', 'qPerpTailScale'};
scaleFactors = cfg.stage10.mappingScaleFactors(:).';
for parameterIndex = 1:numel(mappingNames)
    name = mappingNames{parameterIndex};
    for level = 1:numel(scaleFactors)
        options = baseOptions;
        options.(name) = baseOptions.(name) .* scaleFactors(level);
        source = evaluate_affected_source(name, cfg, geometry, ...
            spectrum, baseSource, options);
        mappingRecords(end + 1, 1) = make_record( ... %#ok<AGROW>
            name, options.(name), scaleFactors(level), source, options);
    end
end
mapPowers = cfg.stage10.mappingPowers(:).';
for level = 1:numel(mapPowers)
    options = baseOptions;
    options.q4MapPower = mapPowers(level);
    source = evaluate_affected_source('q4MapPower', cfg, geometry, ...
        spectrum, baseSource, options);
    mappingRecords(end + 1, 1) = make_record( ... %#ok<AGROW>
        'q4MapPower', mapPowers(level), ...
        mapPowers(level) ./ baseOptions.q4MapPower, source, options);
end

mappingComparisons = repmat(comparison_record(), ...
    numel(mappingRecords), 1);
for index = 1:numel(mappingRecords)
    item = comparison(mappingRecords(index).sourceMatrix, baseSource, cfg);
    item.parameter = mappingRecords(index).parameter;
    item.referenceValue = baseOptions.(item.parameter);
    item.comparisonValue = mappingRecords(index).value;
    mappingComparisons(index) = item;
end
maximumMappingError = max([mappingComparisons.maximumError]);

switchFactors = cfg.stage10.endpointSwitchFactors(:).';
endpointRecords = repmat(scan_record(), numel(switchFactors), 1);
for index = 1:numel(switchFactors)
    localCfg = cfg;
    localCfg.integration.endpointTauSwitchRelative = ...
        cfg.integration.endpointTauSwitchRelative .* switchFactors(index);
    localCfg = ndelta.config.finalize_configuration(localCfg);
    integrated = ndelta.integration.integrate_g1( ...
        localCfg, geometry, spectrum, baseOptions);
    endpointRecords(index) = make_record( ...
        'endpointTauSwitchRelative', ...
        localCfg.integration.endpointTauSwitchRelative, ...
        switchFactors(index), integrated.sourceMatrix, baseOptions);
end
endpointComparisons = repmat(comparison_record(), ...
    numel(endpointRecords), 1);
for index = 1:numel(endpointRecords)
    item = comparison(endpointRecords(index).sourceMatrix, ...
        baseSource, cfg);
    item.parameter = endpointRecords(index).parameter;
    item.referenceValue = cfg.integration.endpointTauSwitchRelative;
    item.comparisonValue = endpointRecords(index).value;
    endpointComparisons(index) = item;
end
maximumEndpointSwitchError = max([endpointComparisons.maximumError]);

result = struct();
result.baselineValues = baseValues;
result.baselineSourceMatrix = baseSource;
result.baselineComponentMatrix = baseline.componentMatrix;
result.baseOptions = baseOptions;
result.orderRecords = orderRecords;
result.orderComparisons = orderComparisons;
result.jointHighOrder = struct('options', jointOptions, ...
    'values', joint.values, 'sourceMatrix', joint.sourceMatrix, ...
    'componentMatrix', joint.componentMatrix, ...
    'comparison', jointComparison);
result.mappingRecords = mappingRecords;
result.mappingComparisons = mappingComparisons;
result.endpointSwitchRecords = endpointRecords;
result.endpointSwitchComparisons = endpointComparisons;
result.maximumOrderError = maximumOrderError;
result.maximumMappingError = maximumMappingError;
result.maximumEndpointSwitchError = maximumEndpointSwitchError;
result.orderAccepted = maximumOrderError <= ...
    cfg.tolerances.stage10OrderConvergence;
result.mappingAccepted = maximumMappingError <= ...
    cfg.tolerances.stage10MappingSensitivity;
result.endpointSwitchAccepted = maximumEndpointSwitchError <= ...
    cfg.tolerances.stage10EndpointSwitch;
result.accepted = result.orderAccepted && result.mappingAccepted && ...
    result.endpointSwitchAccepted;
result.status = 'stage10_source_resolved_one_variable_scans';

    function record = make_record(parameter, value, multiplier, source, options)
        record = scan_record();
        record.parameter = parameter;
        record.value = value;
        record.multiplier = multiplier;
        record.values = sum(source, 2).';
        record.sourceMatrix = source;
        record.componentMatrix = source_to_components(source);
        record.effectiveOptions = options;
    end
end

function source = evaluate_affected_source(name, cfg, geometry, ...
        spectrum, baseSource, options)
source = baseSource;
switch name
    case {'q4Order', 'qPerpOrder', 'q4Scale', ...
            'qPerpTailScale', 'q4MapPower'}
        transmission = ndelta.integration.integrate_euclidean( ...
            'T', cfg, geometry, spectrum, options);
        reflection = ndelta.integration.integrate_euclidean( ...
            'R', cfg, geometry, spectrum, options);
        source(:, 1) = [transmission.value; reflection.value];
    case 'collectiveOrder'
        transmission = ndelta.integration.integrate_collective( ...
            'T', cfg, geometry, spectrum, options);
        reflection = ndelta.integration.integrate_collective( ...
            'R', cfg, geometry, spectrum, options);
        source(:, 3) = [transmission.value; reflection.value];
    case {'cutRadialOrder', 'cutAngleOrder', 'endpointOrder'}
        transmission = ndelta.integration.integrate_cut( ...
            'T', cfg, geometry, spectrum, options);
        reflection = ndelta.integration.integrate_cut( ...
            'R', cfg, geometry, spectrum, options);
        source(:, 4) = [transmission.bankContribution; ...
            reflection.bankContribution];
        source(:, 5) = [transmission.endpointContribution; ...
            reflection.endpointContribution];
    otherwise
        error('ndelta:diagnostics:UnknownScanParameter', ...
            'Unsupported Stage 10 scan parameter %s.', name);
end
end

function components = source_to_components(source)
components = [source(:, 1:3), source(:, 4) + source(:, 5)];
end

function item = comparison(candidate, reference, cfg)
floorValue = 1e-8 ./ max(cfg.derived.massScale, realmin);
candidateValues = sum(candidate, 2);
referenceValues = sum(reference, 2);
totalError = symmetric_error(candidateValues, referenceValues, floorValue);
candidateComponents = source_to_components(candidate);
referenceComponents = source_to_components(reference);
componentError = symmetric_error( ...
    candidateComponents, referenceComponents, floorValue);
sourceError = symmetric_error(candidate, reference, floorValue);
item = comparison_record();
item.totalError = totalError;
item.componentError = componentError;
item.sourceError = sourceError;
item.maximumError = max([totalError, componentError, sourceError]);
end

function value = symmetric_error(left, right, floorValue)
denominator = max(floorValue, max(abs(left), abs(right)));
substantial = max(abs(left), abs(right)) > floorValue;
errors = abs(left - right) ./ denominator;
errors(~substantial) = 0;
value = max(errors(:));
end

function record = scan_record()
record = struct('parameter', '', 'value', NaN, 'multiplier', NaN, ...
    'values', complex(zeros(1, 2)), ...
    'sourceMatrix', complex(zeros(2, 5)), ...
    'componentMatrix', complex(zeros(2, 4)), ...
    'effectiveOptions', struct());
end

function record = comparison_record()
record = struct('parameter', '', 'referenceValue', NaN, ...
    'comparisonValue', NaN, 'totalError', Inf, ...
    'componentError', Inf, 'sourceError', Inf, 'maximumError', Inf);
end
