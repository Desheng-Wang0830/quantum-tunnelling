function result = collective_root_scan( ...
        cfg, geometry, scanSamples, rootTolerances)
%COLLECTIVE_ROOT_SCAN Paired convergence scan of the collective spectrum.
%
%   RESULT = COLLECTIVE_ROOT_SCAN(CFG,GEOMETRY,SCANSAMPLES,ROOTTOLERANCES)
%   pairs the requested grid sizes and root tolerances element by element.
%   One scalar input may be expanded to the length of the other input.
%   Every pair is independently finalised before FIND_COLLECTIVE_MODES is
%   called; no derived configuration or spectrum is reused.
%
%   Mode comparisons are identity-aware.  A changed mode count, label set
%   or branch identity is reported as a failed comparison before any mode
%   arrays are indexed.  Thus a missing mode is a diagnostic result, not
%   an indexing error.

narginchk(4, 4);
[scanSamples, rootTolerances] = paired_inputs( ...
    scanSamples, rootTolerances);
numberOfRuns = numel(scanSamples);
runs = repmat(run_record(), numberOfRuns, 1);

for runIndex = 1:numberOfRuns
    trialCfg = cfg;
    trialCfg.collective.scanSamples = scanSamples(runIndex);
    trialCfg.tolerances.collectiveRoot = rootTolerances(runIndex);
    trialCfg = ndelta.config.finalize_configuration(trialCfg);
    spectrum = ndelta.singularity.find_collective_modes( ...
        trialCfg, geometry);
    runs(runIndex) = summarise_run( ...
        runIndex, trialCfg, spectrum);
end

comparisons = repmat(comparison_record(), max(numberOfRuns - 1, 0), 1);
for comparisonIndex = 1:(numberOfRuns - 1)
    comparisons(comparisonIndex) = compare_runs( ...
        runs(1), runs(comparisonIndex + 1));
end

if isempty(comparisons)
    allModeCountsMatch = true;
    allModeLabelsMatch = true;
    allModeIdentitiesMatch = true;
    allNumericallyConsistent = true;
    maximumAlphaRelativeDifference = 0;
    maximumQcritRelativeDifference = 0;
else
    allModeCountsMatch = all([comparisons.modeCountMatches]);
    allModeLabelsMatch = all([comparisons.modeLabelsMatch]);
    allModeIdentitiesMatch = all([comparisons.modeIdentityMatches]);
    allNumericallyConsistent = all([comparisons.numericallyConsistent]);
    maximumAlphaRelativeDifference = max( ...
        [comparisons.maximumAlphaRelativeDifference]);
    maximumQcritRelativeDifference = max( ...
        [comparisons.maximumQcritRelativeDifference]);
end

modeCounts = reshape([runs.modeCount], [], 1);
maximumRootResiduals = reshape([runs.maximumRootResidual], [], 1);
allSpectraAccepted = all([runs.spectrumAccepted]);
allRootResidualsAccepted = all([runs.rootResidualsAccepted]);

result = struct();
result.scanSamples = scanSamples;
result.rootTolerances = rootTolerances;
result.pairedInputs = true;
result.numberOfRuns = numberOfRuns;
result.referenceRunIndex = 1;
result.runs = runs;
result.comparisons = comparisons;
result.modeCounts = modeCounts;
result.labels = {runs.labels}.';
result.alpha = {runs.alpha}.';
result.qcrit = {runs.qcrit}.';
result.rootResiduals = {runs.rootResiduals}.';
result.maximumRootResiduals = maximumRootResiduals;
result.maximumRootResidual = max(maximumRootResiduals);
result.allModeCountsMatch = allModeCountsMatch;
result.allModeLabelsMatch = allModeLabelsMatch;
result.allModeIdentitiesMatch = allModeIdentitiesMatch;
result.modeCountsStable = allModeCountsMatch;
result.modeLabelsStable = allModeLabelsMatch;
result.modeIdentitiesStable = allModeIdentitiesMatch;
result.modeCountStable = allModeCountsMatch;
result.labelsStable = allModeLabelsMatch;
result.allNumericallyConsistent = allNumericallyConsistent;
result.allSpectraAccepted = allSpectraAccepted;
result.allRootResidualsAccepted = allRootResidualsAccepted;
result.maximumAlphaRelativeDifference = ...
    maximumAlphaRelativeDifference;
result.maximumQcritRelativeDifference = ...
    maximumQcritRelativeDifference;
result.maximumRelativeAlphaChange = ...
    maximumAlphaRelativeDifference;
result.maximumRelativeQcritChange = ...
    maximumQcritRelativeDifference;
result.stabilityTolerance = max([runs.stabilityTolerance]);
result.modeIdentityComparisonIsBoundsSafe = true;
result.performsIntegration = false;
result.accepted = allSpectraAccepted && allRootResidualsAccepted && ...
    allModeCountsMatch && allModeLabelsMatch && ...
    allModeIdentitiesMatch && allNumericallyConsistent;
end

function [scanSamples, rootTolerances] = paired_inputs( ...
        scanSamples, rootTolerances)
if ~isnumeric(scanSamples) || isempty(scanSamples) || ...
        ~isvector(scanSamples) || ~isreal(scanSamples) || ...
        any(~isfinite(scanSamples(:))) || ...
        any(scanSamples(:) ~= fix(scanSamples(:))) || ...
        any(scanSamples(:) < 101)
    error('ndelta:diagnostics:InvalidCollectiveScanSamples', ...
        ['scanSamples must be a nonempty vector of finite integers ' ...
         'greater than or equal to 101.']);
end
if ~isnumeric(rootTolerances) || isempty(rootTolerances) || ...
        ~isvector(rootTolerances) || ~isreal(rootTolerances) || ...
        any(~isfinite(rootTolerances(:))) || ...
        any(rootTolerances(:) <= 0)
    error('ndelta:diagnostics:InvalidCollectiveRootTolerances', ...
        'rootTolerances must be a nonempty vector of positive finite values.');
end
scanSamples = scanSamples(:);
rootTolerances = rootTolerances(:);
if isscalar(scanSamples) && ~isscalar(rootTolerances)
    scanSamples = repmat(scanSamples, size(rootTolerances));
elseif isscalar(rootTolerances) && ~isscalar(scanSamples)
    rootTolerances = repmat(rootTolerances, size(scanSamples));
elseif numel(scanSamples) ~= numel(rootTolerances)
    error('ndelta:diagnostics:CollectiveRootScanPairCountMismatch', ...
        ['scanSamples and rootTolerances must have equal lengths, ' ...
         'unless one input is scalar.']);
end
end

function record = summarise_run(runIndex, cfg, spectrum)
numberOfModes = spectrum.numberOfModes;
labels = cell(1, numberOfModes);
identities = cell(1, numberOfModes);
alpha = zeros(1, numberOfModes);
qcrit = zeros(1, numberOfModes);
rootResiduals = zeros(1, numberOfModes);
for modeIndex = 1:numberOfModes
    mode = spectrum.modes(modeIndex);
    labels{modeIndex} = normalise_label(mode.label);
    identities{modeIndex} = mode_identity(mode);
    alpha(modeIndex) = mode.alpha;
    qcrit(modeIndex) = mode.qPerpCritical;
    rootResiduals(modeIndex) = mode.rootResidual;
end
record = run_record();
record.index = runIndex;
record.scanSamples = cfg.collective.scanSamples;
record.rootTolerance = cfg.tolerances.collectiveRoot;
record.collectiveResidualTolerance = ...
    cfg.tolerances.collectiveResidual;
record.stabilityTolerance = cfg.tolerances.stage10RootStability;
record.modeCount = numberOfModes;
record.numberOfModes = numberOfModes;
record.labels = labels;
record.modeIdentities = identities;
record.alpha = alpha;
record.qcrit = qcrit;
record.qPerpCritical = qcrit;
record.rootResiduals = rootResiduals;
record.maximumRootResidual = spectrum.maximumRootResidual;
record.rootResidualsAccepted = spectrum.maximumRootResidual <= ...
    cfg.tolerances.collectiveResidual;
record.spectrumAccepted = spectrum.accepted;
record.configurationFingerprint = spectrum.configurationFingerprint;
end

function comparison = compare_runs(reference, candidate)
comparison = comparison_record();
comparison.referenceRunIndex = reference.index;
comparison.candidateRunIndex = candidate.index;
comparison.modeCountMatches = ...
    reference.modeCount == candidate.modeCount;
if ~comparison.modeCountMatches
    comparison.failureReason = 'mode_count_changed';
    return;
end

comparison.modeLabelsMatch = multiset_equal( ...
    reference.labels, candidate.labels);
if ~comparison.modeLabelsMatch
    comparison.failureReason = 'mode_labels_changed';
    return;
end

[identityMap, identitiesMatch] = identity_map( ...
    reference.modeIdentities, candidate.modeIdentities);
comparison.modeIdentityMatches = identitiesMatch;
comparison.identityMap = identityMap;
if ~identitiesMatch
    comparison.failureReason = 'mode_identity_changed';
    return;
end

if reference.modeCount == 0
    alphaDifference = zeros(1, 0);
    alphaRelativeDifference = zeros(1, 0);
    qcritDifference = zeros(1, 0);
    qcritRelativeDifference = zeros(1, 0);
    rootResidualDifference = zeros(1, 0);
else
    candidateAlpha = candidate.alpha(identityMap);
    candidateQcrit = candidate.qcrit(identityMap);
    candidateResiduals = candidate.rootResiduals(identityMap);
    alphaDifference = abs(reference.alpha - candidateAlpha);
    qcritDifference = abs(reference.qcrit - candidateQcrit);
    rootResidualDifference = abs( ...
        reference.rootResiduals - candidateResiduals);
    alphaScale = max(max(abs(reference.alpha), ...
        abs(candidateAlpha)), realmin);
    qcritScale = max(max(abs(reference.qcrit), ...
        abs(candidateQcrit)), realmin);
    alphaRelativeDifference = alphaDifference ./ alphaScale;
    qcritRelativeDifference = qcritDifference ./ qcritScale;
end

comparison.alphaAbsoluteDifference = alphaDifference;
comparison.alphaRelativeDifference = alphaRelativeDifference;
comparison.qcritAbsoluteDifference = qcritDifference;
comparison.qcritRelativeDifference = qcritRelativeDifference;
comparison.rootResidualAbsoluteDifference = rootResidualDifference;
comparison.maximumAlphaRelativeDifference = ...
    maximum_or_zero(alphaRelativeDifference);
comparison.maximumQcritRelativeDifference = ...
    maximum_or_zero(qcritRelativeDifference);
comparison.maximumRootResidualDifference = ...
    maximum_or_zero(rootResidualDifference);
comparison.rootSearchToleranceEnvelope = max(32 .* eps, ...
    8 .* max(reference.rootTolerance, candidate.rootTolerance));
comparison.comparisonTolerance = max( ...
    reference.stabilityTolerance, candidate.stabilityTolerance);
comparison.rootResidualsAccepted = ...
    reference.rootResidualsAccepted && candidate.rootResidualsAccepted;
comparison.numericallyConsistent = comparison.rootResidualsAccepted && ...
    comparison.maximumAlphaRelativeDifference <= ...
        comparison.comparisonTolerance && ...
    comparison.maximumQcritRelativeDifference <= ...
        comparison.comparisonTolerance;
comparison.accepted = comparison.modeCountMatches && ...
    comparison.modeLabelsMatch && comparison.modeIdentityMatches && ...
    comparison.numericallyConsistent;
if comparison.accepted
    comparison.failureReason = '';
elseif ~comparison.rootResidualsAccepted
    comparison.failureReason = 'root_residual_tolerance_failed';
else
    comparison.failureReason = 'root_values_not_converged';
end
end

function [mapping, matches] = identity_map(reference, candidate)
numberOfModes = numel(reference);
mapping = zeros(1, numberOfModes);
used = false(1, numel(candidate));
matches = numel(candidate) == numberOfModes;
if ~matches
    return;
end
for index = 1:numberOfModes
    candidates = find(~used & strcmp(reference{index}, candidate));
    if isempty(candidates)
        matches = false;
        mapping = zeros(1, 0);
        return;
    end
    selected = candidates(1);
    mapping(index) = selected;
    used(selected) = true;
end
matches = all(used);
end

function tf = multiset_equal(left, right)
tf = numel(left) == numel(right) && ...
    isequal(sort(left(:)), sort(right(:)));
end

function identity = mode_identity(mode)
label = normalise_label(mode.label);
if isfield(mode, 'branchIndices')
    branches = mode.branchIndices(:).';
elseif isfield(mode, 'branchIndex')
    branches = mode.branchIndex;
else
    branches = zeros(1, 0);
end
branchText = sprintf('%d,', branches);
identity = sprintf('%s|branches:%s', label, branchText);
end

function label = normalise_label(value)
if ischar(value)
    label = value;
elseif isstring(value) && isscalar(value)
    label = char(value);
else
    error('ndelta:diagnostics:InvalidCollectiveModeLabel', ...
        'Every collective mode label must be text.');
end
end

function value = maximum_or_zero(values)
if isempty(values)
    value = 0;
else
    value = max(values);
end
end

function record = run_record()
record = struct('index', 0, 'scanSamples', 0, ...
    'rootTolerance', NaN, 'collectiveResidualTolerance', NaN, ...
    'stabilityTolerance', NaN, ...
    'modeCount', 0, 'numberOfModes', 0, ...
    'labels', {cell(1, 0)}, 'modeIdentities', {cell(1, 0)}, ...
    'alpha', zeros(1, 0), 'qcrit', zeros(1, 0), ...
    'qPerpCritical', zeros(1, 0), ...
    'rootResiduals', zeros(1, 0), 'maximumRootResidual', Inf, ...
    'rootResidualsAccepted', false, 'spectrumAccepted', false, ...
    'configurationFingerprint', struct());
end

function comparison = comparison_record()
comparison = struct('referenceRunIndex', 0, ...
    'candidateRunIndex', 0, 'modeCountMatches', false, ...
    'modeLabelsMatch', false, 'modeIdentityMatches', false, ...
    'identityMap', zeros(1, 0), ...
    'alphaAbsoluteDifference', zeros(1, 0), ...
    'alphaRelativeDifference', zeros(1, 0), ...
    'qcritAbsoluteDifference', zeros(1, 0), ...
    'qcritRelativeDifference', zeros(1, 0), ...
    'rootResidualAbsoluteDifference', zeros(1, 0), ...
    'maximumAlphaRelativeDifference', Inf, ...
    'maximumQcritRelativeDifference', Inf, ...
    'maximumRootResidualDifference', Inf, ...
    'rootSearchToleranceEnvelope', NaN, 'comparisonTolerance', NaN, ...
    'rootResidualsAccepted', false, ...
    'numericallyConsistent', false, 'accepted', false, ...
    'failureReason', 'comparison_not_evaluated');
end
