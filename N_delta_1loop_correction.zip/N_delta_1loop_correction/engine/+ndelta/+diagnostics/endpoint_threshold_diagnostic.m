function result = endpoint_threshold_diagnostic(cfg, relativeOffsets)
%ENDPOINT_THRESHOLD_DIAGNOSTIC Resolve the symmetric N=2 zero-mode onset.
%
%   RESULT = ENDPOINT_THRESHOLD_DIAGNOSTIC(CFG,RELATIVEOFFSETS) replaces
%   the barrier data by two equal wells g_1=g_2=-0.2 at separations
%   b=b_c*(1+RELATIVEOFFSETS), where b_c=10.  The default offsets are
%   [-1e-4,0,+1e-4].  Below threshold there must be one finite collective
%   mode; at threshold K=0 must be classified as a rejected compound
%   branch endpoint; above threshold there must be two finite modes.
%
%   This routine is diagnostic only.  It never calls a Stage 8 integrator.

narginchk(1, 2);
if nargin < 2
    relativeOffsets = [-1e-4, 0, 1e-4];
end
if ~isnumeric(relativeOffsets) || isempty(relativeOffsets) || ...
        ~isvector(relativeOffsets) || ~isreal(relativeOffsets) || ...
        any(~isfinite(relativeOffsets(:))) || ...
        any(relativeOffsets(:) <= -1)
    error('ndelta:diagnostics:InvalidThresholdOffsets', ...
        ['relativeOffsets must be a nonempty finite real vector with ' ...
         'every entry greater than -1.']);
end

cfg = ndelta.config.finalize_configuration(cfg);
canonicalCfg = run_stage0(false);
canonicalCfg.referenceEnergy = 0.30;
canonicalCfg.model.mphi = 0.2;
canonicalCfg.model.mPhi = 1.4;
canonicalCfg.model.mu = 0.1;
canonicalCfg.sheet.epsilon = 1e-9;
canonicalCfg.collective.scanSamples = 801;
canonicalCfg.tolerances.distanceMerge = 1e-12;
canonicalCfg.tolerances.collectiveRoot = 5e-11;
canonicalCfg.tolerances.collectiveResidual = 2e-8;
canonicalCfg.tolerances.collectiveDuplicate = 2e-12;
canonicalCfg.tolerances.zeroEnergy = 2e-9;
canonicalCfg.execution.rejectUnstableCollective = true;
canonicalCfg = ndelta.config.finalize_configuration(canonicalCfg);
relativeOffsets = relativeOffsets(:);
wellStrength = -0.2;
criticalSeparation = 2 ./ abs(wellStrength);
numberOfSamples = numel(relativeOffsets);
samples = repmat(sample_record(), numberOfSamples, 1);

for sampleIndex = 1:numberOfSamples
    relativeOffset = relativeOffsets(sampleIndex);
    separation = criticalSeparation .* (1 + relativeOffset);
    trialCfg = canonicalCfg;
    trialCfg.barriers.positions = [-separation ./ 2, separation ./ 2];
    trialCfg.barriers.strengths = [wellStrength, wellStrength];
    trialCfg = ndelta.config.finalize_configuration(trialCfg);
    geometry = ndelta.geometry.build_geometry( ...
        trialCfg.barriers.positions, trialCfg.tolerances.distanceMerge);
    zeroEnergy = ndelta.singularity.zero_energy_diagnostic( ...
        geometry, trialCfg.barriers.strengths, ...
        trialCfg.tolerances.zeroEnergy);
    spectrum = ndelta.singularity.find_collective_modes( ...
        trialCfg, geometry);
    samples(sampleIndex) = summarise_sample(sampleIndex, ...
        relativeOffset, separation, criticalSeparation, ...
        trialCfg, zeroEnergy, spectrum);
end

belowMask = relativeOffsets < 0;
thresholdMask = relativeOffsets == 0;
aboveMask = relativeOffsets > 0;
hasBelowSample = any(belowMask);
hasThresholdSample = any(thresholdMask);
hasAboveSample = any(aboveMask);
regimeCoverageComplete = hasBelowSample && ...
    hasThresholdSample && hasAboveSample;
belowAccepted = hasBelowSample && all([samples(belowMask).passed]);
thresholdAccepted = hasThresholdSample && ...
    all([samples(thresholdMask).passed]);
aboveAccepted = hasAboveSample && all([samples(aboveMask).passed]);

result = struct();
result.wellStrengths = [wellStrength, wellStrength];
result.criticalSeparation = criticalSeparation;
result.criticalDistance = criticalSeparation;
result.bCritical = criticalSeparation;
result.relativeOffsets = relativeOffsets;
result.separations = reshape([samples.separation], [], 1);
result.samples = samples;
result.below = samples(belowMask);
result.threshold = samples(thresholdMask);
result.above = samples(aboveMask);
result.modeCounts = reshape([samples.modeCount], [], 1);
result.labels = {samples.labels}.';
result.alpha = {samples.alpha}.';
result.qcrit = {samples.qcrit}.';
result.rootResiduals = {samples.rootResiduals}.';
result.hasBelowSample = hasBelowSample;
result.hasThresholdSample = hasThresholdSample;
result.hasAboveSample = hasAboveSample;
result.regimeCoverageComplete = regimeCoverageComplete;
result.belowAccepted = belowAccepted;
result.thresholdAccepted = thresholdAccepted;
result.aboveAccepted = aboveAccepted;
result.thresholdIsCompoundEndpoint = hasThresholdSample && all( ...
    [samples(thresholdMask).endpointClassificationPassed]);
result.thresholdRejected = hasThresholdSample && all( ...
    ~[samples(thresholdMask).spectrumAccepted]);
result.performsStage8Integration = false;
result.callsStage8 = false;
result.diagnosticOnly = true;
result.usesFrozenReferenceConfiguration = true;
result.referenceConfiguration = canonicalCfg;
result.accepted = regimeCoverageComplete && belowAccepted && ...
    thresholdAccepted && aboveAccepted;
end

function sample = summarise_sample(sampleIndex, relativeOffset, ...
        separation, criticalSeparation, cfg, zeroEnergy, spectrum)
numberOfModes = spectrum.numberOfModes;
labels = cell(1, numberOfModes);
alpha = zeros(1, numberOfModes);
qcrit = zeros(1, numberOfModes);
rootResiduals = zeros(1, numberOfModes);
for modeIndex = 1:numberOfModes
    mode = spectrum.modes(modeIndex);
    labels{modeIndex} = normalise_label(mode.label);
    alpha(modeIndex) = mode.alpha;
    qcrit(modeIndex) = mode.qPerpCritical;
    rootResiduals(modeIndex) = mode.rootResidual;
end

if relativeOffset < 0
    regime = 'below_threshold';
    expectedModeCount = 1;
    modeCountPassed = numberOfModes == expectedModeCount;
    endpointClassificationPassed = ...
        ~zeroEnergy.isZeroEnergyResonance;
    rejectionRulePassed = spectrum.accepted;
elseif relativeOffset > 0
    regime = 'above_threshold';
    expectedModeCount = 2;
    modeCountPassed = numberOfModes == expectedModeCount;
    endpointClassificationPassed = ...
        ~zeroEnergy.isZeroEnergyResonance;
    rejectionRulePassed = spectrum.accepted;
else
    regime = 'critical_compound_endpoint';
    % Once the endpoint diagnostic fires, FIND_COLLECTIVE_MODES is
    % rejected as an isolated-pole spectrum.  Its finite-alpha list is
    % retained for audit but is deliberately not assigned a required
    % count: roundoff-close samples of the K=0 branch are not physical
    % isolated modes and must not decide this threshold gate.
    expectedModeCount = NaN;
    modeCountPassed = true;
    endpointClassificationPassed = ...
        zeroEnergy.isZeroEnergyResonance && strcmp( ...
        zeroEnergy.classification, ...
        'compound_branch_endpoint_zero_energy_collective_threshold');
    rejectionRulePassed = ~spectrum.accepted;
end
isolatedRootResidualsPassed = spectrum.maximumRootResidual <= ...
    cfg.tolerances.collectiveResidual;
% At the exact compound endpoint the isolated-pole spectrum is rejected
% by construction.  A roundoff-scale K~0 candidate is audit data only and
% must not become a second acceptance gate for that rejected spectrum.
rootResidualGateApplied = relativeOffset ~= 0;
rootResidualsPassed = ~rootResidualGateApplied || ...
    isolatedRootResidualsPassed;

sample = sample_record();
sample.index = sampleIndex;
sample.relativeOffset = relativeOffset;
sample.separation = separation;
sample.criticalSeparation = criticalSeparation;
sample.positions = cfg.barriers.positions;
sample.strengths = cfg.barriers.strengths;
sample.regime = regime;
sample.expectedModeCount = expectedModeCount;
sample.modeCount = numberOfModes;
sample.numberOfModes = numberOfModes;
sample.labels = labels;
sample.modeLabels = labels;
sample.alpha = alpha;
sample.qcrit = qcrit;
sample.qPerpCritical = qcrit;
sample.rootResiduals = rootResiduals;
sample.maximumRootResidual = spectrum.maximumRootResidual;
sample.isolatedRootResidualsPassed = isolatedRootResidualsPassed;
sample.rootResidualGateApplied = rootResidualGateApplied;
sample.rootResidualsPassed = rootResidualsPassed;
sample.zeroEnergy = zeroEnergy;
sample.isZeroEnergyResonance = zeroEnergy.isZeroEnergyResonance;
sample.zeroEnergyClassification = zeroEnergy.classification;
sample.spectrumAccepted = spectrum.accepted;
sample.modeCountPassed = modeCountPassed;
sample.endpointClassificationPassed = endpointClassificationPassed;
sample.rejectionRulePassed = rejectionRulePassed;
sample.passed = modeCountPassed && endpointClassificationPassed && ...
    rejectionRulePassed && rootResidualsPassed;
if sample.passed
    sample.failureReason = '';
elseif ~modeCountPassed
    sample.failureReason = 'unexpected_finite_mode_count';
elseif ~endpointClassificationPassed
    sample.failureReason = 'zero_energy_endpoint_classification_failed';
elseif ~rejectionRulePassed
    sample.failureReason = 'threshold_acceptance_rule_failed';
else
    sample.failureReason = 'collective_root_residual_failed';
end
end

function label = normalise_label(value)
if ischar(value)
    label = value;
elseif isstring(value) && isscalar(value)
    label = char(value);
else
    error('ndelta:diagnostics:InvalidCollectiveModeLabel', ...
        'Every collective mode label must be text.');
end
end

function sample = sample_record()
sample = struct('index', 0, 'relativeOffset', NaN, ...
    'separation', NaN, 'criticalSeparation', 10, ...
    'positions', zeros(1, 0), 'strengths', zeros(1, 0), ...
    'regime', '', 'expectedModeCount', 0, ...
    'modeCount', 0, 'numberOfModes', 0, ...
    'labels', {cell(1, 0)}, 'modeLabels', {cell(1, 0)}, ...
    'alpha', zeros(1, 0), ...
    'qcrit', zeros(1, 0), 'qPerpCritical', zeros(1, 0), ...
    'rootResiduals', zeros(1, 0), 'maximumRootResidual', Inf, ...
    'isolatedRootResidualsPassed', false, ...
    'rootResidualGateApplied', true, ...
    'rootResidualsPassed', false, 'zeroEnergy', struct(), ...
    'isZeroEnergyResonance', false, ...
    'zeroEnergyClassification', '', 'spectrumAccepted', false, ...
    'modeCountPassed', false, ...
    'endpointClassificationPassed', false, ...
    'rejectionRulePassed', false, 'passed', false, ...
    'failureReason', 'sample_not_evaluated');
end
