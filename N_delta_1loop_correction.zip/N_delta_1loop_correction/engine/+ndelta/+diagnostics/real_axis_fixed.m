function result = real_axis_fixed( ...
        qPerp, channelInput, cfg, geometry, spectrum, options)
%REAL_AXIS_FIXED Independent fixed-qPerp raw real-q0 diagnostic.
%
%   RESULT = REAL_AXIS_FIXED(QPERP,CHANNEL,CFG,GEOMETRY,SPECTRUM,OPTIONS)
%   integrates the finite-epsilon physical-sheet Stage 6 pointwise kernel
%   directly on -Inf<q0<Inf,
%
%       integral dq0/(2*pi) F_code(q0),
%       F_code = -F_Stage6_raw.
%
%   This routine never reads modified-Wick residues, cut-bank jumps or an
%   endpoint-keyhole value.  Collective modes and the reflection
%   kappaI=+/-P attachment locations are used only to refine the real-axis
%   quadrature grid.  Every finite interval and both rationally mapped
%   tails use an open Gauss-Legendre rule.

narginchk(5, 6);
if nargin < 6
    options = struct();
end
cfg = ndelta.config.finalize_configuration(cfg);
validateattributes(qPerp, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, ...
    mfilename, 'qPerp');
channel = ndelta.g1.normalise_channel(channelInput);
geometry = ndelta.g1.resolve_pair_geometry(cfg, geometry);
validate_spectrum(spectrum, cfg);
[order, tailScale, windowFactors] = parse_options(options, cfg);

landmarks = build_landmarks(qPerp, channel, cfg, spectrum, ...
    windowFactors);
finiteEdges = build_finite_edges(landmarks);
segmentEdges = [-Inf, finiteEdges, Inf];
numberOfSegments = numel(segmentEdges) - 1;
segmentValuesBeforeMeasure = complex(zeros(1, numberOfSegments));
segmentValues = complex(zeros(1, numberOfSegments));
segmentKinds = cell(1, numberOfSegments);
for segment = 1:numberOfSegments
    segmentKinds{segment} = classify_segment( ...
        segmentEdges(segment), segmentEdges(segment + 1));
end

factorFlags = exact_factor_flags();
result = base_result(qPerp, channel, order, tailScale, ...
    windowFactors, landmarks, segmentEdges, segmentKinds, ...
    segmentValuesBeforeMeasure, segmentValues, factorFlags);

% The interaction-only kernel is exactly zero when every centre is
% inactive.  Return before creating roots or evaluating any longitudinal
% kernel, so irrelevant formal singularities cannot contaminate the zero.
if cfg.derived.numberOfActiveCentres == 0
    result.allInactiveExactZero = true;
    result.status = 'interaction_only_exact_zero_at_all_inactive';
    return;
end

[unitNodes, unitWeights] = ndelta.numerics.unit_gauss_rule(order);
maximumTauResidual = 0;
numberOfPointEvaluations = 0;
for segment = 1:numberOfSegments
    lower = segmentEdges(segment);
    upper = segmentEdges(segment + 1);
    [q0Nodes, jacobian] = map_segment( ...
        unitNodes, lower, upper, tailScale);
    contribution = complex(0);
    for node = 1:numel(q0Nodes)
        roots = ndelta.sheet.physical_roots( ...
            q0Nodes(node), qPerp, cfg.referenceEnergy, ...
            cfg.model, cfg.sheet.epsilon);
        [rawStage6, details] = ...
            ndelta.g1.contour_pair_contraction_from_roots( ...
            roots.omega, roots.kappaI, cfg.derived.P, channel, ...
            geometry, cfg.barriers.strengths, cfg);
        % The endpoint-stable point solver above still returns the raw
        % Stage 6 contraction.  It supplies no contour residue, cut or
        % endpoint value.  Apply the vertex-reduced minus sign once here.
        codeValue = -rawStage6;
        contribution = contribution + unitWeights(node) .* ...
            jacobian(node) .* codeValue;
        maximumTauResidual = max(maximumTauResidual, ...
            details.tauDiagnostics.normalisedEquationResidual);
        numberOfPointEvaluations = numberOfPointEvaluations + 1;
    end
    segmentValuesBeforeMeasure(segment) = contribution;
    segmentValues(segment) = contribution ./ (2 .* pi);
end

valueBeforeMeasure = sum(segmentValuesBeforeMeasure);
value = sum(segmentValues);
result.value = complex(real(value), imag(value));
result.valueBeforeQ0Measure = complex( ...
    real(valueBeforeMeasure), imag(valueBeforeMeasure));
result.segmentValuesBeforeMeasure = segmentValuesBeforeMeasure;
result.segmentValues = segmentValues;
result.maxTauResidual = maximumTauResidual;
result.maximumTauEquationResidual = maximumTauResidual;
result.numberOfPointEvaluations = numberOfPointEvaluations;
result.numberOfPairEvaluations = numberOfPointEvaluations;
result.segmentClosureResidual = abs(result.value - ...
    sum(result.segmentValues)) ./ (1 + abs(result.value));
result.status = 'fixed_qperp_independent_raw_real_axis_integral';
end

function result = base_result(qPerp, channel, order, tailScale, ...
        windowFactors, landmarks, segmentEdges, segmentKinds, ...
        segmentValuesBeforeMeasure, segmentValues, factorFlags)
result = struct();
result.value = complex(0);
result.valueBeforeQ0Measure = complex(0);
result.qPerp = qPerp;
result.channel = channel;
result.order = order;
result.tailScale = tailScale;
result.windowFactors = windowFactors;
result.segmentEdges = segmentEdges;
result.segmentValues = segmentValues;
result.segmentValuesBeforeMeasure = segmentValuesBeforeMeasure;
result.segmentKinds = segmentKinds;
result.landmarks = landmarks;
if isempty(landmarks)
    result.landmarkQ0 = complex(zeros(1, 0));
    result.landmarkRealParts = zeros(1, 0);
    result.landmarkImaginaryWidths = zeros(1, 0);
else
    result.landmarkQ0 = [landmarks.q0];
    result.landmarkRealParts = [landmarks.realPart];
    result.landmarkImaginaryWidths = [landmarks.imaginaryWidth];
end
result.maxTauResidual = 0;
result.maximumTauEquationResidual = 0;
result.numberOfPointEvaluations = 0;
result.numberOfPairEvaluations = 0;
result.numberOfSegments = numel(segmentValues);
result.segmentClosureResidual = 0;
result.factorFlags = factorFlags;
result.exactFactorFlags = factorFlags;
result.includesQ0Measure = true;
result.includesQPerpMeasure = false;
result.includesMuSquared = false;
result.includesLSZ = false;
result.includesOneOverTwoP = false;
result.muIndependent = true;
result.massDimension = -3;
result.performsQ0Integration = true;
result.performsQPerpIntegration = false;
result.kernelConvention = 'F_code=-F_Stage6_raw';
result.q0MeasureConvention = 'dq0/(2*pi)';
result.tailMapping = ...
    'q0=edge+/-tailScale*t/(1-t), t in (0,1)';
result.pointwiseRawEvaluator = ...
    'ndelta.g1.contour_pair_contraction_from_roots';
result.pointwiseEvaluatorReturnsRawStage6 = true;
result.endpointStableSolveIsPointwiseOnly = true;
result.usesModifiedWickRotation = false;
result.usesMWRSourceValues = false;
result.usesCollectiveResidueValues = false;
result.usesCutBankValues = false;
result.usesEndpointKeyholeValues = false;
result.collectiveModesUsedOnlyAsGridLandmarks = true;
result.reflectionAttachmentsUsedOnlyAsGridLandmarks = channel == 'R';
result.allInactiveExactZero = false;
result.status = 'not_evaluated';
end

function flags = exact_factor_flags()
flags = struct();
flags.stage6RawMultiplicativeFactor = -1;
flags.q0MeasureMultiplicativeFactor = 1 ./ (2 .* pi);
flags.negativeStage6RawAppliedExactlyOnce = true;
flags.q0OneOverTwoPiAppliedExactlyOnce = true;
flags.qPerpMeasureApplied = false;
flags.muSquaredApplied = false;
flags.LSZApplied = false;
flags.oneOverTwoPApplied = false;
flags.modifiedWickJacobianApplied = false;
flags.residueFactorApplied = false;
flags.cutJumpFactorApplied = false;
flags.endpointKeyholeFactorApplied = false;
end

function landmarks = build_landmarks( ...
        qPerp, channel, cfg, spectrum, windowFactors)
points = ndelta.sheet.branch_points( ...
    qPerp, cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
landmarks = empty_landmarks();
landmarks(end + 1) = landmark_record( ...
    'free_branch', 'omega_left', 'left', points.omega.left, 0, ...
    windowFactors); %#ok<AGROW>
landmarks(end + 1) = landmark_record( ...
    'free_branch', 'omega_right', 'right', points.omega.right, 0, ...
    windowFactors); %#ok<AGROW>
landmarks(end + 1) = landmark_record( ...
    'free_branch', 'kappaI_left', 'left', points.kappaI.left, 0, ...
    windowFactors); %#ok<AGROW>
landmarks(end + 1) = landmark_record( ...
    'free_branch', 'kappaI_right', 'right', points.kappaI.right, 0, ...
    windowFactors); %#ok<AGROW>

E = cfg.referenceEnergy;
Ephi = hypot(qPerp, cfg.model.mphi);
for index = 1:numel(spectrum.modes)
    alpha = spectrum.modes(index).alpha;
    offset = sqrt(Ephi.^2 - alpha.^2 - 1i .* cfg.sheet.epsilon);
    landmarks(end + 1) = landmark_record( ...
        'collective_mode_grid_only', ...
        sprintf('collective_%d_left', index), 'left', ...
        E - offset, index, windowFactors); %#ok<AGROW>
    landmarks(end + 1) = landmark_record( ...
        'collective_mode_grid_only', ...
        sprintf('collective_%d_right', index), 'right', ...
        E + offset, index, windowFactors); %#ok<AGROW>
end

if channel == 'R'
    attachmentOffset = sqrt(Ephi.^2 + cfg.derived.P.^2 ...
        - 1i .* cfg.sheet.epsilon);
    landmarks(end + 1) = landmark_record( ...
        'reflection_kappaI_attachment_grid_only', ...
        'reflection_kappaI_attachment_left', 'left', ...
        E - attachmentOffset, 0, windowFactors); %#ok<AGROW>
    landmarks(end + 1) = landmark_record( ...
        'reflection_kappaI_attachment_grid_only', ...
        'reflection_kappaI_attachment_right', 'right', ...
        E + attachmentOffset, 0, windowFactors); %#ok<AGROW>
end
end

function item = landmark_record( ...
        source, label, side, q0, modeIndex, windowFactors)
width = abs(imag(q0));
centre = real(q0);
windowEdges = centre + width .* windowFactors;
item = struct();
item.source = source;
item.label = label;
item.side = side;
item.q0 = q0;
item.realPart = centre;
item.imaginaryWidth = width;
item.modeIndex = modeIndex;
item.windowFactors = windowFactors;
item.windowEdges = windowEdges;
item.centreIsSegmentEdge = true;
item.usedAsGridOnly = true;
item.residueEvaluated = false;
end

function landmarks = empty_landmarks()
template = struct('source', '', 'label', '', 'side', '', ...
    'q0', complex(0), 'realPart', 0, 'imaginaryWidth', 0, ...
    'modeIndex', 0, 'windowFactors', zeros(1, 0), ...
    'windowEdges', zeros(1, 0), 'centreIsSegmentEdge', true, ...
    'usedAsGridOnly', true, 'residueEvaluated', false);
landmarks = repmat(template, 0, 1);
end

function finiteEdges = build_finite_edges(landmarks)
finiteEdges = zeros(1, 0);
for index = 1:numel(landmarks)
    finiteEdges = [finiteEdges, landmarks(index).realPart, ...
        landmarks(index).windowEdges]; %#ok<AGROW>
end
finiteEdges = finiteEdges(isfinite(finiteEdges));
finiteEdges = unique(sort(finiteEdges));
if numel(finiteEdges) < 2
    error('ndelta:diagnostics:InsufficientRealAxisEdges', ...
        'The finite-epsilon landmark windows did not define an interval.');
end
end

function kind = classify_segment(lower, upper)
if isinf(lower)
    kind = 'left_rational_tail';
elseif isinf(upper)
    kind = 'right_rational_tail';
else
    kind = 'finite_landmark_interval';
end
end

function [q0, jacobian] = map_segment(t, lower, upper, tailScale)
if isinf(lower) && isfinite(upper)
    ratio = t ./ (1 - t);
    q0 = upper - tailScale .* ratio;
    jacobian = tailScale ./ (1 - t).^2;
elseif isfinite(lower) && isinf(upper)
    ratio = t ./ (1 - t);
    q0 = lower + tailScale .* ratio;
    jacobian = tailScale ./ (1 - t).^2;
elseif isfinite(lower) && isfinite(upper) && upper > lower
    q0 = lower + (upper - lower) .* t;
    jacobian = (upper - lower) .* ones(size(t));
else
    error('ndelta:diagnostics:InvalidRealAxisSegment', ...
        'Real-axis segment edges must be strictly ordered.');
end
end

function [order, tailScale, windowFactors] = parse_options(options, cfg)
if ~isstruct(options) || ~isscalar(options)
    error('ndelta:diagnostics:InvalidRealAxisOptions', ...
        'options must be a scalar structure.');
end
knownNames = {'order', 'tailScale', 'windowFactors'};
unknownNames = setdiff(fieldnames(options), knownNames);
if ~isempty(unknownNames)
    error('ndelta:diagnostics:UnknownRealAxisOption', ...
        'Unknown real-axis option(s): %s.', strjoin(unknownNames, ', '));
end
order = option_value(options, 'order', cfg.integration.q4Order);
tailScale = option_value(options, 'tailScale', cfg.integration.q4Scale);
windowFactors = option_value(options, 'windowFactors', [1, 4, 16, 64]);
validateattributes(order, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'options.order');
validateattributes(tailScale, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'options.tailScale');
if ~isnumeric(windowFactors) || isempty(windowFactors) || ...
        ~isvector(windowFactors) || ~isreal(windowFactors) || ...
        any(~isfinite(windowFactors(:))) || ...
        ~any(windowFactors(:) ~= 0)
    error('ndelta:diagnostics:InvalidWindowFactors', ...
        ['options.windowFactors must contain at least one finite ' ...
         'nonzero real factor.']);
end
% Accept either the compact magnitude convention [1,4,16,64] or an
% explicitly signed list such as [-64,...,0,...,64].  Freeze a symmetric
% signed set including zero, so the real landmark itself is an open-rule
% segment edge and is never sampled by the Gauss nodes.
magnitudes = unique(sort(abs(windowFactors(windowFactors ~= 0))));
magnitudes = magnitudes(:).';
windowFactors = [-fliplr(magnitudes), 0, magnitudes];
end

function value = option_value(options, name, defaultValue)
if isfield(options, name)
    value = options.(name);
else
    value = defaultValue;
end
end

function validate_spectrum(spectrum, cfg)
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~all(isfield(spectrum, {'modes', 'configurationFingerprint', ...
        'solverFingerprint'})) || ...
        ~isstruct(spectrum.modes)
    error('ndelta:diagnostics:InvalidCollectiveSpectrum', ...
        ['spectrum must be the scalar structure returned by ' ...
         'ndelta.singularity.find_collective_modes.']);
end
ndelta.config.assert_physics_fingerprint( ...
    spectrum.configurationFingerprint, cfg, ...
    'ndelta:diagnostics:SpectrumConfigurationMismatch');
if ~isequaln(spectrum.solverFingerprint, ...
        ndelta.config.spectrum_solver_fingerprint(cfg))
    error('ndelta:diagnostics:SpectrumSolverConfigurationMismatch', ...
        'spectrum was produced with different collective solver settings.');
end
for index = 1:numel(spectrum.modes)
    if ~isfield(spectrum.modes(index), 'alpha') || ...
            ~isnumeric(spectrum.modes(index).alpha) || ...
            ~isscalar(spectrum.modes(index).alpha) || ...
            ~isreal(spectrum.modes(index).alpha) || ...
            ~isfinite(spectrum.modes(index).alpha) || ...
            spectrum.modes(index).alpha < 0
        error('ndelta:diagnostics:InvalidCollectiveSpectrum', ...
            'Every collective mode must contain finite alpha>=0.');
    end
end
end
