function tree = tree_amplitudes_N( ...
        P, geometry, strengths, nearSingularRcond)
%TREE_AMPLITUDES_N Exact elastic amplitudes for arbitrary N deltas.
%
%       t0 = 1 + B_{N,T}/(2P),
%       r0 =     B_{N,R}/(2P).
%
%   G_RQM=G_B contains only terms with at least one barrier insertion.
%   The free identity is restored once, and only once, in transmission.

narginchk(4, 4);
background = ndelta.background.background_kernel_N( ...
    P, P, geometry, strengths, nearSingularRcond);

t0 = 1 + background.transmissionAmplitudeCorrection;
r0 = background.reflectionAmplitudeCorrection;

tree = struct();
tree.t0 = t0;
tree.r0 = r0;
tree.T0 = abs(t0).^2;
tree.R0 = abs(r0).^2;
tree.probabilityClosureResidual = tree.T0 + tree.R0 - 1;
tree.background = background;
tree.freeTransmissionContribution = 1;
tree.freeReflectionContribution = 0;
tree.convention = ['G_RQM=G_B; transmission restores identity; ' ...
    'reflection has no free term'];
end
