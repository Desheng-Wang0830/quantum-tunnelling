function [matrix, derivative] = collective_matrix(alpha, positions, strengths)
%COLLECTIVE_MATRIX Real symmetric physical-sheet bound-state matrix.
%
%   Gamma_N(i*alpha)=i*M(alpha), where
%       M_ab=delta_ab/g_a+exp(-alpha*|z_a-z_b|)/(2*alpha).

narginchk(3, 3);
validateattributes(alpha, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'alpha');
z = positions(:);
g = strengths(:);
if isempty(z) || ~isnumeric(z) || ~isreal(z) || ...
        any(~isfinite(z)) || numel(z) ~= numel(g) || ...
        ~isnumeric(g) || ~isreal(g) || any(~isfinite(g)) || any(g == 0)
    error('ndelta:singularity:InvalidCollectiveSystem', ...
        'positions and active nonzero strengths must be finite real vectors.');
end
distances = abs(z - z.');
exponential = exp(-alpha .* distances);
matrix = diag(1 ./ g) + exponential ./ (2 .* alpha);
if nargout > 1
    derivative = -exponential .* (1 + alpha .* distances) ./ ...
        (2 .* alpha.^2);
end
end
