function result = mixed_candidates(qPerp, cfg)
%MIXED_CANDIDATES Audit squared candidates for Omega+kappaI=P.

narginchk(2, 2);
E = cfg.referenceEnergy;
P = cfg.derived.P;
m = cfg.model.mphi;
M = cfg.model.mPhi;
epsilon = cfg.sheet.epsilon;
EPhiSquared = qPerp.^2 + M.^2;
discriminant = M.^4 - 4 .* m.^2 .* EPhiSquared ...
    + 4i .* m.^2 .* epsilon;
candidates = [ ...
    (E .* M.^2 - P .* sqrt(discriminant)) ./ (2 .* m.^2), ...
    (E .* M.^2 + P .* sqrt(discriminant)) ./ (2 .* m.^2)];
records = repmat(struct(), 1, 2);
for index = 1:2
    roots = ndelta.sheet.physical_roots( ...
        candidates(index), qPerp, E, cfg.model, epsilon);
    residual = abs(roots.omega + roots.kappaI - P) ./ ...
        (1 + abs(roots.omega) + abs(roots.kappaI) + P);
    records(index).q0 = candidates(index);
    records(index).quadrant = char(ndelta.sheet.quadrant(candidates(index)));
    records(index).omega = roots.omega;
    records(index).kappaI = roots.kappaI;
    records(index).unsquaredResidual = residual;
    records(index).accepted = false;
    records(index).rejectionReason = ...
        'no_on_shell_physical_sheet_solution_in_open_QI';
end
result = struct();
result.targetEquation = 'Omega+kappaI=P';
result.candidates = records;
result.acceptedCount = 0;
result.value = complex(0);
result.squaredCandidatesNeverAcceptedWithoutUnsquaredCheck = true;
end
