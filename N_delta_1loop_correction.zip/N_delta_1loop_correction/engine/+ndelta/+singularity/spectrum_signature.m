function signature = spectrum_signature(spectrum)
%SPECTRUM_SIGNATURE Compact deterministic identity of collective modes.

narginchk(1, 1);
if ~isstruct(spectrum) || ~isscalar(spectrum) || ...
        ~all(isfield(spectrum, {'modes', 'numberOfModes', ...
        'zeroEnergy', 'solverFingerprint'})) || ...
        ~isstruct(spectrum.modes) || ...
        spectrum.numberOfModes ~= numel(spectrum.modes)
    error('ndelta:singularity:InvalidSpectrumSignatureInput', ...
        'spectrum must be a complete find_collective_modes result.');
end
numberOfModes = spectrum.numberOfModes;
labels = cell(1, numberOfModes);
branchIndices = cell(1, numberOfModes);
for index = 1:numberOfModes
    mode = spectrum.modes(index);
    labels{index} = mode.label;
    branchIndices{index} = mode.branchIndices;
end
signature = struct();
signature.version = 1;
signature.solverFingerprint = spectrum.solverFingerprint;
signature.numberOfModes = numberOfModes;
signature.labels = labels;
signature.branchIndices = branchIndices;
signature.alpha = reshape([spectrum.modes.alpha], 1, []);
signature.qPerpCritical = reshape( ...
    [spectrum.modes.qPerpCritical], 1, []);
signature.multiplicity = reshape([spectrum.modes.multiplicity], 1, []);
signature.semisimple = reshape([spectrum.modes.semisimple], 1, []);
signature.stable = reshape([spectrum.modes.stable], 1, []);
signature.rootResidual = reshape([spectrum.modes.rootResidual], 1, []);
signature.zeroEnergyResonance = ...
    spectrum.zeroEnergy.isZeroEnergyResonance;
signature.zeroEnergyClassification = spectrum.zeroEnergy.classification;
end
