function derivative = gamma_derivative_N(K, positions)
%GAMMA_DERIVATIVE_N Analytic derivative d Gamma_N / dK.

narginchk(2, 2);
if ~isnumeric(K) || ~isscalar(K) || K == 0 || ...
        ~isfinite(real(K)) || ~isfinite(imag(K))
    error('ndelta:singularity:InvalidGammaDerivativeK', ...
        'K must be one finite nonzero scalar.');
end
z = positions(:);
if isempty(z) || ~isnumeric(z) || ~isreal(z) || any(~isfinite(z))
    error('ndelta:singularity:InvalidGammaDerivativePositions', ...
        'positions must be a nonempty finite real vector.');
end
distances = abs(z - z.');
derivative = exp(1i .* K .* distances) .* ...
    (1 - 1i .* K .* distances) ./ (2 .* K.^2);
end
