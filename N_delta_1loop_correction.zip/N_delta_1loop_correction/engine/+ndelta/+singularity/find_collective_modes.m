function spectrum = find_collective_modes(cfg, geometry)
%FIND_COLLECTIVE_MODES Find physical K=i*alpha zeros of Gamma_N.
%
%   The search tracks ordered eigenvalues of the real symmetric scaled
%   matrix 2*alpha*M(alpha).  Determinants are never used in production.

narginchk(2, 2);
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.g1.resolve_pair_geometry(cfg, geometry);
gFull = cfg.barriers.strengths(:);
activeMask = gFull ~= 0;
z = geometry.positions(activeMask);
g = gFull(activeMask);
n = numel(g);
rootClusterTolerance = max(cfg.tolerances.collectiveDuplicate, ...
    2 .* cfg.tolerances.collectiveRoot);
zeroEnergy = ndelta.singularity.zero_energy_diagnostic( ...
    geometry, gFull, cfg.tolerances.zeroEnergy);

spectrum = struct();
spectrum.modes = empty_modes();
spectrum.numberOfModes = 0;
spectrum.numberOfStableModes = 0;
spectrum.numberOfUnstableModes = 0;
spectrum.numberOfSemisimpleModes = 0;
spectrum.numberOfNonsemisimpleModes = 0;
spectrum.activeMask = activeMask;
spectrum.activeIndices = find(activeMask);
spectrum.configurationFingerprint = ...
    ndelta.config.physics_fingerprint(cfg);
spectrum.solverFingerprint = ...
    ndelta.config.spectrum_solver_fingerprint(cfg);
spectrum.zeroEnergy = zeroEnergy;
spectrum.searchMethod = ...
    'ordered_real_symmetric_eigenvalue_bracketing_in_K_equals_i_alpha';
spectrum.detUsedForProduction = false;
spectrum.searchUpperBound = 0;
spectrum.searchGrid = zeros(0, 1);
spectrum.rootClusterTolerance = rootClusterTolerance;
spectrum.maximumRootResidual = 0;
spectrum.allPhysicalModesStable = true;
spectrum.allModesSemisimple = true;
spectrum.accepted = ~zeroEnergy.isZeroEnergyResonance;
if n == 0 || ~any(g < 0)
    spectrum = attach_inelastic_thresholds(spectrum, cfg);
    spectrum.accepted = spectrum.accepted && ...
        spectrum.referenceEnergyBelowImplementedElasticUpperBound;
    return;
end

bound = 0.5 .* sum(abs(g(g < 0)));
upper = bound .* (1 + 1e-6) + ...
    64 .* eps(max(bound, cfg.derived.massScale));
lower = max(bound .* 1e-10, ...
    256 .* eps(cfg.derived.massScale));
number = cfg.collective.scanSamples;
logGrid = logspace(log10(lower), log10(upper), ceil(number ./ 2));
linearGrid = linspace(lower, upper, floor(number ./ 2) + 1);
grid = unique(sort([logGrid(:); linearGrid(:)]));
values = zeros(numel(grid), n);
for index = 1:numel(grid)
    values(index, :) = scaled_eigenvalues(grid(index), z, g).';
end

candidates = zeros(0, 1);
candidateBranches = zeros(0, 1);
for branch = 1:n
    for index = 1:(numel(grid) - 1)
        leftValue = values(index, branch);
        rightValue = values(index + 1, branch);
        if leftValue == 0
            candidates(end + 1, 1) = grid(index); %#ok<AGROW>
            candidateBranches(end + 1, 1) = branch; %#ok<AGROW>
        elseif leftValue .* rightValue < 0
            root = bisect_branch(grid(index), grid(index + 1), ...
                branch, z, g, cfg.tolerances.collectiveRoot);
            candidates(end + 1, 1) = root; %#ok<AGROW>
            candidateBranches(end + 1, 1) = branch; %#ok<AGROW>
        end
    end
end

[candidates, order] = sort(candidates);
candidateBranches = candidateBranches(order);
modes = empty_modes();
processed = false(size(candidates));
for index = 1:numel(candidates)
    if processed(index)
        continue;
    end
    clusterMask = transitive_root_cluster( ...
        candidates, index, processed, rootClusterTolerance);
    processed(clusterMask) = true;
    clusterCandidates = candidates(clusterMask);
    clusterBranches = unique(candidateBranches(clusterMask));
    alpha = mean(clusterCandidates);
    [scaledMatrix, scaledDerivative] = scaled_matrix(alpha, z, g);
    [vectors, diagonal] = eig((scaledMatrix + scaledMatrix.') ./ 2);
    eigenvalues = diag(diagonal);
    [~, permutation] = sort(eigenvalues);
    eigenvalues = eigenvalues(permutation);
    vectors = vectors(:, permutation);
    scale = max(1, norm(scaledMatrix, 2));
    % Multiplicity comes only from eigenvalue branches whose independently
    % bracketed roots belong to this alpha cluster.  A broad residual
    % tolerance must not absorb a nearby but distinct collective pole.
    nullVectors = vectors(:, clusterBranches);
    projectedDerivative = nullVectors.' * scaledDerivative * nullVectors;
    derivativeScale = max(1, norm(scaledDerivative, 2));
    projectedDerivativeSingularValues = svd(projectedDerivative);
    minimumProjectedDerivative = min(projectedDerivativeSingularValues);
    rootResidual = max(abs(eigenvalues(clusterBranches))) ./ scale;
    mode = mode_record();
    mode.index = numel(modes) + 1;
    mode.alpha = alpha;
    mode.K = 1i .* alpha;
    mode.activeIndices = find(activeMask);
    mode.nullVectorsActive = nullVectors;
    mode.nullity = size(nullVectors, 2);
    mode.multiplicity = mode.nullity;
    mode.projectedScaledDerivative = projectedDerivative;
    mode.minimumProjectedScaledDerivative = minimumProjectedDerivative;
    mode.projectedScaledDerivativeScale = derivativeScale;
    mode.semisimple = minimumProjectedDerivative > ...
        cfg.tolerances.collectiveResidual .* derivativeScale;
    mode.simple = mode.nullity == 1 && mode.semisimple;
    mode.rootResidual = rootResidual;
    mode.branchIndex = clusterBranches(1);
    mode.branchIndices = clusterBranches(:).';
    mode.candidateAlphas = clusterCandidates(:).';
    mode.rootClusterTolerance = rootClusterTolerance;
    mode.stable = alpha < cfg.model.mphi .* ...
        (1 - cfg.tolerances.collectiveRoot);
    finiteEpsilonCorrection = ...
        (cfg.sheet.epsilon ./ (2 .* cfg.referenceEnergy)).^2;
    qPerpCriticalSquared = cfg.derived.P.^2 + alpha.^2 ...
        - finiteEpsilonCorrection;
    mode.qPerpCriticalSquared = qPerpCriticalSquared;
    mode.hasOpenTransverseSupport = qPerpCriticalSquared > 0;
    mode.qPerpCritical = sqrt(max(qPerpCriticalSquared, 0));
    mode.label = classify_mode(nullVectors, z, g);
    mode.physicalKSheet = true;
    modes(end + 1) = mode; %#ok<AGROW>
end

spectrum.modes = modes;
spectrum.numberOfModes = numel(modes);
if isempty(modes)
    stableFlags = false(0, 1);
    rootResiduals = 0;
else
    stableFlags = [modes.stable];
    rootResiduals = [modes.rootResidual];
end
spectrum.numberOfStableModes = nnz(stableFlags);
spectrum.numberOfUnstableModes = numel(stableFlags) - nnz(stableFlags);
spectrum.allPhysicalModesStable = all(stableFlags);
semisimpleFlags = [modes.semisimple];
spectrum.numberOfSemisimpleModes = nnz(semisimpleFlags);
spectrum.numberOfNonsemisimpleModes = ...
    numel(semisimpleFlags) - nnz(semisimpleFlags);
spectrum.allModesSemisimple = all(semisimpleFlags);
spectrum.maximumRootResidual = max(rootResiduals);
spectrum.searchUpperBound = upper;
spectrum.searchGrid = grid;
spectrum.rootClusterTolerance = rootClusterTolerance;
spectrum.accepted = ~zeroEnergy.isZeroEnergyResonance && ...
    (~cfg.execution.rejectUnstableCollective || ...
     spectrum.allPhysicalModesStable) && ...
    spectrum.allModesSemisimple && ...
    spectrum.maximumRootResidual <= cfg.tolerances.collectiveResidual;
spectrum = attach_inelastic_thresholds(spectrum, cfg);
spectrum.accepted = spectrum.accepted && ...
    spectrum.referenceEnergyBelowImplementedElasticUpperBound;
end

function spectrum = attach_inelastic_thresholds(spectrum, cfg)
numberOfModes = numel(spectrum.modes);
alphas = reshape([spectrum.modes.alpha], 1, []);
stable = reshape([spectrum.modes.stable], 1, []);
boundMasses = NaN(1, numberOfModes);
boundThresholds = NaN(1, numberOfModes);
boundMasses(stable) = sqrt(max( ...
    cfg.model.mphi.^2 - alphas(stable).^2, 0));
boundThresholds(stable) = cfg.model.mPhi + boundMasses(stable);
freeThreshold = cfg.model.mphi + cfg.model.mPhi;
upper = freeThreshold;
limitingModeIndex = 0;
if any(stable)
    stableIndices = find(stable);
    [candidate, localIndex] = min(boundThresholds(stable));
    candidateIndex = stableIndices(localIndex);
    if candidate < upper
        upper = candidate;
        limitingModeIndex = candidateIndex;
    end
end
scale = max([1, abs(cfg.referenceEnergy), abs(upper)]);
tolerance = 128 .* eps(scale);
spectrum.boundModeMasses = boundMasses;
spectrum.boundModeInelasticThresholds = boundThresholds;
spectrum.boundModeStableMask = stable;
spectrum.freeTwoParticleThreshold = freeThreshold;
spectrum.implementedElasticUpperBound = upper;
spectrum.limitingInelasticModeIndex = limitingModeIndex;
spectrum.inelasticThresholdTolerance = tolerance;
spectrum.referenceEnergyBelowImplementedElasticUpperBound = ...
    cfg.referenceEnergy < upper - tolerance;
spectrum.referenceEnergyAtImplementedElasticUpperBound = ...
    abs(cfg.referenceEnergy - upper) <= tolerance;
spectrum.inelasticChannelImplemented = false;
spectrum.qPerpCriticalIsNotInelasticProductionThreshold = true;
end

function values = scaled_eigenvalues(alpha, z, g)
matrix = scaled_matrix(alpha, z, g);
values = sort(eig((matrix + matrix.') ./ 2));
end

function [matrix, derivative] = scaled_matrix(alpha, z, g)
distances = abs(z - z.');
exponential = exp(-alpha .* distances);
matrix = 2 .* alpha .* diag(1 ./ g) + exponential;
if nargout > 1
    derivative = 2 .* diag(1 ./ g) - distances .* exponential;
end
end

function root = bisect_branch(left, right, branch, z, g, tolerance)
fLeft = branch_value(left, branch, z, g);
for iteration = 1:120
    middle = 0.5 .* (left + right);
    fMiddle = branch_value(middle, branch, z, g);
    if fMiddle == 0 || ...
            abs(right - left) <= tolerance .* max(middle, realmin)
        root = middle;
        return;
    end
    if fLeft .* fMiddle <= 0
        right = middle;
    else
        left = middle;
        fLeft = fMiddle;
    end
end
root = 0.5 .* (left + right);
end

function value = branch_value(alpha, branch, z, g)
values = scaled_eigenvalues(alpha, z, g);
value = values(branch);
end

function clusterMask = transitive_root_cluster( ...
        candidates, seedIndex, processed, tolerance)
%TRANSITIVE_ROOT_CLUSTER Join every pair indistinguishable at root scale.
clusterMask = false(size(candidates));
clusterMask(seedIndex) = true;
changed = true;
while changed
    previous = clusterMask;
    members = find(clusterMask);
    for memberIndex = members(:).'
        seed = candidates(memberIndex);
        % MAX(A,scalar) is element-wise: no deep root can enlarge the
        % relative resolution window of two shallow roots.
        pairScale = max(max(abs(candidates), abs(seed)), realmin);
        neighbours = ~processed & abs(candidates - seed) <= ...
            tolerance .* pairScale;
        clusterMask = clusterMask | neighbours;
    end
    changed = ~isequal(clusterMask, previous);
end
end

function label = classify_mode(vectors, z, g)
label = 'collective';
if size(vectors, 2) ~= 1 || numel(z) ~= 2 || ...
        abs(g(1) - g(2)) > 128 .* eps(max(abs(g))) || ...
        abs((z(1) + z(2)) - 2 .* mean(z)) > 128 .* eps(max(abs(z)))
    return;
end
v = vectors(:, 1);
evenOverlap = abs(sum(v));
oddOverlap = abs(v(1) - v(2));
if evenOverlap >= oddOverlap
    label = 'even';
else
    label = 'odd';
end
end

function modes = empty_modes()
modes = repmat(mode_record(), 0, 1);
end

function mode = mode_record()
mode = struct('index', 0, 'alpha', 0, 'K', complex(0), ...
    'activeIndices', zeros(0, 1), ...
    'nullVectorsActive', zeros(0), 'nullity', 0, ...
    'multiplicity', 0, 'projectedScaledDerivative', zeros(0), ...
    'minimumProjectedScaledDerivative', 0, ...
    'projectedScaledDerivativeScale', 1, ...
    'semisimple', false, 'simple', false, ...
    'rootResidual', Inf, 'branchIndex', 0, ...
    'branchIndices', zeros(1, 0), 'candidateAlphas', zeros(1, 0), ...
    'rootClusterTolerance', NaN, ...
    'stable', false, 'qPerpCriticalSquared', 0, ...
    'hasOpenTransverseSupport', false, 'qPerpCritical', 0, ...
    'label', 'collective', ...
    'physicalKSheet', false);
end
