function mapped = map_collective_q0(mode, qPerp, cfg)
%MAP_COLLECTIVE_Q0 Map one K=i*alpha mode to the two q0 candidates.

narginchk(3, 3);
validateattributes(qPerp, {'numeric'}, ...
    {'real', 'finite', 'nonnegative', 'scalar'}, mfilename, 'qPerp');
E = cfg.referenceEnergy;
EphiSquared = qPerp.^2 + cfg.model.mphi.^2;
offset = sqrt(EphiSquared - mode.alpha.^2 - 1i .* cfg.sheet.epsilon);
qLeft = E - offset;
qRight = E + offset;
leftRoots = ndelta.sheet.physical_roots( ...
    qLeft, qPerp, E, cfg.model, cfg.sheet.epsilon);
rightRoots = ndelta.sheet.physical_roots( ...
    qRight, qPerp, E, cfg.model, cfg.sheet.epsilon);
K = mode.K;
leftResidual = abs(leftRoots.kappaI - K) ./ (1 + abs(K));
rightResidual = abs(rightRoots.kappaI - K) ./ (1 + abs(K));
if isfield(mode, 'hasOpenTransverseSupport')
    hasOpenSupport = mode.hasOpenTransverseSupport;
else
    hasOpenSupport = mode.qPerpCritical > 0;
end
support = hasOpenSupport && qPerp < mode.qPerpCritical;
leftQI = real(qLeft) > 0 && imag(qLeft) > 0;
if isfield(mode, 'semisimple')
    admissibleMultiplicity = mode.semisimple;
else
    admissibleMultiplicity = mode.simple;
end

mapped = struct();
mapped.modeIndex = mode.index;
mapped.alpha = mode.alpha;
mapped.K = K;
mapped.qPerp = qPerp;
mapped.qPerpCritical = mode.qPerpCritical;
mapped.insideOpenTransverseSupport = support;
mapped.left = candidate(qLeft, leftRoots, leftResidual, ...
    leftQI && support && mode.stable && admissibleMultiplicity, ...
    'left_physical_candidate');
mapped.right = candidate(qRight, rightRoots, rightResidual, false, ...
    'right_physical_candidate_not_swept');
mapped.left.accepted = mapped.left.accepted && ...
    leftResidual <= cfg.tolerances.collectiveResidual;
mapped.right.accepted = false;
mapped.unsquaredResidualTolerance = ...
    cfg.tolerances.collectiveResidual;
mapped.thirdQuadrantAccepted = false;
end

function out = candidate(q0, roots, residual, accepted, reason)
out = struct();
out.q0 = q0;
out.quadrant = char(ndelta.sheet.quadrant(q0));
out.omega = roots.omega;
out.kappaI = roots.kappaI;
out.unsquaredKappaResidual = residual;
out.physicalSheet = true;
out.accepted = accepted;
out.reason = reason;
end
