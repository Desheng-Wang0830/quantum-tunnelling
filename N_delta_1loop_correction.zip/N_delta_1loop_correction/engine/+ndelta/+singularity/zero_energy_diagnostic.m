function diagnostics = zero_energy_diagnostic(geometry, strengths, tolerance)
%ZERO_ENERGY_DIAGNOSTIC Detect a genuine K=0 collective threshold.

narginchk(3, 3);
validateattributes(tolerance, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'tolerance');
g = strengths(:);
activeMask = g ~= 0;
z = geometry.positions(activeMask);
g = g(activeMask);
n = numel(g);
diagnostics = struct('activeCount', n, 'matrix', zeros(0), ...
    'minimumSingularValue', Inf, 'normalisedMinimumSingularValue', Inf, ...
    'parentScale', Inf, ...
    'isZeroEnergyResonance', false, ...
    'classification', 'no_zero_energy_collective_threshold');
if n <= 1
    return;
end
basis = helmert_orthogonal_block(n);
distances = abs(z - z.');
finitePart = diag(1 ./ g) - distances ./ 2;
endpointBlock = basis.' * finitePart * basis;
singularValues = svd(endpointBlock);
minimum = min(singularValues);
% Use a cancellation-free scale from the two parent terms.  Scaling by
% sigma_max(endpointBlock) is blind for the N=2 one-by-one block.
parentScale = norm(diag(1 ./ g), 2) + norm(distances ./ 2, 2);
normalised = minimum ./ max(parentScale, realmin);
diagnostics.matrix = endpointBlock;
diagnostics.minimumSingularValue = minimum;
diagnostics.normalisedMinimumSingularValue = normalised;
diagnostics.parentScale = parentScale;
diagnostics.isZeroEnergyResonance = normalised <= tolerance;
if diagnostics.isZeroEnergyResonance
    diagnostics.classification = ...
        'compound_branch_endpoint_zero_energy_collective_threshold';
end
end

function block = helmert_orthogonal_block(n)
block = zeros(n, n - 1);
for column = 1:(n - 1)
    k = column;
    block(1:k, column) = 1 ./ sqrt(k .* (k + 1));
    block(k + 1, column) = -k ./ sqrt(k .* (k + 1));
end
end
