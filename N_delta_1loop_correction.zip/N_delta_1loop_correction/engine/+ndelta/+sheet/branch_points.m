function points = branch_points(qPerp, E, model, epsilon)
%BRANCH_POINTS Locate finite-epsilon branch points in the q0 plane.

narginchk(4, 4);
ndelta.sheet.validate_inputs(qPerp, E, model, epsilon);
scales = ndelta.sheet.transverse_energies(qPerp, model);

omegaOffset = sqrt(scales.EPhi.^2 - 1i .* epsilon);
kappaOffset = sqrt(scales.Ephi.^2 - 1i .* epsilon);

points = struct();
points.omega = struct('left', -omegaOffset, 'right', +omegaOffset);
points.kappaI = struct( ...
    'left', E - kappaOffset, 'right', E + kappaOffset);
points.outwardDirection = struct( ...
    'omegaLeft', -1, 'omegaRight', +1, ...
    'kappaILeft', -1, 'kappaIRight', +1);
points.types = struct( ...
    'omegaLeft', 'branch_point_not_pole', ...
    'omegaRight', 'branch_point_not_pole', ...
    'kappaILeft', 'branch_point_not_pole', ...
    'kappaIRight', 'branch_point_not_pole');
points.scales = scales;
points.E = E;
points.epsilon = epsilon;
end
