function scales = transverse_energies(qPerp, model)
%TRANSVERSE_ENERGIES Return fixed-qPerp light/heavy threshold energies.

narginchk(2, 2);
if ~isstruct(model) || ~isscalar(model) || ...
        ~isfield(model, 'mphi') || ~isfield(model, 'mPhi')
    error('ndelta:sheet:InvalidModel', ...
        'model must contain the scalar masses mphi and mPhi.');
end
if ~isnumeric(qPerp) || isempty(qPerp) || ~isreal(qPerp) || ...
        any(~isfinite(qPerp(:))) || any(qPerp(:) < 0)
    error('ndelta:sheet:InvalidQPerp', ...
        'qPerp must be a nonempty finite real array with qPerp >= 0.');
end
if ~isnumeric(model.mphi) || ~isscalar(model.mphi) || ...
        ~isreal(model.mphi) || ~isfinite(model.mphi) || model.mphi <= 0 || ...
        ~isnumeric(model.mPhi) || ~isscalar(model.mPhi) || ...
        ~isreal(model.mPhi) || ~isfinite(model.mPhi) || model.mPhi <= 0
    error('ndelta:sheet:InvalidMass', ...
        'mphi and mPhi must be finite positive real scalars.');
end

scales = struct();
scales.qPerp = qPerp;
scales.Ephi = hypot(qPerp, model.mphi);
scales.EPhi = hypot(qPerp, model.mPhi);
end
