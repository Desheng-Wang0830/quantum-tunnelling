function roots = physical_roots(q0, qPerp, E, model, epsilon)
%PHYSICAL_ROOTS Evaluate the frozen outward-cut Feynman sheet.
%
%   The two independent propagation roots are
%
%       Omega^2  = q0^2       - EPhi(qPerp)^2 + i*epsilon,
%       kappaI^2 = (E-q0)^2   - Ephi(qPerp)^2 + i*epsilon.
%
%   Their global physical-sheet representation is
%
%       Omega  = i*sqrt(EPhi^2-q0^2-i*epsilon),
%       kappaI = i*sqrt(Ephi^2-(E-q0)^2-i*epsilon),
%
%   with MATLAB's principal square root on the right.  KAPPAI is already
%   the propagation root K_I used by Gamma_N(K); below threshold it tends
%   to +i times the positive decay constant as epsilon->0+.  At finite
%   epsilon it generally retains a small real part.  In G1,
%   kappaB[p-q]=kappaI and
%   is not a third independent square root.

narginchk(5, 5);
ndelta.sheet.validate_inputs(qPerp, E, model, epsilon);
if ~isnumeric(q0) || isempty(q0) || ...
        any(~isfinite(real(q0(:)))) || any(~isfinite(imag(q0(:))))
    error('ndelta:sheet:InvalidQ0', ...
        'q0 must be a nonempty finite numeric array.');
end

scales = ndelta.sheet.transverse_energies(qPerp, model);
omegaSquared = q0.^2 - scales.EPhi.^2 + 1i .* epsilon;
kappaISquared = (E - q0).^2 - scales.Ephi.^2 + 1i .* epsilon;

omega = 1i .* sqrt(scales.EPhi.^2 - q0.^2 - 1i .* epsilon);
kappaI = 1i .* sqrt( ...
    scales.Ephi.^2 - (E - q0).^2 - 1i .* epsilon);

roots = struct();
roots.q0 = q0;
roots.qPerp = qPerp;
roots.E = E;
roots.epsilon = epsilon;
roots.scales = scales;
roots.omega = omega;
roots.kappaI = kappaI;
roots.kappaBOfPMinusQ = kappaI;
roots.decayConventionKappaI = -1i .* kappaI;
roots.omegaSquared = omegaSquared;
roots.kappaISquared = kappaISquared;
roots.omegaResidual = omega.^2 - omegaSquared;
roots.kappaIResidual = kappaI.^2 - kappaISquared;
roots.maximumOmegaRelativeResidual = max( ...
    abs(roots.omegaResidual(:)) ./ (1 + abs(omegaSquared(:))));
roots.maximumKappaIRelativeResidual = max( ...
    abs(roots.kappaIResidual(:)) ./ (1 + abs(kappaISquared(:))));
roots.sheet = 'outward_cut_feynman';
roots.independentRootNames = {'omega', 'kappaI'};
roots.numberOfIndependentRoots = 2;
roots.kappaIIsPropagationRoot = true;
end
