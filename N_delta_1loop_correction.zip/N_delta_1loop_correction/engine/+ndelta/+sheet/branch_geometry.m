function geometry = branch_geometry(qPerp, E, model, epsilon)
%BRANCH_GEOMETRY Summarise Stage 4 root-cut geometry, without pole claims.

narginchk(4, 4);
ndelta.sheet.validate_inputs(qPerp, E, model, epsilon);
P = sqrt((E - model.mphi) .* (E + model.mphi));
points = ndelta.sheet.branch_points(qPerp, E, model, epsilon);
finiteEpsilonKappaLeftInQI = ...
    real(points.kappaI.left) > 0 && imag(points.kappaI.left) > 0;

geometry = struct();
geometry.P = P;
geometry.qPerp = qPerp;
geometry.points = points;
geometry.hasKappaILeftSegmentInQI = finiteEpsilonKappaLeftInQI;
geometry.requiresModifiedPositiveRotation = finiteEpsilonKappaLeftInQI;
geometry.zeroEpsilonKappaLeftCriterion = qPerp < P;
geometry.thirdQuadrantHasRootCut = false;
geometry.thirdQuadrantClearForRootRotation = true;
geometry.poleClassificationPerformed = false;
geometry.poleClassificationDeferredToStage = 7;
geometry.branchPointQuadrants = struct( ...
    'omegaLeft', ndelta.sheet.quadrant(points.omega.left), ...
    'omegaRight', ndelta.sheet.quadrant(points.omega.right), ...
    'kappaILeft', ndelta.sheet.quadrant(points.kappaI.left), ...
    'kappaIRight', ndelta.sheet.quadrant(points.kappaI.right));
end
