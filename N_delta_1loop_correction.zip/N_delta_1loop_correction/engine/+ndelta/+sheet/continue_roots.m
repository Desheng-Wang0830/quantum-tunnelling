function result = continue_roots(q0Path, qPerp, E, model, epsilon)
%CONTINUE_ROOTS Lift Omega and kappaI continuously along a discrete path.
%
%   The first path node is seeded by PHYSICAL_ROOTS.  At each later node
%   the sign of the exact square root is chosen by continuity with the
%   preceding accepted value.  Crossing a projected branch cut may move
%   the lifted root to the adjacent sheet; this is reported, not erased.

narginchk(5, 5);
ndelta.sheet.validate_inputs(qPerp, E, model, epsilon);
if ~isnumeric(q0Path) || ~isvector(q0Path) || isempty(q0Path) || ...
        any(~isfinite(real(q0Path(:)))) || ...
        any(~isfinite(imag(q0Path(:))))
    error('ndelta:sheet:InvalidPath', ...
        'q0Path must be a nonempty finite numeric vector.');
end

pathShape = size(q0Path);
pathColumn = q0Path(:);
points = ndelta.sheet.branch_points(qPerp, E, model, epsilon);
allBranchPoints = [points.omega.left; points.omega.right; ...
    points.kappaI.left; points.kappaI.right];
minimumQ0BranchPointClearance = minimum_path_clearance( ...
    pathColumn, allBranchPoints);
q0Scale = max([1; abs(pathColumn); abs(allBranchPoints)]);
minimumAllowedQ0Clearance = min(2048 .* eps(q0Scale), ...
    0.1 .* epsilon ./ (1 + q0Scale));
if minimumQ0BranchPointClearance <= minimumAllowedQ0Clearance
    error('ndelta:sheet:PathHitsBranchPoint', ...
        ['A path node or a straight segment between consecutive nodes ' ...
         'reaches a branch point within floating-point resolution.']);
end
direct = ndelta.sheet.physical_roots( ...
    pathColumn, qPerp, E, model, epsilon);
omegaRadicand = direct.omegaSquared;
kappaRadicand = direct.kappaISquared;

principalCutScale = max([1, abs(omegaRadicand(1)), ...
    abs(kappaRadicand(1))]);
% A genuine nonzero Feynman lane must never be collapsed onto a cut just
% because epsilon is smaller than a generic floating-point tolerance.
principalCutTolerance = min(2048 .* eps(principalCutScale), ...
    0.1 .* epsilon);
if starts_on_principal_cut(-omegaRadicand(1), ...
        principalCutTolerance) || ...
        starts_on_principal_cut(-kappaRadicand(1), ...
        principalCutTolerance)
    error('ndelta:sheet:PathStartsOnCut', ...
        ['The continuation seed lies on an outward cut and has no ' ...
         'unambiguous bank. Start the path on a specified side.']);
end

radicandScale = max([1; abs(omegaRadicand(:)); ...
    abs(kappaRadicand(:))]);
minimumAllowedRadicand = min(2048 .* eps(radicandScale), ...
    0.1 .* epsilon);
if any(abs(omegaRadicand) <= minimumAllowedRadicand) || ...
        any(abs(kappaRadicand) <= minimumAllowedRadicand)
    error('ndelta:sheet:PathHitsBranchPoint', ...
        ['q0Path reaches a branch point within floating-point ' ...
         'resolution. Deform the path away from the endpoint.']);
end

[omega, omegaChoiceRatio] = track_one_root( ...
    omegaRadicand, direct.omega(1));
[kappaI, kappaChoiceRatio] = track_one_root( ...
    kappaRadicand, direct.kappaI(1));

omegaResidual = omega.^2 - omegaRadicand;
kappaResidual = kappaI.^2 - kappaRadicand;

result = struct();
result.q0 = reshape(pathColumn, pathShape);
result.qPerp = qPerp;
result.E = E;
result.epsilon = epsilon;
result.omega = reshape(omega, pathShape);
result.kappaI = reshape(kappaI, pathShape);
result.kappaBOfPMinusQ = result.kappaI;
result.omegaSquared = reshape(omegaRadicand, pathShape);
result.kappaISquared = reshape(kappaRadicand, pathShape);
result.directPhysicalOmega = reshape(direct.omega, pathShape);
result.directPhysicalKappaI = reshape(direct.kappaI, pathShape);
result.sheet = 'continuous_lift_from_physical_seed';

diagnostics = struct();
diagnostics.minimumOmegaRadicandMagnitude = min(abs(omegaRadicand));
diagnostics.minimumKappaIRadicandMagnitude = min(abs(kappaRadicand));
diagnostics.maximumOmegaChoiceRatio = max(omegaChoiceRatio);
diagnostics.maximumKappaIChoiceRatio = max(kappaChoiceRatio);
diagnostics.maximumOmegaRelativeResidual = max( ...
    abs(omegaResidual) ./ (1 + abs(omegaRadicand)));
diagnostics.maximumKappaIRelativeResidual = max( ...
    abs(kappaResidual) ./ (1 + abs(kappaRadicand)));
diagnostics.maximumOmegaNormalisedJump = ...
    maximum_normalised_jump(omega);
diagnostics.maximumKappaINormalisedJump = ...
    maximum_normalised_jump(kappaI);
diagnostics.endParityOmega = sheet_parity( ...
    omega(end), direct.omega(end));
diagnostics.endParityKappaI = sheet_parity( ...
    kappaI(end), direct.kappaI(end));
diagnostics.physicalMatchOmega = reshape( ...
    abs(omega - direct.omega) <= abs(omega + direct.omega), pathShape);
diagnostics.physicalMatchKappaI = reshape( ...
    abs(kappaI - direct.kappaI) <= ...
    abs(kappaI + direct.kappaI), pathShape);
diagnostics.minimumAllowedRadicand = minimumAllowedRadicand;
diagnostics.minimumQ0BranchPointClearance = ...
    minimumQ0BranchPointClearance;
diagnostics.minimumAllowedQ0Clearance = minimumAllowedQ0Clearance;
result.diagnostics = diagnostics;
end

function [tracked, choiceRatio] = track_one_root(radicand, seed)
tracked = complex(zeros(size(radicand)));
choiceRatio = zeros(size(radicand));
tracked(1) = seed;

for index = 2:numel(radicand)
    candidate = sqrt(radicand(index));
    positiveDistance = abs(candidate - tracked(index - 1));
    negativeDistance = abs(-candidate - tracked(index - 1));
    distanceScale = max([1, positiveDistance, negativeDistance]);
    if abs(positiveDistance - negativeDistance) <= ...
            128 .* eps(distanceScale)
        error('ndelta:sheet:AmbiguousContinuation', ...
            ['The discrete path is too coarse to choose a unique root ' ...
             'sign. Insert additional path nodes.']);
    end

    if positiveDistance < negativeDistance
        tracked(index) = candidate;
        chosenDistance = positiveDistance;
        rejectedDistance = negativeDistance;
    else
        tracked(index) = -candidate;
        chosenDistance = negativeDistance;
        rejectedDistance = positiveDistance;
    end
    choiceRatio(index) = chosenDistance ./ ...
        max(rejectedDistance, realmin);
end
end

function value = maximum_normalised_jump(rootValues)
if numel(rootValues) < 2
    value = 0;
    return;
end
scale = abs(rootValues(1:end-1)) + abs(rootValues(2:end)) + realmin;
value = max(abs(diff(rootValues)) ./ scale);
end

function parity = sheet_parity(trackedValue, physicalValue)
if abs(trackedValue - physicalValue) <= ...
        abs(trackedValue + physicalValue)
    parity = +1;
else
    parity = -1;
end
end

function minimumDistance = minimum_path_clearance(path, branchPoints)
minimumDistance = Inf;
if numel(path) == 1
    minimumDistance = min(abs(path(1) - branchPoints));
    return;
end

for branchIndex = 1:numel(branchPoints)
    point = branchPoints(branchIndex);
    for pathIndex = 1:(numel(path) - 1)
        first = path(pathIndex);
        second = path(pathIndex + 1);
        segment = second - first;
        if segment == 0
            distance = abs(point - first);
        else
            parameter = real((point - first) .* conj(segment)) ./ ...
                abs(segment).^2;
            parameter = min(1, max(0, parameter));
            closest = first + parameter .* segment;
            distance = abs(point - closest);
        end
        minimumDistance = min(minimumDistance, distance);
    end
end
end

function value = starts_on_principal_cut(principalRadicand, tolerance)
value = real(principalRadicand) < 0 && ...
    abs(imag(principalRadicand)) <= tolerance;
end
