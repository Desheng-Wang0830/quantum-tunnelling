function cuts = outward_cut_points(s, qPerp, E, model, epsilon)
%OUTWARD_CUT_POINTS Evaluate exact finite-epsilon outward-cut curves.
%
%   S>=0 parameterises the negative real axis of the principal-root
%   radicand.  The returned curves satisfy the defining radicand equation
%   exactly; they are not horizontal finite-epsilon approximations.

narginchk(5, 5);
ndelta.sheet.validate_inputs(qPerp, E, model, epsilon);
if ~isnumeric(s) || isempty(s) || ~isreal(s) || ...
        any(~isfinite(s(:))) || any(s(:) < 0)
    error('ndelta:sheet:InvalidCutParameter', ...
        's must be a nonempty finite real array satisfying s >= 0.');
end

scales = ndelta.sheet.transverse_energies(qPerp, model);
omegaOffset = sqrt(scales.EPhi.^2 + s.^2 - 1i .* epsilon);
kappaOffset = sqrt(scales.Ephi.^2 + s.^2 - 1i .* epsilon);

cuts = struct();
cuts.s = s;
cuts.omega = struct('left', -omegaOffset, 'right', +omegaOffset);
cuts.kappaI = struct( ...
    'left', E - kappaOffset, 'right', E + kappaOffset);
cuts.radicandTarget = -s.^2;
cuts.omegaLeftResidual = scales.EPhi.^2 - ...
    cuts.omega.left.^2 - 1i .* epsilon + s.^2;
cuts.omegaRightResidual = scales.EPhi.^2 - ...
    cuts.omega.right.^2 - 1i .* epsilon + s.^2;
cuts.kappaILeftResidual = scales.Ephi.^2 - ...
    (E - cuts.kappaI.left).^2 - 1i .* epsilon + s.^2;
cuts.kappaIRightResidual = scales.Ephi.^2 - ...
    (E - cuts.kappaI.right).^2 - 1i .* epsilon + s.^2;
cuts.scales = scales;
cuts.E = E;
cuts.epsilon = epsilon;
cuts.parameterisation = 'exact_finite_epsilon_outward_cuts';
end
