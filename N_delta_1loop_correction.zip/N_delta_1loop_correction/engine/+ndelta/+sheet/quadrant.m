function labels = quadrant(z)
%QUADRANT Classify finite complex points without erasing finite-i0 signs.

narginchk(1, 1);
if ~isnumeric(z) || isempty(z) || ...
        any(~isfinite(real(z(:)))) || any(~isfinite(imag(z(:))))
    error('ndelta:sheet:InvalidComplexPoint', ...
        'z must be a nonempty finite numeric array.');
end

x = real(z);
y = imag(z);
% Do not use a user-scale tolerance here: even a very small but nonzero
% finite-epsilon imaginary part determines the Wick wedge.  Near-axis
% distances belong in a separate diagnostic, not in the sign label.
xZero = (x == 0);
yZero = (y == 0);
labels = strings(size(z));

labels(~xZero & ~yZero & x > 0 & y > 0) = "QI";
labels(~xZero & ~yZero & x < 0 & y > 0) = "QII";
labels(~xZero & ~yZero & x < 0 & y < 0) = "QIII";
labels(~xZero & ~yZero & x > 0 & y < 0) = "QIV";
labels(xZero & yZero) = "origin";
labels(~xZero & yZero & x > 0) = "positive_real_axis";
labels(~xZero & yZero & x < 0) = "negative_real_axis";
labels(xZero & ~yZero & y > 0) = "positive_imag_axis";
labels(xZero & ~yZero & y < 0) = "negative_imag_axis";
end
