function validate_inputs(qPerp, E, model, epsilon)
%VALIDATE_INPUTS Validate scalar inputs shared by Stage 4 sheet routines.

narginchk(4, 4);

if ~isstruct(model) || ~isscalar(model) || ...
        ~isfield(model, 'mphi') || ~isfield(model, 'mPhi')
    error('ndelta:sheet:InvalidModel', ...
        'model must be a scalar structure containing mphi and mPhi.');
end
validate_positive_mass(model.mphi, 'model.mphi');
validate_positive_mass(model.mPhi, 'model.mPhi');

isValidQPerp = isnumeric(qPerp) && isscalar(qPerp) && ...
    isreal(qPerp) && isfinite(qPerp) && qPerp >= 0;
if ~isValidQPerp
    error('ndelta:sheet:InvalidQPerp', ...
        'qPerp must be a finite real scalar satisfying qPerp >= 0.');
end

isValidEnergy = isnumeric(E) && isscalar(E) && isreal(E) && ...
    isfinite(E);
if ~isValidEnergy
    error('ndelta:sheet:InvalidEnergy', ...
        'E must be a finite real scalar.');
end
if E <= model.mphi || E >= model.mphi + model.mPhi
    error('ndelta:sheet:EnergyOutsideElasticWindow', ...
        'Stage 4 requires model.mphi < E < model.mphi+model.mPhi.');
end

isValidEpsilon = isnumeric(epsilon) && isscalar(epsilon) && ...
    isreal(epsilon) && isfinite(epsilon) && epsilon > 0;
if ~isValidEpsilon
    error('ndelta:sheet:InvalidEpsilon', ...
        'epsilon must be a finite, strictly positive real scalar.');
end
end

function validate_positive_mass(value, name)
isValid = isnumeric(value) && isscalar(value) && isreal(value) && ...
    isfinite(value) && value > 0;
if ~isValid
    error('ndelta:sheet:InvalidMass', ...
        '%s must be a finite positive real scalar.', name);
end
end
