function report = validate_contract(cfg, tree, stage7, stage8, stage9, stage11)
%VALIDATE_CONTRACT Portable analytic and numerical Stage 11 gates.

narginchk(6, 6);
names = cell(0, 1);
errors = zeros(0, 1);
tolerances = zeros(0, 1);
pointTol = cfg.tolerances.stage11Pointwise;
sourceTol = cfg.tolerances.stage11SourceClosure;

for channelName = {'transmission', 'reflection'}
    channel = channelName{1};
    item = stage11.pointwise.(channel);
    add_check(['G2_' channel '_optimised_equals_explicit'], ...
        relative(item.G2Raw, item.G2ReferenceRaw), pointTol);
    add_check(['G3_' channel '_optimised_equals_explicit'], ...
        relative(item.G3Raw, item.G3ReferenceRaw), pointTol);
    add_check(['G4_' channel '_optimised_equals_explicit'], ...
        relative(item.G4Raw, item.G4ReferenceRaw), pointTol);
end

[n1Errors, n1Names] = n1_compact_regression(cfg);
for index = 1:numel(n1Errors)
    add_check(n1Names{index}, n1Errors(index), pointTol);
end

context = stage11.context;
for channelName = {'T', 'R'}
    channel = channelName{1};
    endpoint2 = ndelta.g2.endpoint_data( ...
        cfg.stage11.referenceQPerp, channel, cfg, context);
    endpoint3 = ndelta.g3.endpoint_data( ...
        cfg.stage11.referenceQPerp, channel, cfg, context);
    endpoint4 = ndelta.g4.endpoint_data( ...
        cfg.stage11.referenceQPerp, channel, cfg, context);
    add_check(['G2_G3_' channel '_endpoint_residues_equal'], ...
        relative(endpoint2.vertexReducedResidue, ...
        endpoint3.vertexReducedResidue), pointTol);
    add_check(['G4_' channel '_endpoint_arc_is_exactly_zero'], ...
        abs(endpoint4.keyholeContribution), 0);
end

termNames = {'G2', 'G3', 'G4'};
for index = 1:numel(termNames)
    term = stage11.integrated.(termNames{index});
    add_check([termNames{index} '_five_sources_close'], ...
        term.maximumClosureResidual, sourceTol);
    add_check([termNames{index} '_comparison_orders_converge'], ...
        stage11.comparison.errors(index), ...
        cfg.tolerances.stage11Convergence);
end

add_check('G1_upstream_values_are_unchanged', max([ ...
    relative(stage11.integrated.G1.values, stage8.values), ...
    relative(stage11.amplitudes.G1.deltaProbabilities, ...
    stage9.deltaProbabilities)]), pointTol);
add_check('four_term_amplitude_sum_equals_termwise_interference_sum', ...
    stage11.combined.maximumInterferenceAssemblyResidual, pointTol);
add_check('strict_O_mu2_excludes_all_amplitude_squared_terms', ...
    double(stage11.combined.amplitudeSquaredIncluded || ...
    stage11.combined.mu4TermsIncluded), 0.5);
unitarityScale = max(1e-12, sum(abs( ...
    stage11.combined.totalDeltaProbabilities)));
unitarityError = abs( ...
    stage11.combined.unitarity.oneLoopInterferenceClosure) ...
    ./ unitarityScale;
add_check('complete_G1_G4_left_incidence_unitarity', ...
    unitarityError, cfg.tolerances.stage11Unitarity);
add_check('collective_spectrum_is_reused_without_extra_barrier_poles', ...
    double(~stage7.spectrum.accepted), 0.5);

records = make_records(names, errors, tolerances);
report = struct('records', records, ...
    'numberOfChecks', numel(records), ...
    'numberPassed', sum([records.passed]), ...
    'accepted', all([records.passed]), ...
    'maximumNormalisedError', max([records.normalisedError]), ...
    'oneLoopUnitarityNormalisedError', unitarityError);
if report.numberOfChecks ~= 27
    error('ndelta:stage11:ValidationDiscoveryMismatch', ...
        'Expected 27 Stage 11 portable checks, but assembled %d.', ...
        report.numberOfChecks);
end

    function add_check(name, errorValue, toleranceValue)
        names{end + 1, 1} = name;
        errors(end + 1, 1) = max(abs(errorValue(:)));
        tolerances(end + 1, 1) = toleranceValue;
    end
end

function [errors, names] = n1_compact_regression(cfg)
n1 = cfg;
n1.barriers.positions = 0;
n1.barriers.strengths = -0.3;
n1 = ndelta.config.finalize_configuration(n1);
geometry = ndelta.geometry.build_geometry(0, n1.tolerances.distanceMerge);
context = ndelta.stage11.build_context(n1, geometry);
P = n1.derived.P;
omega = 0.37 + 1.11i;
kappaI = 0.29 + 0.63i;
g = n1.barriers.strengths;
tauI = -2i .* g .* kappaI ./ (2 .* kappaI + 1i .* g);
tauP = -2i .* g .* P ./ (2 .* P + 1i .* g);
Q = (P + 2 .* kappaI) .* omega.^2 ...
    + (P.^2 + 5 .* P .* kappaI + 6 .* kappaI.^2) .* omega ...
    + 4 .* kappaI.^2 .* (P + kappaI);
I2 = -Q ./ (16 .* P .* kappaI.^3 .* (P + kappaI) .* omega ...
    .* (omega + kappaI - P) .* (omega + kappaI + P).^2);
I4 = -(omega + 2 .* (P + kappaI)) ./ ...
    (16 .* P.^2 .* kappaI.^2 .* omega .* (P + kappaI) ...
    .* (omega + P + kappaI).^2);
expected2 = -tauI .* tauP .* I2;
expected4 = -tauP.^2 .* tauI .* I4;
errors = zeros(1, 6);
names = cell(1, 6);
index = 0;
for channelName = {'T', 'R'}
    channel = channelName{1};
    g2 = ndelta.g2.pointwise_contraction_from_roots( ...
        omega, kappaI, channel, n1, geometry, context);
    g3 = ndelta.g3.pointwise_contraction_from_roots( ...
        omega, kappaI, channel, n1, geometry, context);
    g4 = ndelta.g4.pointwise_contraction_from_roots( ...
        omega, kappaI, channel, n1, geometry, context);
    index = index + 1;
    names{index} = ['N1_G2_' channel '_recovers_compact_kernel'];
    errors(index) = relative(-g2, expected2);
    index = index + 1;
    names{index} = ['N1_G3_' channel '_recovers_compact_kernel'];
    errors(index) = relative(-g3, expected2);
    index = index + 1;
    names{index} = ['N1_G4_' channel '_recovers_compact_kernel'];
    errors(index) = relative(-g4, expected4);
end
end

function value = relative(left, right)
entries = abs(left - right) ./ (1 + abs(right));
value = max(entries(:));
end

function records = make_records(names, errors, tolerances)
records = repmat(struct('name', '', 'error', NaN, ...
    'tolerance', NaN, 'normalisedError', NaN, 'passed', false), ...
    numel(names), 1);
for index = 1:numel(names)
    records(index).name = names{index};
    records(index).error = errors(index);
    records(index).tolerance = tolerances(index);
    if tolerances(index) == 0
        records(index).normalisedError = double(errors(index) ~= 0);
    else
        records(index).normalisedError = errors(index) ./ tolerances(index);
    end
    records(index).passed = errors(index) <= tolerances(index);
end
end
