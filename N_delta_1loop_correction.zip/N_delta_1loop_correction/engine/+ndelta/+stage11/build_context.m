function context = build_context(cfg, geometry)
%BUILD_CONTEXT Fixed external-channel data shared by Stage 11 terms.

narginchk(2, 2);
cfg = ndelta.config.finalize_configuration(cfg);
geometry = ndelta.g1.resolve_pair_geometry(cfg, geometry);
P = cfg.derived.P;
background = ndelta.background.background_kernel_N( ...
    P, P, geometry, cfg.barriers.strengths, ...
    cfg.tolerances.nearSingularRcond);
if background.solveDiagnostics.nearSingular
    error('ndelta:stage11:NearSingularExternalGamma', ...
        ['Stage-11 context construction refuses an external Gamma_N(P) ' ...
        'below cfg.tolerances.nearSingularRcond.']);
end
z = geometry.positions(:);
incomingPhase = exp(1i .* P .* z);
phases = ndelta.geometry.build_channel_phases(z, P);

context = struct();
context.P = P;
context.geometry = geometry;
context.positions = z;
context.backgroundP = background;
context.tauP = background.tau;
context.activeMask = background.activeMask(:);
context.activeIndices = background.activeIndices(:);
context.incomingPhase = incomingPhase;
context.incomingDressed = context.tauP * incomingPhase;
context.transmissionPhaseMatrix = phases.transmission;
context.reflectionPhaseMatrix = phases.reflection;
context.transmissionETauP = phases.transmission * context.tauP;
context.reflectionETauP = phases.reflection * context.tauP;
context.transmissionTauPE = context.tauP * phases.transmission;
context.reflectionTauPE = context.tauP * phases.reflection;
context.transmissionOutgoingDressed = context.tauP.' ...
    * exp(-1i .* P .* z);
context.reflectionOutgoingDressed = context.tauP.' ...
    * exp(+1i .* P .* z);
context.configurationFingerprint = ndelta.config.physics_fingerprint(cfg);
context.externalTauArgument = P;
context.externalTauAppliedExactlyOncePerExternalBackgroundSegment = true;
context.containsNoFreeTransmissionIdentity = true;
context.status = 'stage11_fixed_external_background_context';
end
