function result = collective_residue_matrix(mode, qPerp, cfg, geometry)
%COLLECTIVE_RESIDUE_MATRIX Matrix residue of tau_N(kappaI(q0)).

narginchk(4, 4);
mapped = ndelta.singularity.map_collective_q0(mode, qPerp, cfg);
result = struct('accepted', false, ...
    'rejectionReason', 'outside_open_QI_support_or_unstable_mode', ...
    'mapping', mapped, 'q0', complex(NaN), ...
    'omega', complex(NaN), 'kappaI', mode.K, ...
    'residueTau', complex(zeros(geometry.N)), ...
    'nullResidual', Inf, 'projectedDerivativeRcond', 0, ...
    'projectedDerivativeScaledRcond', 0, ...
    'projectedDerivativeConditionThreshold', ...
    cfg.tolerances.nearSingularRcond);
if ~mapped.left.accepted
    return;
end
if isfield(mode, 'semisimple') && ~mode.semisimple
    result.rejectionReason = 'nonsemisimple_collective_mode';
    return;
end

q0 = mapped.left.q0;
K = mode.K;
active = mode.activeIndices(:);
V = mode.nullVectorsActive;
if isempty(V) || size(V, 2) ~= mode.nullity
    error('ndelta:stage11:InvalidCollectiveNullspace', ...
        'The collective mode has no valid active nullspace.');
end
zActive = geometry.positions(active);
gammaDerivativeK = ndelta.singularity.gamma_derivative_N(K, zActive);
dKdq0 = (q0 - cfg.referenceEnergy) ./ K;
derivativeQ0 = gammaDerivativeK .* dKdq0;
projected = V.' * derivativeQ0 * V;
result.projectedDerivativeQ0 = projected;
if any(~isfinite(derivativeQ0(:))) || any(~isfinite(projected(:)))
    result.rejectionReason = 'nonfinite_collective_projected_derivative';
    return;
end
scale = max(1, norm(derivativeQ0, 2));
result.projectedDerivativeQ0Scale = scale;
if ~isfinite(scale)
    result.rejectionReason = 'nonfinite_collective_projected_derivative';
    return;
end
reciprocalCondition = rcond(projected);
singularValues = svd(projected);
minimumSingularValue = min(singularValues);
scaledReciprocalCondition = minimumSingularValue ./ scale;
result.projectedDerivativeRcond = reciprocalCondition;
result.projectedDerivativeScaledRcond = scaledReciprocalCondition;
result.minimumProjectedDerivativeQ0 = minimumSingularValue;
if ~isfinite(reciprocalCondition) || ...
        ~isfinite(scaledReciprocalCondition) || ...
        reciprocalCondition <= 100 .* eps || ...
        minimumSingularValue <= 100 .* eps .* scale
    result.rejectionReason = 'nonsemisimple_or_multiple_q0_pole';
    return;
end
if reciprocalCondition < cfg.tolerances.nearSingularRcond || ...
        scaledReciprocalCondition < cfg.tolerances.nearSingularRcond
    result.rejectionReason = ...
        'near_singular_collective_projected_derivative';
    return;
end
residueActive = V * (projected \ V.');
residueTau = complex(zeros(geometry.N));
residueTau(active, active) = residueActive;
gammaAtPole = ndelta.background.build_gamma_N( ...
    K, zActive, cfg.barriers.strengths(active));
nullResidual = norm(gammaAtPole * V, 'fro') ./ ...
    (1 + norm(gammaAtPole, 'fro'));

result.accepted = nullResidual <= cfg.tolerances.collectiveResidual;
result.rejectionReason = '';
if ~result.accepted
    result.rejectionReason = 'collective_null_residual_failed';
end
result.q0 = q0;
result.omega = mapped.left.omega;
result.kappaI = K;
result.dKdq0 = dKdq0;
result.gammaDerivativeK = gammaDerivativeK;
result.residueTau = residueTau;
result.nullResidual = nullResidual;
result.includesQ0Measure = false;
result.includesMuSquared = false;
end
