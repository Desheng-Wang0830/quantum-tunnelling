function result = cut_fixed( ...
        termLabel, pointEvaluator, endpointEvaluator, qPerp, ...
        channelInput, cfg, geometry, context, options)
%CUT_FIXED One Stage 11 term's lower-minus-upper cut banks and endpoint.

narginchk(8, 9);
if nargin < 9
    options = struct();
end
channel = ndelta.g1.normalise_channel(channelInput);
options = ndelta.contour.resolve_options(cfg, options);
order = options.cutRadialOrder;
endpoint = endpointEvaluator(qPerp, channel, cfg, context);
result = struct('value', complex(0), 'bankContribution', complex(0), ...
    'endpointContribution', endpoint.keyholeContribution, ...
    'endpoint', endpoint, 'term', termLabel, 'channel', channel, ...
    'qPerp', qPerp, 'cutRadialOrder', order, ...
    'maximumTauEquationResidual', 0, ...
    'minimumTauScaledRcond', Inf, ...
    'maximumTauConditionAmplification', 0, ...
    'numberOfPointEvaluations', 0, ...
    'includesQ0Measure', true, 'includesQPerpMeasure', false, ...
    'endpointBelongsOnlyToCut', true, ...
    'status', 'not_evaluated');
if isempty(context.activeIndices)
    result.endpointContribution = complex(0);
    result.status = 'interaction_only_zero_at_all_inactive';
    return;
end
P = cfg.derived.P;
if qPerp >= P
    result.endpointContribution = complex(0);
    result.status = 'no_kappaI_left_cut_in_open_QI';
    return;
end
EphiSquared = qPerp.^2 + cfg.model.mphi.^2;
finiteCorrection = (cfg.sheet.epsilon ./ ...
    (2 .* cfg.referenceEnergy)).^2;
kappaMaximumSquared = P.^2 - qPerp.^2 - finiteCorrection;
if kappaMaximumSquared <= 0
    result.endpointContribution = complex(0);
    result.status = 'finite_epsilon_cut_segment_has_zero_length';
    return;
end
kappaMaximum = sqrt(kappaMaximumSquared);
[t, weights] = ndelta.numerics.unit_gauss_rule(order);
kappaNodes = kappaMaximum .* t;
kappaWeights = kappaMaximum .* weights;
bankBeforeMeasure = complex(0);
maximumResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
for index = 1:numel(kappaNodes)
    kappa = kappaNodes(index);
    radialEnergy = sqrt(EphiSquared + kappa.^2 ...
        - 1i .* cfg.sheet.epsilon);
    q0 = cfg.referenceEnergy - radialEnergy;
    roots = ndelta.sheet.physical_roots(q0, qPerp, ...
        cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
    [rawLower, lowerDetails] = pointEvaluator( ...
        roots.omega, +kappa, channel, cfg, geometry, context);
    [rawUpper, upperDetails] = pointEvaluator( ...
        roots.omega, -kappa, channel, cfg, geometry, context);
    lower = -rawLower;
    upper = -rawUpper;
    if endpoint.evenSubtractionEnabled && ...
            cfg.integration.cutEvenSubtraction
        evenTerm = -endpoint.backgroundContraction ./ ...
            (8 .* P .* (roots.omega.^2 - P.^2) .* kappa.^2);
        lower = lower - evenTerm;
        upper = upper - evenTerm;
    end
    mappedJump = kappa ./ radialEnergy .* (lower - upper);
    bankBeforeMeasure = bankBeforeMeasure + ...
        kappaWeights(index) .* mappedJump;
    maximumResidual = max([maximumResidual, ...
        lowerDetails.tauDiagnostics.normalisedEquationResidual, ...
        upperDetails.tauDiagnostics.normalisedEquationResidual]);
    minimumTauScaledRcond = min([minimumTauScaledRcond, ...
        lowerDetails.tauDiagnostics.scaledRcond, ...
        upperDetails.tauDiagnostics.scaledRcond]);
    maximumTauConditionAmplification = max([ ...
        maximumTauConditionAmplification, ...
        lowerDetails.tauDiagnostics.conditionAmplification, ...
        upperDetails.tauDiagnostics.conditionAmplification]);
end
result.bankBeforeQ0Measure = bankBeforeMeasure;
result.bankContribution = bankBeforeMeasure ./ (2 .* pi);
result.value = result.bankContribution + result.endpointContribution;
result.kappaMaximum = kappaMaximum;
result.maximumTauEquationResidual = maximumResidual;
result.minimumTauScaledRcond = minimumTauScaledRcond;
result.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
result.numberOfPointEvaluations = 2 .* numel(kappaNodes);
result.jumpConvention = 'lower_minus_upper';
result.status = 'stage11_fixed_qperp_cut_banks_plus_endpoint';
end
