function phases = build_channel_phases(positions, P)
%BUILD_CHANNEL_PHASES Build external transmission/reflection phase matrices.
%
%   E_chi(a,b)=exp(i P [z_a-sigma_chi z_b]), with sigma_T=+1 and
%   sigma_R=-1.  These phases contract with tau_N(b,a), never with a
%   complex-conjugated transpose.

narginchk(2, 2);
z = positions(:);
if isempty(z) || ~isnumeric(z) || ~isreal(z) || any(~isfinite(z))
    error('ndelta:geometry:InvalidPhasePositions', ...
        'positions must be a nonempty finite real vector.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');

za = z;
zb = z.';
phases = struct();
phases.sigmaTransmission = 1;
phases.sigmaReflection = -1;
phases.transmission = exp(1i .* P .* (za - zb));
phases.reflection = exp(1i .* P .* (za + zb));
end
