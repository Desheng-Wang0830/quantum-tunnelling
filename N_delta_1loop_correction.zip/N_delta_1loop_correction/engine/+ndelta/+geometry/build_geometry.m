function geometry = build_geometry(positions, relativeTolerance)
%BUILD_GEOMETRY Build directed distances D_ab=z_b-z_a and cache map.

narginchk(2, 2);
if ~isnumeric(positions) || isempty(positions) || ...
        ~isvector(positions) || ~isreal(positions) || ...
        any(~isfinite(positions(:)))
    error('ndelta:geometry:InvalidPositions', ...
        'positions must be a nonempty finite real vector.');
end
validateattributes(relativeTolerance, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'relativeTolerance');

z = positions(:);
N = numel(z);
directed = z.' - z;
if any(~isfinite(directed(:)))
    error('ndelta:geometry:DistanceOverflow', ...
        ['Finite positions produced a non-finite directed distance; ' ...
         'rescale the geometry before building its cache.']);
end
absolute = abs(directed);
[uniqueDirected, directedIndex, absoluteTolerance] = ...
    merge_distances(directed, relativeTolerance);

geometry = struct();
geometry.N = N;
geometry.positions = z;
geometry.directedDistances = directed;
geometry.absoluteDistances = absolute;
geometry.uniqueDirectedDistances = uniqueDirected;
geometry.directedDistanceIndex = directedIndex;
geometry.numberOfUniqueDirectedDistances = numel(uniqueDirected);
geometry.distanceMergeRelativeTolerance = relativeTolerance;
geometry.distanceMergeAbsoluteTolerance = absoluteTolerance;
geometry.distanceMergeScale = max(abs(directed(:)));
if geometry.distanceMergeScale == 0
    geometry.distanceMergeScale = 1;
end
geometry.distanceMergeRepresentative = ...
    'sorted_absolute_cluster_paired_mean';
geometry.distanceMergePermutationInvariant = true;
geometry.distanceMergeScaleInvariant = true;
geometry.distanceMergeSignSymmetric = true;
geometry.directedDistanceConvention = 'D(a,b)=z_b-z_a';
end

function [uniqueValues, indexMap, absoluteTolerance] = ...
        merge_distances(distanceMatrix, relativeTolerance)
values = distanceMatrix(:);
scale = max(abs(values));
if scale == 0
    scale = 1;
end
absoluteTolerance = relativeTolerance .* scale;
if ~isfinite(absoluteTolerance)
    error('ndelta:geometry:DistanceToleranceOverflow', ...
        ['relativeTolerance times the geometry scale must remain ' ...
         'finite.']);
end
flatIndex = zeros(size(values));
zeroIndices = find(values == 0);
nonzeroIndices = find(values ~= 0);

% Cluster absolute distances once.  Every nonzero directed distance has
% its opposite partner in z_b-z_a, so one magnitude representative is
% then emitted as an exact +/- pair.  This preserves Drep_ba=-Drep_ab in
% addition to label-permutation and overall-scale invariance.
[sortedMagnitudes, ordering] = sort(abs(values(nonzeroIndices)));
sortedIndices = nonzeroIndices(ordering);
clusterOfValue = zeros(size(values));
clusterMeans = zeros(0, 1);
if isempty(sortedMagnitudes)
    groupStarts = zeros(0, 1);
    groupEnds = zeros(0, 1);
else
    groupStarts = [1; find(diff(sortedMagnitudes) ~= 0) + 1];
    groupEnds = [groupStarts(2:end) - 1; numel(sortedMagnitudes)];
end
groupMagnitudes = sortedMagnitudes(groupStarts);
groupCounts = groupEnds - groupStarts + 1;
first = 1;
while first <= numel(groupMagnitudes)
    last = first;
    clusterMean = groupMagnitudes(first);
    clusterMinimum = groupMagnitudes(first);
    clusterMaximum = groupMagnitudes(first);
    clusterCount = groupCounts(first);
    while last < numel(groupMagnitudes)
        candidate = groupMagnitudes(last + 1);
        candidateMultiplicity = groupCounts(last + 1);
        candidateCount = clusterCount + candidateMultiplicity;
        candidateMean = clusterMean + ...
            (candidate - clusterMean) .* ...
            (candidateMultiplicity ./ candidateCount);
        candidateMinimum = min(clusterMinimum, candidate);
        candidateMaximum = max(clusterMaximum, candidate);
        if max(candidateMean - candidateMinimum, ...
                candidateMaximum - candidateMean) > absoluteTolerance
            break;
        end
        last = last + 1;
        clusterMean = candidateMean;
        clusterMinimum = candidateMinimum;
        clusterMaximum = candidateMaximum;
        clusterCount = candidateCount;
    end
    if clusterMinimum == clusterMaximum
        representative = clusterMinimum;
    else
        representative = clusterMean;
    end
    clusterMeans(end + 1, 1) = representative; %#ok<AGROW>
    occurrenceRange = groupStarts(first):groupEnds(last);
    clusterOfValue(sortedIndices(occurrenceRange)) = ...
        numel(clusterMeans);
    first = last + 1;
end

numberOfClusters = numel(clusterMeans);
uniqueValues = [-flipud(clusterMeans); 0; clusterMeans];
flatIndex(zeroIndices) = numberOfClusters + 1;
negativeIndices = find(values < 0);
positiveIndices = find(values > 0);
flatIndex(negativeIndices) = numberOfClusters - ...
    clusterOfValue(negativeIndices) + 1;
flatIndex(positiveIndices) = numberOfClusters + 1 + ...
    clusterOfValue(positiveIndices);
indexMap = reshape(flatIndex, size(distanceMatrix));
end
