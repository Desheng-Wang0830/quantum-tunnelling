function [tauFull, diagnostics] = solve_tau_endpoint_stable( ...
        K, geometry, strengths, switchK, nearSingularRcond)
%SOLVE_TAU_ENDPOINT_STABLE Evaluate tau_N without a false K=0 failure.
%
%   Gamma_N has one singular value proportional to 1/|K| at the branch
%   endpoint.  Its inverse is nevertheless finite on the orthogonal
%   centre subspace.  For small |K| this routine solves the exactly
%   row-scaled system in a uniform-mode/Helmert basis.  A singular scaled
%   system is a genuine zero-energy threshold and is not regularised.
%   When NEARSINGULARRCOND is supplied, both the ordinary and balanced
%   endpoint systems fail closed below that common reciprocal-condition
%   threshold.  Omitting it preserves the legacy hard-floor-only API.

narginchk(4, 5);
conditionGuardEnabled = nargin >= 5;
if conditionGuardEnabled
    validateattributes(nearSingularRcond, {'numeric'}, ...
        {'real', 'finite', 'positive', 'scalar'}, ...
        mfilename, 'nearSingularRcond');
else
    nearSingularRcond = 0;
end
if ~isnumeric(K) || ~isscalar(K) || K == 0 || ...
        ~isfinite(real(K)) || ~isfinite(imag(K))
    error('ndelta:background:InvalidEndpointK', ...
        'K must be one finite nonzero complex scalar.');
end
validateattributes(switchK, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'switchK');
if ~isstruct(geometry) || ~isscalar(geometry) || ...
        ~isfield(geometry, 'N') || ~isfield(geometry, 'positions')
    error('ndelta:background:InvalidEndpointGeometry', ...
        'geometry must be returned by ndelta.geometry.build_geometry.');
end
g = strengths(:);
if ~isnumeric(g) || numel(g) ~= geometry.N || ~isreal(g) || ...
        any(~isfinite(g))
    error('ndelta:background:InvalidEndpointStrengths', ...
        'strengths must be finite, real and match geometry.N.');
end

if isa(K, 'single')
    machineEpsilon = eps('single');
else
    machineEpsilon = eps;
end
hardFloor = 100 .* machineEpsilon;

activeMask = g ~= 0;
activeIndices = find(activeMask);
tauFull = complex(zeros(geometry.N));
diagnostics = struct();
diagnostics.K = K;
diagnostics.activeMask = activeMask;
diagnostics.activeIndices = activeIndices;
diagnostics.switchK = switchK;
diagnostics.conditionGuardEnabled = conditionGuardEnabled;
diagnostics.conditionGuardThreshold = nearSingularRcond;
diagnostics.hardSingularFloor = hardFloor;
diagnostics.usedEndpointScaledSolve = false;
diagnostics.method = 'empty_active_system';
diagnostics.rcond = Inf;
diagnostics.scaledRcond = Inf;
diagnostics.conditionAmplification = 0;
diagnostics.nearSingular = false;
diagnostics.normalisedEquationResidual = 0;
diagnostics.complexSymmetryResidual = 0;
if isempty(activeIndices)
    return;
end

z = geometry.positions(activeMask);
ga = g(activeMask);
n = numel(ga);
identity = eye(n);

if abs(K) > switchK
    gamma = ndelta.background.build_gamma_N(K, z, ga);
    reciprocalCondition = rcond(gamma);
    if ~isfinite(reciprocalCondition) || reciprocalCondition <= hardFloor
        error('ndelta:background:ContourGammaSingular', ...
            ['Gamma_N is singular at a non-endpoint contour node; ' ...
             'the node must be classified as a collective pole.']);
    end
    enforce_condition_guard(reciprocalCondition, nearSingularRcond, ...
        conditionGuardEnabled, 'ordinary Gamma_N');
    tauActive = gamma \ identity;
    equationResidual = norm(gamma * tauActive - identity, 'fro') ./ ...
        (1 + norm(gamma, 'fro') .* norm(tauActive, 'fro'));
    diagnostics.method = 'ordinary_gamma_solve';
    diagnostics.rcond = reciprocalCondition;
    diagnostics.scaledRcond = reciprocalCondition;
else
    distances = abs(z - z.');
    % A=2*K*Gamma.  EXPM1 avoids subtracting two nearly equal matrices.
    scaledGamma = -ones(n) + 2i .* K .* diag(1 ./ ga) ...
        - expm1(1i .* K .* distances);
    basis = helmert_basis(n);
    transformed = basis.' * scaledGamma * basis;
    rowScale = ones(n, 1);
    if n > 1
        rowScale(2:end) = 1 ./ K;
    end
    balanced = bsxfun(@times, rowScale, transformed);
    rightHandSide = diag([2 .* K, 2 .* ones(1, n - 1)]);
    reciprocalCondition = rcond(balanced);
    if ~isfinite(reciprocalCondition) || reciprocalCondition <= hardFloor
        error('ndelta:background:ZeroEnergyCollectiveThreshold', ...
            ['The endpoint-scaled Gamma_N system is singular.  This is ' ...
             'a zero-energy collective threshold, not a regular node.']);
    end
    enforce_condition_guard(reciprocalCondition, nearSingularRcond, ...
        conditionGuardEnabled, 'endpoint-scaled Gamma_N');
    transformedTau = balanced \ rightHandSide;
    tauActive = basis * transformedTau * basis.';
    equationResidual = norm( ...
        scaledGamma * tauActive - 2 .* K .* identity, 'fro') ./ ...
        (1 + norm(scaledGamma, 'fro') .* norm(tauActive, 'fro'));
    diagnostics.method = 'uniform_helmert_endpoint_scaled_solve';
    diagnostics.usedEndpointScaledSolve = true;
    diagnostics.rcond = rcond(scaledGamma);
    diagnostics.scaledRcond = reciprocalCondition;
    diagnostics.helmertOrthogonalityResidual = ...
        norm(basis.' * basis - identity, 'fro');
end

tauFull(activeMask, activeMask) = tauActive;
diagnostics.conditionAmplification = 1 ./ diagnostics.scaledRcond;
diagnostics.nearSingular = conditionGuardEnabled && ...
    diagnostics.scaledRcond < nearSingularRcond;
diagnostics.normalisedEquationResidual = equationResidual;
diagnostics.complexSymmetryResidual = norm(tauActive - tauActive.', 'fro') ./ ...
    (1 + norm(tauActive, 'fro'));
diagnostics.tauActive = tauActive;
end

function enforce_condition_guard( ...
        reciprocalCondition, nearSingularRcond, enabled, systemLabel)
if enabled && reciprocalCondition < nearSingularRcond
    error('ndelta:background:NearSingularContourGamma', ...
        ['The %s solve was rejected by the internal contour Gamma_N ' ...
         'condition guard: scaled rcond=%.3e, required rcond>=%.3e.'], ...
        systemLabel, reciprocalCondition, nearSingularRcond);
end
end

function basis = helmert_basis(n)
basis = zeros(n);
basis(:, 1) = ones(n, 1) ./ sqrt(n);
for column = 2:n
    k = column - 1;
    basis(1:k, column) = 1 ./ sqrt(k .* (k + 1));
    basis(k + 1, column) = -k ./ sqrt(k .* (k + 1));
end
end
