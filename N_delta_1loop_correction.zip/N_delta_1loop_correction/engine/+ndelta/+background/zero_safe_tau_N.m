function result = zero_safe_tau_N(K, positions, strengths, nearSingularRcond)
%ZERO_SAFE_TAU_N Equivalent full-N solve that permits exact g_a=0.
%
%   With G=diag(g_a), C_ab=exp(iK|z_a-z_b|)/(2K),
%
%       Gamma = i G^{-1} - C
%
%   on the active subspace.  Hence
%
%       tau = (I+i G C) \ (-i G).
%
%   This form remains defined when one or every g_a is exactly zero.  The
%   production result is cross-checked against the active Gamma solve.

narginchk(4, 4);
z = positions(:);
g = strengths(:);
if ~isnumeric(z) || ~isnumeric(g) || isempty(z) || ...
        numel(g) ~= numel(z) || ~isreal(z) || ~isreal(g) || ...
        any(~isfinite(z)) || any(~isfinite(g))
    error('ndelta:background:InvalidZeroSafeInputs', ...
        'positions and strengths must be matching finite real vectors.');
end
if ~isnumeric(K) || ~isscalar(K) || ...
        ~isfinite(real(K)) || ~isfinite(imag(K))
    error('ndelta:background:InvalidZeroSafeK', ...
        'K must be one finite scalar.');
end

N = numel(z);
G = diag(g);
activeMask = g ~= 0;
activeIndices = find(activeMask);
C = complex(zeros(N, N));
M = complex(eye(N));
tau = complex(zeros(N, N));
hardFloor = 100 .* eps(class(real(M)));

if isempty(activeIndices)
    reciprocalCondition = 1;
else
    if K == 0
        error('ndelta:background:InvalidZeroSafeK', ...
            'K must be nonzero when at least one centre is active.');
    end
    activePositions = z(activeMask);
    activeStrengths = g(activeMask);
    Cactive = exp(1i .* K .* abs( ...
        activePositions.' - activePositions)) ./ (2 .* K);
    Gactive = diag(activeStrengths);
    Mactive = eye(numel(activeIndices)) + 1i .* Gactive * Cactive;
    reciprocalCondition = rcond(Mactive);
    if ~isfinite(reciprocalCondition) || ...
            reciprocalCondition <= hardFloor
        error('ndelta:background:NumericallySingularZeroSafeSystem', ...
            'The zero-safe system is numerically singular: rcond=%.3e.', ...
            reciprocalCondition);
    end
    tauActive = Mactive \ (-1i .* Gactive);
    C(activeMask, activeMask) = Cactive;
    M(activeMask, activeMask) = Mactive;
    tau(activeMask, activeMask) = tauActive;
end
result = struct();
result.tau = tau;
result.systemMatrix = M;
result.freeCentreMatrix = C;
result.rcond = reciprocalCondition;
result.nearSingular = reciprocalCondition < nearSingularRcond;
result.solveResidualFro = norm(M * tau + 1i .* G, 'fro');
result.activeMask = activeMask;
result.activeIndices = activeIndices;
result.inactiveCrossBlocksOmittedExactly = true;
end
