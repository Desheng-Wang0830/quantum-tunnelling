function gamma = build_gamma_N(K, positions, activeStrengths)
%BUILD_GAMMA_N Construct the active-centre Gamma_N(K) matrix.
%
%   Gamma_ab = i/g_a delta_ab - exp(iK|z_a-z_b|)/(2K).
%
%   Exact zero strengths are handled one layer above by removing inactive
%   centres.  Passing a zero here is therefore a contract violation.

narginchk(3, 3);
validate_K(K);

z = positions(:);
g = activeStrengths(:);
if isempty(z) || ~isnumeric(z) || ~isreal(z) || any(~isfinite(z))
    error('ndelta:background:InvalidGammaPositions', ...
        'positions must be a nonempty finite real vector.');
end
if numel(g) ~= numel(z) || ~isnumeric(g) || ~isreal(g) || ...
        any(~isfinite(g))
    error('ndelta:background:InvalidGammaStrengths', ...
        'activeStrengths must be finite, real and match positions.');
end
if any(g == 0)
    error('ndelta:background:ZeroActiveStrength', ...
        ['build_gamma_N accepts active nonzero strengths only.  ' ...
         'Use background_kernel_N for zero-safe centre removal.']);
end

absoluteDistances = abs(z.' - z);
freeCentreMatrix = exp(1i .* K .* absoluteDistances) ./ (2 .* K);
gamma = diag(1i ./ g) - freeCentreMatrix;
end

function validate_K(K)
isValid = isnumeric(K) && isscalar(K) && isfinite(real(K)) && ...
    isfinite(imag(K)) && K ~= 0;
if ~isValid
    error('ndelta:background:InvalidK', ...
        'K must be one finite nonzero real or complex scalar.');
end
end
