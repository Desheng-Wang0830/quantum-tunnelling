function background = background_kernel_N( ...
        K, P, geometry, strengths, nearSingularRcond)
%BACKGROUND_KERNEL_N Evaluate tau_N and external-channel contractions.
%
%   B_N,chi = sum_ab E_chi(a,b) tau_N(b,a)
%           = trace(E_chi tau_N),
%
%   The tree-amplitude correction is B_N,chi/(2P).  B_N itself remains
%   unnormalised so later LSZ code cannot accidentally apply 1/(2P) twice.
%
%   K is the momentum entering Gamma_N.  Tree level uses K=P; later loop
%   stages may pass a physical-sheet complex K while retaining external P.

narginchk(5, 5);
if ~isstruct(geometry) || ~isscalar(geometry) || ...
        ~isfield(geometry, 'positions') || ~isfield(geometry, 'N')
    error('ndelta:background:InvalidGeometry', ...
        'geometry must be returned by ndelta.geometry.build_geometry.');
end
validateattributes(P, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'P');

g = strengths(:);
if ~isnumeric(g) || numel(g) ~= geometry.N || ...
        ~isreal(g) || any(~isfinite(g))
    error('ndelta:background:StrengthSizeMismatch', ...
        'strengths must be a finite real vector with geometry.N entries.');
end

N = geometry.N;
activeMask = g ~= 0;
activeIndices = find(activeMask);
tauFull = complex(zeros(N, N));
gammaActive = complex(zeros(0, 0));
activeSolution = empty_solution();

if ~isempty(activeIndices)
    gammaActive = ndelta.background.build_gamma_N( ...
        K, geometry.positions(activeMask), g(activeMask));
    activeSolution = ndelta.background.solve_tau_N( ...
        gammaActive, nearSingularRcond);
    tauFull(activeMask, activeMask) = activeSolution.tau;
end

zeroSafe = ndelta.background.zero_safe_tau_N( ...
    K, geometry.positions, g, nearSingularRcond);
gammaVsZeroSafeResidual = norm(tauFull - zeroSafe.tau, 'fro');
tauComparisonScale = max([1, norm(tauFull, 'fro'), ...
    norm(zeroSafe.tau, 'fro')]);
gammaVsZeroSafeRelativeResidual = ...
    gammaVsZeroSafeResidual ./ tauComparisonScale;

phases = ndelta.geometry.build_channel_phases(geometry.positions, P);
contractionT = trace(phases.transmission * tauFull);
contractionR = trace(phases.reflection * tauFull);
[explicitT, explicitR] = explicit_contractions(phases, tauFull);

background = struct();
background.K = K;
background.externalP = P;
background.activeMask = activeMask;
background.activeIndices = activeIndices;
background.numberOfActiveCentres = numel(activeIndices);
background.gammaActive = gammaActive;
background.tauActive = activeSolution.tau;
background.tau = tauFull;
background.zeroSafeTau = zeroSafe.tau;
background.zeroSafeSystem = zeroSafe;
background.solveDiagnostics = activeSolution;
background.gammaVsZeroSafeResidual = gammaVsZeroSafeResidual;
background.gammaVsZeroSafeRelativeResidual = ...
    gammaVsZeroSafeRelativeResidual;
background.gammaVsZeroSafeScale = tauComparisonScale;
background.phases = phases;
background.contractionTransmission = contractionT;
background.contractionReflection = contractionR;
background.explicitContractionTransmission = explicitT;
background.explicitContractionReflection = explicitR;
background.transmissionContractionResidual = contractionT - explicitT;
background.reflectionContractionResidual = contractionR - explicitR;
background.BNTransmission = contractionT;
background.BNReflection = contractionR;
background.BT = background.BNTransmission;
background.BR = background.BNReflection;
background.transmissionAmplitudeCorrection = ...
    background.BNTransmission ./ (2 .* P);
background.reflectionAmplitudeCorrection = ...
    background.BNReflection ./ (2 .* P);
end

function [valueT, valueR] = explicit_contractions(phases, tau)
N = size(tau, 1);
valueT = complex(0);
valueR = complex(0);
for a = 1:N
    for b = 1:N
        valueT = valueT + phases.transmission(a, b) .* tau(b, a);
        valueR = valueR + phases.reflection(a, b) .* tau(b, a);
    end
end
end

function value = empty_solution()
value = struct();
value.tau = complex(zeros(0, 0));
value.rcond = Inf;
value.nearSingular = false;
value.hardSingularFloor = 0;
value.minimumSingularValue = Inf;
value.maximumSingularValue = 0;
value.conditionNumber2 = 1;
value.singular = false;
value.leftInverseResidualFro = 0;
value.rightInverseResidualFro = 0;
value.inverseResidualFro = 0;
value.normalisedLeftInverseResidual = 0;
value.normalisedRightInverseResidual = 0;
value.complexSymmetryResidual = 0;
end
