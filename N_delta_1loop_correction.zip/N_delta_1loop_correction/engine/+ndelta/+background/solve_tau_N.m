function solution = solve_tau_N(gamma, nearSingularRcond)
%SOLVE_TAU_N Solve tau_N=Gamma_N\I without forming inv(Gamma_N).

narginchk(2, 2);
if ~isnumeric(gamma) || ndims(gamma) ~= 2 || ...
        size(gamma, 1) ~= size(gamma, 2) || isempty(gamma) || ...
        any(~isfinite(real(gamma(:)))) || ...
        any(~isfinite(imag(gamma(:))))
    error('ndelta:background:InvalidGamma', ...
        'gamma must be a nonempty finite square numeric matrix.');
end
validateattributes(nearSingularRcond, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'nearSingularRcond');

N = size(gamma, 1);
identity = eye(N);
reciprocalCondition = rcond(gamma);
hardFloor = 100 .* eps(class(real(gamma)));
if ~isfinite(reciprocalCondition) || reciprocalCondition <= hardFloor
    error('ndelta:background:NumericallySingularGamma', ...
        ['Gamma_N is numerically singular: rcond=%.3e, ' ...
         'hard floor=%.3e.'], reciprocalCondition, hardFloor);
end

tau = gamma \ identity;
singularValues = svd(gamma);
minimumSingularValue = min(singularValues);
maximumSingularValue = max(singularValues);

solution = struct();
solution.tau = tau;
solution.rcond = reciprocalCondition;
solution.nearSingular = reciprocalCondition < nearSingularRcond;
solution.hardSingularFloor = hardFloor;
solution.minimumSingularValue = minimumSingularValue;
solution.maximumSingularValue = maximumSingularValue;
solution.conditionNumber2 = maximumSingularValue ./ minimumSingularValue;
solution.singular = false;
solution.leftInverseResidualFro = norm(gamma * tau - identity, 'fro');
solution.rightInverseResidualFro = norm(tau * gamma - identity, 'fro');
solution.inverseResidualFro = solution.leftInverseResidualFro;
solution.normalisedLeftInverseResidual = ...
    solution.leftInverseResidualFro ./ ...
    (norm(gamma, 'fro') .* norm(tau, 'fro') + norm(identity, 'fro'));
solution.normalisedRightInverseResidual = ...
    solution.rightInverseResidualFro ./ ...
    (norm(gamma, 'fro') .* norm(tau, 'fro') + norm(identity, 'fro'));
solution.complexSymmetryResidual = norm(gamma - gamma.', 'fro');
end
