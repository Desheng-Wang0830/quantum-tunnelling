function result = cut_fixed(qPerp, channelInput, cfg, geometry, options)
%CUT_FIXED Fixed-qPerp kappaI-left-cut banks and endpoint keyhole.

narginchk(4, 5);
if nargin < 5
    options = struct();
end
channel = ndelta.g1.normalise_channel(channelInput);
options = ndelta.contour.resolve_options(cfg, options);
order = options.cutRadialOrder;
result = base_result(qPerp, channel, order);
P = cfg.derived.P;
if cfg.derived.numberOfActiveCentres == 0
    result.status = 'interaction_only_zero_at_all_inactive';
    return;
end
if qPerp >= P
    result.status = 'no_kappaI_left_cut_in_open_QI';
    return;
end
E = cfg.referenceEnergy;
epsilon = cfg.sheet.epsilon;
EphiSquared = qPerp.^2 + cfg.model.mphi.^2;
finiteEpsilonCorrection = (epsilon ./ (2 .* E)).^2;
kappaMaximumSquared = P.^2 - qPerp.^2 - finiteEpsilonCorrection;
if kappaMaximumSquared <= 0
    result.status = 'finite_epsilon_cut_segment_has_zero_length';
    return;
end
kappaMaximum = sqrt(kappaMaximumSquared);
[t, weights] = ndelta.numerics.unit_gauss_rule(order);
kappaNodes = kappaMaximum .* t;
kappaWeights = kappaMaximum .* weights;
bankBeforeQ0Measure = complex(0);
maximumTauResidual = 0;
minimumTauScaledRcond = Inf;
maximumTauConditionAmplification = 0;
maximumRegularisationRatio = 0;
for index = 1:numel(kappaNodes)
    kappa = kappaNodes(index);
    radialEnergy = sqrt(EphiSquared + kappa.^2 - 1i .* epsilon);
    q0 = E - radialEnergy;
    roots = ndelta.sheet.physical_roots( ...
        q0, qPerp, E, cfg.model, epsilon);
    [rawLower, lowerDetails] = ...
        ndelta.g1.contour_pair_contraction_from_roots( ...
        roots.omega, +kappa, P, channel, geometry, ...
        cfg.barriers.strengths, cfg);
    [rawUpper, upperDetails] = ...
        ndelta.g1.contour_pair_contraction_from_roots( ...
        roots.omega, -kappa, P, channel, geometry, ...
        cfg.barriers.strengths, cfg);
    lower = -rawLower;
    upper = -rawUpper;
    directDifference = lower - upper;
    regularisedDifference = directDifference;
    if channel == 'T' && cfg.integration.cutEvenSubtraction
        evenA = roots.omega.^2 + kappa.^2 - P.^2;
        universalEven = -1 ./ (2 .* evenA .* kappa.^2);
        lowerRegular = lower - universalEven;
        upperRegular = upper - universalEven;
        regularisedDifference = lowerRegular - upperRegular;
        maximumRegularisationRatio = max(maximumRegularisationRatio, ...
            abs(universalEven) ./ (1 + abs(lower) + abs(upper)));
    end
    mappedJump = kappa ./ radialEnergy .* regularisedDifference;
    bankBeforeQ0Measure = bankBeforeQ0Measure + ...
        kappaWeights(index) .* mappedJump;
    maximumTauResidual = max([maximumTauResidual, ...
        lowerDetails.tauDiagnostics.normalisedEquationResidual, ...
        upperDetails.tauDiagnostics.normalisedEquationResidual]);
    minimumTauScaledRcond = min([minimumTauScaledRcond, ...
        lowerDetails.tauDiagnostics.scaledRcond, ...
        upperDetails.tauDiagnostics.scaledRcond]);
    maximumTauConditionAmplification = max([ ...
        maximumTauConditionAmplification, ...
        lowerDetails.tauDiagnostics.conditionAmplification, ...
        upperDetails.tauDiagnostics.conditionAmplification]);
end

radialBranch = sqrt(EphiSquared - 1i .* epsilon);
q0Branch = E - radialBranch;
branchRoots = ndelta.sheet.physical_roots( ...
    q0Branch, qPerp, E, cfg.model, epsilon);
ABranch = branchRoots.omega.^2 - P.^2;
if channel == 'T'
    endpointResidue = 1 ./ (4 .* radialBranch .* ABranch);
    endpointArcBeforeQ0Measure = 2 .* pi .* 1i .* endpointResidue;
else
    endpointResidue = complex(0);
    endpointArcBeforeQ0Measure = complex(0);
end
bankContribution = bankBeforeQ0Measure ./ (2 .* pi);
endpointContribution = endpointArcBeforeQ0Measure ./ (2 .* pi);

result.value = bankContribution + endpointContribution;
result.bankContribution = bankContribution;
result.endpointContribution = endpointContribution;
result.bankBeforeQ0Measure = bankBeforeQ0Measure;
result.endpointArcBeforeQ0Measure = endpointArcBeforeQ0Measure;
result.endpointResidue = endpointResidue;
result.kappaMaximum = kappaMaximum;
result.q0Branch = q0Branch;
result.omegaBranch = branchRoots.omega;
result.ABranch = ABranch;
result.maximumTauEquationResidual = maximumTauResidual;
result.minimumTauScaledRcond = minimumTauScaledRcond;
result.maximumTauConditionAmplification = ...
    maximumTauConditionAmplification;
result.maximumEvenSubtractionRatio = maximumRegularisationRatio;
result.numberOfBankPairEvaluations = 2 .* order;
result.status = 'fixed_qperp_cut_banks_plus_endpoint_keyhole';
end

function result = base_result(qPerp, channel, order)
result = struct('value', complex(0), 'bankContribution', complex(0), ...
    'endpointContribution', complex(0), ...
    'bankBeforeQ0Measure', complex(0), ...
    'endpointArcBeforeQ0Measure', complex(0), ...
    'endpointResidue', complex(0), 'qPerp', qPerp, ...
    'channel', channel, 'cutRadialOrder', order, 'kappaMaximum', 0, ...
    'q0Branch', complex(NaN), 'omegaBranch', complex(NaN), ...
    'ABranch', complex(NaN), 'maximumTauEquationResidual', 0, ...
    'minimumTauScaledRcond', Inf, ...
    'maximumTauConditionAmplification', 0, ...
    'maximumEvenSubtractionRatio', 0, ...
    'numberOfBankPairEvaluations', 0, ...
    'jumpConvention', 'lower_minus_upper', ...
    'keyholeQ0WindingFraction', 1, ...
    'keyholeContributionRule', 'plus_i_times_endpoint_residue', ...
    'ordinarySimplePoleHalfIndentationFraction', 0.5, ...
    'ordinaryHalfIndentationUsedHere', false, ...
    'endpointBelongsOnlyToCut', true, ...
    'includesQ0Measure', true, 'includesQPerpMeasure', false, ...
    'includesMuSquared', false, 'includesLSZ', false, ...
    'status', 'not_evaluated');
end
