function result = fixed_qperp_g1(qPerp, channelInput, cfg, geometry, spectrum, options)
%FIXED_QPERP_G1 Complete Stage 7 modified-Wick source ledger.

narginchk(5, 6);
if nargin < 6
    options = struct();
end
channel = ndelta.g1.normalise_channel(channelInput);
options = ndelta.contour.resolve_options(cfg, options);
if spectrum.zeroEnergy.isZeroEnergyResonance
    error('ndelta:contour:ZeroEnergyEndpointUnsupported', ...
        ['The generic cut endpoint expansion is invalid at a ' ...
         'zero-energy collective threshold.']);
end
ledger = ndelta.singularity.g1_ledger(qPerp, cfg, geometry, spectrum);
euclidean = ndelta.contour.euclidean_fixed( ...
    qPerp, channel, cfg, geometry, options);
cut = ndelta.contour.cut_fixed( ...
    qPerp, channel, cfg, geometry, options);

collectiveValue = complex(0);
collectiveDetails = cell(numel(spectrum.modes), 1);
minimumProjectedRcond = Inf;
minimumProjectedScaledRcond = Inf;
for index = 1:numel(spectrum.modes)
    mode = spectrum.modes(index);
    item = ndelta.g1.collective_pole_residue( ...
        mode, qPerp, channel, cfg, geometry);
    collectiveDetails{index} = item;
    if item.accepted
        collectiveValue = collectiveValue + item.contourContribution;
        minimumProjectedRcond = min(minimumProjectedRcond, ...
            item.projectedDerivativeRcond);
        minimumProjectedScaledRcond = min( ...
            minimumProjectedScaledRcond, ...
            item.projectedDerivativeScaledRcond);
    elseif mode.stable && mode.hasOpenTransverseSupport && ...
            qPerp < mode.qPerpCritical
        error('ndelta:contour:InteriorCollectiveResidueRejected', ...
            ['A G1 collective mode expected inside its open support ' ...
             'was rejected by the matrix-residue gate.']);
    end
end
ordinaryValue = complex(0);
total = euclidean.value + ordinaryValue + collectiveValue + cut.value;

result = struct();
result.value = complex(real(total), imag(total));
result.qPerp = qPerp;
result.channel = channel;
result.ledger = ledger;
result.components = struct('euclidean', euclidean.value, ...
    'ordinaryPole', ordinaryValue, ...
    'collectivePole', collectiveValue, ...
    'cutBanks', cut.bankContribution, ...
    'endpointKeyhole', cut.endpointContribution, ...
    'cutTotal', cut.value, 'total', total);
result.euclidean = euclidean;
result.collective = collectiveDetails;
result.minimumCollectiveProjectedRcond = minimumProjectedRcond;
result.minimumCollectiveProjectedScaledRcond = ...
    minimumProjectedScaledRcond;
result.collectiveConditionAccepted = ...
    minimumProjectedRcond >= cfg.tolerances.nearSingularRcond && ...
    minimumProjectedScaledRcond >= cfg.tolerances.nearSingularRcond;
result.cut = cut;
result.ordinaryPoleIsMixedPole = true;
result.mixedPoleExactlyZero = true;
result.oldSingleDeltaBarrierCountedOnlyAsCollective = true;
result.fourPieceClosureResidual = abs(total - ...
    (euclidean.value + ordinaryValue + collectiveValue + cut.value)) ./ ...
    (1 + abs(total));
result.cutClosureResidual = abs(cut.value - ...
    cut.bankContribution - cut.endpointContribution) ./ ...
    (1 + abs(cut.value));
result.includesQ0Measure = true;
result.includesQPerpMeasure = false;
result.includesMuSquared = false;
result.includesLSZ = false;
result.kernelConvention = 'F_code=-F_Stage6_raw';
result.status = 'complete_fixed_qperp_modified_wick_ledger';
end
