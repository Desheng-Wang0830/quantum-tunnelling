function resolved = resolve_options(cfg, options)
%RESOLVE_OPTIONS Canonicalise fixed-qPerp contour quadrature options.

narginchk(1, 2);
if nargin < 2
    options = struct();
end
if ~isstruct(options) || ~isscalar(options)
    error('ndelta:contour:InvalidOptions', ...
        'options must be a scalar structure.');
end

canonicalNames = {'q4Order', 'q4Scale', 'q4MapPower', ...
    'cutRadialOrder'};
acceptedNames = [canonicalNames, {'cutOrder'}];
unknownNames = setdiff(fieldnames(options), acceptedNames);
if ~isempty(unknownNames)
    error('ndelta:contour:UnknownOption', ...
        'Unknown contour option(s): %s.', strjoin(unknownNames, ', '));
end
if isfield(options, 'cutOrder') && isfield(options, 'cutRadialOrder') && ...
        ~isequaln(options.cutOrder, options.cutRadialOrder)
    error('ndelta:contour:ConflictingCutOrderAliases', ...
        ['cutOrder and cutRadialOrder were both supplied with ' ...
         'different values.']);
end
if ~isstruct(cfg) || ~isscalar(cfg) || ...
        ~isfield(cfg, 'integration') || ...
        ~isstruct(cfg.integration) || ~isscalar(cfg.integration)
    error('ndelta:contour:InvalidOptionsConfiguration', ...
        'cfg.integration must be a scalar structure.');
end

resolved = struct();
resolved.q4Order = resolve_one('q4Order');
resolved.q4Scale = resolve_one('q4Scale');
resolved.q4MapPower = resolve_one('q4MapPower');
if isfield(options, 'cutRadialOrder')
    resolved.cutRadialOrder = options.cutRadialOrder;
elseif isfield(options, 'cutOrder')
    resolved.cutRadialOrder = options.cutOrder;
else
    resolved.cutRadialOrder = resolve_one('cutRadialOrder');
end

validateattributes(resolved.q4Order, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'options.q4Order');
validateattributes(resolved.cutRadialOrder, {'numeric'}, ...
    {'real', 'finite', 'integer', '>=', 4, 'scalar'}, ...
    mfilename, 'options.cutRadialOrder');
validateattributes(resolved.q4Scale, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'options.q4Scale');
validateattributes(resolved.q4MapPower, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, ...
    mfilename, 'options.q4MapPower');

    function value = resolve_one(name)
        if isfield(options, name)
            value = options.(name);
        elseif isfield(cfg.integration, name)
            value = cfg.integration.(name);
        else
            error('ndelta:contour:InvalidOptionsConfiguration', ...
                'Missing cfg.integration.%s default.', name);
        end
    end
end
