function files = write_stage0_11_outputs(cfg, result)
%WRITE_STAGE0_11_OUTPUTS Save cumulative Stage 0--11 diagnostics.

narginchk(2, 2);
legacyCfg = cfg;
legacyCfg.output.writeTextReport = false;
legacyCfg.output.saveMatFile = false;
files = ndelta.reporting.write_stage0_10_outputs(legacyCfg, result);
outputDirectory = files.outputDirectory;
files.stage11PointwiseCsv = fullfile(outputDirectory, ...
    'stage11_pointwise_G2_G3_G4.csv');
files.stage11IntegratedCsv = fullfile(outputDirectory, ...
    'stage11_integrated_sources.csv');
files.stage11AmplitudeCsv = fullfile(outputDirectory, ...
    'stage11_complete_amplitudes.csv');
files.stage11ValidationCsv = fullfile(outputDirectory, ...
    'stage11_validation_records.csv');
files.report = fullfile(outputDirectory, ...
    'STAGE0_11_VALIDATION_REPORT.txt');
files.mat = '';

write_pointwise(files.stage11PointwiseCsv, result.stage11);
write_integrated(files.stage11IntegratedCsv, result.stage11);
write_amplitudes(files.stage11AmplitudeCsv, result.stage11);
write_checks(files.stage11ValidationCsv, ...
    result.stage11.validation.records);
if cfg.output.writeTextReport
    write_report(files.report, cfg, result);
else
    files.report = '';
end
if cfg.output.saveMatFile
    files.mat = fullfile(outputDirectory, ...
        'N_delta_stage0_11_results.mat');
    result.outputFiles = files;
    save(files.mat, 'cfg', 'result', '-v7');
end
end

function write_pointwise(path, stage11)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['channel,term,optimised_raw_real,' ...
    'optimised_raw_imag,explicit_raw_real,explicit_raw_imag,' ...
    'relative_error\n']);
for channelIndex = 1:2
    if channelIndex == 1
        channelName = 'transmission';
        channelLabel = 'T';
    else
        channelName = 'reflection';
        channelLabel = 'R';
    end
    item = stage11.pointwise.(channelName);
    for termIndex = 2:4
        label = sprintf('G%d', termIndex);
        actual = item.([label 'Raw']);
        reference = item.([label 'ReferenceRaw']);
        relativeError = abs(actual - reference) ./ (1 + abs(reference));
        fprintf(fileId, '%s,%s,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
            channelLabel, label, real(actual), imag(actual), ...
            real(reference), imag(reference), relativeError);
    end
end
end

function write_integrated(path, stage11)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['term,channel,source,real_value,imag_value,' ...
    'included_in_total\n']);
for termCell = {'G2', 'G3', 'G4'}
    term = termCell{1};
    item = stage11.integrated.(term);
    for channelIndex = 1:2
        if channelIndex == 1, channel = 'T'; else, channel = 'R'; end
        for sourceIndex = 1:numel(item.sourceNames)
            value = item.sourceMatrix(channelIndex, sourceIndex);
            fprintf(fileId, '%s,%s,%s,%.17g,%.17g,1\n', ...
                term, channel, item.sourceNames{sourceIndex}, ...
                real(value), imag(value));
        end
        total = item.values(channelIndex);
        fprintf(fileId, '%s,%s,total,%.17g,%.17g,0\n', ...
            term, channel, real(total), imag(total));
    end
end
end

function write_amplitudes(path, stage11)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['term,channel,K_real,K_imag,deltaA_real,' ...
    'deltaA_imag,delta_probability\n']);
terms = {'G1', 'G2', 'G3', 'G4'};
for termIndex = 1:4
    for channelIndex = 1:2
        if channelIndex == 1, channel = 'T'; else, channel = 'R'; end
        fprintf(fileId, '%s,%s,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
            terms{termIndex}, channel, ...
            real(stage11.termKernelMatrix(termIndex, channelIndex)), ...
            imag(stage11.termKernelMatrix(termIndex, channelIndex)), ...
            real(stage11.termDeltaAmplitudeMatrix(termIndex, channelIndex)), ...
            imag(stage11.termDeltaAmplitudeMatrix(termIndex, channelIndex)), ...
            stage11.combined.termDeltaProbabilityMatrix( ...
            termIndex, channelIndex));
    end
end
for channelIndex = 1:2
    if channelIndex == 1, channel = 'T'; else, channel = 'R'; end
    fprintf(fileId, 'total,%s,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
        channel, ...
        real(stage11.combined.totalReducedKernelsPerMu2(channelIndex)), ...
        imag(stage11.combined.totalReducedKernelsPerMu2(channelIndex)), ...
        real(stage11.totalDeltaAmplitudes(channelIndex)), ...
        imag(stage11.totalDeltaAmplitudes(channelIndex)), ...
        stage11.totalDeltaProbabilities(channelIndex));
end
end

function write_checks(path, records)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, 'name,error,tolerance,normalised_error,passed\n');
for index = 1:numel(records)
    item = records(index);
    fprintf(fileId, '%s,%.17g,%.17g,%.17g,%d\n', item.name, ...
        item.error, item.tolerance, item.normalisedError, item.passed);
end
end

function write_report(path, cfg, result)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
stage11 = result.stage11;
release = ndelta.config.release_contract();
releaseLabel = release.releaseLabel;
if isfield(result, 'release')
    releaseLabel = result.release;
end
fprintf(fileId, 'N-delta Stage 0--11 complete Rose validation report\n');
fprintf(fileId, '==================================================\n\n');
fprintf(fileId, 'Release: %s\n', releaseLabel);
fprintf(fileId, 'Configuration version: %.1f\n', cfg.configurationVersion);
fprintf(fileId, 'E=%.17g, P=%.17g, N=%d, active=%d\n', ...
    cfg.referenceEnergy, cfg.derived.P, cfg.derived.N, ...
    cfg.derived.numberOfActiveCentres);
fprintf(fileId, 'Stage 11 portable checks: %d/%d\n', ...
    stage11.validation.numberPassed, ...
    stage11.validation.numberOfChecks);
fprintf(fileId, 'Pointwise node: q0=%.17g %+.17gi, qPerp=%.17g\n', ...
    real(cfg.stage11.referenceQ0), imag(cfg.stage11.referenceQ0), ...
    cfg.stage11.referenceQPerp);
fprintf(fileId, 'Maximum independent comparison-order error: %.6e\n\n', ...
    stage11.comparison.maximumError);
for termCell = {'G2', 'G3', 'G4'}
    term = termCell{1};
    value = stage11.integrated.(term).values;
    fprintf(fileId, 'K_%s,T=%.17g %+.17gi\n', ...
        term, real(value(1)), imag(value(1)));
    fprintf(fileId, 'K_%s,R=%.17g %+.17gi\n', ...
        term, real(value(2)), imag(value(2)));
end
fprintf(fileId, '\nComplete strict-O(mu^2) correction:\n');
fprintf(fileId, 'deltaT=%.17g\n', ...
    stage11.totalDeltaProbabilities(1));
fprintf(fileId, 'deltaR=%.17g\n', ...
    stage11.totalDeltaProbabilities(2));
fprintf(fileId, 'deltaT+deltaR=%.17g\n', ...
    stage11.combined.unitarity.oneLoopInterferenceClosure);
fprintf(fileId, '|deltaA|^2 and all O(mu^4) terms are excluded.\n');
fprintf(fileId, ['G2/G3 keep distinct ordered contractions; G4 keeps ' ...
    'tau_P*tau_I*tau_P.\n']);
fprintf(fileId, ['Stage 11 performs no energy scan and no dedicated ' ...
    'N>=3 physics scan.\n']);
end

function fileId = open_file(path)
fileId = fopen(path, 'w');
if fileId < 0
    error('ndelta:reporting:OpenFailure', ...
        'Could not open output file %s.', path);
end
end
