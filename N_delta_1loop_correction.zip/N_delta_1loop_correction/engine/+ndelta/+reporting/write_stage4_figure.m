function path = write_stage4_figure(outputDirectory, stage4)
%WRITE_STAGE4_FIGURE Plot exact cuts and real-axis physical roots.

narginchk(2, 2);
if ~exist(outputDirectory, 'dir')
    mkdir(outputDirectory);
end
path = fullfile(outputDirectory, 'stage4_physical_sheet_map.png');

fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [100, 100, 1180, 520]);
cleanup = onCleanup(@() close(fig)); %#ok<NASGU>

cuts = stage4.cutCurves;
points = stage4.branchPoints;

subplot(1, 2, 1);
hold on;
plot(real(cuts.omega.left), imag(cuts.omega.left), ...
    'b-', 'LineWidth', 1.5);
plot(real(cuts.omega.right), imag(cuts.omega.right), ...
    'b--', 'LineWidth', 1.5);
plot(real(cuts.kappaI.left), imag(cuts.kappaI.left), ...
    'r-', 'LineWidth', 1.5);
plot(real(cuts.kappaI.right), imag(cuts.kappaI.right), ...
    'r--', 'LineWidth', 1.5);
plot(real([points.omega.left, points.omega.right]), ...
    imag([points.omega.left, points.omega.right]), ...
    'bo', 'MarkerFaceColor', 'b');
plot(real([points.kappaI.left, points.kappaI.right]), ...
    imag([points.kappaI.left, points.kappaI.right]), ...
    'ro', 'MarkerFaceColor', 'r');
plot(xlim, [0, 0], 'k:', 'HandleVisibility', 'off');
plot([0, 0], ylim, 'k:', 'HandleVisibility', 'off');
grid on;
box on;
xlabel('Re q^0');
ylabel('Im q^0');
title('Exact finite-epsilon outward cuts');
legend({'Omega left', 'Omega right', 'kappaI left', ...
    'kappaI right', 'Omega endpoints', 'kappaI endpoints'}, ...
    'Location', 'best');

subplot(1, 2, 2);
q0 = real(stage4.realAxisRoots.q0);
plot(q0, real(stage4.realAxisRoots.omega), ...
    'b-', 'LineWidth', 1.2);
hold on;
plot(q0, imag(stage4.realAxisRoots.omega), ...
    'b--', 'LineWidth', 1.2);
plot(q0, real(stage4.realAxisRoots.kappaI), ...
    'r-', 'LineWidth', 1.2);
plot(q0, imag(stage4.realAxisRoots.kappaI), ...
    'r--', 'LineWidth', 1.2);
grid on;
box on;
xlabel('real q^0');
ylabel('root value');
title('Physical-sheet values on the Feynman real axis');
legend({'Re Omega', 'Im Omega', 'Re kappaI', 'Im kappaI'}, ...
    'Location', 'best');

print(fig, path, '-dpng', '-r180');
if ~exist(path, 'file')
    error('ndelta:reporting:Stage4FigureMissing', ...
        'MATLAB print returned without creating %s.', path);
end
end
