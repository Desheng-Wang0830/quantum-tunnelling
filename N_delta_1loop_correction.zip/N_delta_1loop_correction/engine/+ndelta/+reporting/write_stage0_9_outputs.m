function files = write_stage0_9_outputs(cfg, result)
%WRITE_STAGE0_9_OUTPUTS Save source-resolved Stage 0--9 diagnostics.

narginchk(2, 2);
baseCfg = cfg;
baseCfg.output.writeTextReport = false;
baseCfg.output.saveMatFile = false;
files = ndelta.reporting.write_stage0_6_outputs(baseCfg, result);
outputDirectory = files.outputDirectory;
files.collectiveModesCsv = fullfile(outputDirectory, ...
    'stage7_collective_modes.csv');
files.fixedContourCsv = fullfile(outputDirectory, ...
    'stage7_fixed_qperp_components.csv');
files.stage7ValidationCsv = fullfile(outputDirectory, ...
    'stage7_validation_records.csv');
files.integratedComponentsCsv = fullfile(outputDirectory, ...
    'stage8_integrated_components.csv');
files.stage8ValidationCsv = fullfile(outputDirectory, ...
    'stage8_validation_records.csv');
files.probabilitiesCsv = fullfile(outputDirectory, ...
    'stage9_g1_probabilities.csv');
files.stage9ValidationCsv = fullfile(outputDirectory, ...
    'stage9_validation_records.csv');
files.report = fullfile(outputDirectory, ...
    'STAGE0_9_VALIDATION_REPORT.txt');
files.mat = '';
files.stage9Figure = '';

write_modes(files.collectiveModesCsv, result.stage7.spectrum);
write_fixed(files.fixedContourCsv, result.stage7);
write_checks(files.stage7ValidationCsv, result.stage7.validation.records);
write_integrated(files.integratedComponentsCsv, result.stage8);
write_checks(files.stage8ValidationCsv, result.stage8.validation.records);
write_probabilities(files.probabilitiesCsv, result.stage9);
write_checks(files.stage9ValidationCsv, result.stage9.validation.records);
if cfg.output.writeTextReport
    write_report(files.report, cfg, result);
else
    files.report = '';
end
if cfg.output.writeStage9Figure
    try
        files.stage9Figure = write_figure(outputDirectory, result);
    catch exception
        warning('ndelta:reporting:Stage9FigureFailure', ...
            'Could not write the Stage 9 figure: %s', exception.message);
        files.stage9Figure = '';
    end
end
if cfg.output.saveMatFile
    files.mat = fullfile(outputDirectory, 'N_delta_stage0_9_results.mat');
    result.outputFiles = files;
    save(files.mat, 'cfg', 'result', '-v7');
end
end

function write_modes(path, spectrum)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['mode,label,alpha,K_real,K_imag,multiplicity,' ...
    'semisimple,simple,stable,qperp_critical,root_residual\n']);
for index = 1:numel(spectrum.modes)
    mode = spectrum.modes(index);
    fprintf(fileId, ...
        '%d,%s,%.17g,%.17g,%.17g,%d,%d,%d,%d,%.17g,%.17g\n', ...
        mode.index, mode.label, mode.alpha, real(mode.K), imag(mode.K), ...
        mode.multiplicity, mode.semisimple, mode.simple, mode.stable, ...
        mode.qPerpCritical, mode.rootResidual);
end
end

function write_fixed(path, stage7)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['channel,qperp,source,real_value,imag_value,' ...
    'included_in_total\n']);
write_channel('T', stage7.transmission);
write_channel('R', stage7.reflection);
    function write_channel(channel, item)
        names = {'euclidean', 'ordinaryPole', 'collectivePole', ...
            'cutBanks', 'endpointKeyhole', 'cutTotal', 'total'};
        included = [1, 1, 1, 0, 0, 1, 0];
        for n = 1:numel(names)
            value = item.components.(names{n});
            fprintf(fileId, '%s,%.17g,%s,%.17g,%.17g,%d\n', ...
                channel, item.qPerp, names{n}, real(value), ...
                imag(value), included(n));
        end
    end
end

function write_integrated(path, stage8)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['channel,source,real_value,imag_value,' ...
    'included_in_total\n']);
write_channel('T', stage8.transmission);
write_channel('R', stage8.reflection);
    function write_channel(channel, item)
        names = {'euclidean', 'ordinaryPole', 'collectivePole', ...
            'cutBanks', 'endpointKeyhole', 'cutTotal', 'total'};
        values = [item.euclidean.value, item.ordinaryPole, ...
            item.collectivePole.value, item.cut.bankContribution, ...
            item.cut.endpointContribution, item.cut.value, item.value];
        included = [1, 1, 1, 0, 0, 1, 0];
        for n = 1:numel(names)
            fprintf(fileId, '%s,%s,%.17g,%.17g,%d\n', ...
                channel, names{n}, real(values(n)), imag(values(n)), ...
                included(n));
        end
    end
end

function write_probabilities(path, stage9)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, ['channel,tree_probability,K_real,K_imag,' ...
    'deltaA_real,deltaA_imag,delta_probability,' ...
    'truncated_probability\n']);
write_one('T', stage9.transmission);
write_one('R', stage9.reflection);
    function write_one(channel, item)
        fprintf(fileId, '%s,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
            channel, item.treeProbability, real(item.reducedKernelPerMu2), ...
            imag(item.reducedKernelPerMu2), real(item.deltaAmplitude), ...
            imag(item.deltaAmplitude), item.deltaProbability, ...
            item.truncatedProbability);
    end
end

function write_report(path, cfg, result)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, 'N-delta Stage 0--9 G1 validation report\n');
fprintf(fileId, '=======================================\n\n');
fprintf(fileId, 'Configuration version: %.1f\n', cfg.configurationVersion);
fprintf(fileId, 'E=%.17g, P=%.17g, N=%d, active=%d\n', ...
    cfg.referenceEnergy, cfg.derived.P, cfg.derived.N, ...
    cfg.derived.numberOfActiveCentres);
fprintf(fileId, 'Collective modes: %d (stable: %d)\n', ...
    result.stage7.spectrum.numberOfModes, ...
    result.stage7.spectrum.numberOfStableModes);
for index = 1:numel(result.stage7.spectrum.modes)
    mode = result.stage7.spectrum.modes(index);
    fprintf(fileId, '  mode %d [%s]: alpha=%.17g, qcrit=%.17g\n', ...
        mode.index, mode.label, mode.alpha, mode.qPerpCritical);
end
fprintf(fileId, 'Stage 7 portable checks: %d/%d\n', ...
    result.stage7.validation.numberPassed, ...
    result.stage7.validation.numberOfChecks);
fprintf(fileId, 'Stage 8 portable checks: %d/%d\n', ...
    result.stage8.validation.numberPassed, ...
    result.stage8.validation.numberOfChecks);
fprintf(fileId, 'Stage 9 portable checks: %d/%d\n', ...
    result.stage9.validation.numberPassed, ...
    result.stage9.validation.numberOfChecks);
fprintf(fileId, '\nEndpoint rule: square-root keyhole full q0 winding (+iR).\n');
fprintf(fileId, 'Ordinary simple-pole half indentation (+iR/2) is not used here.\n');
fprintf(fileId, '\nK_T=%.17g %+.17gi\n', ...
    real(result.stage8.transmission.value), ...
    imag(result.stage8.transmission.value));
fprintf(fileId, 'K_R=%.17g %+.17gi\n', ...
    real(result.stage8.reflection.value), ...
    imag(result.stage8.reflection.value));
fprintf(fileId, 'deltaA_T=%.17g %+.17gi\n', ...
    real(result.stage9.transmission.deltaAmplitude), ...
    imag(result.stage9.transmission.deltaAmplitude));
fprintf(fileId, 'deltaA_R=%.17g %+.17gi\n', ...
    real(result.stage9.reflection.deltaAmplitude), ...
    imag(result.stage9.reflection.deltaAmplitude));
fprintf(fileId, 'DeltaT_G1=%+.17g\n', ...
    result.stage9.transmission.deltaProbability);
fprintf(fileId, 'DeltaR_G1=%+.17g\n', ...
    result.stage9.reflection.deltaProbability);
fprintf(fileId, '\nOnly G1 is included; G1 alone is not required to close unitarity.\n');
fprintf(fileId, '|deltaA|^2 is excluded because it is O(mu^4).\n');
end

function write_checks(path, records)
fileId = open_file(path);
cleanup = onCleanup(@() fclose(fileId)); %#ok<NASGU>
fprintf(fileId, 'check,error,tolerance,normalised_error,passed\n');
for index = 1:numel(records)
    item = records(index);
    fprintf(fileId, '"%s",%.17g,%.17g,%.17g,%d\n', ...
        item.name, item.error, item.tolerance, ...
        item.normalisedError, item.passed);
end
end

function path = write_figure(outputDirectory, result)
figureHandle = figure('Visible', 'off', 'Color', 'w');
cleanup = onCleanup(@() close(figureHandle)); %#ok<NASGU>
subplot(1, 2, 1);
bar(abs(result.stage8.componentMatrix));
set(gca, 'XTickLabel', {'T', 'R'});
ylabel('|K source|');
title('G1 reduced-kernel sources');
legend(result.stage8.componentNames, 'Location', 'best');
grid on;
subplot(1, 2, 2);
bar([result.stage9.deltaProbabilities(:), ...
    result.stage9.truncatedProbabilities(:)]);
set(gca, 'XTickLabel', {'T', 'R'});
ylabel('probability');
title('Strict O(mu^2) result');
legend({'Delta P_{G1}', 'P_0+Delta P_{G1}'}, 'Location', 'best');
grid on;
path = fullfile(outputDirectory, 'stage9_g1_components.png');
print(figureHandle, path, '-dpng', '-r180');
end

function fileId = open_file(path)
fileId = fopen(path, 'w');
if fileId < 0
    error('ndelta:reporting:CannotOpenOutput', ...
        'Could not open output file %s.', path);
end
end
