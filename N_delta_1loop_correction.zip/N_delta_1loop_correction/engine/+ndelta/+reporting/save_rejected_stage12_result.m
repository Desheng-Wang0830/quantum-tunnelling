function path = save_rejected_stage12_result(cfg, result)
%SAVE_REJECTED_STAGE12_RESULT Atomically preserve the complete failed run.

narginchk(2, 2);
cfg = ndelta.config.finalize_configuration(cfg);
if ~isstruct(result) || ~isscalar(result) || ...
        ~isfield(result, 'stage12') || ...
        ~isstruct(result.stage12) || result.stage12.accepted
    error('ndelta:reporting:InvalidRejectedStage12Result', ...
        'A fully assembled rejected Stage 12 result is required.');
end
directory = fullfile(cfg.projectRoot, char(cfg.output.directoryName), ...
    'stage12_checkpoints');
path = fullfile(directory, 'stage12_rejected_full_result.mat');
recoveryMetadata = struct();
recoveryMetadata.schema = 'N_delta_stage12_rejected_full_result_v1';
recoveryMetadata.savedAt = datestr(now, 30);
recoveryMetadata.path = path;
recoveryMetadata.status = result.stage12.status;
recoveryMetadata.validation = result.stage12.validation;
variables = struct('cfg', cfg, 'result', result, ...
    'recoveryMetadata', recoveryMetadata);
ndelta.stage12.atomic_save(path, variables);
fprintf('Stage 12 rejected-result checkpoint SAVED: %s\n', path);
end
