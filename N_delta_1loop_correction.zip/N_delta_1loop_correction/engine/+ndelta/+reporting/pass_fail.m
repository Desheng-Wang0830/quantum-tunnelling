function label = pass_fail(value)
%PASS_FAIL Convert a logical scalar to a stable report label.

if value
    label = 'PASS';
else
    label = 'FAIL';
end
end
