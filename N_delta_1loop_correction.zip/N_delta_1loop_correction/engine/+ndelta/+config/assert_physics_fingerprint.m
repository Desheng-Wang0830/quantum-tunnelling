function assert_physics_fingerprint(actual, cfg, identifier)
%ASSERT_PHYSICS_FINGERPRINT Reject stale Stage 7--11 intermediates.

narginchk(3, 3);
if ~(ischar(identifier) || (isstring(identifier) && isscalar(identifier)))
    error('ndelta:config:InvalidFingerprintIdentifier', ...
        'identifier must be a character vector or scalar string.');
end
expected = ndelta.config.physics_fingerprint(cfg);
if ~isstruct(actual) || ~isscalar(actual) || ~isequaln(actual, expected)
    error(char(identifier), ...
        ['A supplied Stage 7--11 intermediate belongs to a different ' ...
         'physical configuration. Recompute the upstream stage.']);
end
end
