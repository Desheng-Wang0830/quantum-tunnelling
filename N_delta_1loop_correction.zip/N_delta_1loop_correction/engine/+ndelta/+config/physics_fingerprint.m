function fingerprint = physics_fingerprint(cfg)
%PHYSICS_FINGERPRINT Immutable Stage 7--11 physical configuration identity.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
fingerprint = struct();
fingerprint.version = 1;
fingerprint.referenceEnergy = cfg.referenceEnergy;
fingerprint.mphi = cfg.model.mphi;
fingerprint.mPhi = cfg.model.mPhi;
fingerprint.sheetEpsilon = cfg.sheet.epsilon;
fingerprint.positions = cfg.barriers.positions;
fingerprint.strengths = cfg.barriers.strengths;
fingerprint.distanceMerge = cfg.tolerances.distanceMerge;
fingerprint.P = cfg.derived.P;
end
