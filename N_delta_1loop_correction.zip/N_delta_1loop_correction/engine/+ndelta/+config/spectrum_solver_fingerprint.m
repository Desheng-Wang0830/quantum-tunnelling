function fingerprint = spectrum_solver_fingerprint(cfg)
%SPECTRUM_SOLVER_FINGERPRINT Collective-spectrum numerical provenance.

narginchk(1, 1);
cfg = ndelta.config.finalize_configuration(cfg);
fingerprint = struct();
fingerprint.version = 1;
fingerprint.physics = ndelta.config.physics_fingerprint(cfg);
fingerprint.scanSamples = cfg.collective.scanSamples;
fingerprint.collectiveRoot = cfg.tolerances.collectiveRoot;
fingerprint.collectiveResidual = cfg.tolerances.collectiveResidual;
fingerprint.collectiveDuplicate = cfg.tolerances.collectiveDuplicate;
fingerprint.zeroEnergy = cfg.tolerances.zeroEnergy;
fingerprint.rejectUnstableCollective = ...
    cfg.execution.rejectUnstableCollective;
end
