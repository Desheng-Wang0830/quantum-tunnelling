function fingerprint = integration_fingerprint(cfg, options)
%INTEGRATION_FINGERPRINT Stage 8 numerical provenance.

narginchk(2, 2);
cfg = ndelta.config.finalize_configuration(cfg);
effectiveOptions = ndelta.integration.resolve_options(cfg, options);
fingerprint = struct();
fingerprint.version = 2;
fingerprint.spectrumSolver = ...
    ndelta.config.spectrum_solver_fingerprint(cfg);
fingerprint.effectiveOptions = effectiveOptions;
fingerprint.endpointTauSwitchRelative = ...
    cfg.integration.endpointTauSwitchRelative;
fingerprint.cutEvenSubtraction = cfg.integration.cutEvenSubtraction;
fingerprint.g1Coalescence = cfg.tolerances.g1Coalescence;
fingerprint.nearSingularRcond = ...
    cfg.tolerances.nearSingularRcond;
fingerprint.cutBankQuadratureFamily = ...
    'shared_polar_quarter_disk_v1';
end
