function [nodes, weights] = unit_gauss_rule(order)
%UNIT_GAUSS_RULE Gauss-Legendre nodes and weights on the open unit interval.

narginchk(1, 1);
[baseNodes, baseWeights] = ndelta.numerics.gauss_legendre_rule(order);
nodes = 0.5 .* (baseNodes + 1);
weights = 0.5 .* baseWeights;
end
