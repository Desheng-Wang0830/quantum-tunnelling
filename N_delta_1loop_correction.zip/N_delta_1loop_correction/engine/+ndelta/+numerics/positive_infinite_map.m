function [values, jacobian] = positive_infinite_map(t, scale, power)
%POSITIVE_INFINITE_MAP Map t in (0,1) to [0,infinity).

narginchk(3, 3);
if ~isnumeric(t) || isempty(t) || ~isreal(t) || ...
        any(~isfinite(t(:))) || any(t(:) <= 0) || any(t(:) >= 1)
    error('ndelta:numerics:InvalidInfiniteMapNode', ...
        't must contain finite real nodes strictly inside (0,1).');
end
validateattributes(scale, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'scale');
validateattributes(power, {'numeric'}, ...
    {'real', 'finite', 'positive', 'scalar'}, mfilename, 'power');
ratio = t ./ (1 - t);
values = scale .* ratio.^power;
jacobian = scale .* power .* t.^(power - 1) ./ ...
    (1 - t).^(power + 1);
end
