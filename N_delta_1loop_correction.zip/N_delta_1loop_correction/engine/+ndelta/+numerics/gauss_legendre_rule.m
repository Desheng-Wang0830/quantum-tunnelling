function [nodes, weights] = gauss_legendre_rule(order)
%GAUSS_LEGENDRE_RULE Deterministic Gauss-Legendre rule on [-1,1].

narginchk(1, 1);
if ~isnumeric(order) || ~isscalar(order) || ~isreal(order) || ...
        ~isfinite(order) || order ~= fix(order) || order < 2
    error('ndelta:numerics:InvalidGaussOrder', ...
        'order must be an integer greater than or equal to 2.');
end

persistent cachedNodesByOrder cachedWeightsByOrder
if isempty(cachedNodesByOrder)
    cachedNodesByOrder = cell(1, 0);
    cachedWeightsByOrder = cell(1, 0);
end
if order <= numel(cachedNodesByOrder) && ...
        ~isempty(cachedNodesByOrder{order})
    nodes = cachedNodesByOrder{order};
    weights = cachedWeightsByOrder{order};
    return;
end

indices = (1:(order - 1)).';
offDiagonal = indices ./ sqrt(4 .* indices.^2 - 1);
jacobi = diag(offDiagonal, 1) + diag(offDiagonal, -1);
[vectors, eigenvalues] = eig(jacobi);
[nodes, permutation] = sort(diag(eigenvalues));
vectors = vectors(:, permutation);
weights = 2 .* (vectors(1, :).').^2;

cachedNodesByOrder{order} = nodes;
cachedWeightsByOrder{order} = weights;
end
