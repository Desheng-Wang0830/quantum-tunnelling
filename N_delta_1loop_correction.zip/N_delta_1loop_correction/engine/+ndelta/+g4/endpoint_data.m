function result = endpoint_data(qPerp, channelInput, cfg, context)
%ENDPOINT_DATA G4 has an integrable square-root endpoint and zero arc.

narginchk(4, 4);
channel = ndelta.g1.normalise_channel(channelInput);
radialBranch = sqrt(qPerp.^2 + cfg.model.mphi.^2 ...
    - 1i .* cfg.sheet.epsilon);
q0Branch = cfg.referenceEnergy - radialBranch;
roots = ndelta.sheet.physical_roots(q0Branch, qPerp, ...
    cfg.referenceEnergy, cfg.model, cfg.sheet.epsilon);
result = struct();
result.term = 'G4';
result.channel = channel;
result.qPerp = qPerp;
result.radialBranch = radialBranch;
result.q0Branch = q0Branch;
result.omegaBranch = roots.omega;
result.ABranch = roots.omega.^2 - cfg.derived.P.^2;
result.backgroundContraction = complex(0);
result.vertexReducedResidue = complex(0);
result.keyholeContribution = complex(0);
result.keyholeQ0WindingFraction = 0;
result.ordinaryHalfIndentationUsed = false;
result.evenSubtractionEnabled = false;
result.endpointIsZero = true;
result.localBehaviour = 'O((q0-qb)^(-1/2)); integrable; arc vanishes';
result.contextChecked = isstruct(context);
end
