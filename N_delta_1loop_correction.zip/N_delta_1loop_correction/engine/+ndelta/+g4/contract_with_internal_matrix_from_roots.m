function [value, diagnostics] = contract_with_internal_matrix_from_roots( ...
        omega, kappaI, channelInput, internalMatrix, cfg, geometry, context)
%CONTRACT_WITH_INTERNAL_MATRIX_FROM_ROOTS Optimised O(N^4) G4 sum.

narginchk(7, 7);
channel = ndelta.g1.normalise_channel(channelInput);
context = ndelta.stage11.validate_context(context, cfg, geometry);
if ~isnumeric(internalMatrix) || ...
        ~isequal(size(internalMatrix), [geometry.N, geometry.N]) || ...
        any(~isfinite(real(internalMatrix(:)))) || ...
        any(~isfinite(imag(internalMatrix(:))))
    error('ndelta:g4:InvalidInternalMatrix', ...
        'internalMatrix must be one finite geometry.N square matrix.');
end
if channel == 'T'
    outgoing = context.transmissionOutgoingDressed;
else
    outgoing = context.reflectionOutgoingDressed;
end
incoming = context.incomingDressed;
active = context.activeIndices(:).';
value = complex(0);
termCount = 0;
cacheKeys = zeros(0, 3);
cacheValues = complex(zeros(0, 1));
distanceCount = geometry.numberOfUniqueDirectedDistances;
denseCache = double(distanceCount).^3 <= 1e6;
if denseCache
    cacheLookup = zeros(double(distanceCount).^3, 1);
    cacheMap = [];
else
    cacheLookup = [];
    cacheMap = containers.Map( ...
        'KeyType', 'uint64', 'ValueType', 'double');
end
for b = active
    for c = active
        for d = active
            for e = active
                x = geometry.directedDistances(c, d);
                y = geometry.directedDistances(b, c);
                z = geometry.directedDistances(d, e);
                xIndex = geometry.directedDistanceIndex(c, d);
                yIndex = geometry.directedDistanceIndex(b, c);
                zIndex = geometry.directedDistanceIndex(d, e);
                cacheKey = triple_cache_key( ...
                    xIndex, yIndex, zIndex, distanceCount);
                if denseCache
                    cacheIndex = cacheLookup(double(cacheKey));
                elseif isKey(cacheMap, cacheKey)
                    cacheIndex = cacheMap(cacheKey);
                else
                    cacheIndex = 0;
                end
                if cacheIndex == 0
                    kernel = ndelta.longitudinal.g4_kernel_from_roots( ...
                        x, y, z, omega, kappaI, context.P, ...
                        cfg.tolerances.g1Coalescence);
                    cacheKeys(end + 1, :) = [x, y, z]; %#ok<AGROW>
                    cacheValues(end + 1, 1) = kernel; %#ok<AGROW>
                    cacheIndex = numel(cacheValues);
                    if denseCache
                        cacheLookup(double(cacheKey)) = cacheIndex;
                    else
                        cacheMap(cacheKey) = cacheIndex;
                    end
                else
                    kernel = cacheValues(cacheIndex);
                end
                value = value + outgoing(e) .* internalMatrix(d, c) ...
                    .* incoming(b) .* kernel;
                termCount = termCount + 1;
            end
        end
    end
end
value = complex(real(value), imag(value));
diagnostics = struct();
diagnostics.term = 'G4';
diagnostics.value = value;
diagnostics.rawConvention = true;
diagnostics.vertexReducedValue = -value;
diagnostics.channel = channel;
diagnostics.omega = omega;
diagnostics.kappaI = kappaI;
diagnostics.P = context.P;
diagnostics.tauI = internalMatrix;
diagnostics.tauP = context.tauP;
diagnostics.cacheKeys = cacheKeys;
diagnostics.cacheValues = cacheValues;
diagnostics.numberOfKernelEvaluations = size(cacheKeys, 1);
diagnostics.numberOfActiveTerms = termCount;
diagnostics.indexContract = ...
    'R_chi(e)*tauI(d,c)*L(b)*I4(D_cd,D_bc,D_de)';
diagnostics.contractionComplexity = 'O(N_active^4)';
diagnostics.cacheLookupComplexity = 'O(1)_integer_distance_indices';
diagnostics.cacheUsesOrderedDistanceTriples = true;
diagnostics.twoExternalTauPSegmentsApplied = true;
diagnostics.mixedMinusOrdinaryPolePresent = false;
diagnostics.includesTauI = true;
diagnostics.includesTwoTauP = true;
diagnostics.includesMuSquared = false;
diagnostics.includesLSZ = false;
diagnostics.includesOneOverTwoP = false;
diagnostics.massDimension = -4;
end

function key = triple_cache_key(first, second, third, distanceCount)
distanceCount = uint64(distanceCount);
key = (uint64(first - 1) .* distanceCount + ...
    uint64(second - 1)) .* distanceCount + uint64(third);
end
