function stage1 = run_stage1(cfg)
%RUN_STAGE1 Build on-shell kinematics and all directed centre distances.

narginchk(1, 1);

stage1 = struct();
stage1.kinematics = ndelta.model.on_shell_kinematics( ...
    cfg.referenceEnergy, cfg.model.mphi);
stage1.geometry = ndelta.geometry.build_geometry( ...
    cfg.barriers.positions, cfg.tolerances.distanceMerge);
stage1.phases = ndelta.geometry.build_channel_phases( ...
    stage1.geometry.positions, stage1.kinematics.P);
end
