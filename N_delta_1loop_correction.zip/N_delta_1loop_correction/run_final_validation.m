function validation = run_final_validation(outputDirectory)
%RUN_FINAL_VALIDATION Public entry for the thesis frozen-code validation.
%
% The implementation lives under final_validation with a distinct function
% name, so adding that directory cannot shadow or recursively call this
% public wrapper.

solverRoot = fileparts(mfilename('fullpath'));
validationRoot = fullfile(solverRoot, 'final_validation');
engineRoot = fullfile(solverRoot, 'engine');
addpath(solverRoot);
addpath(validationRoot);
addpath(engineRoot);
rehash;

if nargin < 1
    validation = run_final_validation_core();
else
    validation = run_final_validation_core(outputDirectory);
end
end
