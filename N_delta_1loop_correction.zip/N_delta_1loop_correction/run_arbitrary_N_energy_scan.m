function result = run_arbitrary_N_energy_scan(settings)
%RUN_ARBITRARY_N_ENERGY_SCAN Scan one arbitrary-N geometry over E=p^0.
%
%   RESULT = RUN_ARBITRARY_N_ENERGY_SCAN uses arbitrary_N_energy_settings.m.
%   RESULT = RUN_ARBITRARY_N_ENERGY_SCAN(SETTINGS) accepts a validated custom
%   settings structure.  All physical kernels come from the frozen v1.9.6
%   N-delta backend; this driver only builds the geometry, scans the
%   external energy and writes left-incidence source-resolved reports,
%   Rose four-source plots and internal-q^0 singularity figures.  The
%   plotting layer does not repeat any integral.  Paired-mode right
%   incidence is used only for the complete two-by-two S-matrix audit,
%   including exported U_L, U_R and complex V_12 residuals.

narginchk(0, 1);
packageRoot = fileparts(mfilename('fullpath'));
engineRoot = fullfile(packageRoot, 'engine');
addpath(packageRoot, '-begin');
addpath(engineRoot, '-begin');

assert_bundled_function('run_stage0', ...
    fullfile(engineRoot, 'run_stage0.m'));
assert_bundled_function('ndelta.config.release_contract', ...
    fullfile(engineRoot, '+ndelta', '+config', 'release_contract.m'));
assert_bundled_function('ndelta.stage12.evaluate_direction', ...
    fullfile(engineRoot, '+ndelta', '+stage12', 'evaluate_direction.m'));
assert_bundled_function('ndelta.stage12.evaluate_bidirectional', ...
    fullfile(engineRoot, '+ndelta', '+stage12', ...
    'evaluate_bidirectional.m'));
assert_bundled_function('ndelta.stage12.evaluate_order_pair', ...
    fullfile(engineRoot, '+ndelta', '+stage12', ...
    'evaluate_order_pair.m'));

release = ndelta.config.release_contract();
if ~isstruct(release) || ~isscalar(release) || ...
        ~isfield(release, 'releaseVersion') || ...
        ~strcmp(char(release.releaseVersion), '1.9.6')
    if isstruct(release) && isscalar(release) && ...
            isfield(release, 'releaseVersion')
        actualRelease = char(release.releaseVersion);
    else
        actualRelease = '<missing or invalid>';
    end
    error('nqscan:EngineReleaseMismatch', ...
        ['The bundled driver requires engine release 1.9.6, but MATLAB ' ...
         'resolved release %s. Run "clear functions; rehash" from this ' ...
         'package directory and retry.'], actualRelease);
end

if nargin < 1
    settings = arbitrary_N_energy_settings();
else
    settings = nqscan.validate_settings(settings);
end

result = nqscan.execute(settings, packageRoot);
end

function assert_bundled_function(functionName, expectedPath)
resolvedPath = which(functionName);
if ~same_path(resolvedPath, expectedPath)
    error('nqscan:WrongEngineOnPath', ...
        ['%s resolves to %s, not the bundled verified engine %s. Run ' ...
         '"clear functions; rehash" from this package directory and retry.'], ...
        functionName, display_path(resolvedPath), expectedPath);
end
end

function value = display_path(path)
if isempty(path)
    value = '<not found>';
else
    value = path;
end
end

function accepted = same_path(left, right)
if isempty(left) || isempty(right)
    accepted = false;
    return;
end
left = strrep(left, '\', '/');
right = strrep(right, '\', '/');
if ispc
    accepted = strcmpi(left, right);
else
    accepted = strcmp(left, right);
end
end
