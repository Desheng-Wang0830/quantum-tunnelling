function report = run_erman_feature_self_tests()
%RUN_ERMAN_FEATURE_SELF_TESTS Fast tree-only add-on regression tests.

packageRoot = fileparts(mfilename('fullpath'));
addpath(packageRoot, '-begin');
addpath(fullfile(packageRoot, 'engine'), '-begin');

balanced = test_preset('balanced_one_loop', ...
    [-6, -3, 0, 3, 6], 0.5, ...
    [0.437207737, 0.485467263, 1.104274326, 1.500000000], ...
    [0.999999966053643, 0.708487003485144, ...
     0.350933573809126, 0.996335516448000]);
strong = test_preset('strong_tree_demo', ...
    [-5.4, -2.7, 0, 2.7, 5.4], 1.4, ...
    [0.663821789, 0.703290593, 1.309700679], ...
    [0.999999999999903, 0.393017465759922, ...
     0.025038624186231]);

report = struct();
report.addonVersion = '1.0.0';
report.balanced = balanced;
report.strong = strong;
report.allPassed = balanced.passed && strong.passed;
if ~report.allPassed
    error('nqscanErman:SelfTestFailed', ...
        'At least one Erman-feature add-on regression test failed.');
end
fprintf('Erman-feature add-on self-tests: PASS (2/2 presets).\n');
end

function outcome = test_preset(preset, expectedPositions, ...
        expectedStrength, momenta, expectedT)
settings = erman_feature_settings(preset);
profile = nqscan.build_profile(settings);
cfg = nqscan.build_configuration(settings, profile);
geometry = ndelta.geometry.build_geometry( ...
    profile.positions, cfg.tolerances.distanceMerge);

positionResidual = max(abs(profile.positions - expectedPositions));
strengthResidual = max(abs(profile.strengths - expectedStrength));
symmetryResidual = max(abs(profile.positions + fliplr(profile.positions)));
T = NaN(size(momenta));
closure = NaN(size(momenta));
for index = 1:numel(momenta)
    tree = ndelta.tree.tree_amplitudes_N( ...
        momenta(index), geometry, profile.strengths, ...
        cfg.tolerances.nearSingularRcond);
    T(index) = tree.T0;
    closure(index) = tree.probabilityClosureResidual;
end
transmissionResidual = max(abs(T - expectedT));
maximumClosure = max(abs(closure));

outcome = struct();
outcome.preset = preset;
outcome.positionResidual = positionResidual;
outcome.strengthResidual = strengthResidual;
outcome.symmetryResidual = symmetryResidual;
outcome.transmissionResidual = transmissionResidual;
outcome.maximumClosureResidual = maximumClosure;
outcome.passed = positionResidual < 1e-13 && ...
    strengthResidual < 1e-13 && symmetryResidual < 1e-13 && ...
    transmissionResidual < 2e-10 && maximumClosure < 5e-12;
end
