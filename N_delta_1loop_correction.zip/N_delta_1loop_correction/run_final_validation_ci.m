function validation = run_final_validation_ci(outputDirectory)
%RUN_FINAL_VALIDATION_CI Public CI entry; reports before throwing.

solverRoot = fileparts(mfilename('fullpath'));
validationRoot = fullfile(solverRoot, 'final_validation');
engineRoot = fullfile(solverRoot, 'engine');
addpath(solverRoot);
addpath(validationRoot);
addpath(engineRoot);
rehash;

if nargin < 1
    validation = run_final_validation_ci_core();
else
    validation = run_final_validation_ci_core(outputDirectory);
end
end
