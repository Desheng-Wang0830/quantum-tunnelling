function settings = erman_feature_settings(preset)
%ERMAN_FEATURE_SETTINGS Erman-like symmetric N=5 settings for v1.3.0.
%
%   SETTINGS = ERMAN_FEATURE_SETTINGS() returns the conservative
%   'balanced_one_loop' preset.  It is designed to show multi-centre
%   transmission peaks and dips inside the closed elastic window without
%   introducing attractive collective bound modes.
%
%   SETTINGS = ERMAN_FEATURE_SETTINGS('strong_tree_demo') returns a
%   stronger repulsive profile with four especially clear transmission
%   peaks and four dips.  It is primarily a tree-level demonstration;
%   any one-loop use must be accompanied by an order/convergence audit.
%
%   Both presets use the existing public 'explicit' geometry mode.  The
%   frozen ndelta v1.9.6 engine and the v1.3.0 driver are not modified.

narginchk(0, 1);
if nargin < 1
    preset = 'balanced_one_loop';
end
preset = canonical_preset(preset);

settings = arbitrary_N_energy_settings();
settings.geometry.mode = 'explicit';

switch preset
    case 'balanced_one_loop'
        N = 5;
        spacing = 3.0;
        perCentreStrength = 0.50;
        loopMomentumValues = [ ...
            0.200000000, ...              % low-P envelope anchor
            0.437207737, 0.485467263, ... % peak 1 / dip 1
            0.566566112, 0.642048961, ... % peak 2 / dip 2
            0.732190522, 0.825790524, ... % peak 3 / dip 3
            0.911172763, 1.104274326, ... % peak 4 / main dip
            1.250000000, ...              % high-P envelope anchor
            1.326534669, 1.410552569, ... % peak 5 / dip 5
            1.500000000];                 % transparent high-P anchor
        treeMomentumRange = [0.02, 4.0];
        treeSamples = 16001;
        outputName = 'results_erman_balanced_N5';
        description = [ ...
            'Balanced repulsive one-loop pilot: visible interference ' ...
            'inside the elastic window with moderate g_a.'];

    case 'strong_tree_demo'
        N = 5;
        spacing = 2.70;
        perCentreStrength = 1.40;
        loopMomentumValues = [ ...
            0.300000000, ...
            0.653821789, 0.663821789, 0.673821789, ...
            0.703290593, 0.769689063, 0.836546350, ...
            0.915419516, 0.999706946, 1.071677914, ...
            1.299700679, 1.309700679, 1.319700679, ...
            1.450000000];
        treeMomentumRange = [0.02, 4.0];
        treeSamples = 16001;
        outputName = 'results_erman_strong_tree_N5';
        description = [ ...
            'Strong repulsive tree demonstration: four pronounced ' ...
            'near-unity peaks and deep stop-band-like dips.'];

    otherwise
        error('nqscanErman:UnknownPreset', ...
            'Unsupported Erman-feature preset %s.', preset);
end

centreIndices = (1:N) - (N + 1) ./ 2;
settings.geometry.positions = spacing .* centreIndices;
settings.geometry.strengths = ...
    perCentreStrength .* ones(1, N);

% The expensive one-loop scan is deliberately sparse and is specified in
% P, where the interference structure is simplest.  The production driver
% still receives its required external-energy values E=sqrt(P^2+mphi^2).
settings.scan.energyValues = sqrt( ...
    loopMomentumValues.^2 + settings.model.mphi.^2);
settings.singularity.snapshotEnergyIndices = [];
settings.output.directoryName = outputName;

% Extra fields are metadata for the two public add-on wrappers.  The
% original v1.3.0 validator intentionally permits extra metadata fields.
settings.erman = struct();
settings.erman.addonVersion = '1.0.0';
settings.erman.preset = preset;
settings.erman.description = description;
settings.erman.N = N;
settings.erman.spacing = spacing;
settings.erman.perCentreStrength = perCentreStrength;
settings.erman.loopMomentumValues = loopMomentumValues;
settings.erman.treeMomentumRange = treeMomentumRange;
settings.erman.treeSamples = treeSamples;
settings.erman.oneLoopPointsAreSparse = true;
settings.erman.treeUsesExactGammaTau = true;
settings.erman.potentialType = 'repulsive_equal_per_centre';

settings = nqscan.validate_settings(settings);
end

function value = canonical_preset(value)
if isstring(value) && isscalar(value)
    value = char(value);
end
if ~ischar(value) || isempty(strtrim(value))
    error('nqscanErman:InvalidPreset', ...
        'preset must be nonempty text.');
end
value = lower(strtrim(value));
aliases = struct();
aliases.balanced = 'balanced_one_loop';
aliases.strong = 'strong_tree_demo';
if isfield(aliases, value)
    value = aliases.(value);
end
end
